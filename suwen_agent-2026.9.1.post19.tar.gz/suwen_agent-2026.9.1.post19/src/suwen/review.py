from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime, timedelta

from .repository import Repository

REVIEW_RULE_DEFAULTS: dict[str, bool] = {
    "evidence_gap": True,
    "run_reliability": True,
    "unresolved_case": True,
    "reply_persistence_gap": True,
    "evidence_boundary": True,
    "action_uncertainty": True,
    "evidence_provider_candidate": True,
    "runtime_reliability_candidate": True,
    "source_coverage_candidate": True,
}


def normalize_review_config(value: object, *, strict: bool = False) -> dict[str, object]:
    """Return the exact deterministic Review behavior represented by one version."""

    if not isinstance(value, dict):
        if strict:
            raise ValueError("Review Engine config must be an object")
        value = {}
    stored_fields = {
        "input",
        "output",
        "uses_raw_message_content",
        "persists_raw_message_content",
        "model_calls",
        "external_calls",
        "automatic_agent_mutation",
        "rules",
    }
    if strict:
        unknown = sorted(set(value) - {"rules"})
        if unknown:
            raise ValueError(f"unknown Review Engine config fields: {', '.join(unknown)}")
    else:
        value = {key: item for key, item in value.items() if key in stored_fields}
    supplied_rules = value.get("rules", {})
    if not isinstance(supplied_rules, dict):
        if strict:
            raise ValueError("Review Engine rules must be an object")
        supplied_rules = {}
    if strict:
        unknown_rules = sorted(set(supplied_rules) - set(REVIEW_RULE_DEFAULTS))
        if unknown_rules:
            raise ValueError(f"unknown Review Engine rules: {', '.join(unknown_rules)}")
        invalid_rules = sorted(
            key for key, enabled in supplied_rules.items() if not isinstance(enabled, bool)
        )
        if invalid_rules:
            raise ValueError(f"Review Engine rules must be boolean: {', '.join(invalid_rules)}")
    rules = {
        key: supplied_rules.get(key, default)
        if isinstance(supplied_rules.get(key, default), bool)
        else default
        for key, default in REVIEW_RULE_DEFAULTS.items()
    }
    return {
        "input": "immutable case trace identifiers and structured states",
        "output": "bounded-review.v1",
        "uses_raw_message_content": True,
        "persists_raw_message_content": False,
        "model_calls": 0,
        "automatic_agent_mutation": False,
        "rules": rules,
    }


class ReviewEngine:
    def __init__(self, repository: Repository):
        self.repository = repository

    def review_case(self, case_id: str) -> dict:
        case = self.repository.get_case(case_id)
        messages = self.repository.list_messages(case_id)
        if not any(item["role"] == "user" for item in messages):
            raise ValueError("an empty draft is not a reviewable case")
        runs = self.repository.list_runs(case_id)
        if not runs:
            raise ValueError("a reviewable case requires at least one Run")
        tool_calls = self.repository.list_tool_calls(case_id)
        evidence = self.repository.list_evidence(case_id)
        snapshots = self.repository.list_snapshots(case_id)
        feedback = self.repository.list_feedback(case_id)
        actions = self.repository.list_actions(case_id=case_id)
        review_engine_version = self.repository.active_review_engine_version()
        review_config = normalize_review_config(json.loads(review_engine_version.get("config_json") or "{}"))
        rules = review_config["rules"]
        input_snapshot_hash = self._input_snapshot_hash(
            case,
            messages,
            runs,
            tool_calls,
            evidence,
            snapshots,
            feedback,
            actions,
        )
        snapshot_version = input_snapshot_hash
        agent_version_scope = sorted({item["agent_version_id"] for item in runs})
        model_profile_scope = sorted({item["model_profile_version_id"] for item in runs})
        pack_digest_scope = sorted(
            {digest for item in runs for digest in json.loads(item.get("pack_digests_json") or "[]")}
        )
        run_refs = [item["id"] for item in runs]
        reply_refs = [item["id"] for item in messages if item["role"] == "assistant"]
        quality_findings = []
        if not evidence and rules["evidence_gap"]:
            quality_findings.append(
                {
                    "kind": "evidence_gap",
                    "severity": "info",
                    "summary": "本案没有工具证据，结论只能基于会话内容。",
                }
            )
        failed_runs = [item for item in runs if item["status"] != "completed"]
        if failed_runs and rules["run_reliability"]:
            quality_findings.append(
                {
                    "kind": "run_reliability",
                    "severity": "warning",
                    "summary": f"存在 {len(failed_runs)} 次未完整完成的运行。",
                }
            )
        if case["disposition"] in {"unknown", "investigating", "unresolved"} and rules["unresolved_case"]:
            quality_findings.append(
                {
                    "kind": "unresolved_case",
                    "severity": "info",
                    "summary": "案件仍未形成已解决处置；关闭状态不能替代解决状态。",
                }
            )
        missing_replies = max(
            0,
            len([item for item in runs if item["status"] != "running"])
            - len([item for item in messages if item["role"] == "assistant"]),
        )
        if missing_replies and rules["reply_persistence_gap"]:
            quality_findings.append(
                {
                    "kind": "reply_persistence_gap",
                    "severity": "warning",
                    "summary": f"有 {missing_replies} 次已结束运行缺少可关联答复。",
                }
            )

        safety_findings = []
        boundary_states = {
            item["state"]
            for item in evidence
            if item["state"] in {"query_failed", "truncated", "conflict", "not_observable"}
        }
        if boundary_states and rules["evidence_boundary"]:
            safety_findings.append(
                {
                    "kind": "evidence_boundary",
                    "severity": "info",
                    "states": sorted(boundary_states),
                    "summary": "存在失败、截断、冲突或不可观测证据，结论不得越过这些边界。",
                }
            )
        uncertain_actions = [item for item in actions if item["status"] in {"executing", "outcome_unknown"}]
        if uncertain_actions and rules["action_uncertainty"]:
            safety_findings.append(
                {
                    "kind": "controlled_action_uncertainty",
                    "severity": "warning",
                    "action_refs": [item["id"] for item in uncertain_actions],
                    "summary": "存在结果未知的受控动作；不得自动重试或推断成功。",
                }
            )

        capability_gaps = []
        if not evidence and rules["evidence_provider_candidate"]:
            capability_gaps.append(
                {
                    "kind": "evidence_provider_candidate",
                    "candidate": True,
                    "summary": "需要评估是否缺少可复用的只读证据入口；该候选须跨案验证。",
                }
            )
        if failed_runs and rules["runtime_reliability_candidate"]:
            capability_gaps.append(
                {
                    "kind": "runtime_reliability_candidate",
                    "candidate": True,
                    "summary": "运行失败可能反映模型或工具可靠性缺口，须结合其他案件验证。",
                }
            )
        if (
            any(item["state"] in {"zero_matches", "truncated"} for item in evidence)
            and rules["source_coverage_candidate"]
        ):
            capability_gaps.append(
                {
                    "kind": "source_coverage_candidate",
                    "candidate": True,
                    "summary": "证据覆盖可能不足；零命中与截断不得直接解释为业务事实。",
                }
            )

        observed = [item for item in evidence if item["state"] == "observed"]
        resolved_feedback = [item for item in feedback if item["value"] == "resolved"]
        if resolved_feedback:
            conclusion_state = "explicitly_resolved"
        elif case["disposition"] in {"escalated", "unresolved"}:
            conclusion_state = case["disposition"]
        elif observed:
            conclusion_state = "bounded_assessment"
        else:
            conclusion_state = "insufficient_evidence"
        conclusion = {
            "state": conclusion_state,
            "case_lifecycle": case["lifecycle"],
            "case_disposition": case["disposition"],
            "basis": {
                "observed_evidence": len(observed),
                "feedback": len(feedback),
                "completed_runs": len([item for item in runs if item["status"] == "completed"]),
            },
        }
        summary = (
            f"案件包含 {len(messages)} 条消息、{len(runs)} 次运行、"
            f"{len(tool_calls)} 次工具调用、{len(evidence)} 条证据和 {len(feedback)} 条反馈。"
            "该复盘仅形成待人工审核的研究记录，不会修改生产能力。"
        )
        limitations = [
            {
                "kind": "review_projection",
                "summary": "复盘输出只保留结构化状态与不可变引用，不复制会话正文或私有呈现。",
            },
            {
                "kind": "engine_boundary",
                "review_engine_version_id": review_engine_version["id"],
                "review_engine_digest": review_engine_version["digest"],
                "enabled_rules": sorted(key for key, enabled in rules.items() if enabled),
                "summary": "当前复盘按已启用的确定性有界规则执行，不调用模型、外部系统或修改 Agent。",
            },
        ]
        if boundary_states:
            limitations.append(
                {
                    "kind": "evidence_boundary",
                    "states": sorted(boundary_states),
                    "summary": "失败、截断、冲突和不可观测状态限制结论强度。",
                }
            )
        return self.repository.create_review(
            case_id,
            snapshot_version,
            summary,
            conclusion,
            quality_findings,
            safety_findings,
            capability_gaps,
            [item["id"] for item in evidence],
            [item["id"] for item in feedback],
            "bounded: evidence and explicit feedback only",
            input_snapshot_hash=input_snapshot_hash,
            agent_version_scope=agent_version_scope,
            model_profile_scope=model_profile_scope,
            pack_digest_scope=pack_digest_scope,
            run_refs=run_refs,
            reply_refs=reply_refs,
            limitations=limitations,
            review_engine_version_id=review_engine_version["id"],
        )

    @classmethod
    def _input_snapshot_hash(
        cls,
        case: dict,
        messages: list[dict],
        runs: list[dict],
        tool_calls: list[dict],
        evidence: list[dict],
        snapshots: list[dict],
        feedback: list[dict],
        actions: list[dict],
    ) -> str:
        """Hash every review input without persisting raw review input in provenance."""

        source = {
            "case": {
                "id": case["id"],
                "agent_id": case["agent_id"],
                "lifecycle": case["lifecycle"],
                "disposition": case["disposition"],
                "updated_at": case["updated_at"],
            },
            "messages": [
                {
                    "id": item["id"],
                    "role": item["role"],
                    "seq": item["seq"],
                    "content_sha256": cls._value_hash(item["content"]),
                    "metadata_sha256": cls._value_hash(item.get("metadata_json") or "{}"),
                }
                for item in messages
            ],
            "runs": [
                {
                    "id": item["id"],
                    "agent_version_id": item["agent_version_id"],
                    "model_profile_version_id": item["model_profile_version_id"],
                    "provider_version_id": item["provider_version_id"],
                    "status": item["status"],
                    "stop_reason": item["stop_reason"],
                    "prompt_bundle_digest": item["prompt_bundle_digest"],
                    "pack_digests_json": item["pack_digests_json"],
                    "tool_schema_digest": item["tool_schema_digest"],
                }
                for item in runs
            ],
            "tool_calls": [
                {
                    "id": item["id"],
                    "run_id": item["run_id"],
                    "tool_name": item["tool_name"],
                    "risk": item["risk"],
                    "status": item["status"],
                    "result_sha256": cls._value_hash(item.get("result_json") or ""),
                }
                for item in tool_calls
            ],
            "evidence": [
                {
                    "id": item["id"],
                    "run_id": item["run_id"],
                    "state": item["state"],
                    "coverage_state": item["coverage_state"],
                    "truncation_state": item["truncation_state"],
                    "source_role": item["source_role"],
                    "projection_sha256": cls._value_hash(
                        {
                            "summary": item["summary"],
                            "data_json": item["data_json"],
                            "limitations_json": item["limitations_json"],
                            "safe_statements_json": item["safe_statements_json"],
                        }
                    ),
                }
                for item in evidence
            ],
            "snapshots": [
                {
                    "id": item["id"],
                    "through_seq": item["through_seq"],
                    "summary_sha256": cls._value_hash(item["summary"]),
                }
                for item in snapshots
            ],
            "feedback": [
                {
                    "id": item["id"],
                    "kind": item["kind"],
                    "value": item["value"],
                    "note_sha256": cls._value_hash(item["note"]),
                    "actor_sha256": cls._value_hash(item["actor_ref"]),
                }
                for item in feedback
            ],
            "actions": [
                {
                    "id": item["id"],
                    "action_type": item["action_type"],
                    "status": item["status"],
                    "finished_at": item["finished_at"],
                }
                for item in actions
            ],
        }
        encoded = json.dumps(
            source,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
        return hashlib.sha256(encoded).hexdigest()

    @staticmethod
    def _value_hash(value: object) -> str:
        if not isinstance(value, str):
            value = json.dumps(
                value,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
        return hashlib.sha256(value.encode()).hexdigest()


class LifecycleService:
    def __init__(self, repository: Repository, inactive_days: int):
        self.repository = repository
        self.inactive_days = inactive_days

    def close_inactive(self, now: datetime | None = None) -> int:
        now = now or datetime.now(UTC)
        cutoff = now - timedelta(days=self.inactive_days)
        closed = 0
        for case in self.repository.list_inactive_candidates(cutoff):
            if self.repository.close_case(
                case["id"], "inactive", now=now, expected_last_external=case["last_external_at"]
            ):
                closed += 1
        return closed
