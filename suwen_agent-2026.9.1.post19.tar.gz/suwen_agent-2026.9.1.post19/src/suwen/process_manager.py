from __future__ import annotations

import os
import re
import sys
from collections.abc import Mapping
from pathlib import Path
from typing import Any

_MANAGERS = {"none", "launchd", "systemd"}
_LABEL = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{2,127}$")
_SYSTEMD_INVOCATION_ID = re.compile(r"^[0-9A-Fa-f]{32}$")


def validate_process_manager(manager: str, label: str) -> tuple[str, str]:
    normalized_manager = manager.strip().lower()
    normalized_label = label.strip()
    if normalized_manager not in _MANAGERS:
        raise ValueError("app.process_manager must be none, launchd, or systemd")
    if normalized_manager == "none":
        if normalized_label:
            raise ValueError("app.process_manager_label requires a persistent process manager")
        return normalized_manager, ""
    if not _LABEL.fullmatch(normalized_label):
        raise ValueError("app.process_manager_label must be a stable service label")
    if normalized_manager == "systemd" and not normalized_label.endswith(".service"):
        raise ValueError("systemd process manager label must end with .service")
    return normalized_manager, normalized_label


def observe_process_manager(
    manager: str,
    label: str,
    *,
    environment: Mapping[str, str] | None = None,
    platform_name: str | None = None,
    parent_pid: int | None = None,
    cgroup_text: str | None = None,
) -> dict[str, Any]:
    """Fail closed unless the declared manager leaves matching process evidence."""

    manager, label = validate_process_manager(manager, label)
    environment = os.environ if environment is None else environment
    platform_name = sys.platform if platform_name is None else platform_name
    parent_pid = os.getppid() if parent_pid is None else parent_pid
    if manager == "none":
        return {
            "status": "not_observed",
            "manager": None,
            "label": None,
            "platform": platform_name,
            "parent_is_init": parent_pid == 1,
            "service_context_matches": False,
            "reason": "persistent_manager_not_declared",
        }

    if manager == "launchd":
        platform_matches = platform_name == "darwin"
        service_context_matches = label in {
            environment.get("XPC_SERVICE_NAME", ""),
            environment.get("LAUNCH_JOBKEY_LABEL", ""),
        }
        context_name = "launchd_service_context"
    else:
        platform_matches = platform_name.startswith("linux")
        if cgroup_text is None and platform_name == sys.platform:
            try:
                cgroup_text = Path("/proc/self/cgroup").read_text(encoding="utf-8")
            except OSError:
                cgroup_text = ""
        invocation_observed = bool(
            _SYSTEMD_INVOCATION_ID.fullmatch(environment.get("INVOCATION_ID", ""))
        )
        cgroup_observed = any(
            item.endswith(f"/{label}") or f"/{label}/" in item
            for item in (cgroup_text or "").splitlines()
        )
        service_context_matches = invocation_observed and cgroup_observed
        context_name = "systemd_service_context"
    parent_is_init = parent_pid == 1
    observed = platform_matches and parent_is_init and service_context_matches
    failed = []
    if not platform_matches:
        failed.append("platform_mismatch")
    if not parent_is_init:
        failed.append("parent_is_not_init")
    if not service_context_matches:
        failed.append(f"{context_name}_missing")
    return {
        "status": "observed" if observed else "declared_not_observed",
        "manager": manager,
        "label": label,
        "platform": platform_name,
        "parent_is_init": parent_is_init,
        "service_context_matches": service_context_matches,
        "reason": None if observed else ",".join(failed),
    }
