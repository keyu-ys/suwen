from __future__ import annotations

import hashlib
import tomllib
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any

from .tools import ToolRegistry
from .types import EvidenceEnvelope, EvidenceState, ToolDefinition, ToolRisk

MAX_REFERENCE_CHARS = 100_000
REFERENCE_TOOL_NAMES = frozenset(
    {"list_skill_references", "search_skill_references", "read_skill_reference"}
)
SKILL_VIEW_TOOL_NAME = "read_skill"
SKILL_RUNTIME_TOOL_NAMES = frozenset({*REFERENCE_TOOL_NAMES, SKILL_VIEW_TOOL_NAME})


@dataclass(frozen=True)
class SkillReference:
    id: str
    title: str
    description: str
    relative_path: str
    metadata: Mapping[str, Any]
    # Native declarative domain packages deliver an already-validated content
    # snapshot.  Historical Pack references remain path-backed.
    content: str | None = None
    content_digest: str = ""


@dataclass(frozen=True)
class Skill:
    id: str
    version: str
    name: str
    description: str
    instructions: str
    fallback: bool
    path: Path
    references: tuple[SkillReference, ...] = ()
    applicability: str = ""
    source_revision: str = ""
    content_digest: str = ""


class SkillRegistry:
    def __init__(self, skills: list[Skill]):
        self._skills: dict[str, Skill] = {}
        self._skills_by_name: dict[str, Skill] = {}
        for skill in skills:
            existing = self._skills_by_name.get(skill.name)
            if existing is not None and existing.id != skill.id:
                raise ValueError("duplicate Skill name")
            # A process-level Pack catalog can contain several immutable versions of
            # one Skill. Runtime resolution passes only the selected Pack version;
            # catalog-level lookup retains the latest loaded version as before.
            self._skills[skill.id] = skill
            self._skills_by_name[skill.name] = skill

    @classmethod
    def load(cls, root: Path) -> SkillRegistry:
        skills: list[Skill] = []
        if not root.exists():
            return cls([])
        for manifest_path in sorted(root.glob("*/skill.toml")):
            with manifest_path.open("rb") as handle:
                manifest = tomllib.load(handle)
            skill_root = manifest_path.parent.resolve()
            instructions_path = _safe_skill_file(
                skill_root,
                manifest.get("instruction_file", "SKILL.md"),
                "Skill instructions",
            )
            references = _load_references(skill_root, manifest.get("references", []))
            instructions = instructions_path.read_text(encoding="utf-8")
            skills.append(
                Skill(
                    id=manifest["id"],
                    version=manifest["version"],
                    name=manifest["name"],
                    description=manifest["description"],
                    instructions=instructions,
                    fallback=bool(manifest.get("fallback", False)),
                    path=skill_root,
                    references=references,
                    applicability=str(manifest.get("applicability", "")),
                    source_revision=str(manifest.get("source_revision", "")),
                    content_digest=hashlib.sha256(instructions.encode()).hexdigest(),
                )
            )
        if len({skill.id for skill in skills}) != len(skills):
            raise ValueError("duplicate Skill id")
        return cls(skills)

    def list(self) -> list[Skill]:
        return list(self._skills.values())

    def get(self, skill_id: str) -> Skill:
        try:
            return self._skills[skill_id]
        except KeyError as exc:
            raise KeyError(f"unknown Skill: {skill_id}") from exc

    def get_by_name(self, skill_name: str) -> Skill:
        try:
            return self._skills_by_name[skill_name]
        except KeyError as exc:
            raise KeyError(f"unknown Skill name: {skill_name}") from exc

    def list_references(self, skill_id: str) -> list[SkillReference]:
        return list(self.get(skill_id).references)

    def read_reference(self, skill_id: str, reference_id: str) -> str:
        skill = self.get(skill_id)
        reference = next((item for item in skill.references if item.id == reference_id), None)
        if reference is None:
            raise KeyError(f"unknown Skill reference: {skill_id}/{reference_id}")
        if reference.content is not None:
            content = reference.content
        else:
            target = _safe_skill_file(skill.path, reference.relative_path, "Skill reference")
            content = target.read_text(encoding="utf-8")
        if len(content) > MAX_REFERENCE_CHARS:
            raise ValueError(f"Skill reference exceeds {MAX_REFERENCE_CHARS} characters")
        return content

    def search_references(
        self,
        query: str,
        *,
        skill_id: str | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        """Search only references frozen into the current Agent composition."""

        normalized_query = " ".join(query.casefold().split())
        selected_skills = [self.get(skill_id)] if skill_id is not None else self.list()
        matches: list[dict[str, Any]] = []
        skipped_references = 0
        for skill in selected_skills:
            for reference in skill.references:
                try:
                    content = self.read_reference(skill.id, reference.id)
                except ValueError:
                    skipped_references += 1
                    continue
                searchable = "\n".join(
                    (reference.title, reference.description, content)
                ).casefold()
                match_at = searchable.find(normalized_query)
                if match_at < 0:
                    terms = normalized_query.split()
                    if not terms or any(term not in searchable for term in terms):
                        continue
                    content_folded = content.casefold()
                    match_at = next(
                        (content_folded.find(term) for term in terms if term in content_folded),
                        0,
                    )
                else:
                    metadata_chars = len(reference.title) + len(reference.description) + 2
                    match_at = max(0, match_at - metadata_chars)
                excerpt_start = max(0, match_at - 160)
                excerpt_end = min(len(content), excerpt_start + 480)
                excerpt = content[excerpt_start:excerpt_end]
                matches.append(
                    {
                        "skill_id": skill.id,
                        "reference_id": reference.id,
                        "title": reference.title,
                        "description": reference.description,
                        "excerpt": excerpt,
                        "excerpt_offset": excerpt_start,
                    }
                )
        return matches, skipped_references

    def prompt_projection(self, *, include_instructions: bool = False) -> str:
        """Project only the Skill catalog; bodies are loaded through ``read_skill``.

        This keeps domain instructions owned by the selected Pack/capability while leaving
        applicability and Skill choice to the model. References remain separately
        addressable after the Skill body has been read.
        """

        if include_instructions:
            return self._instruction_projection()

        entries: list[str] = []
        for skill in self._skills.values():
            entries.append(
                "<skill>\n"
                f"<name>{skill.name}</name>\n"
                f"<description>{skill.description}</description>\n"
                f"<applicability>{skill.applicability or skill.description}</applicability>\n"
                f"<digest>sha256:{skill.content_digest}</digest>\n"
                "</skill>"
            )
        if not entries:
            return ""
        return (
            "<agent-skills>\n"
            "Skills 是当前 Agent 版本装配的专业指导。这里只提供目录，不包含正文。"
            f"当用户请求与某个 Skill 匹配时，必须先调用 `{SKILL_VIEW_TOOL_NAME}` 读取完整正文，"
            "下一回合再按正文形成领域解释和后续路线。若用户原文已提供可直接复制的精确标识、"
            "时间或其他独立只读锚点，可以在读取 Skill 的同一 Tool wave 并行观察这些锚点；"
            "不要为读取 Skill 单独浪费一个模型回合。多个 Skill 同时接近时，选择适用范围最窄的专业 Skill，"
            "只有没有更具体匹配时才使用 fallback，不要根据目录摘要猜测领域流程。\n\n"
            "# Available Skills\n" + "\n".join(entries) + "\n</agent-skills>"
        )

    def _instruction_projection(self) -> str:
        """Preserve published Agent Versions that predate the Skill viewer Tool."""

        sections: list[str] = []
        for skill in self._skills.values():
            metadata = [
                f"内容摘要: sha256:{skill.content_digest}",
                f"Fallback: {'yes' if skill.fallback else 'no'}",
            ]
            if skill.source_revision:
                metadata.append(f"来源 revision: {skill.source_revision}")
            if skill.applicability:
                metadata.append(f"适用条件: {skill.applicability}")
            if skill.references:
                index = "; ".join(f"{item.title}（{item.description}）" for item in skill.references)
                metadata.append(f"可按需读取的 reference 索引: {index}")
            sections.append(
                f"## Skill: {skill.name}\n{skill.description}\n"
                + "\n".join(metadata)
                + f"\n\n{skill.instructions}"
            )
        return "\n\n".join(sections)

    def register_skill_view_tool(self, registry: ToolRegistry) -> None:
        """Register the host-level, read-only Skill body viewer."""

        if not self._skills:
            return

        def read_skill(arguments: dict[str, Any]) -> EvidenceEnvelope:
            skill_name = str(arguments["skill"])
            try:
                skill = self.get_by_name(skill_name)
            except KeyError:
                return EvidenceEnvelope(
                    state=EvidenceState.NOT_OBSERVABLE,
                    summary="当前智能体版本没有该 Skill，未加载任何指导正文。",
                    data={"skill": skill_name},
                    coverage_state="proven_total",
                    source_ref=f"skill-name:{skill_name}",
                    source_role="capability_status",
                    limitations=("skill_not_delivered",),
                    safe_statements=("未读取当前运行未装配的 Skill",),
                )
            return EvidenceEnvelope(
                state=EvidenceState.OBSERVED,
                summary=f"已加载 Skill {skill.name} 的完整指导正文。",
                data={
                    "skill_id": skill.id,
                    "skill": skill.name,
                    "instructions": skill.instructions,
                    "content_digest": f"sha256:{skill.content_digest}",
                },
                coverage_state="proven_total",
                source_ref=f"skill:{skill.id}",
                source_role="capability_instruction",
                safe_statements=("正文来自当前运行已装配并冻结摘要的 Skill",),
            )

        registry.register(
            ToolDefinition(
                name=SKILL_VIEW_TOOL_NAME,
                description=(
                    "读取当前 Agent 版本已经装配的一个 Skill 完整正文。"
                    "当用户请求与 Skill 目录中的描述匹配时先读取对应 Skill；若用户原文已提供"
                    "可直接复制的精确只读锚点，可以在同一 Tool wave 并行观察，但领域解释与"
                    "后续调查路线必须等待 Skill 正文进入下一回合。"
                    "参数必须使用目录中的精确 Skill 名称。返回的 skill_id 是后续 Skill reference "
                    "工具所需的稳定标识，不要用展示名称代替。"
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "skill": {"type": "string", "minLength": 1, "maxLength": 160},
                    },
                    "required": ["skill"],
                    "additionalProperties": False,
                },
                risk=ToolRisk.READ_ONLY,
                provider_id="runtime-core",
            ),
            read_skill,
        )

    def delivery_manifest(self) -> list[dict[str, Any]]:
        return [
            {
                "id": skill.id,
                "version": skill.version,
                "source_revision": skill.source_revision,
                "content_digest": skill.content_digest,
                "description": skill.description,
                "applicability": skill.applicability,
                "fallback": skill.fallback,
                "references": [
                    {
                        "id": item.id,
                        "title": item.title,
                        "description": item.description,
                        **({"content_digest": item.content_digest} if item.content_digest else {}),
                    }
                    for item in skill.references
                ],
            }
            for skill in self._skills.values()
        ]

    def register_reference_tools(self, registry: ToolRegistry) -> None:
        """Expose selected Skill bodies and references as bounded read-only tools."""

        self.register_skill_view_tool(registry)

        def list_references(arguments: dict[str, Any]) -> EvidenceEnvelope:
            skill_id = str(arguments["skill_id"])
            try:
                references = self.list_references(skill_id)
            except KeyError:
                return EvidenceEnvelope(
                    state=EvidenceState.NOT_OBSERVABLE,
                    summary="当前智能体版本没有该技能，未读取任何参考资料。",
                    data={"skill_id": skill_id, "references": []},
                    coverage_state="proven_total",
                    source_ref=f"skill:{skill_id}",
                    source_role="capability_status",
                    limitations=("skill_not_delivered",),
                    safe_statements=("未读取参考资料正文",),
                )
            return EvidenceEnvelope(
                state=(EvidenceState.OBSERVED if references else EvidenceState.ZERO_MATCHES),
                summary=(
                    f"已列出技能 {skill_id} 的 {len(references)} 份参考资料索引。"
                    if references
                    else f"技能 {skill_id} 没有可读取的参考资料。"
                ),
                data={
                    "skill_id": skill_id,
                    "references": [
                        {
                            "id": item.id,
                            "title": item.title,
                            "description": item.description,
                        }
                        for item in references
                    ],
                },
                coverage_state="proven_total",
                source_ref=f"skill:{skill_id}:references",
                source_role="capability_reference_index",
                safe_statements=("索引只来自当前运行已装配的技能",),
            )

        def read_reference(arguments: dict[str, Any]) -> EvidenceEnvelope:
            skill_id = str(arguments["skill_id"])
            reference_id = str(arguments["reference_id"])
            try:
                content = self.read_reference(skill_id, reference_id)
            except KeyError:
                return EvidenceEnvelope(
                    state=EvidenceState.NOT_OBSERVABLE,
                    summary="当前智能体版本没有该技能或参考资料，未读取文件。",
                    data={"skill_id": skill_id, "reference_id": reference_id},
                    coverage_state="proven_total",
                    source_ref=f"skill:{skill_id}:reference:{reference_id}",
                    source_role="capability_status",
                    limitations=("reference_not_delivered",),
                    safe_statements=("未读取未声明路径",),
                )
            offset = int(arguments.get("offset", 0))
            max_chars = int(arguments.get("max_chars", 12_000))
            chunk = content[offset : offset + max_chars]
            next_offset = offset + len(chunk)
            partial = next_offset < len(content)
            continuation = (
                {
                    "skill_id": skill_id,
                    "reference_id": reference_id,
                    "offset": next_offset,
                    "max_chars": max_chars,
                }
                if partial
                else None
            )
            return EvidenceEnvelope(
                state=(EvidenceState.TRUNCATED if partial else EvidenceState.OBSERVED),
                summary=(
                    f"已读取技能 {skill_id} 的参考资料 {reference_id} 的一个有界片段。"
                    if partial
                    else f"已完整读取技能 {skill_id} 的参考资料 {reference_id}。"
                ),
                data={
                    "skill_id": skill_id,
                    "reference_id": reference_id,
                    "content": chunk,
                    "offset": offset,
                    "returned_chars": len(chunk),
                },
                coverage_state="bounded" if partial else "proven_total",
                truncation_state="partial" if partial else "complete",
                source_ref=f"skill:{skill_id}:reference:{reference_id}",
                source_role="capability_reference",
                limitations=("reference_continuation_required",) if partial else (),
                safe_statements=("内容来自当前运行已装配且摘要固定的能力包",),
                continuation=continuation,
            )

        def search_references(arguments: dict[str, Any]) -> EvidenceEnvelope:
            query = " ".join(str(arguments["query"]).split())
            skill_id_value = arguments.get("skill_id")
            skill_id = str(skill_id_value) if skill_id_value is not None else None
            offset = int(arguments.get("offset", 0))
            limit = int(arguments.get("limit", 10))
            if len(query) < 2:
                return EvidenceEnvelope(
                    state=EvidenceState.INPUT_REJECTED,
                    summary="参考资料搜索词必须至少包含两个非空白字符；未搜索任何正文。",
                    data={"query": query, "matches": []},
                    coverage_state="proven_total",
                    source_ref="skills:references:search",
                    source_role="capability_status",
                    limitations=("reference_search_input_rejected",),
                    safe_statements=("参数拒绝不表示参考资料不存在",),
                )
            try:
                matches, skipped_references = self.search_references(query, skill_id=skill_id)
            except KeyError:
                return EvidenceEnvelope(
                    state=EvidenceState.NOT_OBSERVABLE,
                    summary="当前智能体版本没有该技能，未搜索任何参考资料。",
                    data={"query": query, "skill_id": skill_id, "matches": []},
                    coverage_state="proven_total",
                    source_ref=f"skill:{skill_id}:references",
                    source_role="capability_status",
                    limitations=("skill_not_delivered",),
                    safe_statements=("未搜索当前运行未装配的 Skill",),
                )
            selected = matches[offset : offset + limit]
            next_offset = offset + len(selected)
            partial = next_offset < len(matches)
            incomplete_scope = skipped_references > 0
            continuation = (
                {
                    "query": query,
                    **({"skill_id": skill_id} if skill_id is not None else {}),
                    "offset": next_offset,
                    "limit": limit,
                }
                if partial
                else None
            )
            return EvidenceEnvelope(
                state=(
                    EvidenceState.TRUNCATED
                    if partial or incomplete_scope
                    else EvidenceState.OBSERVED
                    if matches
                    else EvidenceState.ZERO_MATCHES
                ),
                summary=(
                    f"已返回 {len(selected)} 条当前装配参考资料命中；仍有后续结果。"
                    if partial
                    else f"已返回 {len(selected)} 条命中，但有 {skipped_references} 份超限资料未搜索。"
                    if incomplete_scope
                    else f"已在当前装配参考资料中找到 {len(matches)} 条命中。"
                    if matches
                    else "当前装配参考资料中没有找到匹配内容。"
                ),
                data={
                    "query": query,
                    "skill_id": skill_id,
                    "matches": selected,
                    "returned_count": len(selected),
                    "total_matches": len(matches),
                    "offset": offset,
                    "skipped_reference_count": skipped_references,
                },
                coverage_state=(
                    "sample_only" if incomplete_scope else "bounded" if partial else "proven_total"
                ),
                truncation_state="partial" if partial or incomplete_scope else "complete",
                source_ref=(
                    f"skill:{skill_id}:references:search"
                    if skill_id is not None
                    else "skills:references:search"
                ),
                source_role="capability_reference_index",
                limitations=(
                    ("reference_search_continuation_required",)
                    if partial
                    else ("reference_search_scope_incomplete",)
                    if incomplete_scope
                    else ()
                ),
                safe_statements=("只搜索当前运行已装配且摘要固定的 reference",),
                continuation=continuation,
            )

        registry.register(
            ToolDefinition(
                name="list_skill_references",
                description=(
                    "列出当前智能体版本已装配技能的参考资料索引；只返回声明的 ID、标题和说明。"
                    "skill_id 必须逐字使用 read_skill 返回的 skill_id，不能使用 Skill 展示名称。"
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "skill_id": {"type": "string", "minLength": 1, "maxLength": 128},
                    },
                    "required": ["skill_id"],
                    "additionalProperties": False,
                },
                risk=ToolRisk.READ_ONLY,
                provider_id="runtime-core",
            ),
            list_references,
        )
        registry.register(
            ToolDefinition(
                name="search_skill_references",
                description=(
                    "搜索当前 Agent 版本已经装配的 Skill reference；"
                    "只返回 reference ID、说明和有界命中片段，不能搜索工作区路径。"
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "minLength": 2, "maxLength": 200},
                        "skill_id": {"type": "string", "minLength": 1, "maxLength": 128},
                        "offset": {"type": "integer", "minimum": 0, "maximum": 1_000},
                        "limit": {"type": "integer", "minimum": 1, "maximum": 20},
                    },
                    "required": ["query"],
                    "additionalProperties": False,
                },
                risk=ToolRisk.READ_ONLY,
                provider_id="runtime-core",
            ),
            search_references,
        )
        registry.register(
            ToolDefinition(
                name="read_skill_reference",
                description=(
                    "读取当前智能体版本已装配技能中一份已声明的 Markdown 参考资料；"
                    "不能使用路径，也不能跨能力包读取。"
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "skill_id": {"type": "string", "minLength": 1, "maxLength": 128},
                        "reference_id": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 128,
                        },
                        "offset": {"type": "integer", "minimum": 0, "maximum": 100_000},
                        "max_chars": {
                            "type": "integer",
                            "minimum": 1_000,
                            "maximum": 20_000,
                        },
                    },
                    "required": ["skill_id", "reference_id"],
                    "additionalProperties": False,
                },
                risk=ToolRisk.READ_ONLY,
                provider_id="runtime-core",
            ),
            read_reference,
        )


def _load_references(skill_root: Path, raw_references: Any) -> tuple[SkillReference, ...]:
    if not isinstance(raw_references, list):
        raise ValueError("Skill references must be an array of tables")
    references: list[SkillReference] = []
    for raw in raw_references:
        if not isinstance(raw, dict):
            raise ValueError("each Skill reference must be a table")
        reference_id = raw.get("id")
        relative_path = raw.get("path")
        if not isinstance(reference_id, str) or not reference_id.strip():
            raise ValueError("Skill reference id must be a non-empty string")
        if not isinstance(relative_path, str) or not relative_path.strip():
            raise ValueError(f"Skill reference {reference_id!r} path must be a non-empty string")
        _safe_skill_file(skill_root, relative_path, f"Skill reference {reference_id!r}")
        metadata = raw.get("metadata", {})
        if not isinstance(metadata, dict):
            raise ValueError(f"Skill reference {reference_id!r} metadata must be a table")
        references.append(
            SkillReference(
                id=reference_id,
                title=str(raw.get("title") or reference_id),
                description=str(raw.get("description") or ""),
                relative_path=relative_path,
                metadata=MappingProxyType(dict(metadata)),
            )
        )
    if len({reference.id for reference in references}) != len(references):
        raise ValueError("duplicate Skill reference id")
    return tuple(references)


def _safe_skill_file(root: Path, relative_path: Any, label: str) -> Path:
    if not isinstance(relative_path, str) or not relative_path.strip():
        raise ValueError(f"{label} path must be a non-empty string")
    candidate_path = Path(relative_path)
    if candidate_path.is_absolute():
        raise ValueError(f"{label} path must be relative to the Skill")
    resolved_root = root.resolve()
    resolved = (resolved_root / candidate_path).resolve()
    try:
        resolved.relative_to(resolved_root)
    except ValueError as exc:
        raise ValueError(f"{label} path escapes the Skill directory") from exc
    if not resolved.is_file():
        raise ValueError(f"missing {label}: {candidate_path.as_posix()}")
    return resolved


CORE_PROMPT_PATH = Path(__file__).with_name("prompts") / "suwen-core.md"


def bundled_core_system_prompt() -> str:
    """Read the Runtime-owned Markdown Prompt shipped in this exact release."""

    content = CORE_PROMPT_PATH.read_text(encoding="utf-8").strip()
    if not content.startswith("# "):
        raise RuntimeError("bundled Suwen core Prompt must be a Markdown document")
    return content


CORE_SYSTEM_PROMPT = bundled_core_system_prompt()
