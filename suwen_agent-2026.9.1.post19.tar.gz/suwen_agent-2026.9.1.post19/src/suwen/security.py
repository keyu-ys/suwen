from __future__ import annotations

import re
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

_CAMEL_KEY_BOUNDARY = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")
_NON_KEY_WORD = re.compile(r"[^A-Za-z0-9]+")
_SENSITIVE_KEY_MARKERS = (
    ("authorization",),
    ("api", "key"),
    ("apikey",),
    ("auth", "header"),
    ("cookie",),
    ("credential",),
    ("credentials",),
    ("encrypt", "key"),
    ("password",),
    ("passwd",),
    ("private", "key"),
    ("secret",),
    ("server", "token"),
    ("signature",),
    ("signing", "key"),
    ("token",),
)
_SAFE_CREDENTIAL_METADATA_SUFFIXES = frozenset(
    {
        "algorithm",
        "configured",
        "count",
        "created_at",
        "digest",
        "enabled",
        "expires_at",
        "expiry",
        "hash",
        "id",
        "kind",
        "name",
        "present",
        "ref",
        "reference",
        "required",
        "revision",
        "rotated_at",
        "scope",
        "state",
        "status",
        "type",
        "updated_at",
        "url",
        "usage",
        "verified",
        "version",
    }
)
_URL_USERINFO = re.compile(r"(?i)(?P<scheme>\bhttps?://)[^/@\s?#]+@")
_INLINE_CREDENTIAL_VALUE = re.compile(
    r"(?i)(?P<prefix>(?P<key_quote>['\"]?)(?P<key>[A-Za-z][A-Za-z0-9_ -]{0,64})"
    r"(?P=key_quote)\s*[:=：]\s*)"
    r"(?P<value_quote>['\"]?)(?P<value>(?:bearer\s+|basic\s+)?"
    r"[A-Za-z0-9._~+/=-]{6,})(?P=value_quote)"
)


def _key_words(value: Any) -> tuple[str, ...]:
    separated = _CAMEL_KEY_BOUNDARY.sub("_", str(value))
    normalized = _NON_KEY_WORD.sub("_", separated).strip("_").casefold()
    return tuple(part for part in normalized.split("_") if part)


def is_sensitive_key(value: Any) -> bool:
    """Return whether one mapping key denotes a credential value.

    Credential words must align to key/camel-case boundaries.  Operational
    metadata such as ``tokenCount`` and ``signatureStatus`` remains visible,
    while values such as ``accessToken`` and ``x-api-key`` remain excluded.
    """

    words = _key_words(value)
    for marker in _SENSITIVE_KEY_MARKERS:
        marker_size = len(marker)
        for index in range(len(words) - marker_size + 1):
            if words[index : index + marker_size] != marker:
                continue
            trailing = "_".join(words[index + marker_size :])
            if not trailing or trailing not in _SAFE_CREDENTIAL_METADATA_SUFFIXES:
                return True
    return False


def _redact_url_credentials(value: str) -> str:
    """Keep useful URL context while removing userinfo and credential query values."""

    # URL userinfo is credential material even when the URL is embedded in a
    # log line instead of occupying the whole string.  Strip it before parsing
    # so malformed surrounding prose cannot preserve ``user:pass@``.
    result = _URL_USERINFO.sub(lambda match: match.group("scheme"), value)

    try:
        parsed = urlsplit(result)
    except ValueError:
        return result
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return result
    netloc = parsed.netloc.rpartition("@")[2] if "@" in parsed.netloc else parsed.netloc
    changed = False
    query: list[tuple[str, str]] = []
    for key, item in parse_qsl(parsed.query, keep_blank_values=True):
        if is_sensitive_key(key):
            query.append((key, "[REDACTED]"))
            changed = True
        else:
            query.append((key, item))
    if not changed and netloc == parsed.netloc:
        return result
    return urlunsplit(
        (
            parsed.scheme,
            netloc,
            parsed.path,
            urlencode(query, doseq=True) if parsed.query else "",
            parsed.fragment,
        )
    )


def _redact_inline_credentials(value: str) -> str:
    """Remove credential values embedded in otherwise useful prose or logs."""

    def replace(match: re.Match[str]) -> str:
        if not is_sensitive_key(match.group("key")):
            return match.group(0)
        quote = match.group("value_quote")
        return f"{match.group('prefix')}{quote}[REDACTED]{quote}"

    return _INLINE_CREDENTIAL_VALUE.sub(replace, value)


def redact_sensitive(value: Any, extra_values: tuple[str, ...] = ()) -> Any:
    """Return a JSON-compatible copy with credential-shaped data removed."""
    secrets = tuple(item for item in extra_values if item)
    if isinstance(value, dict):
        redacted: dict[str, Any] = {}
        for key, item in value.items():
            if is_sensitive_key(key):
                redacted[str(key)] = "[REDACTED]"
            else:
                redacted[str(key)] = redact_sensitive(item, secrets)
        return redacted
    if isinstance(value, list):
        return [redact_sensitive(item, secrets) for item in value]
    if isinstance(value, tuple):
        return [redact_sensitive(item, secrets) for item in value]
    if isinstance(value, str):
        result = value
        for secret in secrets:
            result = result.replace(secret, "[REDACTED]")
        if result.lower().startswith("bearer "):
            return "[REDACTED]"
        return _redact_inline_credentials(_redact_url_credentials(result))
    return value
