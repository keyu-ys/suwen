"""Lifecycle and runtime loading for first-party capability packages.

This is intentionally separate from historical in-tree Capability Packs and
an external extension host. The development artifact is a
content-addressed snapshot used only by isolated tests; a distributable build
and release chain belongs to a later phase.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import re
import shutil
import stat
import sys
import tomllib
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any

from .capability_api import (
    CAPABILITY_API_VERSION,
    CAPABILITY_CONTRACT_VERSION,
    CapabilityApi,
    CapabilityContext,
    CapabilityExternalAccess,
    CapabilityExternalExecutor,
    CapabilityManifest,
    CapabilityPrompt,
    CapabilityReference,
    CapabilityRegistration,
    CapabilitySkill,
    unavailable_external_executor,
)
from .db import Database
from .repository import iso, new_id
from .skills import Skill, SkillReference, SkillRegistry
from .tools import ToolRegistry
from .types import ToolDefinition

_STABLE_ID = re.compile(r"^[a-z][a-z0-9-]{1,63}$")
_SEMVER = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?$")
_MANIFEST_FIELDS = frozenset(
    {
        "schema",
        "id",
        "kind",
        "version",
        "name",
        "description",
        "capability_api",
        "distribution",
        "entrypoint",
        "content_entrypoint",
        "trusted_code",
        "external_dependencies",
        "provided_external_dependencies",
        "python_namespace",
    }
)
_DOMAIN_FIELDS = frozenset({"schema", "skills_dir", "prompts", "knowledge"})
_DOMAIN_PROMPT_FIELDS = frozenset({"id", "path"})
_DOMAIN_KNOWLEDGE_FIELDS = frozenset({"id", "title", "description", "path", "source_role"})
_DOMAIN_SKILL_FIELDS = frozenset(
    {"id", "name", "description", "applicability", "instruction_file", "fallback", "references"}
)
_DOMAIN_REFERENCE_FIELDS = frozenset({"id", "knowledge_id", "title", "description"})
_DOMAIN_SCHEMA = "suwen-domain.v1"
_MAX_DOMAIN_PROMPT_CHARS = 20_000
_MAX_DOMAIN_PROMPT_TOTAL_CHARS = 40_000
_MAX_DOMAIN_SKILL_CHARS = 30_000
_MAX_DOMAIN_KNOWLEDGE_CHARS = 100_000
_MAX_DOMAIN_TOTAL_CHARS = 1_000_000
_MAX_DOMAIN_SKILLS = 16
_MAX_DOMAIN_REFERENCES_PER_SKILL = 8


@dataclass(frozen=True)
class CapabilityBinding:
    capability_version_id: str
    role: str
    position: int = 0


@dataclass(frozen=True)
class LoadedCapability:
    version_id: str
    manifest: CapabilityManifest
    content_digest: str
    tools: ToolRegistry
    prompts: tuple[CapabilityPrompt, ...]
    skills: tuple[CapabilitySkill, ...]
    artifact_digest: str | None = None
    install_digest: str | None = None
    installation_id: str | None = None


def _canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
    except ValueError:
        return False
    return True


def _content_digest(root: Path) -> str:
    if not root.is_dir():
        raise ValueError("capability package root must be a directory")
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if path.is_dir():
            continue
        relative = path.relative_to(root)
        if "__pycache__" in relative.parts or path.suffix == ".pyc" or path.name == ".DS_Store":
            continue
        if path.is_symlink() or not _inside(path, root):
            raise ValueError("capability package cannot contain symlinked files")
        encoded_relative = relative.as_posix().encode("utf-8")
        payload = path.read_bytes()
        digest.update(len(encoded_relative).to_bytes(4, "big"))
        digest.update(encoded_relative)
        digest.update(len(payload).to_bytes(8, "big"))
        digest.update(payload)
    return digest.hexdigest()


def _version_tuple(value: str) -> tuple[int, int, int]:
    match = re.match(r"^(\d+)\.(\d+)\.(\d+)", value)
    if not match:
        raise ValueError("capability API version must be semantic version")
    return tuple(int(part) for part in match.groups())


def _api_is_compatible(requirement: str) -> bool:
    """Evaluate the deliberately small API range grammar used by v1 manifests."""

    if not requirement or len(requirement) > 100:
        return False
    current = _version_tuple(CAPABILITY_API_VERSION)
    for raw in requirement.split(","):
        item = raw.strip()
        match = re.fullmatch(r"(>=|>|<=|<|==)\s*(\d+\.\d+(?:\.\d+)?)", item)
        if not match:
            return False
        operator, target_raw = match.groups()
        parts = tuple(int(part) for part in target_raw.split("."))
        target = (*parts, *([0] * (3 - len(parts))))
        accepted = {
            ">=": current >= target,
            ">": current > target,
            "<=": current <= target,
            "<": current < target,
            "==": current == target,
        }[operator]
        if not accepted:
            return False
    return True


def _safe_package_path(root: Path, value: Any, label: str, *, directory: bool = False) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label} must be a non-empty relative path")
    candidate = Path(value)
    if candidate.is_absolute():
        raise ValueError(f"{label} must be relative to the capability package")
    if not candidate.parts or any(part in {".", ".."} for part in candidate.parts):
        raise ValueError(f"{label} must not contain traversal segments")
    raw = root.joinpath(*candidate.parts)
    current = root
    for part in candidate.parts:
        current = current / part
        if current.is_symlink():
            raise ValueError(f"{label} cannot traverse a symbolic link")
    resolved = raw.resolve()
    if not _inside(resolved, root):
        raise ValueError(f"{label} escapes the capability package")
    if raw.is_symlink() or (not resolved.is_dir() if directory else not resolved.is_file()):
        expected = "directory" if directory else "file"
        raise ValueError(f"missing {label} {expected}")
    return resolved


def _read_domain_text(path: Path, label: str, maximum: int) -> str:
    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError(f"{label} must be UTF-8 text") from exc
    if not content.strip() or "\x00" in content:
        raise ValueError(f"{label} must be non-empty safe text")
    if len(content) > maximum:
        raise ValueError(f"{label} exceeds {maximum} characters")
    return content


def _validate_declarative_domain_tree(root: Path) -> None:
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if path.is_symlink():
            raise ValueError("declarative domain cannot contain symbolic links")
        if not path.is_file():
            continue
        if "__pycache__" in relative.parts or path.suffix in {".py", ".pyc"}:
            raise ValueError("declarative domain cannot contain Python source or cache")
        if path.stat().st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH):
            raise ValueError("declarative domain cannot contain executable files")


def inspect_capability_package(root: Path) -> tuple[CapabilityManifest, str]:
    """Inspect a source or workspace snapshot without importing its code."""

    root = root.resolve()
    manifest_path = root / "manifest.toml"
    if not manifest_path.is_file():
        raise ValueError("capability package manifest.toml is required")
    with manifest_path.open("rb") as handle:
        raw = tomllib.load(handle)
    if not isinstance(raw, dict):
        raise ValueError("capability manifest must be a TOML table")
    unknown = set(raw) - _MANIFEST_FIELDS
    if unknown:
        raise ValueError(f"capability manifest contains unsupported fields: {sorted(unknown)[0]}")
    required = ("schema", "id", "kind", "version", "name", "description", "capability_api")
    if any(not isinstance(raw.get(field), str) or not str(raw[field]).strip() for field in required):
        raise ValueError("capability manifest has a required empty field")
    if raw["schema"] != CAPABILITY_CONTRACT_VERSION:
        raise ValueError("unsupported capability manifest schema")
    package_id = str(raw["id"])
    if not _STABLE_ID.fullmatch(package_id):
        raise ValueError("capability id must be stable lowercase identifier")
    kind = str(raw["kind"])
    if kind not in {"tools", "domain"}:
        raise ValueError("capability kind must be tools or domain")
    version = str(raw["version"])
    if not _SEMVER.fullmatch(version):
        raise ValueError("capability version must be semantic version")
    requirement = str(raw["capability_api"])
    if not _api_is_compatible(requirement):
        raise ValueError("capability API range is incompatible")

    raw_entrypoint = raw.get("entrypoint")
    raw_content_entrypoint = raw.get("content_entrypoint")
    has_entrypoint = isinstance(raw_entrypoint, str) and bool(raw_entrypoint.strip())
    has_content_entrypoint = isinstance(raw_content_entrypoint, str) and bool(raw_content_entrypoint.strip())
    if raw_entrypoint is not None and not has_entrypoint:
        raise ValueError("capability entrypoint must be a non-empty callable")
    if raw_content_entrypoint is not None and not has_content_entrypoint:
        raise ValueError("capability content_entrypoint must be a non-empty path")
    entrypoint = str(raw_entrypoint).strip() if has_entrypoint else None
    content_entrypoint = str(raw_content_entrypoint).strip() if has_content_entrypoint else None
    trusted_code = raw.get("trusted_code")
    distribution = raw.get("distribution", package_id)
    python_namespace = raw.get("python_namespace", package_id.replace("-", "_"))

    if kind == "tools":
        if (
            not isinstance(distribution, str)
            or re.fullmatch(r"[a-z0-9](?:[a-z0-9.-]{0,126}[a-z0-9])?", distribution) is None
            or not isinstance(python_namespace, str)
            or re.fullmatch(r"[a-zA-Z_][a-zA-Z0-9_]*", python_namespace) is None
        ):
            raise ValueError("tools capability distribution identity is invalid")
    elif "distribution" in raw or "python_namespace" in raw:
        raise ValueError("domain capability cannot declare a Python distribution")

    if kind == "tools":
        if not has_entrypoint or has_content_entrypoint:
            raise ValueError("tools capability requires only a callable entrypoint")
        if not re.fullmatch(r"[a-zA-Z_][a-zA-Z0-9_]*:[a-zA-Z_][a-zA-Z0-9_]*", entrypoint or ""):
            raise ValueError("capability entrypoint must be a package-root callable")
        if trusted_code is not True:
            raise ValueError("capability package code must be explicitly trusted")
        if entrypoint.partition(":")[0].split(".")[0] != python_namespace:
            raise ValueError("capability entrypoint must belong to its Python namespace")
    elif has_content_entrypoint:
        if has_entrypoint or trusted_code is not False:
            raise ValueError("declarative domain requires only content_entrypoint and trusted_code=false")
        _safe_package_path(root, content_entrypoint, "capability content_entrypoint")
        _validate_declarative_domain_tree(root)
    else:
        if not has_entrypoint or trusted_code is not True:
            raise ValueError("legacy code domain requires entrypoint and trusted_code=true")
        if not re.fullmatch(r"[a-zA-Z_][a-zA-Z0-9_]*:[a-zA-Z_][a-zA-Z0-9_]*", entrypoint or ""):
            raise ValueError("capability entrypoint must be a package-root callable")

    external_dependencies = raw.get("external_dependencies", [])
    if not isinstance(external_dependencies, list):
        raise ValueError("external_dependencies must be an array")
    normalized_dependencies: list[dict[str, str]] = []
    for dependency in external_dependencies:
        if not isinstance(dependency, dict) or set(dependency) != {"id", "contract"}:
            raise ValueError("external dependency must declare only id and contract")
        dependency_id = dependency.get("id")
        contract = dependency.get("contract")
        if (
            not isinstance(dependency_id, str)
            or not _STABLE_ID.fullmatch(dependency_id)
            or not isinstance(contract, str)
            or not contract.strip()
            or "/" in contract
            or "\\" in contract
        ):
            raise ValueError("external dependency declaration is invalid")
        if any(item["id"] == dependency_id for item in normalized_dependencies):
            raise ValueError("external dependency id must not be declared twice")
        normalized_dependencies.append({"id": dependency_id, "contract": contract.strip()})
    if kind == "domain" and normalized_dependencies:
        raise ValueError("domain capability cannot declare external dependencies")

    provided_external_dependencies = raw.get("provided_external_dependencies", [])
    if not isinstance(provided_external_dependencies, list):
        raise ValueError("provided_external_dependencies must be an array")
    normalized_providers: list[dict[str, Any]] = []
    declared_contracts = {
        item["id"]: item["contract"] for item in normalized_dependencies
    }
    provider_fields = {
        "id",
        "contract",
        "entrypoint",
        "allowed_subcommands",
        "timeout_seconds",
        "max_output_bytes",
    }
    for provider in provided_external_dependencies:
        if not isinstance(provider, dict) or set(provider) != provider_fields:
            raise ValueError(
                "provided external dependency must declare the exact provider contract"
            )
        provider_id = provider.get("id")
        provider_contract = provider.get("contract")
        provider_entrypoint = provider.get("entrypoint")
        allowed_subcommands = provider.get("allowed_subcommands")
        timeout_seconds = provider.get("timeout_seconds")
        max_output_bytes = provider.get("max_output_bytes")
        if (
            not isinstance(provider_id, str)
            or declared_contracts.get(provider_id) != provider_contract
            or not isinstance(provider_entrypoint, str)
            or re.fullmatch(
                r"[a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)*"
                r":[a-zA-Z_][a-zA-Z0-9_]*",
                provider_entrypoint,
            )
            is None
            or provider_entrypoint.partition(":")[0].split(".")[0]
            != python_namespace
            or not isinstance(allowed_subcommands, list)
            or not 1 <= len(allowed_subcommands) <= 64
            or len(allowed_subcommands) != len(set(allowed_subcommands))
            or any(
                not isinstance(item, str)
                or re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}", item) is None
                for item in allowed_subcommands
            )
            or isinstance(timeout_seconds, bool)
            or not isinstance(timeout_seconds, (int, float))
            or not 0 < float(timeout_seconds) <= 300
            or isinstance(max_output_bytes, bool)
            or not isinstance(max_output_bytes, int)
            or not 1 <= max_output_bytes <= 2 * 1024 * 1024
        ):
            raise ValueError("provided external dependency declaration is invalid")
        if any(item["id"] == provider_id for item in normalized_providers):
            raise ValueError("provided external dependency id must not be declared twice")
        normalized_providers.append(
            {
                "id": provider_id,
                "contract": provider_contract,
                "entrypoint": provider_entrypoint,
                "allowed_subcommands": list(allowed_subcommands),
                "timeout_seconds": float(timeout_seconds),
                "max_output_bytes": max_output_bytes,
            }
        )
    if kind == "domain" and normalized_providers:
        raise ValueError("domain capability cannot provide external dependencies")

    manifest = CapabilityManifest(
        id=package_id,
        kind=kind,  # type: ignore[arg-type]
        version=version,
        name=str(raw["name"]).strip(),
        description=str(raw["description"]).strip(),
        capability_api=requirement,
        entrypoint=entrypoint,
        trusted_code=bool(trusted_code),
        distribution=str(distribution) if kind == "tools" else None,
        python_namespace=str(python_namespace) if kind == "tools" else None,
        content_entrypoint=content_entrypoint,
        external_dependencies=tuple(normalized_dependencies),
        provided_external_dependencies=tuple(normalized_providers),
    )
    # A declarative domain is safe to parse at source registration time.  Do
    # not let malformed content progress into the artifact or workspace state
    # merely because its outer Manifest is well formed.
    if manifest.content_entrypoint is not None:
        _load_domain_registration(root, manifest)
    return manifest, _content_digest(root)


def _domain_id(value: Any, label: str) -> str:
    if not isinstance(value, str) or not _STABLE_ID.fullmatch(value):
        raise ValueError(f"{label} must be a stable lowercase identifier")
    return value


def _domain_text(value: Any, label: str, *, maximum: int = 1_000) -> str:
    if not isinstance(value, str) or not value.strip() or "\x00" in value:
        raise ValueError(f"{label} must be non-empty safe text")
    if len(value) > maximum:
        raise ValueError(f"{label} exceeds {maximum} characters")
    return value.strip()


def _domain_table(value: Any, allowed: frozenset[str], label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be a TOML table")
    unknown = set(value) - allowed
    if unknown:
        raise ValueError(f"{label} contains unsupported field {sorted(unknown)[0]}")
    return value


def _load_toml(path: Path, label: str) -> dict[str, Any]:
    with path.open("rb") as handle:
        raw = tomllib.load(handle)
    if not isinstance(raw, dict):
        raise ValueError(f"{label} must be a TOML table")
    return raw


def _load_domain_registration(root: Path, manifest: CapabilityManifest) -> CapabilityRegistration:
    """Load a declarative domain without importing package code.

    The loader reads only prevalidated files inside the immutable capability
    workspace and turns them into public registration values.  Paths and file
    handles do not leave this host boundary.
    """

    domain_path = _safe_package_path(root, manifest.content_entrypoint, "domain content entrypoint")
    raw_domain = _load_toml(domain_path, "domain content entrypoint")
    unknown = set(raw_domain) - _DOMAIN_FIELDS
    if unknown:
        raise ValueError(f"domain content contains unsupported field {sorted(unknown)[0]}")
    if raw_domain.get("schema") != _DOMAIN_SCHEMA:
        raise ValueError("unsupported declarative domain schema")
    prompts_raw = raw_domain.get("prompts")
    knowledge_raw = raw_domain.get("knowledge", [])
    if not isinstance(prompts_raw, list) or not prompts_raw:
        raise ValueError("declarative domain must declare at least one Prompt")
    if not isinstance(knowledge_raw, list):
        raise ValueError("domain knowledge must be an array of tables")
    if len(prompts_raw) > 8 or len(knowledge_raw) > 64:
        raise ValueError("declarative domain exceeds content item limits")
    skills_root = _safe_package_path(root, raw_domain.get("skills_dir"), "domain skills_dir", directory=True)

    total_chars = 0
    prompts: list[CapabilityPrompt] = []
    prompt_ids: set[str] = set()
    for raw_prompt in prompts_raw:
        prompt = _domain_table(raw_prompt, _DOMAIN_PROMPT_FIELDS, "domain Prompt")
        prompt_id = _domain_id(prompt.get("id"), "domain Prompt id")
        if prompt_id in prompt_ids:
            raise ValueError("duplicate domain Prompt id")
        content = _read_domain_text(
            _safe_package_path(root, prompt.get("path"), f"domain Prompt {prompt_id}"),
            f"domain Prompt {prompt_id}",
            _MAX_DOMAIN_PROMPT_CHARS,
        )
        total_chars += len(content)
        if total_chars > _MAX_DOMAIN_PROMPT_TOTAL_CHARS:
            raise ValueError("domain Prompt content exceeds total limit")
        prompt_ids.add(prompt_id)
        prompts.append(CapabilityPrompt(id=prompt_id, content=content))

    knowledge: dict[str, CapabilityReference] = {}
    for raw_item in knowledge_raw:
        item = _domain_table(raw_item, _DOMAIN_KNOWLEDGE_FIELDS, "domain knowledge")
        knowledge_id = _domain_id(item.get("id"), "domain knowledge id")
        if knowledge_id in knowledge:
            raise ValueError("duplicate domain knowledge id")
        title = _domain_text(item.get("title"), f"domain knowledge {knowledge_id} title", maximum=240)
        description = _domain_text(
            item.get("description"), f"domain knowledge {knowledge_id} description", maximum=1_000
        )
        source_role = _domain_text(
            item.get("source_role"), f"domain knowledge {knowledge_id} source_role", maximum=96
        )
        if not re.fullmatch(r"[a-z][a-z0-9_.-]{1,95}", source_role):
            raise ValueError("domain knowledge source_role is invalid")
        content = _read_domain_text(
            _safe_package_path(root, item.get("path"), f"domain knowledge {knowledge_id}"),
            f"domain knowledge {knowledge_id}",
            _MAX_DOMAIN_KNOWLEDGE_CHARS,
        )
        total_chars += len(content)
        if total_chars > _MAX_DOMAIN_TOTAL_CHARS:
            raise ValueError("declarative domain exceeds total content limit")
        knowledge[knowledge_id] = CapabilityReference(
            id=knowledge_id,
            title=title,
            description=description,
            content=content,
            metadata=MappingProxyType({"knowledge_id": knowledge_id, "source_role": source_role}),
        )

    manifests = sorted(skills_root.glob("*/skill.toml"))
    if not manifests or len(manifests) > _MAX_DOMAIN_SKILLS:
        raise ValueError("declarative domain must declare 1 to 16 Skills")
    skills: list[CapabilitySkill] = []
    skill_ids: set[str] = set()
    skill_names: set[str] = set()
    referenced_knowledge: set[str] = set()
    fallback_count = 0
    for skill_path in manifests:
        skill_root = skill_path.parent.resolve()
        if not _inside(skill_root, skills_root):
            raise ValueError("domain Skill path escapes skills_dir")
        raw_skill = _load_toml(skill_path, "domain Skill")
        skill = _domain_table(raw_skill, _DOMAIN_SKILL_FIELDS, "domain Skill")
        skill_id = _domain_id(skill.get("id"), "domain Skill id")
        if skill_id in skill_ids:
            raise ValueError("duplicate domain Skill id")
        name = _domain_text(skill.get("name"), f"domain Skill {skill_id} name", maximum=160)
        if name in skill_names:
            raise ValueError("duplicate domain Skill name")
        description = _domain_text(
            skill.get("description"), f"domain Skill {skill_id} description", maximum=1_000
        )
        applicability = _domain_text(
            skill.get("applicability", description),
            f"domain Skill {skill_id} applicability",
            maximum=2_000,
        )
        fallback = skill.get("fallback")
        if not isinstance(fallback, bool):
            raise ValueError("domain Skill fallback must be boolean")
        fallback_count += int(fallback)
        instructions = _read_domain_text(
            _safe_package_path(
                skill_root,
                skill.get("instruction_file", "SKILL.md"),
                f"domain Skill {skill_id} instructions",
            ),
            f"domain Skill {skill_id} instructions",
            _MAX_DOMAIN_SKILL_CHARS,
        )
        total_chars += len(instructions)
        if total_chars > _MAX_DOMAIN_TOTAL_CHARS:
            raise ValueError("declarative domain exceeds total content limit")
        raw_references = skill.get("references", [])
        if not isinstance(raw_references, list) or len(raw_references) > _MAX_DOMAIN_REFERENCES_PER_SKILL:
            raise ValueError("domain Skill references exceed the configured limit")
        references: list[CapabilityReference] = []
        reference_ids: set[str] = set()
        for raw_reference in raw_references:
            reference = _domain_table(raw_reference, _DOMAIN_REFERENCE_FIELDS, "domain Skill reference")
            reference_id = _domain_id(reference.get("id"), "domain Skill reference id")
            knowledge_id = _domain_id(reference.get("knowledge_id"), "domain Skill reference knowledge_id")
            if reference_id in reference_ids:
                raise ValueError("duplicate domain Skill reference id")
            try:
                knowledge_item = knowledge[knowledge_id]
            except KeyError as exc:
                raise ValueError("domain Skill references unknown knowledge") from exc
            title = _domain_text(
                reference.get("title", knowledge_item.title),
                f"domain Skill reference {reference_id} title",
                maximum=240,
            )
            reference_description = _domain_text(
                reference.get("description", knowledge_item.description),
                f"domain Skill reference {reference_id} description",
                maximum=1_000,
            )
            reference_ids.add(reference_id)
            referenced_knowledge.add(knowledge_id)
            references.append(
                CapabilityReference(
                    id=reference_id,
                    title=title,
                    description=reference_description,
                    content=knowledge_item.content,
                    metadata=knowledge_item.metadata,
                )
            )
        skill_ids.add(skill_id)
        skill_names.add(name)
        skills.append(
            CapabilitySkill(
                id=skill_id,
                version=manifest.version,
                name=name,
                description=description,
                instructions=instructions,
                applicability=applicability,
                is_fallback=fallback,
                references=tuple(references),
            )
        )
    if fallback_count != 1:
        raise ValueError("declarative domain must declare exactly one fallback Skill")
    if set(knowledge) != referenced_knowledge:
        raise ValueError("declarative domain contains unreferenced knowledge")
    return CapabilityRegistration(tools=(), prompts=tuple(prompts), skills=tuple(skills))


class CapabilityPackageRegistry:
    """Controlled registration, isolated installation, and per-version loading."""

    def __init__(
        self,
        database: Database,
        workspace_root: Path,
        *,
        external_executor: CapabilityExternalExecutor | None = None,
    ) -> None:
        self.database = database
        self.workspace_root = workspace_root.resolve()
        self._loaded: dict[str, LoadedCapability] = {}
        self._external_executor = external_executor or unavailable_external_executor
        self._external_executor_override = external_executor is not None
        self._external_dependency_manager: Any | None = None
        self.process_instance_id = new_id("capability-process")

    def set_external_executor(
        self,
        executor: CapabilityExternalExecutor | None,
    ) -> None:
        """Set a host-owned external binding; ``None`` restores fail-closed mode.

        This intentionally accepts a logical executor only. A deployment may
        supply an installation-bound command or Python provider, but package
        source never receives its path, environment, or Secret values.
        """

        self._external_executor = executor or unavailable_external_executor
        self._external_executor_override = True

    def set_external_dependency_manager(self, manager: Any | None) -> None:
        """Use host-owned, per-Run frozen external bindings when configured."""

        self._external_dependency_manager = manager

    def register_source(self, source_root: Path, actor: str) -> dict[str, Any]:
        manifest, digest = inspect_capability_package(source_root)
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                version_id, created = self._register_version(connection, manifest, digest, actor)
                connection.commit()
            except BaseException:
                connection.rollback()
                raise
        return {
            "capability_id": manifest.id,
            "capability_version_id": version_id,
            "kind": manifest.kind,
            "version": manifest.version,
            "content_digest": digest,
            "state": "source-present",
            "created": created,
        }

    def build_development_artifact(self, source_root: Path, actor: str) -> dict[str, Any]:
        """Create a content-addressed test snapshot, not a publishable package artifact."""

        source_root = source_root.resolve()
        registered = self.register_source(source_root, actor)
        target = (
            self.workspace_root
            / "artifacts"
            / registered["capability_id"]
            / (f"{registered['version']}-{registered['content_digest']}")
        )
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        if target.exists():
            if _content_digest(target) != registered["content_digest"]:
                raise RuntimeError("existing capability development artifact has content drift")
        else:
            shutil.copytree(source_root, target, copy_function=shutil.copy2)
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                row = connection.execute(
                    "SELECT content_digest FROM capability_package_versions WHERE id=?",
                    (registered["capability_version_id"],),
                ).fetchone()
                if not row or row["content_digest"] != registered["content_digest"]:
                    raise RuntimeError("capability version changed while building artifact")
                connection.execute(
                    """UPDATE capability_package_versions
                       SET lifecycle_state='artifact-built', artifact_digest=?, artifact_path=?,
                           artifact_built_at=? WHERE id=?""",
                    (
                        registered["content_digest"],
                        str(target),
                        iso(),
                        registered["capability_version_id"],
                    ),
                )
                self._audit(
                    connection,
                    actor,
                    "capability_package.artifact_built",
                    registered["capability_id"],
                    registered["version"],
                    {"capability_version_id": registered["capability_version_id"]},
                )
                connection.commit()
            except BaseException:
                connection.rollback()
                raise
        return {**registered, "state": "artifact-built", "artifact_digest": registered["content_digest"]}

    def install_artifact(self, capability_version_id: str, actor: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT cpv.*, cp.id AS capability_id, cp.kind
                   FROM capability_package_versions cpv
                   JOIN capability_packages cp ON cp.id=cpv.capability_id
                   WHERE cpv.id=?""",
                (capability_version_id,),
            ).fetchone()
        if not row:
            raise KeyError(capability_version_id)
        if row["lifecycle_state"] not in {"artifact-built", "workspace-installed"}:
            raise ValueError("capability artifact must be built before workspace installation")
        artifact_path = Path(str(row["artifact_path"] or ""))
        if not artifact_path.is_dir() or not _inside(artifact_path, self.workspace_root / "artifacts"):
            raise RuntimeError("capability artifact path is unavailable")
        if _content_digest(artifact_path) != row["content_digest"]:
            raise RuntimeError("capability artifact content digest mismatch")
        installed_path = (
            self.workspace_root
            / "installed"
            / str(row["capability_id"])
            / (f"{row['version']}-{row['content_digest']}")
        )
        installed_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        if installed_path.exists():
            if _content_digest(installed_path) != row["content_digest"]:
                raise RuntimeError("existing installed capability has content drift")
        else:
            shutil.copytree(artifact_path, installed_path, copy_function=shutil.copy2)
        manifest, digest = inspect_capability_package(installed_path)
        if (
            manifest.id != row["capability_id"]
            or manifest.version != row["version"]
            or digest != row["content_digest"]
        ):
            raise RuntimeError("installed capability does not match registered identity")
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                connection.execute(
                    """UPDATE capability_package_versions
                       SET lifecycle_state='workspace-installed', workspace_path=?, installed_at=?
                       WHERE id=? AND content_digest=?""",
                    (str(installed_path), iso(), capability_version_id, digest),
                )
                self._audit(
                    connection,
                    actor,
                    "capability_package.workspace_installed",
                    str(row["capability_id"]),
                    str(row["version"]),
                    {"capability_version_id": capability_version_id},
                )
                connection.commit()
            except BaseException:
                connection.rollback()
                raise
        return {
            "capability_id": row["capability_id"],
            "capability_version_id": capability_version_id,
            "kind": row["kind"],
            "version": row["version"],
            "content_digest": digest,
            "state": "workspace-installed",
        }

    def validate_bindings(
        self,
        connection: Any,
        bindings: Iterable[CapabilityBinding],
    ) -> list[CapabilityBinding]:
        normalized = list(bindings)
        if len({item.capability_version_id for item in normalized}) != len(normalized):
            raise ValueError("Agent cannot bind a capability version more than once")
        if any(item.role not in {"tools", "domain"} for item in normalized):
            raise ValueError("capability binding role must be tools or domain")
        package_ids: list[str] = []
        for binding in normalized:
            row = connection.execute(
                """SELECT cp.id AS capability_id, cp.kind, cp.status, cpv.lifecycle_state
                   FROM capability_package_versions cpv
                   JOIN capability_packages cp ON cp.id=cpv.capability_id
                   WHERE cpv.id=?""",
                (binding.capability_version_id,),
            ).fetchone()
            if not row:
                raise KeyError(binding.capability_version_id)
            if row["kind"] != binding.role:
                raise ValueError("capability binding role does not match manifest kind")
            if row["status"] != "available" or row["lifecycle_state"] != "workspace-installed":
                raise ValueError("capability version is not workspace-installed and available")
            package_ids.append(str(row["capability_id"]))
        if len(package_ids) != len(set(package_ids)):
            raise ValueError("Agent cannot bind multiple versions of the same capability package")
        return normalized

    def load_bindings(self, bindings: Iterable[CapabilityBinding]) -> tuple[LoadedCapability, ...]:
        result: list[LoadedCapability] = []
        for binding in sorted(bindings, key=lambda item: (item.position, item.capability_version_id)):
            loaded = self.load_version(binding.capability_version_id)
            if loaded.manifest.kind != binding.role:
                raise RuntimeError("installed capability kind differs from Agent binding")
            result.append(loaded)
        return tuple(result)

    def load_version(self, capability_version_id: str) -> LoadedCapability:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT cpv.*, cp.id AS capability_id, cp.kind, cp.status
                   FROM capability_package_versions cpv
                   JOIN capability_packages cp ON cp.id=cpv.capability_id
                   WHERE cpv.id=?""",
                (capability_version_id,),
            ).fetchone()
        if not row:
            raise KeyError(capability_version_id)
        if row["status"] != "available" or row["lifecycle_state"] != "workspace-installed":
            self._loaded.pop(capability_version_id, None)
            raise RuntimeError("capability version is not available in the workspace")
        cached = self._loaded.get(capability_version_id)
        if cached is not None:
            return cached
        with self.database.connect() as connection:
            formal = connection.execute(
                """SELECT nwi.id, nwi.install_digest, nwi.workspace_path, nra.artifact_digest
                   FROM native_workspace_installations nwi
                   JOIN native_release_artifacts nra ON nra.id=nwi.artifact_id
                   WHERE nwi.capability_version_id=? AND nwi.status='installed'""",
                (capability_version_id,),
            ).fetchone()
        workspace_path = Path(str(formal["workspace_path"] if formal else row["workspace_path"] or ""))
        allowed_root = (
            self.workspace_root.parent / "native-releases" / "installations"
            if formal
            else self.workspace_root / "installed"
        )
        source_root = workspace_path / "source" if formal else workspace_path
        if not workspace_path.is_dir() or not _inside(workspace_path, allowed_root):
            raise RuntimeError("capability workspace path is unavailable")
        manifest, digest = inspect_capability_package(source_root)
        if (
            manifest.id != row["capability_id"]
            or manifest.kind != row["kind"]
            or manifest.version != row["version"]
            or digest != row["content_digest"]
        ):
            raise RuntimeError("capability workspace content drift")
        registration = (
            self._registration_from_domain_content(source_root, manifest)
            if manifest.content_entrypoint is not None
            else self._registration_from_entrypoint(
                source_root,
                manifest,
                digest,
                code_root=workspace_path / "code" if formal else None,
            )
        )
        code_root = workspace_path / "code" if formal else workspace_path / "src"
        provided_external_bindings = tuple(
            {
                **provider,
                "code_root": str(code_root),
                "capability_id": manifest.id,
                "capability_version": manifest.version,
                "capability_digest": digest,
            }
            for provider in manifest.provided_external_dependencies
        )
        loaded = self._loaded_capability(
            capability_version_id,
            manifest,
            digest,
            registration,
            artifact_digest=str(formal["artifact_digest"]) if formal else None,
            install_digest=str(formal["install_digest"]) if formal else None,
            installation_id=str(formal["id"]) if formal else None,
            provided_external_bindings=provided_external_bindings,
        )
        self._loaded[capability_version_id] = loaded
        return loaded

    def record_process_loads(self, loaded: Iterable[LoadedCapability]) -> None:
        """Persist successful Runtime loads after composition transactions finish."""

        items = list(loaded)
        if not items:
            return
        with self.database.connect() as connection:
            connection.executemany(
                """INSERT INTO capability_process_loads(
                   process_instance_id, capability_version_id, installation_id,
                   artifact_digest, state, loaded_at, last_used_at
                ) VALUES (?, ?, ?, ?, 'process-loaded', ?, ?)
                ON CONFLICT(process_instance_id, capability_version_id) DO UPDATE SET
                   installation_id=excluded.installation_id,
                   artifact_digest=excluded.artifact_digest,
                   state='process-loaded', last_used_at=excluded.last_used_at, error_code=NULL""",
                [
                    (
                        self.process_instance_id,
                        item.version_id,
                        item.installation_id,
                        item.artifact_digest,
                        iso(),
                        iso(),
                    )
                    for item in items
                ],
            )

    def tools_for(self, bindings: Iterable[CapabilityBinding]) -> ToolRegistry:
        tools = ToolRegistry()
        for loaded in self.load_bindings(bindings):
            if loaded.manifest.kind == "tools":
                tools.merge_from(loaded.tools)
        return tools

    def domains_for(self, bindings: Iterable[CapabilityBinding]) -> tuple[LoadedCapability, ...]:
        return tuple(loaded for loaded in self.load_bindings(bindings) if loaded.manifest.kind == "domain")

    def list_domain_experts(self) -> list[dict[str, Any]]:
        """Return installed declarative domains with bounded Skill previews."""

        with self.database.connect() as connection:
            packages = connection.execute(
                """SELECT id, name, description, status
                   FROM capability_packages
                   WHERE kind='domain' AND status='available'
                   ORDER BY name, id"""
            ).fetchall()
            versions = connection.execute(
                """SELECT id, capability_id, version, lifecycle_state,
                          content_digest, created_at
                   FROM capability_package_versions
                   WHERE capability_id IN (
                     SELECT id FROM capability_packages WHERE kind='domain'
                   )
                   ORDER BY capability_id, created_at DESC, id DESC"""
            ).fetchall()

        versions_by_package: dict[str, list[dict[str, Any]]] = {}
        for row in versions:
            versions_by_package.setdefault(str(row["capability_id"]), []).append(
                {
                    "id": str(row["id"]),
                    "version": str(row["version"]),
                    "state": str(row["lifecycle_state"]),
                    "content_digest": str(row["content_digest"]),
                    "created_at": str(row["created_at"]),
                }
            )

        result: list[dict[str, Any]] = []
        for package in packages:
            package_id = str(package["id"])
            package_versions = versions_by_package.get(package_id, [])
            current = next(
                (item for item in package_versions if item["state"] == "workspace-installed"),
                package_versions[0] if package_versions else None,
            )
            skills: list[dict[str, Any]] = []
            load_state = "not_installed"
            load_error = ""
            if current and current["state"] == "workspace-installed":
                try:
                    loaded = self.load_version(str(current["id"]))
                except (KeyError, OSError, RuntimeError, ValueError) as exc:
                    load_state = "unavailable"
                    load_error = str(exc)
                else:
                    load_state = "available"
                    skills = [
                        {
                            "id": skill.id,
                            "version": skill.version,
                            "name": skill.name,
                            "description": skill.description,
                            "applicability": skill.applicability,
                            "instructions": skill.instructions,
                            "fallback": bool(skill.is_fallback),
                            "reference_count": len(skill.references),
                            "references": [
                                {
                                    "id": reference.id,
                                    "title": reference.title,
                                    "description": reference.description,
                                }
                                for reference in skill.references
                            ],
                        }
                        for skill in loaded.skills
                    ]
            result.append(
                {
                    "id": package_id,
                    "name": str(package["name"]),
                    "description": str(package["description"]),
                    "status": str(package["status"]),
                    "load_state": load_state,
                    "load_error": load_error,
                    "current_version": current,
                    "versions": package_versions,
                    "skills": skills,
                }
            )
        return result

    def get_domain_reference(
        self,
        capability_id: str,
        capability_version_id: str,
        skill_id: str,
        reference_id: str,
    ) -> dict[str, Any]:
        """Return one frozen Markdown reference without exposing workspace paths."""

        loaded = self.load_version(capability_version_id)
        if loaded.manifest.id != capability_id or loaded.manifest.kind != "domain":
            raise KeyError(capability_version_id)
        skill = next((item for item in loaded.skills if item.id == skill_id), None)
        if skill is None:
            raise KeyError(skill_id)
        reference = next((item for item in skill.references if item.id == reference_id), None)
        if reference is None:
            raise KeyError(reference_id)
        return {
            "capability_id": capability_id,
            "capability_version_id": capability_version_id,
            "version": loaded.manifest.version,
            "skill_id": skill.id,
            "reference": {
                "id": reference.id,
                "title": reference.title,
                "description": reference.description,
                "content": reference.content,
                "content_digest": capability_reference_digest(reference),
            },
        }

    def delete_package(self, capability_id: str, actor: str) -> dict[str, Any]:
        """Retire one unused package while retaining immutable historical records."""

        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                package = connection.execute(
                    "SELECT id, name, status FROM capability_packages WHERE id=?",
                    (capability_id,),
                ).fetchone()
                if not package:
                    raise KeyError(capability_id)
                version_rows = connection.execute(
                    "SELECT id, version FROM capability_package_versions WHERE capability_id=?",
                    (capability_id,),
                ).fetchall()
                version_ids = [str(row["id"]) for row in version_rows]
                if package["status"] == "retired":
                    connection.rollback()
                    for version_id in version_ids:
                        self._loaded.pop(version_id, None)
                    return {"id": capability_id, "deleted": True, "mode": "retired"}

                active_agents = connection.execute(
                    """SELECT DISTINCT agent.id, agent.name
                       FROM agents agent
                       JOIN agent_version_capabilities binding
                         ON binding.agent_version_id=agent.active_version_id AND binding.enabled=1
                       JOIN capability_package_versions version
                         ON version.id=binding.capability_version_id
                       WHERE version.capability_id=?
                       ORDER BY agent.id""",
                    (capability_id,),
                ).fetchall()
                draft_agents = connection.execute(
                    """SELECT DISTINCT agent.id, agent.name
                       FROM agents agent
                       JOIN agent_versions draft
                         ON draft.agent_id=agent.id AND draft.status='draft'
                       JOIN agent_version_capabilities binding
                         ON binding.agent_version_id=draft.id AND binding.enabled=1
                       JOIN capability_package_versions version
                         ON version.id=binding.capability_version_id
                       WHERE version.capability_id=?
                       ORDER BY agent.id""",
                    (capability_id,),
                ).fetchall()
                running_runs = connection.execute(
                    """SELECT DISTINCT run.id
                       FROM runs run
                       JOIN run_capabilities loaded ON loaded.run_id=run.id
                       JOIN capability_package_versions version
                         ON version.id=loaded.capability_version_id
                       WHERE version.capability_id=? AND run.status='running'
                       ORDER BY run.id""",
                    (capability_id,),
                ).fetchall()
                blockers: list[str] = []
                if active_agents:
                    blockers.append(f"{len(active_agents)} 个当前 Agent")
                if draft_agents:
                    blockers.append(f"{len(draft_agents)} 个 Agent 草稿")
                if running_runs:
                    blockers.append(f"{len(running_runs)} 个运行中 Run")
                if blockers:
                    raise ValueError("领域能力仍被使用，不能删除：" + "、".join(blockers))

                historical_agent_versions = connection.execute(
                    """SELECT COUNT(DISTINCT binding.agent_version_id)
                       FROM agent_version_capabilities binding
                       JOIN capability_package_versions version
                         ON version.id=binding.capability_version_id
                       WHERE version.capability_id=?""",
                    (capability_id,),
                ).fetchone()[0]
                historical_runs = connection.execute(
                    """SELECT COUNT(DISTINCT loaded.run_id)
                       FROM run_capabilities loaded
                       JOIN capability_package_versions version
                         ON version.id=loaded.capability_version_id
                       WHERE version.capability_id=?""",
                    (capability_id,),
                ).fetchone()[0]
                deleted_at = iso()
                connection.execute(
                    """UPDATE capability_packages
                       SET status='retired', updated_at=? WHERE id=?""",
                    (deleted_at, capability_id),
                )
                installations = connection.execute(
                    """UPDATE native_workspace_installations
                       SET status='disabled', disabled_at=?
                       WHERE capability_version_id IN (
                         SELECT id FROM capability_package_versions WHERE capability_id=?
                       ) AND status='installed'""",
                    (deleted_at, capability_id),
                ).rowcount
                self._audit(
                    connection,
                    actor,
                    "capability_package.deleted",
                    capability_id,
                    "*",
                    {
                        "name": str(package["name"]),
                        "disabled_installations": int(installations),
                        "retained_historical_agent_versions": int(historical_agent_versions),
                        "retained_historical_runs": int(historical_runs),
                    },
                )
                connection.commit()
            except BaseException:
                connection.rollback()
                raise
        for version_id in version_ids:
            self._loaded.pop(version_id, None)
        return {
            "id": capability_id,
            "deleted": True,
            "mode": "retired",
            "disabled_installations": int(installations),
        }

    def version_view(self, capability_version_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT cpv.*, cp.id AS capability_id, cp.kind, cp.status
                   FROM capability_package_versions cpv
                   JOIN capability_packages cp ON cp.id=cpv.capability_id
                   WHERE cpv.id=?""",
                (capability_version_id,),
            ).fetchone()
            if not row:
                raise KeyError(capability_version_id)
            profile_enabled = connection.execute(
                """SELECT COUNT(*) FROM agent_version_capabilities
                   WHERE capability_version_id=? AND enabled=1""",
                (capability_version_id,),
            ).fetchone()[0]
            runs = connection.execute(
                """SELECT COUNT(*), COALESCE(SUM(tool_call_count), 0),
                          COALESCE(SUM(evidence_count), 0)
                   FROM run_capabilities WHERE capability_version_id=?""",
                (capability_version_id,),
            ).fetchone()
        item = dict(row)
        item["manifest"] = json.loads(item.pop("manifest_json"))
        item["state"] = item.pop("lifecycle_state")
        item["profile_enabled_bindings"] = int(profile_enabled)
        item["process_loaded_runs"] = int(runs[0])
        item["real_called_tool_calls"] = int(runs[1])
        item["evidence_count"] = int(runs[2])
        item["process_loaded"] = capability_version_id in self._loaded
        with self.database.connect() as connection:
            formal = connection.execute(
                """SELECT nwi.id AS installation_id, nwi.install_digest,
                          nra.artifact_digest, nwi.status AS installation_status
                   FROM native_workspace_installations nwi
                   JOIN native_release_artifacts nra ON nra.id=nwi.artifact_id
                   WHERE nwi.capability_version_id=?""",
                (capability_version_id,),
            ).fetchone()
        item["artifact_class"] = "release" if formal else "development"
        item["source_content_digest"] = item["content_digest"]
        item["formal_installation"] = dict(formal) if formal else None
        return item

    def _register_version(
        self,
        connection: Any,
        manifest: CapabilityManifest,
        digest: str,
        actor: str,
    ) -> tuple[str, bool]:
        package = connection.execute(
            "SELECT kind, status FROM capability_packages WHERE id=?", (manifest.id,)
        ).fetchone()
        now = iso()
        if package is None:
            connection.execute(
                """INSERT INTO capability_packages(
                   id, kind, name, description, status, created_at, updated_at
                ) VALUES (?, ?, ?, ?, 'available', ?, ?)""",
                (manifest.id, manifest.kind, manifest.name, manifest.description, now, now),
            )
        elif package["kind"] != manifest.kind:
            raise ValueError("capability id cannot change kind")
        elif package["status"] != "available":
            raise ValueError("unavailable capability cannot receive a new version")
        existing = connection.execute(
            """SELECT id, content_digest FROM capability_package_versions
               WHERE capability_id=? AND version=?""",
            (manifest.id, manifest.version),
        ).fetchone()
        if existing:
            if existing["content_digest"] != digest:
                raise ValueError("capability version content cannot change in place")
            return str(existing["id"]), False
        version_id = new_id("capver")
        connection.execute(
            """INSERT INTO capability_package_versions(
               id, capability_id, version, manifest_json, content_digest,
               capability_api_range, lifecycle_state, created_by, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, 'source-present', ?, ?)""",
            (
                version_id,
                manifest.id,
                manifest.version,
                _canonical_json(
                    {
                        "schema": manifest.schema,
                        "id": manifest.id,
                        "kind": manifest.kind,
                        "version": manifest.version,
                        "name": manifest.name,
                        "description": manifest.description,
                        "capability_api": manifest.capability_api,
                        "distribution": manifest.distribution,
                        "entrypoint": manifest.entrypoint,
                        "content_entrypoint": manifest.content_entrypoint,
                        "trusted_code": manifest.trusted_code,
                        "external_dependencies": list(manifest.external_dependencies),
                        "provided_external_dependencies": list(
                            manifest.provided_external_dependencies
                        ),
                        "python_namespace": manifest.python_namespace,
                    }
                ),
                digest,
                manifest.capability_api,
                actor,
                now,
            ),
        )
        self._audit(
            connection,
            actor,
            "capability_package.source_registered",
            manifest.id,
            manifest.version,
            {"capability_version_id": version_id, "content_digest": digest},
        )
        return version_id, True

    @staticmethod
    def _audit(
        connection: Any,
        actor: str,
        action: str,
        capability_id: str,
        version: str,
        metadata: Mapping[str, Any],
    ) -> None:
        connection.execute(
            """INSERT INTO audit_events(
               actor_type, actor_ref, action, target_type, target_id, target_version,
               result, metadata_json, created_at
            ) VALUES ('operator', ?, ?, 'capability_package', ?, ?, 'succeeded', ?, ?)""",
            (actor, action, capability_id, version, _canonical_json(dict(metadata)), iso()),
        )

    @staticmethod
    def _registration_from_entrypoint(
        workspace_path: Path,
        manifest: CapabilityManifest,
        digest: str,
        *,
        code_root: Path | None = None,
    ) -> CapabilityRegistration:
        if not manifest.entrypoint:
            raise RuntimeError("capability code entrypoint is unavailable")
        package_name, _, function_name = manifest.entrypoint.partition(":")
        import_root = code_root or workspace_path / "src"
        module_path = import_root / package_name / "__init__.py"
        if not module_path.is_file() or not _inside(module_path, import_root):
            raise RuntimeError("capability entrypoint package is unavailable")
        unique_name = f"suwen_capability_{digest[:16]}_{package_name}"
        specification = importlib.util.spec_from_file_location(
            unique_name,
            module_path,
            submodule_search_locations=[str(module_path.parent)],
        )
        if specification is None or specification.loader is None:
            raise RuntimeError("capability entrypoint cannot be loaded")
        module = importlib.util.module_from_spec(specification)
        sys.modules[unique_name] = module
        try:
            specification.loader.exec_module(module)
            register = getattr(module, function_name, None)
            if not callable(register):
                raise RuntimeError("capability entrypoint is not callable")
            api = CapabilityApi(manifest)
            register(api)
            return api.registration
        except BaseException:
            sys.modules.pop(unique_name, None)
            raise

    @staticmethod
    def _registration_from_domain_content(
        workspace_path: Path,
        manifest: CapabilityManifest,
    ) -> CapabilityRegistration:
        if manifest.kind != "domain" or not manifest.content_entrypoint or manifest.trusted_code:
            raise RuntimeError("declarative capability domain contract is invalid")
        return _load_domain_registration(workspace_path, manifest)

    def _loaded_capability(
        self,
        version_id: str,
        manifest: CapabilityManifest,
        digest: str,
        registration: CapabilityRegistration,
        *,
        artifact_digest: str | None = None,
        install_digest: str | None = None,
        installation_id: str | None = None,
        provided_external_bindings: tuple[dict[str, Any], ...] = (),
    ) -> LoadedCapability:
        tools = ToolRegistry()
        if manifest.kind == "tools":
            if registration.prompts or registration.skills:
                raise RuntimeError("tools capability registered domain content")
            for tool in registration.tools:
                provider_id = tool.provider_id or manifest.id

                async def handler(
                    arguments: dict[str, Any],
                    *,
                    _handler=tool.handler,
                    _manifest=manifest,
                    _registry=self,
                    _provided_external_bindings=provided_external_bindings,
                ):
                    tool_arguments = dict(arguments)
                    runtime_context = tool_arguments.pop("_runtime_context", {})
                    if not isinstance(runtime_context, dict):
                        runtime_context = {}
                    context = CapabilityContext(
                        capability_id=_manifest.id,
                        capability_version=_manifest.version,
                        run_id=str(runtime_context["run_id"])
                        if runtime_context.get("run_id") is not None
                        else None,
                        case_id=str(runtime_context["case_id"])
                        if runtime_context.get("case_id") is not None
                        else None,
                        external=_registry._external_access(
                            _manifest,
                            str(runtime_context["run_id"])
                            if runtime_context.get("run_id") is not None
                            else None,
                            _provided_external_bindings,
                        ),
                    )
                    return await _await_if_needed(_handler(tool_arguments, context))

                tools.register(
                    ToolDefinition(
                        name=tool.name,
                        description=tool.description,
                        input_schema=tool.input_schema,
                        risk=tool.risk,
                        timeout_seconds=tool.timeout_seconds,
                        result_contract=tool.result_contract,
                        provider_id=provider_id,
                        resource_class=tool.resource_class,
                        run_call_limit=tool.run_call_limit,
                        run_call_limit_range=tool.run_call_limit_range,
                        equivalence_key=tool.equivalence_key,
                    ),
                    handler,
                )
        elif registration.tools:
            raise RuntimeError("domain capability registered Tools")
        return LoadedCapability(
            version_id=version_id,
            manifest=manifest,
            content_digest=digest,
            tools=tools,
            prompts=registration.prompts,
            skills=registration.skills,
            artifact_digest=artifact_digest,
            install_digest=install_digest,
            installation_id=installation_id,
        )

    def _external_access(
        self,
        manifest: CapabilityManifest,
        run_id: str | None,
        provided_external_bindings: tuple[dict[str, Any], ...] = (),
    ) -> CapabilityExternalAccess:
        executor = self._external_executor
        if self._external_dependency_manager is not None and not self._external_executor_override:
            executor = self._external_dependency_manager.executor_for(
                run_id,
                manifest.external_dependencies,
                provided_bindings=provided_external_bindings,
            )
        return CapabilityExternalAccess(
            {item["id"]: item["contract"] for item in manifest.external_dependencies},
            executor,
        )


async def _await_if_needed(value: Any) -> Any:
    if hasattr(value, "__await__"):
        return await value
    return value


def _capability_content_digest(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(_canonical_json(dict(value)).encode("utf-8")).hexdigest()


def capability_prompt_digest(prompt: CapabilityPrompt) -> str:
    return _capability_content_digest({"id": prompt.id, "content": prompt.content})


def capability_reference_digest(reference: CapabilityReference) -> str:
    return _capability_content_digest(
        {
            "id": reference.id,
            "title": reference.title,
            "description": reference.description,
            "content": reference.content,
            "metadata": dict(reference.metadata),
        }
    )


def capability_skill_digest(skill: CapabilitySkill) -> str:
    return _capability_content_digest(
        {
            "id": skill.id,
            "version": skill.version,
            "name": skill.name,
            "description": skill.description,
            "instructions": skill.instructions,
            "fallback": skill.fallback,
            "is_fallback": skill.is_fallback,
            "applicability": skill.applicability,
            "references": [
                {"id": item.id, "content_digest": capability_reference_digest(item)}
                for item in skill.references
            ],
        }
    )


def capability_skill_registry(loaded: Iterable[LoadedCapability]) -> SkillRegistry:
    """Translate selected domain declarations into the existing Runtime Skill view."""

    skills: list[Skill] = []
    skill_ids: set[str] = set()
    skill_names: set[str] = set()
    for capability in loaded:
        if capability.manifest.kind != "domain":
            continue
        for item in capability.skills:
            if item.id in skill_ids or item.name in skill_names:
                raise ValueError("selected capability packages contain duplicate Skill id or name")
            skill_ids.add(item.id)
            skill_names.add(item.name)
            references = tuple(
                SkillReference(
                    id=reference.id,
                    title=reference.title,
                    description=reference.description,
                    relative_path="",
                    metadata=MappingProxyType(dict(reference.metadata)),
                    content=reference.content,
                    content_digest=capability_reference_digest(reference),
                )
                for reference in item.references
            )
            skills.append(
                Skill(
                    id=item.id,
                    version=item.version,
                    name=item.name,
                    description=item.description,
                    instructions=item.instructions,
                    fallback=item.is_fallback,
                    path=Path("."),
                    references=references,
                    applicability=item.applicability,
                    source_revision=(f"capability:{capability.manifest.id}@{capability.manifest.version}"),
                    content_digest=capability_skill_digest(item),
                )
            )
    return SkillRegistry(skills)


def capability_prompt_text(loaded: Iterable[LoadedCapability]) -> str:
    prompts: list[str] = []
    prompt_ids: set[str] = set()
    for capability in loaded:
        if capability.manifest.kind != "domain":
            continue
        for prompt in capability.prompts:
            if prompt.id in prompt_ids:
                raise ValueError("selected capability packages contain duplicate Prompt id")
            prompt_ids.add(prompt.id)
            if prompt.content.strip():
                prompts.append(prompt.content.strip())
    return "\n\n".join(prompts)


__all__ = [
    "CapabilityBinding",
    "CapabilityPackageRegistry",
    "LoadedCapability",
    "capability_prompt_digest",
    "capability_prompt_text",
    "capability_reference_digest",
    "capability_skill_digest",
    "capability_skill_registry",
    "inspect_capability_package",
]
