from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

HUMAN_REVIEW_DIMENSIONS = (
    "diagnostic_progress",
    "actionable_guidance",
    "continuity_and_evidence_update",
    "evidence_boundary",
    "closure_or_next_hook",
    "investigation_efficiency",
)

CANDIDATE_INTERNAL_SUPPORT_TOOLS = (
    "inspect_claim",
    "find_artifact_text",
    "list_skill_references",
    "read_skill",
    "read_artifact_chunk",
    "read_skill_reference",
    "recall_case_history",
)

CANDIDATE_ALWAYS_AVAILABLE_SUPPORT_TOOLS = (
    "read_skill",
    "recall_case_history",
)


@dataclass(frozen=True)
class RetentionScenario:
    id: str
    category: str
    turns: tuple[str, str]
    expected_skill: str
    allowed_tools: tuple[str, ...]
    boundary: str


@dataclass(frozen=True)
class RetentionSuite:
    schema_version: str
    profile_id: str
    profile_version: str
    data_class: str
    digest: str
    review_rubric: dict[str, str]
    scenarios: tuple[RetentionScenario, ...]


def bundled_retention_suite_path() -> Path:
    return Path(__file__).resolve().parent / "resources" / "acceptance" / "native-retention-v1.json"


def load_retention_suite(path: Path | None = None) -> RetentionSuite:
    from .skills import REFERENCE_TOOL_NAMES

    source = (path or bundled_retention_suite_path()).resolve()
    payload_bytes = source.read_bytes()
    payload = json.loads(payload_bytes)
    if not isinstance(payload, dict) or payload.get("schema_version") != "suwen-native-retention.v1":
        raise ValueError("unsupported retention suite schema")
    baseline = payload.get("baseline")
    review_rubric = payload.get("review_rubric")
    raw_scenarios = payload.get("scenarios")
    if (
        not isinstance(baseline, dict)
        or not isinstance(review_rubric, dict)
        or set(review_rubric) != set(HUMAN_REVIEW_DIMENSIONS)
        or any(not isinstance(value, str) or not value.strip() for value in review_rubric.values())
        or not isinstance(raw_scenarios, list)
    ):
        raise ValueError("retention suite is incomplete")
    scenarios: list[RetentionScenario] = []
    for raw in raw_scenarios:
        if not isinstance(raw, dict):
            raise ValueError("retention scenario must be an object")
        turns = raw.get("turns")
        tools = raw.get("allowed_tools")
        if (
            not isinstance(turns, list)
            or len(turns) != 2
            or any(not isinstance(item, str) or not item for item in turns)
            or not isinstance(tools, list)
            or any(not isinstance(item, str) for item in tools)
        ):
            raise ValueError("retention scenario must contain two turns and a Tool allowlist")
        scenarios.append(
            RetentionScenario(
                id=str(raw["id"]),
                category=str(raw["category"]),
                turns=(turns[0], turns[1]),
                expected_skill=str(raw["expected_skill"]),
                allowed_tools=tuple(tools),
                boundary=str(raw["boundary"]),
            )
        )
    if len(scenarios) != 10 or len({item.id for item in scenarios}) != len(scenarios):
        raise ValueError("native retention suite must contain ten unique scenarios")
    active_skills = {item.expected_skill for item in scenarios}
    if not active_skills:
        raise ValueError("native retention suite must exercise at least one Skill")
    support_tools = set(CANDIDATE_INTERNAL_SUPPORT_TOOLS) | set(REFERENCE_TOOL_NAMES)
    connector_tools = {
        tool for item in scenarios for tool in item.allowed_tools if tool not in support_tools
    }
    if not connector_tools:
        raise ValueError("native retention suite must exercise Connector Tools")
    return RetentionSuite(
        schema_version=str(payload["schema_version"]),
        profile_id=str(baseline["profile_id"]),
        profile_version=str(baseline["profile_version"]),
        data_class=str(baseline["data_class"]),
        digest=hashlib.sha256(payload_bytes).hexdigest(),
        review_rubric={key: str(review_rubric[key]) for key in HUMAN_REVIEW_DIMENSIONS},
        scenarios=tuple(scenarios),
    )


def candidate_manifest(
    path: Path | None = None,
    *,
    max_model_turns: int = 60,
    max_elapsed_seconds: int = 15 * 60,
) -> dict[str, Any]:
    suite = load_retention_suite(path)
    expected_skills = sorted({scenario.expected_skill for scenario in suite.scenarios})
    support_contracts = set(CANDIDATE_INTERNAL_SUPPORT_TOOLS)
    allowed_tools = sorted(
        {
            tool
            for scenario in suite.scenarios
            for tool in scenario.allowed_tools
            if tool not in support_contracts
        }
    )
    support_tools = sorted(
        {
            tool
            for scenario in suite.scenarios
            for tool in scenario.allowed_tools
            if tool in set(CANDIDATE_INTERNAL_SUPPORT_TOOLS)
        }
        | set(CANDIDATE_ALWAYS_AVAILABLE_SUPPORT_TOOLS)
    )
    return {
        "schema_version": "suwen-candidate-manifest.v1",
        "suite_digest": suite.digest,
        "scenario_count": len(suite.scenarios),
        "episode_count": len(suite.scenarios),
        "turns_per_episode": 2,
        "agent_profile": {"id": suite.profile_id, "version": suite.profile_version},
        "data_class": suite.data_class,
        "coverage": {
            "expected_skills": expected_skills,
            "expected_skill_count": len(expected_skills),
            "candidate_allowlist_tools": allowed_tools,
            "candidate_allowlist_tool_count": len(allowed_tools),
            "candidate_support_tools": support_tools,
            "candidate_support_tool_count": len(support_tools),
            "tool_contract_count": len(allowed_tools),
            "claim_boundary": (
                "全部声明的 Skill 均有行为场景；Tool 只有实际调用并经人工复核后才算影响已观察，"
                "其余仅证明契约装配；本地主张、Artifact 与 Skill reference 支撑工具单列，"
                "不计入 Connector Tool 行为覆盖或外部来源调用。Tool 名由冻结场景数据与"
                "Agent 实际 Connector catalog 共同校验，不在 Runtime 写死业务白名单。"
            ),
        },
        "execution_policy": {
            "runs_per_scenario": 1,
            "automatic_reruns": 0,
            "max_tool_calls_per_run": 60,
            "max_tool_waves_per_run": 30,
            "max_parallel_read_only": 6,
            "max_model_turns_total": max_model_turns,
            "max_elapsed_seconds": max_elapsed_seconds,
            "source_calls": 0,
            "external_writes": 0,
        },
        "human_review_dimensions": list(HUMAN_REVIEW_DIMENSIONS),
        "human_review_rubric": suite.review_rubric,
        "stop_conditions": [
            "preflight_invalid",
            "unauthorized_source_observed",
            "external_write_observed",
            "model_turn_budget_exhausted",
            "elapsed_time_budget_exhausted",
            "infrastructure_failure",
        ],
        "status": "frozen_not_run",
    }
