from __future__ import annotations

import json
import re

STREAMING_ELEMENT_ID = "streaming_content"
_MESSAGE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{2,127}$")
_STALE_IDENTIFIER_LINE = re.compile(r"(?m)^\s*(?:会话|对话|消息)\s*ID\s*[：:]\s*[^\n]+\s*$")
_ARTIFACT_IMAGE = re.compile(
    r"!\[([^\]\n]{0,200})\]\(artifact://(artifact_[A-Za-z0-9]+)\)"
)


def streaming_card(content: str = "...") -> dict[str, object]:
    """Build the CardKit streaming shell used by the Feishu channel."""

    return {
        "schema": "2.0",
        "config": {"streaming_mode": True},
        "body": {
            "elements": [
                {
                    "tag": "markdown",
                    "content": content,
                    "element_id": STREAMING_ELEMENT_ID,
                }
            ]
        },
    }


def markdown_card(content: str) -> dict[str, object]:
    """Build one non-streaming CardKit card from canonical Markdown."""

    return {
        "schema": "2.0",
        "config": {
            "streaming_mode": False,
            "summary": {"content": card_summary(content) or "素问答复"},
        },
        "body": {
            "elements": [
                {
                    "tag": "markdown",
                    "content": content,
                    "element_id": "answer_content",
                }
            ]
        },
    }


def adapt_markdown_for_feishu(text: str) -> tuple[str, tuple[dict[str, str], ...]]:
    """Keep Markdown canonical while extracting local Run images for upload.

    `artifact://` is intentionally private to Suwen's authenticated Case view.
    Feishu cannot fetch it, so the adapter leaves a readable anchor in the card
    and returns exact Case-bound handles for subsequent image replies.
    """

    images: list[dict[str, str]] = []
    seen: set[str] = set()

    def replace(match: re.Match[str]) -> str:
        alt = match.group(1).strip() or "说明图"
        artifact_id = match.group(2)
        if artifact_id not in seen:
            seen.add(artifact_id)
            images.append({"artifact_id": artifact_id, "alt": alt})
        return f"> 🖼️ **{alt}**（见紧随本答复的图片）"

    return _ARTIFACT_IMAGE.sub(replace, text), tuple(images)


def card_reference(card_id: str) -> str:
    return json.dumps(
        {"type": "card", "data": {"card_id": card_id}},
        ensure_ascii=False,
        separators=(",", ":"),
    )


def apply_message_footer(text: str, message_id: str) -> str:
    """Append exactly one Feishu-visible ID backed by the persisted assistant Msg.id."""

    if not _MESSAGE_ID.fullmatch(message_id):
        raise ValueError("invalid persisted message id")
    retained: list[str] = []
    for line in text.rstrip().splitlines():
        if _STALE_IDENTIFIER_LINE.fullmatch(line):
            while retained and not retained[-1].strip():
                retained.pop()
            if retained and retained[-1].strip() == "---":
                retained.pop()
            continue
        retained.append(line)
    body = "\n".join(retained).strip()
    return f"{body}\n\n---\n消息 ID：{message_id}" if body else f"---\n消息 ID：{message_id}"


def card_summary(text: str, limit: int = 80) -> str:
    compact = " ".join(text.split())
    return compact if len(compact) <= limit else compact[: limit - 1] + "…"
