from __future__ import annotations

import argparse
import asyncio
import ipaddress
import json
import os
import sqlite3
import subprocess
import sys
import time
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

import httpx
import uvicorn

from .acceptance import build_delivery_preflight
from .access_tokens import provision_access_token_bundle
from .api import create_app
from .canary import HUMAN_REVIEW_DIMENSIONS, candidate_manifest
from .candidate import CandidateAlreadyAttempted, CandidateRegistry, CandidateRunner
from .capability_installations import NativeReleaseManager
from .capability_packages import CapabilityPackageRegistry
from .config import load_settings
from .db import SUWEN_AGENT_ID, Database
from .deployment import ReleaseManager, RuntimeLayout, configure_product_runtime
from .external_dependencies import ExternalDependencyManager
from .operations import OperationsView
from .release_artifacts import build_release_artifact, verify_release_artifact
from .release_channel import publish_release_channel, serve_release_channel
from .repository import iso
from .service_manager import (
    render_launchd_plist,
    render_release_channel_launchd_plist,
    render_systemd_unit,
    write_new_service_file,
)


def validate_serve_security(
    host: str,
    api_token: str,
    admin_token: str,
    *,
    access_tokens_expired: bool = False,
) -> None:
    normalized_host = host.strip().strip("[]")
    try:
        loopback = ipaddress.ip_address(normalized_host).is_loopback
    except ValueError:
        loopback = normalized_host.lower() == "localhost"
    if not loopback and access_tokens_expired:
        raise ValueError("non-loopback serving requires unexpired access tokens")
    if not loopback and (not api_token or not admin_token):
        raise ValueError("non-loopback serving requires both API and admin tokens to be configured")


def normalize_loopback_base_url(value: str) -> str:
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError as exc:
        raise ValueError("local observation URL is invalid") from exc
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("local observation URL must use http or https")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("local observation URL cannot contain credentials, query, or fragment")
    if parsed.path not in {"", "/"}:
        raise ValueError("local observation URL must point to the service root")
    normalized_host = parsed.hostname.strip().strip("[]")
    try:
        loopback = ipaddress.ip_address(normalized_host).is_loopback
    except ValueError:
        loopback = normalized_host.lower() == "localhost"
    if not loopback:
        raise ValueError("local observation URL must use a loopback host")
    netloc = parsed.hostname
    if ":" in netloc and not netloc.startswith("["):
        netloc = f"[{netloc}]"
    if port is not None:
        netloc = f"{netloc}:{port}"
    return urlunsplit((parsed.scheme, netloc, "", "", ""))


def management_headers(settings: object) -> dict[str, str]:
    token = getattr(settings, "viewer_token", "") or getattr(settings, "admin_token", "")
    return {"Authorization": f"Bearer {token}"} if token else {}


def _is_managed_product_runtime(
    module_path: str | Path,
    layout: RuntimeLayout,
    *,
    explicit_home: bool,
) -> bool:
    """Distinguish an installed Runtime CLI from the repository's dev entrypoint."""
    if explicit_home:
        return True
    try:
        Path(module_path).expanduser().resolve().relative_to(layout.home)
    except ValueError:
        return False
    return True


def _managed_runtime_admin_headers(layout: RuntimeLayout) -> dict[str, str]:
    token_file = layout.data / "private" / "access-tokens.json"
    try:
        payload = json.loads(token_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("managed runtime activation requires the product access token file") from exc
    token = payload.get("admin_token") if isinstance(payload, dict) else None
    if not isinstance(token, str) or not token:
        raise ValueError("managed runtime activation requires an admin token")
    return {"Authorization": f"Bearer {token}"}


def _runtime_health(client: httpx.Client, base_url: str) -> dict[str, object]:
    response = client.get(f"{base_url}/health")
    response.raise_for_status()
    payload = response.json()
    if payload.get("service_id") != "suwen" or payload.get("contract_version") != "suwen-health.v1":
        raise RuntimeError("managed runtime activation found an unexpected health contract")
    return payload


def _activation_health_failure(
    health: dict[str, object],
    baseline_health: dict[str, object],
) -> str | None:
    """Return why a loaded worker is not yet safe to accept as activated."""

    if health.get("status") != "ready":
        return "new worker is not ready"
    readiness = health.get("runtime_readiness")
    if isinstance(readiness, dict) and readiness.get("ready") is not True:
        return "new worker runtime readiness has not converged"
    availability = health.get("message_availability")
    if isinstance(availability, dict) and availability.get("draining") is not False:
        return "new worker is still draining"
    if health.get("activation_handoff_error") is not None:
        return "new worker reports an activation handoff error"
    channels = health.get("managed_channels")
    if isinstance(channels, list):
        for item in channels:
            if not isinstance(item, dict):
                return "new worker returned an invalid managed Channel projection"
            if item.get("status") != "active" or item.get("mode") != "long_connection":
                continue
            if item.get("health_state") != "connected" or item.get("reply_ready") is not True:
                return f"managed Channel {item.get('id') or 'unknown'} is not reply-ready"
    expected_configuration = baseline_health.get("runtime_configuration_digest")
    if isinstance(expected_configuration, str) and expected_configuration:
        if health.get("runtime_configuration_digest") != expected_configuration:
            return "runtime Agent/Channel configuration changed during activation"
    return None


def activate_updated_release(
    manager: ReleaseManager,
    update_result: dict[str, object],
    baseline_health: dict[str, object],
    *,
    base_url: str,
    timeout_seconds: float,
    client: httpx.Client | None = None,
    poll_seconds: float = 0.25,
) -> dict[str, object]:
    activation = update_result.get("activation")
    if not isinstance(activation, dict):
        return update_result
    activation_id = activation.get("activation_id")
    target_release = activation.get("target_release")
    previous_release = activation.get("from_release")
    if not all(isinstance(value, str) and value for value in (activation_id, target_release)):
        raise RuntimeError("managed runtime activation metadata is incomplete")
    if not isinstance(previous_release, str) or not previous_release:
        raise RuntimeError("managed runtime activation has no rollback target")
    baseline_loaded_release = baseline_health.get("loaded_release")
    if baseline_loaded_release == target_release:
        manager.complete_activation(
            activation_id,
            process_instance_id=str(baseline_health["process_instance_id"]),
        )
        retention = manager.prune_superseded_releases()
        return {
            **update_result,
            "service_action": "managed_release_already_loaded",
            "service_restart_required": False,
            "loaded_release": target_release,
            "process_instance_id": baseline_health["process_instance_id"],
            "release_retention": retention,
        }
    if baseline_loaded_release != previous_release:
        manager.rollback(previous_release)
        raise RuntimeError(
            "managed runtime activation refused because the loaded worker does not match "
            "the previous release; previous release restored"
        )
    normalized_url = normalize_loopback_base_url(base_url)
    owned_client = client is None
    runtime_client = client or httpx.Client(
        headers=_managed_runtime_admin_headers(manager.layout),
        timeout=5,
    )
    try:
        try:
            response = runtime_client.post(
                f"{normalized_url}/api/v1/admin/runtime/activate-release",
                json={"activation_id": activation_id, "target_release": target_release},
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            rollback = manager.rollback(previous_release)
            rollback_activation = rollback.get("activation")
            if isinstance(rollback_activation, dict):
                manager.complete_activation(
                    str(rollback_activation["activation_id"]),
                    process_instance_id=str(baseline_health["process_instance_id"]),
                )
            raise RuntimeError(
                "managed runtime activation request failed; previous release restored"
            ) from exc
        baseline_instance = baseline_health.get("process_instance_id")
        deadline = time.monotonic() + timeout_seconds
        last_error = "new worker did not become ready"
        while time.monotonic() < deadline:
            try:
                health = _runtime_health(runtime_client, normalized_url)
            except (httpx.HTTPError, RuntimeError) as exc:
                last_error = str(exc)
            else:
                readiness_failure = _activation_health_failure(health, baseline_health)
                if (
                    readiness_failure is None
                    and health.get("loaded_release") == target_release
                    and health.get("process_instance_id") != baseline_instance
                ):
                    manager.complete_activation(
                        activation_id,
                        process_instance_id=str(health["process_instance_id"]),
                    )
                    retention = manager.prune_superseded_releases()
                    return {
                        **update_result,
                        "service_action": "managed_handoff_completed",
                        "service_restart_required": False,
                        "loaded_release": target_release,
                        "process_instance_id": health["process_instance_id"],
                        "release_retention": retention,
                    }
                if readiness_failure is not None:
                    last_error = readiness_failure
            time.sleep(poll_seconds)

        rollback = manager.rollback(previous_release)
        rollback_activation = rollback.get("activation")
        if isinstance(rollback_activation, dict):
            try:
                runtime_client.post(
                    f"{normalized_url}/api/v1/admin/runtime/activate-release",
                    json={
                        "activation_id": rollback_activation["activation_id"],
                        "target_release": previous_release,
                    },
                )
            except httpx.HTTPError:
                pass
        recovery_deadline = time.monotonic() + timeout_seconds
        while time.monotonic() < recovery_deadline:
            try:
                recovered = _runtime_health(runtime_client, normalized_url)
            except (httpx.HTTPError, RuntimeError):
                time.sleep(poll_seconds)
                continue
            if recovered.get("status") == "ready" and recovered.get("loaded_release") == previous_release:
                if isinstance(rollback_activation, dict):
                    manager.complete_activation(
                        str(rollback_activation["activation_id"]),
                        process_instance_id=str(recovered["process_instance_id"]),
                    )
                raise RuntimeError(
                    f"new Suwen worker activation failed; previous release restored: {last_error}"
                )
            time.sleep(poll_seconds)
        raise RuntimeError(
            "new Suwen worker activation failed and previous release recovery was not verified"
        )
    finally:
        if owned_client:
            runtime_client.close()


def parse_candidate_review_input(
    source: object,
    attempt_id: str,
) -> tuple[
    str,
    dict[str, dict[str, str]],
    dict[str, bool],
    dict[str, bool | None],
    dict[str, str],
    str,
]:
    if not isinstance(source, dict):
        raise ValueError("candidate review input must be one JSON object")
    allowed = {
        "schema_version",
        "candidate_attempt_id",
        "scorecard_digest",
        "review_context",
        "episode_dimensions",
        "skill_influence_observed",
        "tool_influence_observed",
        "influence_notes",
        "note",
    }
    if set(source) - allowed:
        raise ValueError("candidate review input contains unsupported fields")
    if source.get("schema_version") != "suwen-candidate-review-input.v3":
        raise ValueError("unsupported candidate review input schema")
    if source.get("candidate_attempt_id") != attempt_id:
        raise ValueError("candidate review input does not match --attempt")
    scorecard_digest = source.get("scorecard_digest")
    if (
        not isinstance(scorecard_digest, str)
        or len(scorecard_digest) != 64
        or any(character not in "0123456789abcdef" for character in scorecard_digest)
    ):
        raise ValueError("candidate review input requires a scorecard sha256 digest")
    raw_dimensions = source.get("episode_dimensions")
    raw_skill_influence = source.get("skill_influence_observed")
    raw_tool_influence = source.get("tool_influence_observed")
    raw_influence_notes = source.get("influence_notes")
    review_context = source.get("review_context")
    if not isinstance(raw_dimensions, dict) or not raw_dimensions:
        raise ValueError("candidate review input requires episode_dimensions")
    if not isinstance(raw_skill_influence, dict) or set(raw_skill_influence) != set(raw_dimensions):
        raise ValueError("candidate review input requires Skill influence for every episode")
    if not isinstance(raw_tool_influence, dict) or set(raw_tool_influence) != set(raw_dimensions):
        raise ValueError("candidate review input requires Tool influence for every episode")
    if not isinstance(raw_influence_notes, dict) or set(raw_influence_notes) != set(raw_dimensions):
        raise ValueError("candidate review input requires influence notes for every episode")
    if not isinstance(review_context, dict) or set(review_context) != set(raw_dimensions):
        raise ValueError("candidate review input requires evidence context for every episode")
    dimensions: dict[str, dict[str, str]] = {}
    skill_influence: dict[str, bool] = {}
    tool_influence: dict[str, bool | None] = {}
    influence_notes: dict[str, str] = {}
    for episode_id, raw_values in raw_dimensions.items():
        if not isinstance(episode_id, str) or not episode_id or not isinstance(raw_values, dict):
            raise ValueError("candidate review episode dimensions are invalid")
        if not isinstance(review_context[episode_id], dict):
            raise ValueError("candidate review episode evidence context is invalid")
        if set(raw_values) != set(HUMAN_REVIEW_DIMENSIONS):
            raise ValueError("candidate review requires all six dimensions for every episode")
        if any(value not in {"passed", "failed"} for value in raw_values.values()):
            raise ValueError("candidate review dimensions must be passed or failed")
        dimensions[episode_id] = {
            dimension: str(raw_values[dimension]) for dimension in HUMAN_REVIEW_DIMENSIONS
        }
        skill_observed = raw_skill_influence[episode_id]
        if type(skill_observed) is not bool:
            raise ValueError("candidate review Skill influence observations must be boolean")
        skill_influence[episode_id] = skill_observed
        context = review_context[episode_id]
        actual_tools = context.get("actual_tools")
        if not isinstance(actual_tools, list) or any(not isinstance(value, str) for value in actual_tools):
            raise ValueError("candidate review actual Tool evidence is invalid")
        tool_observed = raw_tool_influence[episode_id]
        if actual_tools and type(tool_observed) is not bool:
            raise ValueError("candidate review Tool influence must be boolean after a Tool call")
        if not actual_tools and tool_observed is not None:
            raise ValueError("candidate review Tool influence must be null without a Tool call")
        tool_influence[episode_id] = tool_observed
        influence_note = raw_influence_notes[episode_id]
        if not isinstance(influence_note, str) or not influence_note.strip() or len(influence_note) > 1000:
            raise ValueError("candidate review influence notes must be non-empty")
        influence_notes[episode_id] = influence_note.strip()
    note = source.get("note", "")
    if not isinstance(note, str):
        raise ValueError("candidate review note must be text")
    return (
        scorecard_digest,
        dimensions,
        skill_influence,
        tool_influence,
        influence_notes,
        note,
    )


def main() -> None:
    default_runtime_port = 18090
    parser = argparse.ArgumentParser(prog="suwen")
    parser.add_argument("--config", default=None)
    parser.add_argument("--home", default=None, help="Suwen installation root (default: ~/.suwen)")
    subparsers = parser.add_subparsers(dest="command", required=True)
    install = subparsers.add_parser("install")
    install.add_argument("--source", default=".")
    update = subparsers.add_parser("update")
    update.add_argument("--source", default=None)
    update.add_argument("--activate", action="store_true")
    update.add_argument("--url", default="http://127.0.0.1:8090")
    update.add_argument("--activation-timeout-seconds", type=float, default=1860.0)
    subparsers.add_parser("status")
    rollback = subparsers.add_parser("rollback")
    rollback.add_argument("--release", default=None)
    release_build = subparsers.add_parser("release-build")
    release_build.add_argument("--source", required=True)
    release_build.add_argument("--output", required=True)
    release_build.add_argument("--source-revision", required=True)
    release_build.add_argument("--rollback-target", default=None)
    release_verify = subparsers.add_parser("release-verify")
    release_verify.add_argument("--artifact", required=True)
    release_verify.add_argument("--expected-sha256", default=None)
    channel_publish = subparsers.add_parser("release-channel-publish")
    channel_publish.add_argument("--wheel", required=True)
    channel_publish.add_argument("--repository", required=True)
    channel_publish.add_argument("--git-commit", required=True)
    channel_publish.add_argument("--git-tree", required=True)
    channel_publish.add_argument("--candidate-id", required=True)
    channel_publish.add_argument("--acceptance-sha256", required=True)
    channel_serve = subparsers.add_parser("release-channel-serve")
    channel_serve.add_argument("--repository", required=True)
    channel_serve.add_argument("--host", default="0.0.0.0")
    channel_serve.add_argument("--port", type=int, default=4020)
    native_import = subparsers.add_parser("native-release-import")
    native_import.add_argument("--artifact", required=True)
    native_import.add_argument("--expected-sha256", required=True)
    native_import.add_argument("--trust-code", action="store_true")
    native_install = subparsers.add_parser("native-release-install")
    native_install.add_argument("--artifact-sha256", required=True)
    native_install.add_argument("--trust-code", action="store_true")
    external_preview = subparsers.add_parser("external-cli-preview")
    external_preview.add_argument("--dependency", required=True)
    external_preview.add_argument("--contract", required=True)
    external_preview.add_argument("--command", dest="cli_command", required=True)
    external_configure = subparsers.add_parser("external-cli-configure")
    external_configure.add_argument("--dependency", required=True)
    external_configure.add_argument("--contract", required=True)
    external_configure.add_argument("--command", dest="cli_command", required=True)
    external_configure.add_argument("--allow-subcommand", action="append", required=True)
    external_configure.add_argument("--timeout-seconds", type=float, default=30.0)
    external_configure.add_argument("--max-output-bytes", type=int, default=128 * 1024)
    external_inspect = subparsers.add_parser("external-cli-inspect")
    external_inspect.add_argument("--binding-id", default=None)
    external_disable = subparsers.add_parser("external-cli-disable")
    external_disable.add_argument("--dependency", required=True)
    external_disable.add_argument("--contract", required=True)
    subparsers.add_parser("init-db")
    subparsers.add_parser("check-db")
    candidate = subparsers.add_parser("candidate-manifest")
    candidate.add_argument("--suite", default=None)
    candidate_preflight = subparsers.add_parser("candidate-preflight")
    candidate_preflight.add_argument("--agent", default=SUWEN_AGENT_ID)
    candidate_run = subparsers.add_parser("candidate-run")
    candidate_run.add_argument("--agent", default=SUWEN_AGENT_ID)
    candidate_status = subparsers.add_parser("candidate-status")
    candidate_status.add_argument("--attempt", default=None)
    candidate_review_template = subparsers.add_parser("candidate-review-template")
    candidate_review_template.add_argument("--attempt", required=True)
    candidate_review = subparsers.add_parser("candidate-review")
    candidate_review.add_argument("--attempt", required=True)
    candidate_review.add_argument("--decision", choices=("approved", "rejected"), required=True)
    candidate_review.add_argument("--review", required=True)
    candidate_review.add_argument("--note", default=None)
    delivery_preflight = subparsers.add_parser("delivery-preflight")
    delivery_preflight.add_argument("--agent", default=SUWEN_AGENT_ID)
    delivery_preflight.add_argument(
        "--require",
        choices=("candidate-ready", "delivery-complete"),
        default=None,
    )
    delivery_preflight.add_argument(
        "--url",
        default=None,
        help="从正在运行的本机实例读取准出；delivery-complete 必须使用此入口",
    )
    stability = subparsers.add_parser("observe-stability")
    stability.add_argument("--agent", default=SUWEN_AGENT_ID)
    stability.add_argument("--url", default=f"http://127.0.0.1:{default_runtime_port}")
    stability.add_argument("--interval-seconds", type=float, default=5.0)
    stability.add_argument("--timeout-seconds", type=float, default=10.0)
    backup = subparsers.add_parser("backup-db")
    backup.add_argument("--output", required=True)
    provision_tokens = subparsers.add_parser("provision-access-tokens")
    provision_tokens.add_argument("--ttl-days", type=int, default=365)
    provision_tokens.add_argument("--rotate", action="store_true")
    launchd = subparsers.add_parser("render-launchd-service")
    launchd.add_argument("--output", required=True)
    launchd.add_argument("--project-root", default=".")
    launchd.add_argument("--label", default="com.keyu.suwen")
    launchd.add_argument("--host", default="127.0.0.1")
    launchd.add_argument("--port", type=int, default=8090)
    channel_launchd = subparsers.add_parser("render-release-channel-launchd-service")
    channel_launchd.add_argument("--output", required=True)
    channel_launchd.add_argument("--executable", required=True)
    channel_launchd.add_argument("--repository", required=True)
    channel_launchd.add_argument("--label", default="com.keyu.suwen-release-channel")
    channel_launchd.add_argument("--host", default="0.0.0.0")
    channel_launchd.add_argument("--port", type=int, default=4020)
    systemd = subparsers.add_parser("render-systemd-service")
    systemd.add_argument("--output", required=True)
    systemd.add_argument("--project-root", default=".")
    systemd.add_argument("--label", default="suwen.service")
    systemd.add_argument("--user", default=None)
    systemd.add_argument("--host", default="127.0.0.1")
    systemd.add_argument("--port", type=int, default=4010)
    serve = subparsers.add_parser("serve")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=default_runtime_port)
    args = parser.parse_args()
    try:
        if args.command == "release-build":
            artifact = build_release_artifact(
                Path(args.source),
                Path(args.output),
                source_revision=args.source_revision,
                rollback_target=args.rollback_target,
            )
            print(json.dumps(artifact.public_view(), ensure_ascii=False, sort_keys=True))
            return
        if args.command == "release-verify":
            artifact = verify_release_artifact(
                Path(args.artifact),
                expected_digest=args.expected_sha256,
            )
            print(json.dumps(artifact.public_view(), ensure_ascii=False, sort_keys=True))
            return
        if args.command == "release-channel-publish":
            result = publish_release_channel(
                args.wheel,
                args.repository,
                source_identity={
                    "git_commit": args.git_commit,
                    "git_tree": args.git_tree,
                    "candidate_id": args.candidate_id,
                    "acceptance_sha256": args.acceptance_sha256,
                },
            )
            print(json.dumps(result, ensure_ascii=False, sort_keys=True))
            return
        if args.command == "release-channel-serve":
            serve_release_channel(args.repository, host=args.host, port=args.port)
            return
        if args.command in {"install", "update", "status", "rollback"}:
            layout = RuntimeLayout.resolve(args.home)
            releases = ReleaseManager(layout)
            if args.command == "install":
                print(
                    json.dumps(
                        releases.install(args.source),
                        ensure_ascii=False,
                        sort_keys=True,
                    )
                )
                return
            if args.command == "update":
                baseline_health = None
                if args.activate:
                    normalized_url = normalize_loopback_base_url(args.url)
                    with httpx.Client(timeout=5) as health_client:
                        baseline_health = _runtime_health(health_client, normalized_url)
                    if args.activation_timeout_seconds <= 0 or args.activation_timeout_seconds > 2100:
                        raise ValueError("activation timeout must be between 0 and 2100 seconds")
                result = releases.update(args.source)
                if args.activate and isinstance(result.get("activation"), dict):
                    result = activate_updated_release(
                        releases,
                        result,
                        baseline_health or {},
                        base_url=args.url,
                        timeout_seconds=args.activation_timeout_seconds,
                    )
                print(
                    json.dumps(
                        result,
                        ensure_ascii=False,
                        sort_keys=True,
                    )
                )
                return
            if args.command == "status":
                print(json.dumps(releases.status(), ensure_ascii=False, sort_keys=True))
                return
            if args.command == "rollback":
                print(
                    json.dumps(
                        releases.rollback(args.release),
                        ensure_ascii=False,
                        sort_keys=True,
                    )
                )
                return
        layout = RuntimeLayout.resolve(args.home)
        if _is_managed_product_runtime(
            __file__,
            layout,
            explicit_home=args.home is not None,
        ):
            configure_product_runtime(layout)
            if args.config is None:
                args.config = str(layout.config)
    except (OSError, RuntimeError, ValueError, subprocess.CalledProcessError, httpx.HTTPError) as exc:
        parser.error(str(exc))
    settings = load_settings(args.config)
    if args.command in {
        "external-cli-preview",
        "external-cli-configure",
        "external-cli-inspect",
        "external-cli-disable",
    }:
        database = Database(
            settings.database_path,
            enable_test_fixture_agent=settings.enable_test_fixture_agent,
        )
        try:
            database.initialize()
            manager = ExternalDependencyManager(database)
            if args.command == "external-cli-preview":
                result = manager.preview(args.dependency, args.contract, args.cli_command)
            elif args.command == "external-cli-configure":
                result = manager.configure(
                    args.dependency,
                    args.contract,
                    args.cli_command,
                    "cli:local-admin",
                    allowed_subcommands=tuple(args.allow_subcommand),
                    timeout_seconds=args.timeout_seconds,
                    max_output_bytes=args.max_output_bytes,
                )
            elif args.command == "external-cli-inspect":
                result = (
                    manager.binding_view(args.binding_id)
                    if args.binding_id
                    else {"items": manager.list_bindings()}
                )
            else:
                result = manager.disable(args.dependency, args.contract, "cli:local-admin")
        except (KeyError, OSError, RuntimeError, ValueError, sqlite3.Error) as exc:
            parser.error(str(exc))
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    elif args.command in {"native-release-import", "native-release-install"}:
        database = Database(
            settings.database_path,
            enable_test_fixture_agent=settings.enable_test_fixture_agent,
        )
        try:
            database.initialize()
            capability_packages = CapabilityPackageRegistry(
                database,
                settings.data_dir / "capability-packages",
            )
            native_releases = NativeReleaseManager(
                database,
                settings.data_dir / "native-releases",
                capability_packages,
            )
            if args.command == "native-release-import":
                result = native_releases.import_artifact(
                    Path(args.artifact),
                    "cli:local-admin",
                    expected_digest=args.expected_sha256,
                    trust_code=args.trust_code,
                )
            else:
                result = native_releases.install_artifact(
                    args.artifact_sha256,
                    "cli:local-admin",
                    trust_code=args.trust_code,
                )
        except (KeyError, OSError, PermissionError, RuntimeError, ValueError, sqlite3.Error) as exc:
            parser.error(str(exc))
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    elif args.command == "init-db":
        database = Database(
            settings.database_path,
            enable_test_fixture_agent=settings.enable_test_fixture_agent,
        )
        try:
            result = database.initialize()
        except (OSError, RuntimeError, ValueError, sqlite3.Error) as exc:
            parser.error(str(exc))
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    elif args.command == "check-db":
        database = Database(
            settings.database_path,
            enable_test_fixture_agent=settings.enable_test_fixture_agent,
        )
        report = database.check()
        print(json.dumps(report, ensure_ascii=False, sort_keys=True))
        if not report["ready"]:
            raise SystemExit(1)
    elif args.command == "candidate-manifest":
        print(
            json.dumps(
                candidate_manifest(
                    Path(args.suite) if args.suite else None,
                    max_model_turns=settings.candidate.max_model_turns,
                    max_elapsed_seconds=settings.candidate.max_elapsed_seconds,
                ),
                # The manifest is configuration evidence, so it must expose the
                # same frozen budget candidate-run will enforce.
                ensure_ascii=False,
                sort_keys=True,
            )
        )
    elif args.command == "candidate-preflight":
        result = CandidateRunner(settings).preflight(args.agent)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    elif args.command == "candidate-run":
        try:
            result = asyncio.run(
                CandidateRunner(settings).run(
                    agent_id=args.agent,
                    actor="cli:local-admin",
                )
            )
        except CandidateAlreadyAttempted as exc:
            print(json.dumps({"status": "already_attempted", "detail": str(exc)}))
            raise SystemExit(2) from exc
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        if result["status"] not in {
            "completed_pending_human_review",
            "outcome_reviewed",
        }:
            raise SystemExit(1)
    elif args.command == "candidate-status":
        database = Database(
            settings.database_path,
            enable_test_fixture_agent=settings.enable_test_fixture_agent,
        )
        database.initialize()
        registry = CandidateRegistry(database)
        result: object = (
            registry.get_attempt(args.attempt) if args.attempt else {"items": registry.list_attempts()}
        )
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    elif args.command == "candidate-review-template":
        database = Database(
            settings.database_path,
            enable_test_fixture_agent=settings.enable_test_fixture_agent,
        )
        database.initialize()
        try:
            result = CandidateRegistry(database).review_template(args.attempt)
        except (KeyError, ValueError) as exc:
            parser.error(str(exc))
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    elif args.command == "candidate-review":
        database = Database(
            settings.database_path,
            enable_test_fixture_agent=settings.enable_test_fixture_agent,
        )
        database.initialize()
        source: object
        try:
            if args.review == "-":
                source = json.load(sys.stdin)
            else:
                source = json.loads(Path(args.review).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            parser.error(f"candidate review input could not be read: {type(exc).__name__}")
        try:
            (
                scorecard_digest,
                episode_dimensions,
                skill_influence_observed,
                tool_influence_observed,
                influence_notes,
                payload_note,
            ) = parse_candidate_review_input(source, args.attempt)
            registry = CandidateRegistry(database)
            canonical_template = registry.review_template(args.attempt)
            if source.get("review_context") != canonical_template["review_context"]:
                raise ValueError("candidate review evidence context does not match the scorecard")
            result = registry.human_review(
                args.attempt,
                "cli:local-reviewer",
                args.decision,
                scorecard_digest,
                episode_dimensions,
                skill_influence_observed,
                tool_influence_observed,
                influence_notes,
                args.note if args.note is not None else payload_note,
            )
        except (KeyError, ValueError) as exc:
            parser.error(str(exc))
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    elif args.command == "delivery-preflight":
        try:
            if args.url:
                base_url = normalize_loopback_base_url(args.url)
                with httpx.Client(
                    base_url=base_url,
                    headers=management_headers(settings),
                    timeout=10.0,
                ) as client:
                    response = client.get(
                        "/api/v1/admin/delivery-preflight",
                        params={"agent_id": args.agent},
                    )
                    response.raise_for_status()
                    result = response.json()
                if not isinstance(result, dict) or result.get("schema_version") != (
                    "suwen-delivery-preflight.v1"
                ):
                    raise ValueError("live delivery preflight returned an unsupported schema")
            else:
                if args.require == "delivery-complete":
                    raise ValueError("delivery-complete requires --url for live process evidence")
                result = build_delivery_preflight(settings).inspect(
                    args.agent,
                    scheduler_running=False,
                )
        except (KeyError, RuntimeError, ValueError, httpx.HTTPError) as exc:
            parser.error(str(exc))
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        if args.require == "candidate-ready" and not result["candidate_ready"]:
            raise SystemExit(1)
        if args.require == "delivery-complete" and not result["delivery_complete"]:
            raise SystemExit(1)
    elif args.command == "observe-stability":
        try:
            if not 5.0 <= args.interval_seconds <= 3600:
                raise ValueError("stability interval must be between 5 and 3600 seconds")
            if not 0.1 <= args.timeout_seconds <= 60:
                raise ValueError("stability request timeout must be between 0.1 and 60 seconds")
            base_url = normalize_loopback_base_url(args.url)
            database = Database(
                settings.database_path,
                enable_test_fixture_agent=settings.enable_test_fixture_agent,
            )
            if not database.check()["ready"]:
                raise ValueError("stability observation requires an initialized current database")
            operations = OperationsView(database, settings.data_dir)
            target = operations.stability_target(args.agent)
            samples: list[dict[str, object]] = []
            with httpx.Client(base_url=base_url, timeout=args.timeout_seconds) as client:
                for index in range(2):
                    response = client.get("/health")
                    response.raise_for_status()
                    sample = {"observed_at": iso(), "health": response.json()}
                    operations.validate_stability_sample(sample, target)
                    samples.append(sample)
                    if index == 0:
                        time.sleep(args.interval_seconds)
            result = operations.record_stability_observation(
                "cli:local-operator",
                args.agent,
                samples,
            )
        except (KeyError, RuntimeError, ValueError, httpx.HTTPError) as exc:
            parser.error(str(exc))
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    elif args.command == "backup-db":
        database = Database(
            settings.database_path,
            enable_test_fixture_agent=settings.enable_test_fixture_agent,
        )
        target = database.backup(args.output)
        backup = OperationsView(database, settings.data_dir).verify_backup_file(target)
        print(json.dumps({"target": str(target), **backup}, ensure_ascii=False, sort_keys=True))
        if not backup["restorable"] or backup["mode"] != "0o600":
            raise SystemExit(1)
    elif args.command == "provision-access-tokens":
        if settings.access_tokens_file is None:
            parser.error("access token provisioning requires a production token file path")
        try:
            result = provision_access_token_bundle(
                settings.access_tokens_file,
                ttl_days=args.ttl_days,
                rotate=args.rotate,
            )
        except (OSError, ValueError) as exc:
            parser.error(str(exc))
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    elif args.command == "render-launchd-service":
        try:
            project_root = Path(args.project_root).expanduser().resolve()
            payload = render_launchd_plist(
                project_root,
                label=args.label,
                host=args.host,
                port=args.port,
            )
            target = write_new_service_file(args.output, payload)
        except (FileExistsError, OSError, ValueError) as exc:
            parser.error(str(exc))
        print(
            json.dumps(
                {
                    "status": "rendered_not_installed",
                    "manager": "launchd",
                    "label": args.label,
                    "path": str(target),
                    "mode": oct(target.stat().st_mode & 0o777),
                    "contains_secret_values": False,
                    "deployment_authorized": False,
                },
                ensure_ascii=False,
                sort_keys=True,
            )
        )
    elif args.command == "render-release-channel-launchd-service":
        try:
            payload = render_release_channel_launchd_plist(
                args.executable,
                args.repository,
                label=args.label,
                host=args.host,
                port=args.port,
            )
            target = write_new_service_file(args.output, payload)
        except (FileExistsError, OSError, ValueError) as exc:
            parser.error(str(exc))
        print(
            json.dumps(
                {
                    "status": "rendered_not_installed",
                    "manager": "launchd",
                    "label": args.label,
                    "path": str(target),
                    "mode": oct(target.stat().st_mode & 0o777),
                    "contains_secret_values": False,
                    "external_writes": 0,
                },
                ensure_ascii=False,
                sort_keys=True,
            )
        )
    elif args.command == "render-systemd-service":
        try:
            project_root = Path(args.project_root).expanduser().resolve()
            payload = render_systemd_unit(
                project_root,
                label=args.label,
                user=args.user,
                host=args.host,
                port=args.port,
            )
            target = write_new_service_file(args.output, payload)
        except (FileExistsError, OSError, ValueError) as exc:
            parser.error(str(exc))
        print(
            json.dumps(
                {
                    "status": "rendered_not_installed",
                    "manager": "systemd",
                    "label": args.label,
                    "path": str(target),
                    "mode": oct(target.stat().st_mode & 0o777),
                    "contains_secret_values": False,
                    "deployment_authorized": False,
                },
                ensure_ascii=False,
                sort_keys=True,
            )
        )
    elif args.command == "serve":
        try:
            validate_serve_security(
                args.host,
                settings.api_token,
                settings.admin_token,
                access_tokens_expired=(
                    settings.access_tokens.expired() if settings.access_tokens is not None else False
                ),
            )
        except ValueError as exc:
            parser.error(str(exc))
        app = create_app(settings)
        server = uvicorn.Server(uvicorn.Config(app, host=args.host, port=args.port))
        activation_requested = False

        def request_activation_handoff() -> None:
            nonlocal activation_requested
            activation_requested = True
            server.should_exit = True

        app.state.runtime.shutdown_callback = request_activation_handoff
        server.run()
        if activation_requested:
            runtime = app.state.runtime
            if runtime.runtime_layout is None or runtime.loaded_release is None:
                raise RuntimeError("managed runtime handoff lost its release identity")
            manager = ReleaseManager(runtime.runtime_layout)
            executable, command = manager.worker_handoff_command(
                runtime.loaded_release,
                sys.argv[1:],
            )
            try:
                os.execv(executable, command)
            except OSError:
                manager.rollback(runtime.loaded_release)
                raise


if __name__ == "__main__":
    main()
