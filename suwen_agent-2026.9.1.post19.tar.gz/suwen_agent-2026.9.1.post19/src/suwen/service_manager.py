from __future__ import annotations

import getpass
import ipaddress
import os
import plistlib
import re
from pathlib import Path

from .access_tokens import default_access_tokens_path, load_access_token_bundle
from .process_manager import validate_process_manager

DEFAULT_LAUNCHD_PATH = "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
DEFAULT_SYSTEMD_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
_SERVICE_USER = re.compile(r"^[A-Za-z_][A-Za-z0-9_.-]{0,63}$")


def render_launchd_plist(
    project_root: str | Path,
    *,
    label: str = "com.keyu.suwen",
    host: str = "127.0.0.1",
    port: int = 8090,
) -> bytes:
    _, label = validate_process_manager("launchd", label)
    root = Path(project_root).expanduser().resolve()
    if not root.is_dir():
        raise ValueError("launchd project root must be an existing directory")
    installed_executable = root / "current" / "venv" / "bin" / "suwen"
    installed_config = root / "workspace" / "config" / "agent.toml"
    installed_layout = installed_executable.is_file() or installed_config.is_file()
    if installed_layout:
        executable = installed_executable
        config = installed_config
        working_directory = root / "workspace"
        runtime = working_directory / ".data" / "runtime"
    else:
        executable = root / ".venv" / "bin" / "suwen"
        config = root / "config" / "agent.toml"
        working_directory = root
        runtime = root / ".data" / "runtime"
    if not executable.is_file() or not os.access(executable, os.X_OK):
        raise ValueError("launchd Suwen executable is unavailable")
    if not config.is_file():
        raise ValueError("launchd Suwen configuration is unavailable")
    normalized_host = host.strip().strip("[]")
    try:
        address = ipaddress.ip_address(normalized_host)
        loopback = address.is_loopback
        unspecified = address.is_unspecified
    except ValueError:
        loopback = normalized_host.lower() == "localhost"
        unspecified = False
    access_tokens_file: Path | None = None
    if not loopback:
        if not installed_layout or not unspecified:
            raise ValueError("non-loopback launchd service must use an installed all-interface host")
        access_tokens_file = default_access_tokens_path(working_directory / ".data")
        bundle = load_access_token_bundle(access_tokens_file)
        if bundle.expired():
            raise ValueError("non-loopback launchd service requires unexpired access tokens")
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError("launchd service port is invalid")
    payload = {
        "Label": label,
        "ProgramArguments": [
            str(executable),
            "--config",
            str(config),
            "serve",
            "--host",
            host,
            "--port",
            str(port),
        ],
        "WorkingDirectory": str(working_directory),
        "RunAtLoad": True,
        "KeepAlive": {"SuccessfulExit": False},
        "ProcessType": "Background",
        "ThrottleInterval": 10,
        "EnvironmentVariables": {
            "PATH": DEFAULT_LAUNCHD_PATH,
            "SUWEN_CONFIG": str(config),
            "SUWEN_PROCESS_MANAGER": "launchd",
            "SUWEN_PROCESS_MANAGER_LABEL": label,
            "PYTHONUNBUFFERED": "1",
            **({"SUWEN_HOME": str(root)} if installed_layout else {}),
            **(
                {"SUWEN_ACCESS_TOKENS_FILE": str(access_tokens_file)}
                if access_tokens_file is not None
                else {}
            ),
        },
        "StandardOutPath": str(runtime / "launchd.stdout.log"),
        "StandardErrorPath": str(runtime / "launchd.stderr.log"),
    }
    return plistlib.dumps(payload, fmt=plistlib.FMT_XML, sort_keys=True)


def render_release_channel_launchd_plist(
    executable: str | Path,
    repository: str | Path,
    *,
    label: str = "com.keyu.suwen-release-channel",
    host: str = "0.0.0.0",
    port: int = 4020,
) -> bytes:
    """Render the read-only LAN wheel feed independently from the Agent service."""

    _, label = validate_process_manager("launchd", label)
    command = Path(executable).expanduser().resolve()
    root = Path(repository).expanduser().resolve()
    if not command.is_file() or not os.access(command, os.X_OK):
        raise ValueError("release-channel Suwen executable is unavailable")
    if not (root / "channel.json").is_file():
        raise ValueError("release-channel repository has no published channel.json")
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError("release-channel port is invalid")
    logs = root.parent / "logs"
    if not logs.is_dir():
        raise ValueError("release-channel log directory is unavailable")
    payload = {
        "Label": label,
        "ProgramArguments": [
            str(command),
            "release-channel-serve",
            "--repository",
            str(root),
            "--host",
            host,
            "--port",
            str(port),
        ],
        "WorkingDirectory": str(root),
        "RunAtLoad": True,
        "KeepAlive": {"SuccessfulExit": False},
        "ProcessType": "Background",
        "ThrottleInterval": 10,
        "EnvironmentVariables": {
            "PATH": DEFAULT_LAUNCHD_PATH,
            "PYTHONUNBUFFERED": "1",
        },
        "StandardOutPath": str(logs / "launchd.stdout.log"),
        "StandardErrorPath": str(logs / "launchd.stderr.log"),
    }
    return plistlib.dumps(payload, fmt=plistlib.FMT_XML, sort_keys=True)


def render_systemd_unit(
    project_root: str | Path,
    *,
    label: str = "suwen.service",
    user: str | None = None,
    host: str = "127.0.0.1",
    port: int = 4010,
) -> bytes:
    """Render a system-level unit for an installed Suwen release.

    The renderer writes no credentials.  A non-loopback service receives only
    the path to the separately provisioned access-token bundle.
    """

    _, label = validate_process_manager("systemd", label)
    root = Path(project_root).expanduser().resolve()
    executable = root / "current" / "venv" / "bin" / "suwen"
    config = root / "workspace" / "config" / "agent.toml"
    working_directory = root / "workspace"
    if not executable.is_file() or not os.access(executable, os.X_OK):
        raise ValueError("systemd Suwen executable is unavailable")
    if not config.is_file():
        raise ValueError("systemd Suwen configuration is unavailable")
    service_user = (user or getpass.getuser()).strip()
    if not _SERVICE_USER.fullmatch(service_user):
        raise ValueError("systemd service user is invalid")
    normalized_host = host.strip().strip("[]")
    try:
        address = ipaddress.ip_address(normalized_host)
        loopback = address.is_loopback
        unspecified = address.is_unspecified
    except ValueError:
        loopback = normalized_host.lower() == "localhost"
        unspecified = False
    access_tokens_file: Path | None = None
    if not loopback:
        if not unspecified:
            raise ValueError("non-loopback systemd service must use an all-interface host")
        access_tokens_file = default_access_tokens_path(working_directory / ".data")
        bundle = load_access_token_bundle(access_tokens_file)
        if bundle.expired():
            raise ValueError("non-loopback systemd service requires unexpired access tokens")
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError("systemd service port is invalid")

    environment = {
        "PATH": DEFAULT_SYSTEMD_PATH,
        "SUWEN_HOME": str(root),
        "SUWEN_CONFIG": str(config),
        "SUWEN_PROCESS_MANAGER": "systemd",
        "SUWEN_PROCESS_MANAGER_LABEL": label,
        "PYTHONUNBUFFERED": "1",
        **(
            {"SUWEN_ACCESS_TOKENS_FILE": str(access_tokens_file)}
            if access_tokens_file is not None
            else {}
        ),
    }
    command = [
        str(executable),
        "--config",
        str(config),
        "serve",
        "--host",
        host,
        "--port",
        str(port),
    ]
    lines = [
        "[Unit]",
        "Description=Suwen Agent Runtime",
        "Wants=network-online.target",
        "After=network-online.target",
        "",
        "[Service]",
        "Type=simple",
        f"User={service_user}",
        f"WorkingDirectory={_systemd_path(str(working_directory))}",
        "ExecStart=" + " ".join(_systemd_quote(item) for item in command),
        *(f"Environment={_systemd_quote(f'{name}={value}')}" for name, value in environment.items()),
        "Restart=on-failure",
        "RestartSec=10s",
        "TimeoutStopSec=1900s",
        "KillMode=control-group",
        "UMask=0077",
        "",
        "[Install]",
        "WantedBy=multi-user.target",
        "",
    ]
    return "\n".join(lines).encode("utf-8")


def _systemd_quote(value: str) -> str:
    if any(character in value for character in ("\x00", "\n", "\r")):
        raise ValueError("systemd service value contains control characters")
    escaped = value.replace("\\", "\\\\").replace('"', '\\"').replace("%", "%%")
    return f'"{escaped}"'


def _systemd_path(value: str) -> str:
    if not value.startswith("/") or any(
        character.isspace() or character in {"\x00", "\"", "'", "%"} for character in value
    ):
        raise ValueError("systemd service path must be an absolute path without special characters")
    return value


def write_new_service_file(path: str | Path, payload: bytes) -> Path:
    target = Path(path).expanduser()
    if not target.is_absolute():
        raise ValueError("service output path must be absolute")
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    descriptor = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
            os.fchmod(handle.fileno(), 0o600)
    except BaseException:
        target.unlink(missing_ok=True)
        raise
    return target
