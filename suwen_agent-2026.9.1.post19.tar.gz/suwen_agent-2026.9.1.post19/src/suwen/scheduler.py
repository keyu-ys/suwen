from __future__ import annotations

import asyncio
import json
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime, timedelta

from .outbox import OutboxDispatcher
from .repository import Repository
from .review import LifecycleService, ReviewEngine


class Scheduler:
    def __init__(
        self,
        repository: Repository,
        review_engine: ReviewEngine,
        lifecycle: LifecycleService,
        cleanup_artifacts: Callable[[datetime | None], int] | None = None,
        outbox: OutboxDispatcher | None = None,
        poll_seconds: float = 2,
        lease_seconds: int = 30,
        process_inbound: Callable[[dict, dict], Awaitable[bool]] | None = None,
        prepare_inbound: Callable[[dict, dict], Awaitable[bool]] | None = None,
    ) -> None:
        self.repository = repository
        self.review_engine = review_engine
        self.lifecycle = lifecycle
        self.cleanup_artifacts = cleanup_artifacts
        self.outbox = outbox
        self.poll_seconds = poll_seconds
        self.lease_seconds = lease_seconds
        self.process_inbound = process_inbound
        self.prepare_inbound = prepare_inbound
        self.last_success: str | None = None
        self.last_error: str | None = None
        self._stopping = False
        self._task: asyncio.Task[None] | None = None

    @property
    def running(self) -> bool:
        return self._task is not None and not self._task.done()

    def start(self) -> None:
        if self.running:
            return
        self._stopping = False
        self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._stopping = True
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def _loop(self) -> None:
        while not self._stopping:
            try:
                await self.run_once()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.last_error = f"{type(exc).__name__}: {exc}"[:1000]
            else:
                self.last_success = datetime.now(UTC).isoformat()
                self.last_error = None
            await asyncio.sleep(self.poll_seconds)

    async def run_once(self, now: datetime | None = None) -> int:
        now = now or datetime.now(UTC)
        self.lifecycle.close_inactive(now)
        if self.cleanup_artifacts:
            self.cleanup_artifacts(now)
        if self.outbox:
            await self.outbox.run_once()
        jobs = self.repository.lease_due_jobs(now, now + timedelta(seconds=self.lease_seconds))
        handled = 0
        for job in jobs:
            try:
                payload = json.loads(job["payload_json"])
                if job["kind"] == "review_case":
                    self.review_engine.review_case(payload["case_id"])
                elif job["kind"] == "close_inactive":
                    self.lifecycle.close_inactive(now)
                elif job["kind"] == "process_inbound":
                    if self.process_inbound is None:
                        raise RuntimeError("process_inbound handler is unavailable")
                    execution = asyncio.create_task(self.process_inbound(job, payload))
                    if not await execution:
                        continue
                    handled += 1
                    continue
                elif job["kind"] == "prepare_inbound":
                    if self.prepare_inbound is None:
                        raise RuntimeError("prepare_inbound handler is unavailable")
                    preparation = asyncio.create_task(self.prepare_inbound(job, payload))
                    if not await preparation:
                        continue
                    handled += 1
                    continue
                else:
                    raise ValueError(f"unknown job kind: {job['kind']}")
                self.repository.finish_job(job["id"])
                handled += 1
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.repository.finish_job(job["id"], str(exc))
        return handled
