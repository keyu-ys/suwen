from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

PressureTier = Literal["normal", "checkpoint", "reference", "minimal", "hard_limit"]


@dataclass(frozen=True)
class ContextBudgetPolicy:
    """Provider-aware input budget.

    Output reservation and a safety margin are removed before any conversation
    or Tool projection is admitted.  Thresholds describe projection strategy,
    not deletion of ledger data.
    """

    safety_margin_ratio: float = 0.05
    safety_margin_min_tokens: int = 4_096
    checkpoint_ratio: float = 0.75
    reference_ratio: float = 0.85
    minimal_ratio: float = 0.90


@dataclass(frozen=True)
class ContextBudget:
    context_window: int
    reserved_output_tokens: int
    safety_margin_tokens: int
    effective_input_tokens: int
    estimated_input_tokens: int
    pressure_ratio: float
    tier: PressureTier

    def as_dict(self) -> dict[str, int | float | str]:
        return {
            "context_window": self.context_window,
            "reserved_output_tokens": self.reserved_output_tokens,
            "safety_margin_tokens": self.safety_margin_tokens,
            "effective_input_tokens": self.effective_input_tokens,
            "estimated_input_tokens": self.estimated_input_tokens,
            "pressure_ratio": round(self.pressure_ratio, 6),
            "tier": self.tier,
        }


def context_budget(
    *,
    context_window: int,
    reserved_output_tokens: int,
    estimated_input_tokens: int,
    policy: ContextBudgetPolicy,
) -> ContextBudget:
    window = max(1, int(context_window))
    output = max(0, min(int(reserved_output_tokens), window - 1))
    margin = max(
        int(policy.safety_margin_min_tokens),
        int(window * policy.safety_margin_ratio),
    )
    raw_input = max(1, window - output)
    # A fixed 4K reserve cannot consume an entire legitimately configured
    # small model window. Keep at least one policy-floor-sized input region;
    # large windows still receive the full ratio/minimum safety margin.
    minimum_usable_input = min(int(policy.safety_margin_min_tokens), raw_input)
    margin = min(margin, max(0, raw_input - minimum_usable_input))
    effective = max(1, raw_input - margin)
    estimated = max(0, int(estimated_input_tokens))
    pressure = estimated / effective
    if pressure > 1:
        tier: PressureTier = "hard_limit"
    elif pressure >= policy.minimal_ratio:
        tier = "minimal"
    elif pressure >= policy.reference_ratio:
        tier = "reference"
    elif pressure >= policy.checkpoint_ratio:
        tier = "checkpoint"
    else:
        tier = "normal"
    return ContextBudget(
        context_window=window,
        reserved_output_tokens=output,
        safety_margin_tokens=margin,
        effective_input_tokens=effective,
        estimated_input_tokens=estimated,
        pressure_ratio=pressure,
        tier=tier,
    )
