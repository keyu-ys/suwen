"""Run context management for the Suwen diagnostic harness.

The Case ledger remains authoritative.  This package only builds a bounded,
fully traceable projection for one model turn.
"""

from .assembly import ContextGeneration, rebuild_context
from .budget import ContextBudget, ContextBudgetPolicy, context_budget
from .facts import answer_fact_message, build_answer_fact_projection, render_answer_facts
from .working_set import WaveProgress, classify_tool_wave, stable_anchors

__all__ = [
    "ContextBudget",
    "ContextBudgetPolicy",
    "ContextGeneration",
    "WaveProgress",
    "answer_fact_message",
    "build_answer_fact_projection",
    "classify_tool_wave",
    "context_budget",
    "rebuild_context",
    "render_answer_facts",
    "stable_anchors",
]
