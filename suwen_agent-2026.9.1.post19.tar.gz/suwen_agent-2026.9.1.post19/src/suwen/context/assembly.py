from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from .budget import ContextBudget, ContextBudgetPolicy, context_budget
from .facts import (
    answer_fact_message,
    build_answer_fact_projection,
    collect_field_selectors,
    path_matches_selector,
)
from .working_set import build_working_set, stable_anchors

_JSON_SCALAR_PAIR = re.compile(
    r'"(?P<key>(?:\\.|[^"\\]){1,128})"\s*:\s*'
    r'(?P<value>"(?:\\.|[^"\\])*"|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?|true|false|null)'
)


@dataclass(frozen=True)
class ContextGeneration:
    messages: list[dict[str, Any]]
    checkpoint: dict[str, Any]
    working_set: dict[str, Any]
    loaded_skills: tuple[dict[str, Any], ...]
    evidence_refs: tuple[str, ...]
    source_budget: ContextBudget
    budget: ContextBudget
    strategy: str
    omitted_protocol_groups: int
    omitted_history_messages: int


def canonical_digest(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return "sha256:" + hashlib.sha256(payload.encode()).hexdigest()


def evidence_card(
    payload: dict[str, Any],
    *,
    evidence_id: str | None = None,
    max_chars: int = 2_400,
    known_anchors: tuple[str, ...] = (),
    related_to_known_anchor: bool = False,
) -> dict[str, Any]:
    """Create a compact, loss-aware reference to immutable Evidence."""

    raw_safe_statements = payload.get("safe_statements")
    if not isinstance(raw_safe_statements, (list, tuple)):
        raw_safe_statements = []
    safe_statements = [
        str(item)[:800]
        for item in raw_safe_statements[:8]
        if isinstance(item, str) and item.strip()
    ]
    summary = str(payload.get("summary") or "").strip()[:1_200]
    raw_limitations = payload.get("limitations")
    if not isinstance(raw_limitations, (list, tuple)):
        raw_limitations = []
    limitations = [
        str(item)[:500]
        for item in raw_limitations[:8]
        if isinstance(item, str) and item.strip()
    ]
    if summary and any(" ".join(item.split()) == " ".join(summary.split()) for item in safe_statements):
        summary = ""
    card = {
        "evidence_id": evidence_id,
        "tool_call_id": payload.get("tool_call_id"),
        "state": payload.get("state") or payload.get("operation_state"),
        "coverage_state": payload.get("coverage_state"),
        "truncation_state": payload.get("truncation_state"),
        "source_ref": str(payload.get("source_ref") or "")[:500],
        "source_role": payload.get("source_role"),
        "observed_at": payload.get("observed_at"),
        "summary": summary,
        "safe_statements": list(dict.fromkeys(safe_statements)),
        "limitations": limitations,
        "continuation": payload.get("continuation"),
        "full_evidence_available": bool(evidence_id),
    }
    data = payload.get("data")
    recalled = data.get("evidence") if isinstance(data, dict) else None
    if payload.get("source_role") == "case_history_recall" and isinstance(recalled, list):
        recalled_cards = []
        for item in recalled[:12]:
            if not isinstance(item, dict):
                continue
            recalled_cards.append(
                {
                    key: (
                        str(item[key])[:500]
                        if key == "summary"
                        else item[key][:4]
                        if key == "limitations" and isinstance(item[key], list)
                        else item[key]
                    )
                    for key in (
                        "evidence_id",
                        "state",
                        "coverage_state",
                        "source_ref",
                        "summary",
                        "limitations",
                        "observed_at",
                    )
                    if item.get(key) not in (None, "", [], {})
                }
            )
        if recalled_cards:
            card["recalled_evidence"] = recalled_cards
            card["evidence_refs"] = [
                item["evidence_id"]
                for item in recalled_cards
                if isinstance(item.get("evidence_id"), str)
            ]
    state = str(card.get("state") or "")
    source_role = str(card.get("source_role") or "")
    user_anchor_match = related_to_known_anchor or any(
        anchor.casefold() in json.dumps(payload, ensure_ascii=False, sort_keys=True).casefold()
        for anchor in known_anchors
    )
    answer_bearing = bool(card.get("safe_statements")) or data not in (None, "", [], {})
    if state == "conflict" or user_anchor_match or (not known_anchors and answer_bearing):
        priority = "P1"
        selection_reason = (
            "known_anchor_or_direct_answer"
            if state != "conflict"
            else "direct_evidence_conflict"
        )
    elif card.get("limitations") or card.get("continuation") or state in {
        "zero_matches",
        "not_observable",
        "input_rejected",
        "query_failed",
    }:
        priority = "P2"
        selection_reason = "coverage_limit_or_recovery_boundary"
    else:
        priority = "P3"
        selection_reason = "discovery_or_low_signal_observation"
    card["priority"] = priority
    card["selection_reason"] = selection_reason
    card["body_mode"] = "card" if priority in {"P1", "P2"} else "reference"
    if priority == "P1" and len(card.get("limitations", [])) > 4:
        card["limitations_omitted"] = len(card["limitations"]) - 4
        card["limitations"] = card["limitations"][:4]

    if data not in (None, "", [], {}) and priority in {"P1", "P2"}:
        preview = _balanced_scalar_data_preview(
            data,
            retained=card,
            max_chars=max_chars,
            priority_anchors=known_anchors,
        )
        if preview is not None:
            card["data_preview"] = preview
    if priority == "P3":
        card.pop("summary", None)
        card.pop("safe_statements", None)
        card.pop("limitations", None)
        card.pop("continuation", None)
        card["projection"] = "reference_only; immutable Evidence remains in the Case ledger"
    elif source_role == "capability_instruction":
        # Loaded Skill bodies have one authoritative projection managed by the
        # fixed capability layer, never a second Evidence Card body.
        card["body_mode"] = "fixed_capability_layer"
    card = {key: value for key, value in card.items() if value not in (None, "", [], {})}
    raw = json.dumps(card, ensure_ascii=False, sort_keys=True)
    while len(raw) > max_chars and len(card.get("recalled_evidence", [])) > 1:
        card["recalled_evidence"].pop()
        card["evidence_refs"] = [
            item["evidence_id"]
            for item in card["recalled_evidence"]
            if isinstance(item.get("evidence_id"), str)
        ]
        raw = json.dumps(card, ensure_ascii=False, sort_keys=True)
    if len(raw) <= max_chars:
        return card
    if "data_preview" in card:
        card.pop("data_preview", None)
        raw = json.dumps(card, ensure_ascii=False, sort_keys=True)
        if len(raw) <= max_chars:
            card["projection"] = "metadata_and_claims; immutable Evidence remains in the Case ledger"
            return card
    summary = str(card.get("summary") or "")
    if summary:
        card["summary"] = summary[: max(160, max_chars // 3)]
    for field in ("safe_statements", "limitations"):
        while len(json.dumps(card, ensure_ascii=False, sort_keys=True)) > max_chars and len(
            card.get(field, [])
        ) > 1:
            card[field].pop()
    if len(json.dumps(card, ensure_ascii=False, sort_keys=True)) > max_chars:
        card.pop("continuation", None)
    card["projection"] = "summary_bounded; immutable Evidence remains in the Case ledger"
    return card


def _balanced_scalar_data_preview(
    data: Any,
    *,
    retained: dict[str, Any],
    max_chars: int,
    priority_anchors: tuple[str, ...],
) -> dict[str, Any] | None:
    """Round-robin bounded scalar leaves without knowing business fields."""

    leaves: dict[str, list[tuple[int, int, str, Any]]] = {}
    visited = 0
    focus_terms: set[str] = set()

    def collect_focus_terms(value: Any) -> None:
        for item in collect_field_selectors({"fields": value}):
            if 1 <= len(item) <= 128:
                focus_terms.add(item.casefold())

    if isinstance(data, dict):
        query = data.get("query")
        if isinstance(query, dict):
            for key in ("field", "fields", "field_names", "keywords", "projection_fields"):
                collect_focus_terms(query.get(key))
        # Providers commonly expose the caller-selected fields separately from
        # the returned records. Those names are generic answer intent, not
        # business knowledge, and must outrank planner/provenance metadata when
        # a bounded card is built.
        for key, value in data.items():
            normalized = str(key).casefold()
            if (
                "projection" in normalized
                or "field_selection" in normalized
                or "selected_fields" in normalized
                or "requested_fields" in normalized
            ):
                collect_focus_terms(value)

    def append_leaf(value: Any, path: tuple[str, ...], bucket: str) -> None:
        pointer = "/" + "/".join(
            segment.replace("~", "~0").replace("/", "~1") for segment in path
        )
        lowered = [segment.lower() for segment in path]
        scalar_text = str(value).casefold()
        anchor_match = any(anchor.casefold() in scalar_text for anchor in priority_anchors)
        focus_match = any(path_matches_selector(path, term) for term in focus_terms)
        metadata_branch = any(
            segment
            in {
                "coverage",
                "identifier_extraction",
                "limits",
                "metadata",
                "provenance",
                "query",
                "query_plan",
                "window",
            }
            or segment.startswith("__suwen_")
            or segment.endswith(("_plan", "_metadata", "_provenance"))
            for segment in lowered
        )
        relationship_branch = any(
            segment
            in {
                "identifier",
                "identifiers",
                "match_provenance",
                "matched_by",
                "related_objects",
                "relations",
                "links",
                "requested_identifier",
            }
            or segment.endswith(
                (
                    "_identifier",
                    "_relation",
                    "_relations",
                    "_link",
                    "_links",
                    "_matched_by",
                )
            )
            for segment in lowered
        )
        record_branch = any(
            marker in segment
            for segment in lowered
            for marker in ("record", "result", "document", "item", "event", "fact", "context")
        )
        structured_scalar = "@json" in lowered
        long_text = isinstance(value, str) and len(value) > 512
        priority = (
            0
            if anchor_match
            else 1
            if focus_match
            else 2
            if relationship_branch
            else 3
            if structured_scalar and not long_text
            else 4
            if record_branch
            else 5
            if long_text
            else 6
            if metadata_branch
            else 5
        )
        leaves.setdefault(bucket or "/", []).append(
            (priority, sum(len(items) for items in leaves.values()), pointer, value)
        )

    def walk(value: Any, path: tuple[str, ...], depth: int, bucket: str) -> None:
        nonlocal visited
        if visited >= 800 or depth > 10:
            return
        visited += 1
        if isinstance(value, str) and value.lstrip().startswith(("{", "[")):
            decoded: Any = None
            try:
                decoded = json.loads(value)
            except (TypeError, ValueError, json.JSONDecodeError):
                decoded = None
            if isinstance(decoded, (dict, list)):
                walk(decoded, (*path, "@json"), depth + 1, bucket)
                return
            pairs: list[tuple[str, Any]] = []
            for match in _JSON_SCALAR_PAIR.finditer(value[:32_000]):
                try:
                    key = json.loads(f'"{match.group("key")}"')
                    scalar = json.loads(match.group("value"))
                except (TypeError, ValueError, json.JSONDecodeError):
                    continue
                if not isinstance(key, str) or isinstance(scalar, (dict, list)):
                    continue
                pairs.append((key, scalar))
                if len(pairs) >= 64:
                    break
            if pairs:
                for pair_index, (key, scalar) in enumerate(pairs):
                    walk(
                        scalar,
                        (*path, "@json", str(pair_index), key),
                        depth + 1,
                        bucket,
                    )
                return
        if value is None or isinstance(value, (str, int, float, bool)):
            append_leaf(value, path, bucket)
            return
        if isinstance(value, (dict, list, tuple)) and not value:
            # An explicitly returned empty container is an observed value. It
            # must survive projection so the model cannot turn "empty" into
            # "the field was unavailable" during finalization.
            append_leaf({} if isinstance(value, dict) else [], path, bucket)
            return
        if isinstance(value, dict):
            for key in sorted(value):
                if str(key).startswith("__suwen_"):
                    continue
                child_bucket = bucket or f"/{key}"
                walk(value[key], (*path, str(key)), depth + 1, child_bucket)
                if visited >= 800:
                    break
            return
        if isinstance(value, (list, tuple)):
            indexes = list(range(min(len(value), 24)))
            if len(value) > 24:
                indexes[-1] = len(value) - 1
            for index in indexes:
                child_bucket = f"{bucket or '/items'}/{index}"
                walk(value[index], (*path, str(index)), depth + 1, child_bucket)
                if visited >= 800:
                    break

    walk(data, (), 0, "")
    if not leaves:
        return None
    for bucket in leaves:
        leaves[bucket].sort(key=lambda item: (item[0], item[1]))

    preview: dict[str, Any] = {
        "format": "bounded-scalar-leaves.v2",
        "items": [],
        "omitted": False,
    }
    ordered_buckets = sorted(leaves)
    seen: set[tuple[str, str]] = set()
    remaining = sum(len(items) for items in leaves.values())
    omitted_any = False

    def bounded_text(value: str, char_limit: int) -> str:
        if len(value) <= char_limit:
            return value
        marker = "\n[…Evidence 中间片段省略…]\n"
        if char_limit <= len(marker) * 2 + 24:
            return value[:char_limit]
        payload = char_limit - len(marker) * 2
        head = max(8, payload // 3)
        middle = max(8, payload // 3)
        tail = max(8, payload - head - middle)
        middle_start = max(head, (len(value) - middle) // 2)
        tail_start = max(middle_start + middle, len(value) - tail)
        return (
            value[:head]
            + marker
            + value[middle_start : middle_start + middle]
            + marker
            + value[tail_start:]
        )

    def append_item(item: tuple[int, int, str, Any]) -> str:
        nonlocal omitted_any, remaining
        _priority, _order, pointer, value = item
        remaining -= 1
        leaf_name = pointer.rsplit("/", 1)[-1]
        canonical_value = json.dumps(value, ensure_ascii=False, sort_keys=True)
        dedupe_key = (leaf_name, canonical_value)
        if dedupe_key in seen:
            omitted_any = True
            return "skipped"
        seen.add(dedupe_key)
        bounded_value = value
        if isinstance(value, str) and len(value) > 320:
            bounded_value = bounded_text(value, 320)
        preview["items"].append({"path": pointer, "value": bounded_value})
        candidate = {**retained, "data_preview": preview}
        if len(json.dumps(candidate, ensure_ascii=False, sort_keys=True)) > max_chars:
            preview["items"].pop()
            if isinstance(value, str):
                empty_item = {"path": pointer, "value": ""}
                preview["items"].append(empty_item)
                base_chars = len(
                    json.dumps(
                        {**retained, "data_preview": preview},
                        ensure_ascii=False,
                        sort_keys=True,
                    )
                )
                preview["items"].pop()
                available = max_chars - base_chars
                if available >= 160:
                    preview["items"].append(
                        {"path": pointer, "value": bounded_text(value, available)}
                    )
                    candidate = {**retained, "data_preview": preview}
                    if len(json.dumps(candidate, ensure_ascii=False, sort_keys=True)) <= max_chars:
                        omitted_any = True
                        return "added"
                    preview["items"].pop()
            omitted_any = True
            return "skipped"
        return "added"

    # Preserve exact anchor joins, generic match/relationship provenance, and
    # compact scalars recovered from structured JSON containers before sampling
    # verbose record prose or execution metadata.
    # This is field-agnostic: numbers/booleans and bounded key/value strings are
    # simply denser than a head/tail slice of one large serialized object.
    high_signal: list[tuple[int, int, str, Any]] = []
    for bucket in ordered_buckets:
        high_signal.extend(item for item in leaves[bucket] if item[0] <= 3)
        leaves[bucket] = [item for item in leaves[bucket] if item[0] > 3]
    high_signal.sort(key=lambda item: (item[0], item[1]))
    prefilled = 0
    for item in high_signal:
        outcome = append_item(item)
        if outcome == "added":
            prefilled += 1
        if prefilled >= 24:
            omitted_any = True
            break

    while remaining and len(preview["items"]) < 48:
        advanced = False
        for bucket in ordered_buckets:
            items = leaves[bucket]
            while items:
                outcome = append_item(items.pop(0))
                if outcome == "added":
                    advanced = True
                    break
        if not advanced:
            break
    preview["omitted"] = bool(remaining) or omitted_any
    return preview if preview["items"] else None


def _parse_tool_payload(message: dict[str, Any]) -> dict[str, Any]:
    try:
        value = json.loads(str(message.get("content") or "{}"))
    except (TypeError, ValueError, json.JSONDecodeError):
        return {"summary": "Tool result is recorded but its projection is not structured."}
    return value if isinstance(value, dict) else {"summary": str(value)[:400]}


def _payload_evidence_refs(payload: dict[str, Any]) -> list[str]:
    refs = [item for item in payload.get("evidence_refs", []) if isinstance(item, str)]
    data = payload.get("data")
    recalled = data.get("evidence") if isinstance(data, dict) else None
    if isinstance(recalled, list):
        refs.extend(
            str(item["evidence_id"])
            for item in recalled
            if isinstance(item, dict) and isinstance(item.get("evidence_id"), str)
        )
    return list(dict.fromkeys(refs))


def _tool_requests(message: dict[str, Any]) -> list[dict[str, Any]]:
    requests: list[dict[str, Any]] = []
    for item in message.get("tool_calls", []):
        if not isinstance(item, dict):
            continue
        function = item.get("function") if isinstance(item.get("function"), dict) else {}
        raw_arguments = function.get("arguments", {})
        if isinstance(raw_arguments, str):
            try:
                arguments = json.loads(raw_arguments)
            except json.JSONDecodeError:
                arguments = {"unparsed_arguments": raw_arguments[:2_000]}
        else:
            arguments = raw_arguments
        requests.append(
            {
                "call_id": str(item.get("id") or ""),
                "name": str(function.get("name") or ""),
                "arguments": arguments if isinstance(arguments, dict) else {},
            }
        )
    return requests


def _protocol_waves(
    messages: list[dict[str, Any]],
    groups: list[tuple[int, int]],
    evidence_by_tool_call: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    waves: list[dict[str, Any]] = []
    for start, end in groups:
        requests = _tool_requests(messages[start])
        results: list[dict[str, Any]] = []
        for message in messages[start + 1 : end]:
            payload = _parse_tool_payload(message)
            provider_call_id = str(message.get("tool_call_id") or "")
            tool_call_id = str(payload.get("tool_call_id") or "")
            evidence = evidence_by_tool_call.get(tool_call_id, {})
            evidence_id = str(evidence.get("id") or "")
            payload = {**payload, "_provider_call_id": provider_call_id}
            if evidence_id:
                payload["evidence_id"] = evidence_id
            results.append(payload)
        waves.append({"requests": requests, "results": results})
    return waves


def _loaded_skill(payload: dict[str, Any]) -> dict[str, Any] | None:
    if (
        payload.get("source_role") != "capability_instruction"
        or str(payload.get("state") or payload.get("operation_state") or "") != "observed"
    ):
        return None
    data = payload.get("data")
    if not isinstance(data, dict):
        return None
    skill_id = data.get("skill_id")
    instructions = data.get("instructions")
    content_digest = data.get("content_digest")
    if not all(isinstance(item, str) and item for item in (skill_id, instructions, content_digest)):
        return None
    return {
        "skill_id": skill_id,
        "skill": str(data.get("skill") or skill_id),
        "instructions": instructions,
        "content_digest": content_digest,
        "source_ref": payload.get("source_ref"),
        "tool_call_id": payload.get("tool_call_id"),
    }


def _loaded_skills(
    waves: list[dict[str, Any]],
    evidence_by_tool_call: dict[str, dict[str, Any]],
    *,
    recent_provider_call_ids: set[str],
) -> tuple[dict[str, Any], ...]:
    found: list[dict[str, Any]] = []
    visible_digests: set[str] = set()
    for wave in waves:
        for result in wave.get("results", []):
            if not isinstance(result, dict):
                continue
            item = _loaded_skill(result)
            if item is None:
                continue
            found.append(item)
            provider_call_id = str(result.get("_provider_call_id") or "")
            if provider_call_id in recent_provider_call_ids:
                visible_digests.add(str(item["content_digest"]))
    for row in evidence_by_tool_call.values():
        payload = _evidence_row_payload(row)
        item = _loaded_skill(payload)
        if item is not None:
            found.append(item)

    deduped: dict[str, dict[str, Any]] = {}
    for item in found:
        digest = str(item["content_digest"])
        deduped[digest] = {
            **item,
            "projection": (
                "recent_tool_result" if digest in visible_digests else "fixed_capability_layer"
            ),
        }
    return tuple(deduped.values())


def _loaded_skill_message(skills: tuple[dict[str, Any], ...]) -> dict[str, Any] | None:
    fixed = [item for item in skills if item.get("projection") == "fixed_capability_layer"]
    if not fixed:
        return None
    return {
        "role": "system",
        "content": json.dumps(
            {
                "schema": "suwen.loaded-skills.v1",
                "instruction": (
                    "以下 Skill 已由本 Run 明确读取并冻结。它们在本 Run 后续每个模型回合持续有效；"
                    "不得把‘已加载’摘要当作正文，也不要再次读取相同 digest。"
                ),
                "skills": [
                    {
                        "skill_id": item["skill_id"],
                        "skill": item["skill"],
                        "content_digest": item["content_digest"],
                        "instructions": item["instructions"],
                    }
                    for item in fixed
                ],
            },
            ensure_ascii=False,
            sort_keys=True,
        ),
    }


def _protocol_groups(messages: list[dict[str, Any]]) -> list[tuple[int, int]]:
    groups: list[tuple[int, int]] = []
    index = 0
    while index < len(messages):
        message = messages[index]
        if message.get("role") != "assistant" or not message.get("tool_calls"):
            index += 1
            continue
        end = index + 1
        while end < len(messages) and messages[end].get("role") == "tool":
            end += 1
        requested_ids = [
            str(item.get("id") or "")
            for item in message.get("tool_calls", [])
            if isinstance(item, dict)
        ]
        result_ids = [
            str(item.get("tool_call_id") or "")
            for item in messages[index + 1 : end]
        ]
        complete = (
            bool(requested_ids)
            and len(requested_ids) == len(set(requested_ids))
            and len(result_ids) == len(set(result_ids))
            and sorted(requested_ids) == sorted(result_ids)
        )
        if complete:
            groups.append((index, end))
        index = end
    return groups


def _checkpoint(
    messages: list[dict[str, Any]],
    cards: list[dict[str, Any]],
    *,
    user_context: list[str] | None = None,
    working_set: dict[str, Any] | None = None,
) -> dict[str, Any]:
    user_messages = (
        [str(content) for content in user_context if content]
        if user_context is not None
        else [
            str(message.get("content") or "")
            for message in messages
            if message.get("role") == "user" and message.get("content")
        ]
    )
    return {
        "schema": "suwen.diagnostic-checkpoint.v1",
        "current_goal": user_messages[-1] if user_messages else "",
        "recent_user_context": user_messages[-4:],
        "evidence_refs": list(
            dict.fromkeys(
                evidence_id
                for card in cards
                for evidence_id in (
                    ([card["evidence_id"]] if isinstance(card.get("evidence_id"), str) else [])
                    + [
                        item
                        for item in card.get("evidence_refs", [])
                        if isinstance(item, str)
                    ]
                )
            )
        ),
        "observations": list((working_set or {}).get("observations", [])),
        "unknowns": list((working_set or {}).get("unknowns", [])),
        # Hypotheses are deliberately not synthesized by deterministic Runtime
        # code.  The model remains responsible for causal reasoning.
        "hypotheses": [],
        "working_set": working_set or {},
    }


def _checkpoint_message(checkpoint: dict[str, Any], cards: list[dict[str, Any]]) -> dict[str, Any]:
    payload = {
        "schema": "suwen.context-projection.v1",
        "instruction": (
            "这是由 Runtime 从不可变 Case ledger 重建的诊断检查点与 Evidence Card。"
            "它们是引用投影，不是新证据；因果判断仍须由当前可见 Evidence 支撑。"
            "同一 Evidence Card 中，查询标识、match_provenance 与返回记录字段共同描述一次观察；"
            "exact_literal_in_provider_record 表示该标识已在这条返回记录中逐字命中，不得反称未桥接。"
            "优先利用工作集中最新 bridge/answer anchor；存在范围更窄的锚点时不要继续广泛目录发现。"
            "若 progress=no_progress，只选择一个实质不同且会改变结论的最小只读检查，否则立即收口。"
        ),
        "checkpoint": checkpoint,
        "evidence_cards": cards,
    }
    return {
        # Checkpoints and Evidence Cards contain source-controlled data, not
        # Runtime instructions.  Keeping them below the system layer prevents
        # a provider payload from acquiring system authority after compaction.
        "role": "user",
        "content": json.dumps(payload, ensure_ascii=False, sort_keys=True),
    }


def _terminal_checkpoint_projection(checkpoint: dict[str, Any]) -> dict[str, Any]:
    working_set = checkpoint.get("working_set")
    if not isinstance(working_set, dict):
        working_set = {}
    anchors = working_set.get("anchors")
    if not isinstance(anchors, list):
        anchors = []
    user_anchors = [item for item in anchors if item.get("kind") == "user_anchor"]
    observed_anchors = [item for item in anchors if item.get("kind") != "user_anchor"]
    attempts = working_set.get("attempts")
    if not isinstance(attempts, list):
        attempts = []
    progress = working_set.get("progress")
    if not isinstance(progress, dict):
        progress = {}
    latest = progress.get("latest")
    if not isinstance(latest, dict):
        latest = None
    compact_latest = (
        {
            key: latest[key]
            for key in (
                "wave",
                "level",
                "reasons",
                "observed_states",
                "known_anchor_hits",
                "new_anchor_count",
                "answer_fragment_count",
            )
            if key in latest
        }
        if latest is not None
        else None
    )
    compact_working_set = {
        "schema": working_set.get("schema"),
        "goal": working_set.get("goal"),
        "anchors": [*user_anchors, *observed_anchors[: max(0, 16 - len(user_anchors))]],
        "loaded_skills": working_set.get("loaded_skills", []),
        "observations": list(working_set.get("observations", []))[-12:],
        "unknowns": list(working_set.get("unknowns", []))[-8:],
        "attempts": [
            {
                key: attempt[key]
                for key in ("wave", "tools", "selector_anchor_count", "states", "progress")
                if key in attempt
            }
            for attempt in attempts[-8:]
            if isinstance(attempt, dict)
        ],
        "progress": {
            "latest": compact_latest,
            "consecutive_no_progress_waves": progress.get(
                "consecutive_no_progress_waves",
                0,
            ),
            "max_consecutive_no_progress_waves": progress.get(
                "max_consecutive_no_progress_waves",
                0,
            ),
        },
    }
    return {
        **checkpoint,
        "observations": compact_working_set["observations"],
        "unknowns": compact_working_set["unknowns"],
        "working_set": compact_working_set,
    }


def _is_previous_projection(message: dict[str, Any]) -> bool:
    if message.get("role") not in {"system", "user"}:
        return False
    try:
        payload = json.loads(str(message.get("content") or "{}"))
    except (TypeError, ValueError, json.JSONDecodeError):
        return False
    return isinstance(payload, dict) and payload.get("schema") in {
        "suwen.answer-basis.v2",
        "suwen.answer-facts.v1",
        "suwen.context-projection.v1",
        "suwen.loaded-skills.v1",
    }


def _evidence_row_payload(row: dict[str, Any]) -> dict[str, Any]:
    def decoded(name: str, fallback: Any) -> Any:
        value = row.get(name)
        if value in (None, ""):
            return fallback
        try:
            return json.loads(str(value))
        except (TypeError, ValueError, json.JSONDecodeError):
            return fallback

    return {
        "tool_call_id": row.get("tool_call_id"),
        "operation_state": row.get("state"),
        "state": row.get("state"),
        "coverage_state": row.get("coverage_state"),
        "truncation_state": row.get("truncation_state"),
        "source_ref": row.get("source_ref"),
        "source_role": row.get("source_role"),
        "observed_at": row.get("observed_at"),
        "summary": row.get("summary"),
        "data": decoded("data_json", {}),
        "safe_statements": decoded("safe_statements_json", []),
        "limitations": decoded("limitations_json", []),
        "continuation": decoded("continuation_json", None),
    }


def rebuild_context(
    messages: list[dict[str, Any]],
    *,
    evidence_by_tool_call: dict[str, dict[str, Any]],
    estimate_request: Callable[[list[dict[str, Any]]], int],
    context_window: int,
    reserved_output_tokens: int,
    policy: ContextBudgetPolicy,
    recent_protocol_pairs: int = 2,
    recent_history_messages: int = 12,
    evidence_card_max_chars: int = 2_400,
    user_context: list[str] | None = None,
    evidence_rows: list[dict[str, Any]] | None = None,
    tool_calls: list[dict[str, Any]] | None = None,
    terminal_projection: bool = False,
) -> ContextGeneration:
    """Rebuild one model request without mutating the in-memory Run ledger."""

    source = [dict(message) for message in messages if not _is_previous_projection(message)]
    groups = _protocol_groups(source)
    protocol_pair_count = 1 if terminal_projection else max(0, recent_protocol_pairs)
    keep_groups = set(groups[-protocol_pair_count:]) if protocol_pair_count else set()
    waves = _protocol_waves(source, groups, evidence_by_tool_call)
    user_messages = (
        [str(item) for item in user_context if item]
        if user_context is not None
        else [
            str(message.get("content") or "")
            for message in source
            if message.get("role") == "user" and message.get("content")
        ]
    )
    known_anchors = list(stable_anchors(user_messages, limit=24))
    user_anchors = tuple(known_anchors)
    related_by_provider_call_id: dict[str, bool] = {}
    priority_anchors_by_provider_call_id: dict[str, tuple[str, ...]] = {}
    priority_anchors_by_tool_call_id: dict[str, tuple[str, ...]] = {}
    for wave in waves:
        requests_by_id = {
            str(item.get("call_id") or ""): item
            for item in wave.get("requests", [])
            if isinstance(item, dict)
        }
        for result in wave.get("results", []):
            if not isinstance(result, dict):
                continue
            provider_call_id = str(result.get("_provider_call_id") or "")
            request = requests_by_id.get(provider_call_id, {})
            request_anchors = stable_anchors(request, limit=8)
            priority_anchors = tuple(
                dict.fromkeys([*user_anchors, *request_anchors])
            )[:16]
            priority_anchors_by_provider_call_id[provider_call_id] = priority_anchors
            tool_call_id = str(result.get("tool_call_id") or "")
            if tool_call_id:
                priority_anchors_by_tool_call_id[tool_call_id] = priority_anchors
            request_text = json.dumps(request, ensure_ascii=False, sort_keys=True).casefold()
            result_text = json.dumps(result, ensure_ascii=False, sort_keys=True).casefold()
            related = not known_anchors or any(
                anchor.casefold() in request_text or anchor.casefold() in result_text
                for anchor in known_anchors
            )
            related_by_provider_call_id[provider_call_id] = related
            state = str(result.get("state") or result.get("operation_state") or "")
            if (
                related
                and state in {"observed", "truncated", "conflict"}
                and result.get("source_role") != "capability_instruction"
            ):
                known_folded = {item.casefold() for item in known_anchors}
                for anchor in stable_anchors(result, limit=12):
                    if len(known_anchors) >= 32:
                        break
                    if anchor.casefold() not in known_folded:
                        known_anchors.append(anchor)
                        known_folded.add(anchor.casefold())

    recent_provider_call_ids = {
        str(item.get("call_id") or "")
        for start, end in keep_groups
        for item in _tool_requests(source[start])
    }
    loaded_skills = _loaded_skills(
        waves,
        evidence_by_tool_call,
        recent_provider_call_ids=recent_provider_call_ids,
    )
    loaded_skill_digests = {
        str(item.get("content_digest") or "") for item in loaded_skills
    }
    omit_indexes: set[int] = set()
    cards: list[dict[str, Any]] = []
    recent_tool_call_ids: set[str] = set()
    direct_materialization_refs: list[str] = []
    for start, end in groups:
        if (start, end) in keep_groups:
            for message in source[start + 1 : end]:
                payload = _parse_tool_payload(message)
                direct_materialization_refs.extend(_payload_evidence_refs(payload))
                if payload.get("tool_call_id"):
                    recent_tool_call_ids.add(str(payload["tool_call_id"]))
            continue
        omit_indexes.update(range(start, end))
        for message in source[start + 1 : end]:
            payload = _parse_tool_payload(message)
            loaded = _loaded_skill(payload)
            if loaded is not None and str(loaded["content_digest"]) in loaded_skill_digests:
                continue
            tool_call_id = str(payload.get("tool_call_id") or "")
            evidence = evidence_by_tool_call.get(tool_call_id, {})
            evidence_id = str(evidence.get("id") or "") or None
            cards.append(
                evidence_card(
                    payload,
                    evidence_id=evidence_id,
                    max_chars=evidence_card_max_chars,
                    known_anchors=priority_anchors_by_provider_call_id.get(
                        str(message.get("tool_call_id") or ""),
                        user_anchors,
                    ),
                    related_to_known_anchor=related_by_provider_call_id.get(
                        str(message.get("tool_call_id") or ""),
                        False,
                    ),
                )
            )

    grouped_tool_indexes = {
        index
        for start, end in groups
        for index in range(start + 1, end)
        if source[index].get("role") == "tool"
    }
    grouped_assistant_indexes = {start for start, _end in groups}
    for index, message in enumerate(source):
        if (
            message.get("role") == "assistant"
            and message.get("tool_calls")
            and index not in grouped_assistant_indexes
        ):
            omit_indexes.add(index)
    for index, message in enumerate(source):
        if message.get("role") != "tool" or index in grouped_tool_indexes:
            continue
        omit_indexes.add(index)
        payload = _parse_tool_payload(message)
        loaded = _loaded_skill(payload)
        if loaded is not None and str(loaded["content_digest"]) in loaded_skill_digests:
            continue
        tool_call_id = str(payload.get("tool_call_id") or "")
        evidence = evidence_by_tool_call.get(tool_call_id, {})
        evidence_id = str(evidence.get("id") or "") or None
        cards.append(
            evidence_card(
                payload,
                evidence_id=evidence_id,
                max_chars=evidence_card_max_chars,
                known_anchors=priority_anchors_by_provider_call_id.get(
                    str(message.get("tool_call_id") or ""),
                    user_anchors,
                ),
                related_to_known_anchor=any(
                    anchor.casefold()
                    in json.dumps(payload, ensure_ascii=False, sort_keys=True).casefold()
                    for anchor in known_anchors
                ),
            )
        )

    card_evidence_ids = {
        str(card["evidence_id"])
        for card in cards
        if isinstance(card.get("evidence_id"), str)
    }
    for tool_call_id, evidence in evidence_by_tool_call.items():
        evidence_id = str(evidence.get("id") or "")
        if tool_call_id in recent_tool_call_ids or evidence_id in card_evidence_ids:
            continue
        evidence_payload = _evidence_row_payload(evidence)
        loaded = _loaded_skill(evidence_payload)
        if loaded is not None and str(loaded["content_digest"]) in loaded_skill_digests:
            continue
        cards.append(
            evidence_card(
                evidence_payload,
                evidence_id=evidence_id or None,
                max_chars=evidence_card_max_chars,
                known_anchors=priority_anchors_by_tool_call_id.get(
                    tool_call_id,
                    user_anchors,
                ),
                related_to_known_anchor=any(
                    anchor.casefold()
                    in json.dumps(evidence_payload, ensure_ascii=False, sort_keys=True).casefold()
                    for anchor in known_anchors
                ),
            )
        )
        if evidence_id:
            card_evidence_ids.add(evidence_id)

    priority_order = {"P1": 0, "P2": 1, "P3": 2}
    cards.sort(key=lambda item: priority_order.get(str(item.get("priority") or "P3"), 3))
    working_set = build_working_set(
        user_context=user_messages,
        waves=waves,
        evidence_cards=cards,
        loaded_skills=loaded_skills,
    )
    retained = [message for index, message in enumerate(source) if index not in omit_indexes]
    checkpoint = _checkpoint(
        source,
        cards,
        user_context=user_messages,
        working_set=working_set,
    )
    checkpoint["evidence_refs"] = list(
        dict.fromkeys([*checkpoint.get("evidence_refs", []), *direct_materialization_refs])
    )
    system_end = 0
    while system_end < len(retained) and retained[system_end].get("role") == "system":
        system_end += 1
    dynamic_context: list[dict[str, Any]] = []
    skill_message = _loaded_skill_message(loaded_skills)
    if skill_message is not None:
        dynamic_context.append(skill_message)
    if evidence_rows is not None:
        fact_projection = build_answer_fact_projection(
            evidence_rows,
            tool_calls=tool_calls or (),
            user_context=user_messages,
        )
        fact_message = answer_fact_message(fact_projection)
        if fact_message is not None:
            dynamic_context.append(fact_message)
    # A checkpoint is a replacement for omitted protocol history, not a
    # duplicate of a fully retained recent Tool pair.  Keep it when cards or
    # loaded Skill projections actually need that bridge.
    if cards or loaded_skills:
        projected_checkpoint = (
            _terminal_checkpoint_projection(checkpoint)
            if terminal_projection
            else checkpoint
        )
        dynamic_context.append(_checkpoint_message(projected_checkpoint, cards))
    retained[system_end:system_end] = dynamic_context

    estimate = estimate_request(retained)
    budget = context_budget(
        context_window=context_window,
        reserved_output_tokens=reserved_output_tokens,
        estimated_input_tokens=estimate,
        policy=policy,
    )
    source_budget = budget
    omitted_history = 0
    strategy = "ledger_plus_recent_protocol"

    if terminal_projection:
        terminal_user_index = next(
            (
                index
                for index in range(len(source) - 1, -1, -1)
                if source[index].get("role") == "user" and source[index].get("content")
            ),
            None,
        )
        recent_user_corpus = set(user_messages[-max(1, min(recent_history_messages, 4)) :])
        selected_indexes = {
            index
            for index, message in enumerate(source)
            if message.get("role") == "user"
            and str(message.get("content") or "") in recent_user_corpus
        }
        for start, end in keep_groups:
            selected_indexes.update(range(start, end))
        if terminal_user_index is not None:
            selected_indexes.add(terminal_user_index)
        selected_non_system = [
            message
            for index, message in enumerate(source)
            if index in selected_indexes and message.get("role") != "system"
        ]
        terminal_systems = []
        for message in retained:
            if message.get("role") != "system":
                continue
            content = str(message.get("content") or "")
            if loaded_skills and content.startswith("<agent-skills>"):
                continue
            if content.startswith(
                ("Runtime 工具参数来源门", "Runtime Case 来源门")
            ):
                continue
            terminal_systems.append(message)
        retained = terminal_systems
        retained.extend(
            message for message in dynamic_context if message.get("role") != "system"
        )
        retained.extend(selected_non_system)
        omitted_history = max(
            0,
            len(
                [
                    message
                    for message in source
                    if message.get("role") in {"user", "assistant"}
                    and not message.get("tool_calls")
                ]
            )
            - sum(
                1
                for index in selected_indexes
                if source[index].get("role") in {"user", "assistant"}
                and not source[index].get("tool_calls")
            ),
        )
        strategy = "terminal_evidence_projection"
        estimate = estimate_request(retained)
        budget = context_budget(
            context_window=context_window,
            reserved_output_tokens=reserved_output_tokens,
            estimated_input_tokens=estimate,
            policy=policy,
        )
    elif budget.tier in {"checkpoint", "reference", "minimal", "hard_limit"}:
        protected = {
            index
            for start, end in keep_groups
            for index in range(start, end)
        }
        non_system_history = [
            index
            for index, message in enumerate(source)
            if message.get("role") in {"user", "assistant"}
            and not message.get("tool_calls")
            and index not in protected
        ]
        keep_history = set(non_system_history[-max(1, recent_history_messages) :])
        extra_omit = set(non_system_history) - keep_history
        omitted_history = len(extra_omit)
        retained = [
            message
            for index, message in enumerate(source)
            if index not in omit_indexes and index not in extra_omit
        ]
        system_end = 0
        while system_end < len(retained) and retained[system_end].get("role") == "system":
            system_end += 1
        retained[system_end:system_end] = dynamic_context
        strategy = "checkpoint_plus_refs"
        estimate = estimate_request(retained)
        budget = context_budget(
            context_window=context_window,
            reserved_output_tokens=reserved_output_tokens,
            estimated_input_tokens=estimate,
            policy=policy,
        )

    evidence_refs = tuple(
        dict.fromkeys(
            [
                evidence_id
                for card in cards
                for evidence_id in (
                    ([str(card["evidence_id"])] if isinstance(card.get("evidence_id"), str) else [])
                    + [
                        item
                        for item in card.get("evidence_refs", [])
                        if isinstance(item, str)
                    ]
                )
            ]
            + direct_materialization_refs
        )
    )
    return ContextGeneration(
        messages=retained,
        checkpoint=checkpoint,
        working_set=working_set,
        loaded_skills=loaded_skills,
        evidence_refs=evidence_refs,
        source_budget=source_budget,
        budget=budget,
        strategy=strategy,
        omitted_protocol_groups=max(0, len(groups) - len(keep_groups)),
        omitted_history_messages=omitted_history,
    )
