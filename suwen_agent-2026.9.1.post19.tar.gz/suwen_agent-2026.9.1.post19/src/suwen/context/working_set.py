from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Literal

ProgressLevel = Literal[
    "answer_progress",
    "bridge_progress",
    "coverage_progress",
    "no_progress",
]

_UUID = re.compile(
    r"(?<![0-9A-Fa-f])[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[1-5][0-9A-Fa-f]{3}-"
    r"[89ABab][0-9A-Fa-f]{3}-[0-9A-Fa-f]{12}(?![0-9A-Fa-f])"
)
_PREFIXED_IDENTIFIER = re.compile(
    r"(?<![A-Za-z0-9])(?:[A-Za-z][A-Za-z0-9]{1,24})[_:-]"
    r"[A-Za-z0-9][A-Za-z0-9._:-]{5,127}(?![A-Za-z0-9])"
)
_OPAQUE_HEX = re.compile(r"(?<![0-9A-Fa-f])[0-9A-Fa-f]{16,64}(?![0-9A-Fa-f])")
_LONG_NUMBER = re.compile(r"(?<!\d)\d{5,20}(?!\d)")
_ISO_TIME = re.compile(
    r"(?<!\d)20\d{2}[-/]\d{1,2}[-/]\d{1,2}"
    r"(?:[T ]\d{1,2}:\d{2}(?::\d{2}(?:\.\d{1,6})?)?(?:Z|[+-]\d{2}:?\d{2})?)?"
)
_ZH_TIME = re.compile(
    r"(?<!\d)20\d{2}年\d{1,2}月\d{1,2}日"
    r"(?:\s*\d{1,2}(?::|时)\d{1,2}(?::|分)?\d{0,2}秒?)?"
)
_SECRET_NEIGHBOR = re.compile(
    r"(?i)(?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|token|secret|"
    r"password|authorization|cookie|signature)\s*[:=：]\s*$"
)
_INTERNAL_ANCHOR_KEY = re.compile(
    r"(?i)^(?:_(?:provider|producer|local|truncated).*|evidence_id|tool_call_id|"
    r"provider_call_id|call_id|run_id|case_id|source_ref|observed_at|content_digest|"
    r"signature|progress_signature|call_fingerprint|contract_version|operation_state|"
    r"coverage_state|truncation_state|source_role|state|status|name|operation|subcommand|"
    r"continuation|cursor|next_cursor|opaque_cursor|limitations|catalog_digest|"
    r"catalog_revision|schema_digest|schema_version|composition_digest|artifact_digest|"
    r"install_digest|source_content_digest)$"
)
_METADATA_ANCHOR_KEY = re.compile(
    r"(?i)(?:^|_)(?:coverage|query_budget|budget|timing|transport|provenance|metadata|metrics|"
    r"debug|window|query_plan|execution_plan|returned_count|page_size|max_time_ms)$"
)

_OBSERVED_STATES = frozenset({"observed", "truncated", "conflict"})
_BOUNDARY_STATES = frozenset({"zero_matches", "not_observable"})
_NO_PROGRESS_STATES = frozenset({"no_progress", "input_rejected", "query_failed"})


def _json_text(value: Any) -> str:
    if isinstance(value, str):
        return value
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        )
    except (TypeError, ValueError):
        return str(value)


def _anchor_projection(value: Any, *, depth: int = 0) -> Any:
    if depth >= 12:
        return None
    if isinstance(value, dict):
        return [
            _anchor_projection(item, depth=depth + 1)
            for key, item in value.items()
            if not _INTERNAL_ANCHOR_KEY.match(str(key))
            and not _METADATA_ANCHOR_KEY.search(str(key))
        ]
    if isinstance(value, (list, tuple)):
        return [_anchor_projection(item, depth=depth + 1) for item in value[:256]]
    return value


def stable_anchors(value: Any, *, limit: int = 64) -> tuple[str, ...]:
    """Extract exact, domain-neutral identifiers and time shadows.

    The extractor deliberately ignores ordinary words and field names.  It is
    used only to keep already-visible exact values reachable; it never assigns
    business meaning or invents object relationships.
    """

    text = _json_text(_anchor_projection(value))
    candidates: list[tuple[int, int, int, str]] = []
    ranked_patterns = (
        (0, _UUID),
        (1, _OPAQUE_HEX),
        (2, _LONG_NUMBER),
        (3, _PREFIXED_IDENTIFIER),
        (4, _ISO_TIME),
        (4, _ZH_TIME),
    )
    for priority, pattern in ranked_patterns:
        for match in pattern.finditer(text):
            prefix = text[max(0, match.start() - 80) : match.start()]
            if _SECRET_NEIGHBOR.search(prefix):
                continue
            candidates.append((priority, match.start(), match.end(), match.group(0)))
    candidates.sort(key=lambda item: (item[0], item[1], -(item[2] - item[1])))

    selected: list[str] = []
    occupied: list[tuple[int, int]] = []
    seen: set[str] = set()
    for _priority, start, end, candidate in candidates:
        if any(start >= left and end <= right for left, right in occupied):
            continue
        normalized = candidate.casefold()
        if normalized in seen:
            continue
        selected.append(candidate)
        seen.add(normalized)
        occupied.append((start, end))
        if len(selected) >= max(1, limit):
            break
    return tuple(selected)


def _payload_state(payload: dict[str, Any]) -> str:
    return str(payload.get("state") or payload.get("operation_state") or "unknown")


def _payload_answer_fragment_count(payload: dict[str, Any]) -> int:
    safe_statements = payload.get("safe_statements")
    safe_count = (
        len([item for item in safe_statements if isinstance(item, str) and item.strip()])
        if isinstance(safe_statements, list)
        else 0
    )
    data = payload.get("data", payload.get("data_preview"))
    return safe_count + (1 if data not in (None, "", [], {}) else 0)


@dataclass(frozen=True)
class WaveProgress:
    level: ProgressLevel
    signature: str
    scope_signature: str
    reasons: tuple[str, ...]
    observed_states: tuple[str, ...]
    known_anchor_hits: int
    new_anchors: tuple[str, ...]
    new_anchor_count: int
    answer_fragment_count: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "level": self.level,
            "signature": self.signature,
            "scope_signature": self.scope_signature,
            "reasons": list(self.reasons),
            "observed_states": list(self.observed_states),
            "known_anchor_hits": self.known_anchor_hits,
            "new_anchor_count": self.new_anchor_count,
            "answer_fragment_count": self.answer_fragment_count,
        }


def classify_tool_wave(
    requests: Sequence[dict[str, Any]],
    results: Sequence[dict[str, Any]],
    *,
    known_anchors: Sequence[str],
) -> WaveProgress:
    """Classify one completed Tool wave by information gain.

    Tool names and business fields are intentionally irrelevant.  A result is
    useful when it advances an exact anchor, adds an answer-bearing observation,
    narrows a reachable boundary, or loads a capability instruction.  A fresh
    but unrelated directory page cannot hide a duplicate or rejected call.
    """

    known = tuple(dict.fromkeys(item for item in known_anchors if item))
    known_folded = {item.casefold() for item in known}
    states = tuple(dict.fromkeys(_payload_state(item) for item in results))
    known_hit_values: set[str] = set()
    related_new_anchors: list[str] = []
    answer_fragments = 0
    pair_levels: list[ProgressLevel] = []
    reasons: list[str] = []
    for index, result in enumerate(results):
        request = requests[index] if index < len(requests) else {}
        request_text = _json_text(request).casefold()
        result_text = _json_text(result).casefold()
        pair_hits = [
            anchor
            for anchor in known
            if anchor.casefold() in request_text or anchor.casefold() in result_text
        ]
        known_hit_values.update(item.casefold() for item in pair_hits)
        state = _payload_state(result)
        fragments = _payload_answer_fragment_count(result)
        result_anchors = tuple(
            item
            for item in stable_anchors(result, limit=12)
            if item.casefold() not in known_folded
        )
        capability_loaded = (
            result.get("source_role") == "capability_instruction"
            and state in _OBSERVED_STATES
        )
        has_continuation = isinstance(result.get("continuation"), dict) and bool(
            result.get("continuation")
        )

        if capability_loaded:
            pair_levels.append("coverage_progress")
            reasons.append("capability_instruction_loaded")
        elif state in _NO_PROGRESS_STATES:
            continue
        elif state in _OBSERVED_STATES and pair_hits and result_anchors:
            pair_levels.append("bridge_progress")
            related_new_anchors.extend(result_anchors[: max(0, 8 - len(related_new_anchors))])
            answer_fragments += fragments
            reasons.append("new_bridge_anchor_from_related_observation")
        elif state in _OBSERVED_STATES and pair_hits and fragments:
            pair_levels.append("answer_progress")
            answer_fragments += fragments
            reasons.append("answer_bearing_observation_for_known_anchor")
        elif state in _OBSERVED_STATES and not known:
            pair_levels.append("coverage_progress")
            related_new_anchors.extend(result_anchors[: max(0, 8 - len(related_new_anchors))])
            answer_fragments += fragments
            reasons.append("bounded_discovery_without_prior_exact_anchor")
        elif state in _BOUNDARY_STATES and (pair_hits or not known):
            pair_levels.append("coverage_progress")
            reasons.append("known_scope_boundary_narrowed")
        elif has_continuation and (pair_hits or not known):
            pair_levels.append("coverage_progress")
            reasons.append("reachable_continuation_added")
        elif state in _OBSERVED_STATES and pair_hits:
            pair_levels.append("coverage_progress")
            answer_fragments += fragments
            reasons.append("related_observation_added")

    if "answer_progress" in pair_levels:
        level: ProgressLevel = "answer_progress"
    elif "bridge_progress" in pair_levels:
        level = "bridge_progress"
    elif "coverage_progress" in pair_levels:
        level = "coverage_progress"
    else:
        level = "no_progress"
        reasons.append(
            "duplicate_rejected_or_failed_only"
            if results and all(_payload_state(item) in _NO_PROGRESS_STATES for item in results)
            else "no_anchor_or_boundary_information_gain"
        )
    new_anchors = tuple(dict.fromkeys(related_new_anchors))
    known_hits = len(known_hit_values)
    reasons = list(dict.fromkeys(reasons))

    signature_payload = {
        "level": level,
        "states": states,
        "known_anchor_hits": known_hits,
        "new_anchors": new_anchors,
        "answer_fragment_count": answer_fragments,
        "coverage": [item.get("coverage_state") for item in results],
        "truncation": [item.get("truncation_state") for item in results],
        "continuation": [item.get("continuation") for item in results],
        "safe_statements": [item.get("safe_statements") for item in results],
    }
    signature = "sha256:" + hashlib.sha256(_json_text(signature_payload).encode()).hexdigest()
    if level == "no_progress" and "no_anchor_or_boundary_information_gain" in reasons:
        scope_payload: Any = {"kind": "unanchored_discovery"}
    else:
        scope_payload = [
            {
                "name": item.get("name"),
                "operation": (
                    item.get("arguments", {}).get("operation")
                    if isinstance(item.get("arguments"), dict)
                    else None
                ),
                "subcommand": (
                    item.get("arguments", {}).get("subcommand")
                    if isinstance(item.get("arguments"), dict)
                    else None
                ),
            }
            for item in requests
            if isinstance(item, dict)
        ]
    scope_signature = "sha256:" + hashlib.sha256(_json_text(scope_payload).encode()).hexdigest()
    return WaveProgress(
        level=level,
        signature=signature,
        scope_signature=scope_signature,
        reasons=tuple(reasons),
        observed_states=states,
        known_anchor_hits=known_hits,
        new_anchors=new_anchors,
        new_anchor_count=len(new_anchors),
        answer_fragment_count=answer_fragments,
    )


def build_working_set(
    *,
    user_context: Sequence[str],
    waves: Sequence[dict[str, Any]],
    evidence_cards: Sequence[dict[str, Any]],
    loaded_skills: Sequence[dict[str, Any]],
) -> dict[str, Any]:
    """Build a deterministic, evidence-referenced investigation state."""

    user_anchors = list(stable_anchors(list(user_context), limit=24))
    known_anchors = list(user_anchors)
    anchor_rows: list[dict[str, Any]] = [
        {"value": value, "kind": "user_anchor", "source": "current_user_context"}
        for value in user_anchors
    ]
    attempts: list[dict[str, Any]] = []
    progress_rows: list[dict[str, Any]] = []
    consecutive_no_progress = 0
    max_consecutive_no_progress = 0
    last_no_progress_scope: str | None = None

    for index, wave in enumerate(waves, start=1):
        requests = wave.get("requests") if isinstance(wave.get("requests"), list) else []
        results = wave.get("results") if isinstance(wave.get("results"), list) else []
        progress = classify_tool_wave(requests, results, known_anchors=known_anchors)
        progress_row = {"wave": index, **progress.as_dict()}
        progress_rows.append(progress_row)
        if progress.level == "no_progress":
            if progress.scope_signature == last_no_progress_scope:
                consecutive_no_progress += 1
            else:
                consecutive_no_progress = 1
                last_no_progress_scope = progress.scope_signature
            max_consecutive_no_progress = max(
                max_consecutive_no_progress,
                consecutive_no_progress,
            )
        else:
            consecutive_no_progress = 0
            last_no_progress_scope = None

        if progress.level != "no_progress":
            existing = {item.casefold() for item in known_anchors}
            for value in progress.new_anchors:
                if len(anchor_rows) >= 32:
                    break
                if value.casefold() in existing:
                    continue
                source = f"tool_wave:{index}"
                for result in results:
                    if not isinstance(result, dict):
                        continue
                    projected = _json_text(_anchor_projection(result)).casefold()
                    if value.casefold() not in projected:
                        continue
                    evidence_id = result.get("evidence_id")
                    if isinstance(evidence_id, str) and evidence_id:
                        source = evidence_id
                    break
                known_anchors.append(value)
                existing.add(value.casefold())
                anchor_rows.append(
                    {"value": value, "kind": "observed_anchor", "source": source}
                )

        attempts.append(
            {
                "wave": index,
                "tools": [
                    str(item.get("name") or "")
                    for item in requests
                    if isinstance(item, dict) and item.get("name")
                ],
                "selector_anchor_count": len(stable_anchors(requests)),
                "states": list(progress.observed_states),
                "progress": progress.level,
                "progress_signature": progress.signature,
                "progress_scope_signature": progress.scope_signature,
            }
        )

    observations = []
    unknowns = []
    for card in evidence_cards:
        evidence_id = card.get("evidence_id")
        observations.append(
            {
                "evidence_id": evidence_id,
                "state": card.get("state"),
                "priority": card.get("priority"),
                "body_mode": card.get("body_mode"),
                "answer_fragment_count": len(card.get("safe_statements", []))
                + (1 if card.get("data_preview") else 0),
            }
        )
        if card.get("limitations") or card.get("continuation"):
            unknowns.append(
                {
                    "evidence_id": evidence_id,
                    "limitation_count": len(card.get("limitations", [])),
                    "has_continuation": bool(card.get("continuation")),
                }
            )

    latest_progress = progress_rows[-1] if progress_rows else None
    return {
        "schema": "suwen.investigation-working-set.v1",
        "goal": {
            "current_ref": "checkpoint.current_goal",
            "recent_context_ref": "checkpoint.recent_user_context",
        },
        "anchors": anchor_rows[:32],
        "loaded_skills": [
            {
                "skill_id": item.get("skill_id"),
                "content_digest": item.get("content_digest"),
                "projection": item.get("projection"),
            }
            for item in loaded_skills
        ],
        "observations": observations[-16:],
        "unknowns": unknowns[-12:],
        "attempts": attempts[-16:],
        "progress": {
            "latest": latest_progress,
            "consecutive_no_progress_waves": consecutive_no_progress,
            "max_consecutive_no_progress_waves": max_consecutive_no_progress,
        },
    }
