from __future__ import annotations

import threading
from typing import Any

_MAX_OCR_LINES = 200
_MAX_OCR_CHARS = 20_000


class ImageTextExtractor:
    """Bounded, local OCR for user-supplied raster images.

    The engine is loaded lazily because most Runtime processes never receive an
    image.  A single engine is shared behind a lock; current RapidOCR engines are
    not documented as safe for concurrent inference.
    """

    def __init__(self) -> None:
        self._engine: Any | None = None
        self._lock = threading.Lock()

    def extract(self, content: bytes) -> dict[str, object]:
        if not content:
            return self._failure("empty_image")
        try:
            with self._lock:
                result = self._get_engine()(content)
        except Exception:
            return self._failure("ocr_execution_failed")

        raw_texts = getattr(result, "txts", None)
        if not raw_texts:
            return {
                "state": "zero_matches",
                "engine": "rapidocr",
                "text": "",
                "line_count": 0,
                "truncation_state": "complete",
                "limitations": ["no_text_detected"],
            }

        texts = [" ".join(str(value).split()) for value in raw_texts]
        texts = [value for value in texts if value]
        if not texts:
            return {
                "state": "zero_matches",
                "engine": "rapidocr",
                "text": "",
                "line_count": 0,
                "truncation_state": "complete",
                "limitations": ["no_text_detected"],
            }

        selected: list[str] = []
        observed_chars = 0
        truncated = False
        for value in texts:
            if len(selected) >= _MAX_OCR_LINES:
                truncated = True
                break
            separator_chars = 1 if selected else 0
            remaining = _MAX_OCR_CHARS - observed_chars - separator_chars
            if remaining <= 0:
                truncated = True
                break
            selected.append(value[:remaining])
            observed_chars += separator_chars + len(selected[-1])
            if len(value) > remaining:
                truncated = True
                break

        scores = getattr(result, "scores", None)
        numeric_scores = [
            float(value)
            for value in (scores if scores is not None else ())
            if isinstance(value, (int, float))
        ]
        extraction: dict[str, object] = {
            "state": "observed",
            "engine": "rapidocr",
            "text": "\n".join(selected),
            "line_count": len(texts),
            "truncation_state": "truncated" if truncated else "complete",
            "limitations": ["ocr_may_contain_recognition_errors"],
        }
        if numeric_scores:
            extraction["average_confidence"] = round(
                sum(numeric_scores) / len(numeric_scores),
                4,
            )
        return extraction

    def _get_engine(self) -> Any:
        if self._engine is None:
            from rapidocr import RapidOCR

            self._engine = RapidOCR(
                params={
                    "Global.max_side_len": 1600,
                    "Global.log_level": "warning",
                }
            )
        return self._engine

    @staticmethod
    def _failure(reason: str) -> dict[str, object]:
        return {
            "state": "query_failed",
            "engine": "rapidocr",
            "text": "",
            "line_count": 0,
            "truncation_state": "complete",
            "limitations": [reason],
        }
