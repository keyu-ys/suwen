from __future__ import annotations

import asyncio
import json
import os
import re
from collections.abc import Mapping
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlsplit

import httpx

from .privacy import sanitize_provider_payload
from .tools import ToolRegistry
from .types import (
    ANSWER_CONTRACT_DATA_KEY,
    EvidenceEnvelope,
    EvidenceState,
    ToolDefinition,
    ToolRisk,
)

MCP_PROTOCOL_VERSION = "2025-03-26"
MAX_MCP_MESSAGE_BYTES = 2 * 1024 * 1024


class MCPProtocolError(RuntimeError):
    pass


class MCPTransport(Protocol):
    async def request(self, method: str, params: dict[str, Any]) -> dict[str, Any]: ...

    async def notify(self, method: str, params: dict[str, Any] | None = None) -> None: ...

    async def close(self) -> None: ...


class StdioMCPTransport:
    """Bounded JSON-RPC transport for an explicitly configured MCP subprocess.

    It never invokes a shell and does not inherit the parent environment. Callers
    must provide an absolute executable, explicit cwd, and the minimal environment.
    """

    def __init__(
        self,
        command: tuple[str, ...] | list[str],
        *,
        cwd: Path,
        environment: Mapping[str, str] | None = None,
        timeout_seconds: float = 30.0,
    ) -> None:
        if not command or not Path(command[0]).is_absolute():
            raise ValueError("MCP executable must be an explicit absolute path")
        resolved_cwd = cwd.resolve()
        if not resolved_cwd.is_dir():
            raise ValueError("MCP cwd must be an existing directory")
        if timeout_seconds <= 0 or timeout_seconds > 300:
            raise ValueError("MCP timeout must be between 0 and 300 seconds")
        self.command = tuple(str(item) for item in command)
        self.cwd = resolved_cwd
        self.environment = dict(environment or {})
        if any(
            not isinstance(key, str) or not isinstance(value, str) or "\x00" in key or "\x00" in value
            for key, value in self.environment.items()
        ):
            raise ValueError("MCP environment must contain safe strings")
        self.timeout_seconds = timeout_seconds
        self._process: asyncio.subprocess.Process | None = None
        self._reader_task: asyncio.Task[None] | None = None
        self._start_lock = asyncio.Lock()
        self._write_lock = asyncio.Lock()
        self._next_id = 0
        self._pending: dict[int, asyncio.Future[dict[str, Any]]] = {}

    async def start(self) -> None:
        async with self._start_lock:
            if self._process and self._process.returncode is None:
                return
            executable = Path(self.command[0])
            if not executable.is_file() or not os.access(executable, os.X_OK):
                raise MCPProtocolError("configured MCP executable is unavailable")
            self._process = await asyncio.create_subprocess_exec(
                *self.command,
                cwd=self.cwd,
                env=self.environment,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            self._reader_task = asyncio.create_task(self._read_responses())

    async def request(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        await self.start()
        process = self._require_process()
        if process.stdin is None:
            raise MCPProtocolError("MCP stdin is unavailable")
        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, Any]] = loop.create_future()
        async with self._write_lock:
            self._next_id += 1
            request_id = self._next_id
            self._pending[request_id] = future
            payload = {
                "jsonrpc": "2.0",
                "id": request_id,
                "method": method,
                "params": params,
            }
            encoded = self._encode(payload)
            process.stdin.write(encoded)
            await process.stdin.drain()
        try:
            return await asyncio.wait_for(future, timeout=self.timeout_seconds)
        except TimeoutError as exc:
            self._pending.pop(request_id, None)
            raise MCPProtocolError("MCP request timed out") from exc

    async def notify(self, method: str, params: dict[str, Any] | None = None) -> None:
        await self.start()
        process = self._require_process()
        if process.stdin is None:
            raise MCPProtocolError("MCP stdin is unavailable")
        payload: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            payload["params"] = params
        async with self._write_lock:
            process.stdin.write(self._encode(payload))
            await process.stdin.drain()

    async def close(self) -> None:
        process = self._process
        if process is None:
            return
        if process.stdin:
            process.stdin.close()
        if process.returncode is None:
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=2.0)
            except TimeoutError:
                process.kill()
                await process.wait()
        if self._reader_task:
            await asyncio.gather(self._reader_task, return_exceptions=True)
        self._fail_pending("MCP transport closed")
        self._process = None

    async def _read_responses(self) -> None:
        process = self._require_process()
        if process.stdout is None:
            self._fail_pending("MCP stdout is unavailable")
            return
        try:
            while True:
                line = await process.stdout.readline()
                if not line:
                    break
                if len(line) > MAX_MCP_MESSAGE_BYTES:
                    raise MCPProtocolError("MCP response exceeds the configured limit")
                try:
                    message = json.loads(line)
                except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                    raise MCPProtocolError("MCP returned invalid JSON") from exc
                if not isinstance(message, dict) or message.get("jsonrpc") != "2.0":
                    raise MCPProtocolError("MCP returned an invalid JSON-RPC message")
                request_id = message.get("id")
                if not isinstance(request_id, int):
                    continue
                future = self._pending.pop(request_id, None)
                if future is None or future.done():
                    continue
                if "error" in message:
                    future.set_exception(MCPProtocolError("MCP request failed"))
                    continue
                result = message.get("result")
                if not isinstance(result, dict):
                    future.set_exception(MCPProtocolError("MCP result must be an object"))
                    continue
                future.set_result(result)
        except Exception as exc:
            self._fail_pending(str(exc))
        finally:
            if process.returncode is None:
                await process.wait()
            self._fail_pending("MCP process ended")

    def _fail_pending(self, message: str) -> None:
        for future in self._pending.values():
            if not future.done():
                future.set_exception(MCPProtocolError(message))
        self._pending.clear()

    def _require_process(self) -> asyncio.subprocess.Process:
        if self._process is None:
            raise MCPProtocolError("MCP process has not started")
        return self._process

    @staticmethod
    def _encode(payload: dict[str, Any]) -> bytes:
        encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode() + b"\n"
        if len(encoded) > MAX_MCP_MESSAGE_BYTES:
            raise MCPProtocolError("MCP request exceeds the configured limit")
        return encoded


class StreamableHTTPMCPTransport:
    """Bounded MCP Streamable HTTP transport.

    The transport implements the request/response subset required by Tool
    providers.  It accepts both JSON and SSE responses, retains an MCP session
    identifier when the server issues one, and never follows redirects.
    """

    def __init__(
        self,
        endpoint: str,
        *,
        timeout_seconds: float = 30.0,
        max_response_bytes: int = MAX_MCP_MESSAGE_BYTES,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        selected = endpoint.strip()
        parsed = urlsplit(selected)
        if (
            parsed.scheme not in {"http", "https"}
            or not parsed.netloc
            or parsed.username is not None
            or parsed.password is not None
            or parsed.fragment
        ):
            raise ValueError("MCP HTTP endpoint must be an HTTP(S) URL without credentials or fragment")
        if timeout_seconds <= 0 or timeout_seconds > 300:
            raise ValueError("MCP timeout must be between 0 and 300 seconds")
        if not 1 <= max_response_bytes <= 16 * 1024 * 1024:
            raise ValueError("MCP response limit must be between 1 byte and 16 MiB")
        self.endpoint = selected
        self.timeout_seconds = float(timeout_seconds)
        self.max_response_bytes = int(max_response_bytes)
        self._client = httpx.AsyncClient(
            timeout=self.timeout_seconds,
            follow_redirects=False,
            transport=transport,
        )
        self._next_id = 0
        self._session_id: str | None = None
        self._closed = False

    @property
    def session_id(self) -> str | None:
        return self._session_id

    async def request(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        self._next_id += 1
        request_id = self._next_id
        payload = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params,
        }
        messages = await self._post(payload, notification=False)
        response = next((item for item in messages if item.get("id") == request_id), None)
        if response is None:
            raise MCPProtocolError("MCP HTTP response lacks the matching JSON-RPC id")
        if "error" in response:
            error = response.get("error")
            code = error.get("code") if isinstance(error, dict) else None
            suffix = f" ({code})" if isinstance(code, int) else ""
            raise MCPProtocolError(f"MCP request failed{suffix}")
        result = response.get("result")
        if not isinstance(result, dict):
            raise MCPProtocolError("MCP result must be an object")
        return result

    async def notify(self, method: str, params: dict[str, Any] | None = None) -> None:
        payload: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            payload["params"] = params
        await self._post(payload, notification=True)

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._session_id:
            try:
                await self._client.delete(
                    self.endpoint,
                    headers={
                        "Mcp-Session-Id": self._session_id,
                        "MCP-Protocol-Version": MCP_PROTOCOL_VERSION,
                    },
                )
            except httpx.HTTPError:
                pass
        await self._client.aclose()

    async def _post(
        self,
        payload: dict[str, Any],
        *,
        notification: bool,
    ) -> list[dict[str, Any]]:
        if self._closed:
            raise MCPProtocolError("MCP HTTP transport is closed")
        encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        if len(encoded) > MAX_MCP_MESSAGE_BYTES:
            raise MCPProtocolError("MCP request exceeds the configured limit")
        headers = {
            "Accept": "application/json, text/event-stream",
            "Content-Type": "application/json",
            "MCP-Protocol-Version": MCP_PROTOCOL_VERSION,
        }
        if self._session_id:
            headers["Mcp-Session-Id"] = self._session_id
        try:
            async with self._client.stream(
                "POST",
                self.endpoint,
                content=encoded,
                headers=headers,
            ) as response:
                issued_session = response.headers.get("Mcp-Session-Id")
                if issued_session:
                    if len(issued_session) > 4096 or any(ord(char) < 32 for char in issued_session):
                        raise MCPProtocolError("MCP server returned an invalid session id")
                    self._session_id = issued_session
                if notification and response.status_code == 202:
                    return []
                if response.status_code < 200 or response.status_code >= 300:
                    raise MCPProtocolError(f"MCP HTTP request failed with status {response.status_code}")
                body = bytearray()
                async for chunk in response.aiter_bytes():
                    body.extend(chunk)
                    if len(body) > self.max_response_bytes:
                        raise MCPProtocolError("MCP response exceeds the configured limit")
        except httpx.TimeoutException as exc:
            raise MCPProtocolError("MCP request timed out") from exc
        except httpx.HTTPError as exc:
            raise MCPProtocolError("MCP HTTP transport failed") from exc
        if not body:
            if notification:
                return []
            raise MCPProtocolError("MCP HTTP response is empty")
        media_type = response.headers.get("content-type", "").split(";", 1)[0].strip().lower()
        if media_type == "application/json":
            return _decode_jsonrpc_body(bytes(body))
        if media_type == "text/event-stream":
            return _decode_sse_jsonrpc_body(bytes(body))
        raise MCPProtocolError("MCP HTTP response has an unsupported content type")


def _decode_jsonrpc_body(body: bytes) -> list[dict[str, Any]]:
    try:
        decoded = json.loads(body)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise MCPProtocolError("MCP returned invalid JSON") from exc
    items = decoded if isinstance(decoded, list) else [decoded]
    if not items or len(items) > 256:
        raise MCPProtocolError("MCP returned an invalid JSON-RPC message set")
    if any(not isinstance(item, dict) or item.get("jsonrpc") != "2.0" for item in items):
        raise MCPProtocolError("MCP returned an invalid JSON-RPC message")
    return items


def _decode_sse_jsonrpc_body(body: bytes) -> list[dict[str, Any]]:
    try:
        text = body.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise MCPProtocolError("MCP returned invalid SSE text") from exc
    messages: list[dict[str, Any]] = []
    for event in text.replace("\r\n", "\n").replace("\r", "\n").split("\n\n"):
        data_lines = [line[5:].lstrip() for line in event.splitlines() if line.startswith("data:")]
        if not data_lines:
            continue
        try:
            decoded = json.loads("\n".join(data_lines))
        except json.JSONDecodeError as exc:
            raise MCPProtocolError("MCP returned invalid SSE JSON") from exc
        if not isinstance(decoded, dict) or decoded.get("jsonrpc") != "2.0":
            raise MCPProtocolError("MCP returned an invalid SSE JSON-RPC message")
        messages.append(decoded)
        if len(messages) > 256:
            raise MCPProtocolError("MCP SSE response contains too many messages")
    if not messages:
        raise MCPProtocolError("MCP SSE response contains no JSON-RPC message")
    return messages


class MCPClient:
    def __init__(self, transport: MCPTransport, *, client_name: str = "suwen"):
        self.transport = transport
        self.client_name = client_name
        self._initialized = False
        self._initialize_result: dict[str, Any] | None = None
        self._initialize_lock = asyncio.Lock()

    async def initialize(self) -> dict[str, Any]:
        async with self._initialize_lock:
            if self._initialized:
                return dict(self._initialize_result or {})
            result = await self.transport.request(
                "initialize",
                {
                    "protocolVersion": MCP_PROTOCOL_VERSION,
                    "capabilities": {},
                    "clientInfo": {"name": self.client_name, "version": "0.1.0"},
                },
            )
            if not isinstance(result.get("protocolVersion"), str):
                raise MCPProtocolError("MCP initialize response lacks protocolVersion")
            await self.transport.notify("notifications/initialized")
            self._initialized = True
            self._initialize_result = dict(result)
            return dict(result)

    async def list_tools(self) -> list[dict[str, Any]]:
        await self.initialize()
        result = await self.transport.request("tools/list", {})
        tools = result.get("tools")
        if not isinstance(tools, list) or any(not isinstance(item, dict) for item in tools):
            raise MCPProtocolError("MCP tools/list returned an invalid catalog")
        return tools

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        await self.initialize()
        return await self.transport.request("tools/call", {"name": name, "arguments": arguments})

    async def close(self) -> None:
        await self.transport.close()


class MCPToolProvider:
    def __init__(
        self,
        provider_id: str,
        client: MCPClient,
        *,
        controlled_actions: set[str] | None = None,
    ) -> None:
        self.provider_id = provider_id
        self.client = client
        self.controlled_actions = controlled_actions or set()
        self.initialize_result: dict[str, Any] = {}
        self.catalog_snapshot: list[dict[str, Any]] = []

    async def register(self, registry: ToolRegistry) -> tuple[ToolDefinition, ...]:
        self.initialize_result = await self.client.initialize()
        catalog = await self.client.list_tools()
        definitions: list[ToolDefinition] = []
        snapshot: list[dict[str, Any]] = []
        for item in catalog:
            name = item.get("name")
            description = item.get("description")
            schema = item.get("inputSchema")
            if not isinstance(name, str) or not name:
                raise MCPProtocolError("MCP Tool lacks a stable name")
            if not isinstance(description, str) or not isinstance(schema, dict):
                raise MCPProtocolError("MCP Tool lacks description or inputSchema")
            output_schema = item.get("outputSchema")
            if output_schema is not None and not isinstance(output_schema, dict):
                raise MCPProtocolError("MCP Tool outputSchema must be an object")
            annotations = item.get("annotations")
            read_only = bool(isinstance(annotations, dict) and annotations.get("readOnlyHint") is True)
            if name in self.controlled_actions:
                risk = ToolRisk.CONTROLLED_ACTION
            elif read_only:
                risk = ToolRisk.READ_ONLY
            else:
                risk = ToolRisk.UNCLASSIFIED
            definition = ToolDefinition(
                name=name,
                description=description,
                input_schema=schema,
                risk=risk,
                provider_id=self.provider_id,
            )

            async def call(arguments: dict[str, Any], *, tool_name: str = name) -> EvidenceEnvelope:
                public_arguments = {key: value for key, value in arguments.items() if not key.startswith("_")}
                result = await self.client.call_tool(tool_name, public_arguments)
                return project_mcp_evidence(result, self.provider_id, tool_name)

            registry.register(definition, call)
            definitions.append(definition)
            snapshot.append(
                {
                    "name": name,
                    "description": description,
                    "input_schema": schema,
                    "output_schema": output_schema,
                    "annotations": annotations if isinstance(annotations, dict) else {},
                    "risk": str(risk),
                    "result_contract": definition.result_contract,
                }
            )
        self.catalog_snapshot = sorted(snapshot, key=lambda item: str(item["name"]))
        return tuple(definitions)


def project_mcp_evidence(result: dict[str, Any], provider_id: str, tool_name: str) -> EvidenceEnvelope:
    if result.get("isError") is True:
        return EvidenceEnvelope(
            state=EvidenceState.QUERY_FAILED,
            summary="MCP Provider 报告工具调用失败；未将其解释为零命中。",
            coverage_state="unknown",
            source_ref=f"mcp:{provider_id}:{tool_name}",
            truncation_state="unknown",
            source_role="capability_status",
            limitations=("mcp_tool_error",),
        )
    payload = result.get("structuredContent")
    if not isinstance(payload, dict):
        content = result.get("content")
        text = (
            next(
                (
                    item.get("text")
                    for item in content
                    if isinstance(item, dict)
                    and item.get("type") == "text"
                    and isinstance(item.get("text"), str)
                ),
                None,
            )
            if isinstance(content, list)
            else None
        )
        if text is not None:
            try:
                decoded = json.loads(text)
            except json.JSONDecodeError:
                decoded = None
            payload = decoded if isinstance(decoded, dict) else None
    return project_producer_evidence(
        payload,
        provider_id,
        tool_name,
        source_namespace="mcp",
        provider_label="MCP",
    )


def _producer_answer_contract(payload: dict[str, Any]) -> tuple[bool, dict[str, Any] | None]:
    """Validate an optional producer declaration of answer-bearing data.

    Providers may declare exact JSON paths or path/value facts.  Runtime later
    verifies declared values against the returned data; query metadata is never
    promoted merely because it happens to contain a scalar leaf.
    """

    present = "answer_paths" in payload or "answer_facts" in payload
    if not present:
        return False, None
    raw_paths = payload.get("answer_paths", [])
    raw_facts = payload.get("answer_facts", [])
    if (
        not isinstance(raw_paths, list)
        or len(raw_paths) > 128
        or any(not isinstance(item, str) or not item.strip() or len(item) > 512 for item in raw_paths)
        or not isinstance(raw_facts, list)
        or len(raw_facts) > 128
    ):
        return True, None
    facts: list[dict[str, Any]] = []
    for item in raw_facts:
        if (
            not isinstance(item, dict)
            or not set(item).issubset({"path", "object_ref", "value"})
            or not isinstance(item.get("path"), str)
            or not item["path"].strip()
            or len(item["path"]) > 512
            or (
                "object_ref" in item
                and (
                    not isinstance(item["object_ref"], str)
                    or not item["object_ref"].strip()
                    or len(item["object_ref"]) > 512
                )
            )
        ):
            return True, None
        facts.append(dict(item))
    paths = list(dict.fromkeys(item.strip() for item in raw_paths))
    if not paths and not facts:
        return True, None
    return True, {"answer_paths": paths, "answer_facts": facts}


def _answer_contract_matches_data(
    contract: dict[str, Any],
    data: dict[str, Any],
) -> bool:
    missing = object()

    def parts(path: str) -> list[str]:
        if path.startswith("/"):
            return [
                item.replace("~1", "/").replace("~0", "~")
                for item in path.split("/")[1:]
                if item
            ]
        return [item for item in re.split(r"[./]+", path.strip("/.")) if item]

    def resolve(path: str) -> Any:
        current: Any = data
        for part in parts(path):
            if isinstance(current, dict) and part in current:
                current = current[part]
            elif isinstance(current, list) and part.isdigit() and int(part) < len(current):
                current = current[int(part)]
            else:
                return missing
        return current

    for path in contract.get("answer_paths", []):
        if resolve(path) is missing:
            return False
    for fact in contract.get("answer_facts", []):
        observed = resolve(str(fact["path"]))
        if observed is missing or (
            "value" in fact
            and json.dumps(observed, ensure_ascii=False, sort_keys=True, default=str)
            != json.dumps(fact["value"], ensure_ascii=False, sort_keys=True, default=str)
        ):
            return False
    return True


def project_producer_evidence(
    payload: Any,
    provider_id: str,
    tool_name: str,
    *,
    source_namespace: str = "provider",
    provider_label: str = "Provider",
) -> EvidenceEnvelope:
    """Project a portable producer payload through Suwen's canonical boundary."""

    fallback_source = f"{source_namespace}:{provider_id}:{tool_name}"
    normalized_payload = _normalize_model_evidence_payload(payload)
    if normalized_payload is None:
        return EvidenceEnvelope(
            state=EvidenceState.QUERY_FAILED,
            summary=f"{provider_label} 返回未满足 model-evidence.v2，原始结果未进入模型。",
            coverage_state="unknown",
            source_ref=fallback_source,
            truncation_state="unknown",
            source_role="capability_status",
            limitations=("evidence_contract_mismatch",),
        )
    payload = _normalize_input_rejection_consistency(normalized_payload)
    safe_payload = sanitize_provider_payload(payload)
    action_token = _provider_action_token(payload)
    operation_state = str(safe_payload.get("operation_state", "query_failed"))
    state = {
        "observed": EvidenceState.OBSERVED,
        "zero_matches": EvidenceState.ZERO_MATCHES,
        "query_failed": EvidenceState.QUERY_FAILED,
        "input_rejected": EvidenceState.INPUT_REJECTED,
        "not_observable": EvidenceState.NOT_OBSERVABLE,
        "conflict": EvidenceState.CONFLICT,
        "truncated": EvidenceState.TRUNCATED,
    }.get(operation_state, EvidenceState.QUERY_FAILED)
    contract_present, answer_contract = _producer_answer_contract(safe_payload)
    if contract_present and answer_contract is None:
        return EvidenceEnvelope(
            state=EvidenceState.QUERY_FAILED,
            summary=f"{provider_label} 返回的 answer-facts 合同无效，原始结果未进入模型。",
            coverage_state="unknown",
            source_ref=fallback_source,
            truncation_state="unknown",
            source_role="capability_status",
            limitations=("evidence_answer_contract_mismatch",),
        )
    data = dict(safe_payload.get("data")) if isinstance(safe_payload.get("data"), dict) else {}
    if ANSWER_CONTRACT_DATA_KEY in data:
        return EvidenceEnvelope(
            state=EvidenceState.QUERY_FAILED,
            summary=f"{provider_label} 返回了 Runtime 保留字段，原始结果未进入模型。",
            coverage_state="unknown",
            source_ref=fallback_source,
            truncation_state="unknown",
            source_role="capability_status",
            limitations=("evidence_reserved_field_collision",),
        )
    if answer_contract and not _answer_contract_matches_data(answer_contract, data):
        return EvidenceEnvelope(
            state=EvidenceState.QUERY_FAILED,
            summary=f"{provider_label} 声明的 answer-facts 与返回数据不一致，原始结果未进入模型。",
            coverage_state="unknown",
            source_ref=fallback_source,
            truncation_state="unknown",
            source_role="capability_status",
            limitations=("evidence_answer_contract_mismatch",),
        )
    if answer_contract:
        data[ANSWER_CONTRACT_DATA_KEY] = answer_contract
    limitations = safe_payload.get("limitations")
    safe_statements = safe_payload.get("safe_statements")
    continuation = safe_payload.get("continuation")
    source_ref = safe_payload.get("source_ref")
    if not isinstance(source_ref, str) or "://" in source_ref or source_ref.startswith("[REDACTED"):
        source_ref = fallback_source
    return EvidenceEnvelope(
        state=state,
        summary=str(safe_payload.get("summary") or f"{provider_label} 返回了结构化证据。")[:10_000],
        data=data,
        coverage_state=_bounded_contract_value(
            safe_payload.get("coverage_state"),
            {"proven_total", "bounded", "sample_only", "unknown"},
            "unknown",
        ),
        source_ref=source_ref,
        contract_version="model-evidence.v2",
        truncation_state=_bounded_contract_value(
            safe_payload.get("truncation_state"),
            {"complete", "partial", "truncated", "unknown"},
            "unknown",
        ),
        source_role=_bounded_contract_value(
            safe_payload.get("source_role"),
            {"current_observation", "reference", "mechanism", "capability_status"},
            "capability_status",
        ),
        limitations=tuple(str(item) for item in limitations) if isinstance(limitations, list) else (),
        safe_statements=(
            tuple(str(item) for item in safe_statements) if isinstance(safe_statements, list) else ()
        ),
        continuation=continuation if isinstance(continuation, dict) else None,
        observed_at=(
            str(safe_payload["observed_at"]) if isinstance(safe_payload.get("observed_at"), str) else None
        ),
        provider_observation=safe_payload,
        action_token=action_token,
    )


def _normalize_input_rejection_consistency(payload: dict[str, Any]) -> dict[str, Any]:
    """Honor an explicit producer input-rejection signal over a generic failure label.

    This is intentionally field- and provider-neutral.  Suwen does not parse a
    database error string or infer a business schema; it only reconciles the
    producer's own structured ``provider_kind=source_query_rejected`` metadata
    with the canonical Evidence state.
    """

    if str(payload.get("operation_state") or "") != "query_failed":
        return payload
    data = payload.get("data")
    if not isinstance(data, dict):
        return payload
    error = data.get("error")
    if not isinstance(error, dict) or error.get("provider_kind") != "source_query_rejected":
        return payload

    normalized = dict(payload)
    normalized_data = dict(data)
    normalized_data["reason_code"] = str(
        error.get("reason_code") or "producer_query_input_rejected"
    )
    normalized_data["minimum_correction"] = str(
        error.get("minimum_correction")
        or "按当前 Tool 的公开 schema 实质修改被来源拒绝的输入结构或取值；不要原样重复。"
    )
    for field in (
        "field",
        "expected_type",
        "expected_structure",
        "received_type",
        "received_structure",
        "example_arguments",
    ):
        value = error.get(field)
        if value not in (None, "", [], {}):
            normalized_data[field] = value
    normalized["data"] = normalized_data
    normalized["operation_state"] = "input_rejected"
    normalized["source_role"] = "capability_status"
    normalized["summary"] = (
        "Provider 明确拒绝了本次查询输入；这是可纠正的输入边界，"
        "不表示来源不可用、对象不存在或查询零命中。"
    )
    limitations = [
        str(item) for item in normalized.get("limitations", []) if isinstance(item, str)
    ]
    normalized["limitations"] = list(
        dict.fromkeys([*limitations, "producer_contract_inconsistent", "source_query_rejected"])
    )
    return normalized


def _normalize_model_evidence_payload(value: Any) -> dict[str, Any] | None:
    """Normalize supported producer projections into Suwen's canonical envelope.

    `model-evidence.v2` is a semantic contract used by more than one host. Suwen's
    canonical field layout is not the only producer layout; portable providers may
    emit `evidence_contract_version` plus nested `evidence_status`. This adapter is
    deliberately generic and conservative; unknown versions, statuses, or
    contradictory state pairs fail closed.
    """

    if not isinstance(value, dict):
        return None
    if value.get("contract_version") == "model-evidence.v2":
        return dict(value)
    if value.get("evidence_contract_version") != "model-evidence.v2":
        return None
    evidence_status = value.get("evidence_status")
    raw_status = value.get("status")
    if not isinstance(evidence_status, dict) or not isinstance(raw_status, str):
        return None
    producer_operation = evidence_status.get("operation_state")
    allowed_operation_pairs = {
        "matched": {"completed", "partial"},
        "zero_matches": {"completed", "partial"},
        "object_absent": {"completed", "partial"},
        "conflict": {"completed", "completed_with_conflict"},
        "query_failed": {"failed"},
        "input_rejected": {"failed"},
        "not_observable": {"not_observable"},
    }
    if producer_operation not in allowed_operation_pairs.get(raw_status, set()):
        return None

    if raw_status == "matched":
        operation_state = "observed"
    elif raw_status in {"zero_matches", "object_absent"}:
        # An incomplete empty slice does not prove a zero-result set.
        operation_state = "zero_matches" if producer_operation == "completed" else "observed"
    elif raw_status == "conflict":
        operation_state = "conflict"
    else:
        operation_state = raw_status

    producer_truncation = evidence_status.get("truncation_state")
    if producer_truncation == "truncated":
        truncation_state = "truncated"
    elif producer_operation == "partial":
        truncation_state = "partial"
    elif producer_truncation == "not_marked_truncated":
        # This only means the returned payload was not marked as cut off. Overall
        # coverage remains independent and conservative below.
        truncation_state = "complete"
    elif producer_truncation == "unknown":
        truncation_state = "unknown"
    else:
        return None

    producer_coverage = evidence_status.get("coverage_state")
    coverage_state = {
        "proven_total": "proven_total",
        "bounded": "bounded",
        "sample_only": "sample_only",
        "unproven": "unknown",
        "unknown": "unknown",
    }.get(producer_coverage)
    if coverage_state is None:
        return None

    raw_role = value.get("evidence_role")
    source_role = {
        "direct_observation": "current_observation",
        "reference": "reference",
        "capability_status": "capability_status",
    }.get(raw_role)
    if source_role is None:
        source_role = (
            "capability_status"
            if operation_state in {"query_failed", "input_rejected", "not_observable"}
            else "current_observation"
        )

    safe_statements = evidence_status.get("safe_statements")
    if not isinstance(safe_statements, list) or any(not isinstance(item, str) for item in safe_statements):
        return None
    summary = "；".join(item.strip() for item in safe_statements if item.strip())
    if not summary:
        summary = f"MCP 返回了 {raw_status} 状态的结构化证据。"

    envelope_fields = {
        "evidence_contract_version",
        "evidence_status",
        "status",
        "evidence_role",
        "limitations",
        "continuation",
        "action_token",
        "answer_paths",
        "answer_facts",
        "_local_developer_delivery",
    }
    result_data = {key: item for key, item in value.items() if key not in envelope_fields}
    limitations = value.get("limitations", [])
    if not isinstance(limitations, list) or any(not isinstance(item, str) for item in limitations):
        return None
    normalized: dict[str, Any] = {
        "contract_version": "model-evidence.v2",
        "operation_state": operation_state,
        "truncation_state": truncation_state,
        "coverage_state": coverage_state,
        "source_role": source_role,
        "summary": summary,
        "data": result_data,
        "limitations": list(limitations),
        "safe_statements": list(safe_statements),
        "continuation": value.get("continuation"),
        "_producer_contract_shape": "evidence_contract_version+nested_status",
        "_producer_status": raw_status,
        "_producer_evidence_status": evidence_status,
    }
    for field in ("answer_paths", "answer_facts"):
        if field in evidence_status:
            normalized[field] = evidence_status[field]
        elif field in value:
            normalized[field] = value[field]
    for field in ("source_ref", "observed_at", "action_token"):
        if field in value:
            normalized[field] = value[field]
    return normalized


def _bounded_contract_value(value: Any, allowed: set[str], fallback: str) -> str:
    return value if isinstance(value, str) and value in allowed else fallback


def _provider_action_token(payload: dict[str, Any]) -> str | None:
    if payload.get("operation_state") != "observed":
        return None
    candidate = payload.get("action_token")
    if candidate is None and isinstance(payload.get("data"), dict):
        candidate = payload["data"].get("action_token")
    if not isinstance(candidate, str) or not candidate or len(candidate) > 4096:
        return None
    return candidate
