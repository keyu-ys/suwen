from __future__ import annotations

import sqlite3
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from .repository import Repository
from .types import EvidenceState, InboundEvent

if TYPE_CHECKING:
    from .artifacts import ArtifactStore


class CaseService:
    def __init__(self, repository: Repository, artifacts: ArtifactStore | None = None):
        self.repository = repository
        self.artifacts = artifacts

    def assert_admitted(self, event: InboundEvent) -> None:
        """Apply the group mention boundary before durable acknowledgement."""

        self._assert_group_conversation_admitted(event)

    def ingest(self, event: InboundEvent, *, preclaimed: bool = False) -> tuple[dict, dict, bool]:
        """Return case, message, duplicate.

        Channel admission must have completed before calling this method.
        """
        if event.command is not None:
            raise ValueError("control events must not be ingested as Case messages")
        event_key = self._event_key(event, event.event_id)
        created_artifact_ids: list[str] = []
        with self.repository.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                result = self._ingest_in_transaction(
                    connection,
                    event,
                    event_key,
                    created_artifact_ids,
                    preclaimed=preclaimed,
                )
                connection.commit()
            except BaseException:
                connection.rollback()
                if self.artifacts is not None and created_artifact_ids:
                    self.artifacts.discard(created_artifact_ids)
                raise
        return result

    def _ingest_in_transaction(
        self,
        connection: sqlite3.Connection,
        event: InboundEvent,
        event_key: str,
        created_artifact_ids: list[str],
        *,
        preclaimed: bool,
    ) -> tuple[dict, dict, bool]:
        if not self.repository._claim_inbound_event(connection, event_key, event.channel):
            row = connection.execute(
                """SELECT case_id, channel, agent_id, state FROM inbound_events
                   WHERE event_id=?""",
                (event_key,),
            ).fetchone()
            if row and row["case_id"]:
                case = self.repository._get_case(connection, row["case_id"])
                message = connection.execute(
                    "SELECT * FROM messages WHERE external_event_id=?", (event_key,)
                ).fetchone()
                if not message:
                    raise InboundEventInProgress(event.event_id)
                return case, dict(message), True
            if (
                not preclaimed
                or not row
                or row["state"] not in {"received", "materializing"}
                or row["channel"] != event.channel
                or (row["agent_id"] and row["agent_id"] != event.agent_id)
            ):
                raise InboundEventInProgress(event.event_id)

        connection.execute(
            "UPDATE inbound_events SET agent_id=? WHERE event_id=?",
            (event.agent_id, event_key),
        )

        binding_actor, binding, parent_case_id = self._conversation_context(
            connection,
            event,
        )
        self._assert_group_conversation_admitted(event)
        if parent_case_id and binding and binding["case_id"] != parent_case_id:
            raise InboundNotAdmitted("conversation_binding_conflict")

        if parent_case_id:
            case = self.repository._get_case(connection, parent_case_id)
            if case["agent_id"] != event.agent_id:
                raise InboundNotAdmitted("parent_message_belongs_to_another_agent")
            if case["lifecycle"] == "closed":
                reopen_reason = (
                    "thread_activity" if event.scope_kind == "thread" else "group_reply_activity"
                )
                self.repository._reopen_case(connection, case["id"], reopen_reason)
                case = self.repository._get_case(connection, case["id"])
            if event.scope_kind == "thread" and not binding:
                self.repository._bind_case(
                    connection,
                    case["id"],
                    event.channel,
                    event.channel_instance,
                    event.scope_kind,
                    event.scope_ref,
                    binding_actor,
                )
        elif binding:
            case = self.repository._get_case(connection, binding["case_id"])
            if case["lifecycle"] == "closed":
                if event.scope_kind == "thread":
                    self.repository._reopen_case(connection, case["id"], "thread_activity")
                    case = self.repository._get_case(connection, case["id"])
                else:
                    case = self.repository._create_case(
                        connection, self._title(event.content), agent_id=event.agent_id
                    )
                    self.repository._bind_case(
                        connection,
                        case["id"],
                        event.channel,
                        event.channel_instance,
                        event.scope_kind,
                        event.scope_ref,
                        binding_actor,
                    )
        else:
            case = self.repository._create_case(
                connection, self._title(event.content), agent_id=event.agent_id
            )
            if event.scope_kind != "group":
                self.repository._bind_case(
                    connection,
                    case["id"],
                    event.channel,
                    event.channel_instance,
                    event.scope_kind,
                    event.scope_ref,
                    binding_actor,
                )

        attachment_descriptors: list[dict[str, object]] = []
        if event.attachments:
            if self.artifacts is None:
                raise ValueError("inbound image storage is unavailable")
            attachment_descriptors = self.artifacts.materialize_inbound_images(
                event.attachments,
                case_id=case["id"],
                connection=connection,
            )
            created_artifact_ids.extend(
                str(item["artifact_id"]) for item in attachment_descriptors
            )
        reply_contexts: list[dict[str, object]] = []
        for context in event.contexts:
            context_attachments: list[dict[str, object]] = []
            if context.attachments:
                if self.artifacts is None:
                    raise ValueError("inbound image storage is unavailable")
                context_attachments = self.artifacts.materialize_inbound_images(
                    context.attachments,
                    case_id=case["id"],
                    connection=connection,
                )
                created_artifact_ids.extend(
                    str(item["artifact_id"]) for item in context_attachments
                )
            projected_context: dict[str, object] = {
                "kind": context.kind,
                "external_ref": context.external_ref,
                "content": context.content,
                "state": (
                    context.state.value
                    if isinstance(context.state, EvidenceState)
                    else str(context.state)
                ),
                "limitations": list(context.limitations),
            }
            if context_attachments:
                projected_context["attachments"] = context_attachments
            reply_contexts.append(projected_context)
        message_metadata = {
            "channel": event.channel,
            "channel_instance": event.channel_instance,
            "scope_kind": event.scope_kind,
            "scope_ref": event.scope_ref,
            "parent_event_ref": event.parent_event_ref,
            "reply_address": event.reply_address,
        }
        if attachment_descriptors:
            message_metadata["attachments"] = attachment_descriptors
        if reply_contexts:
            message_metadata["reply_contexts"] = reply_contexts
        message = self.repository._add_message(
            connection,
            case["id"],
            "user",
            event.content,
            actor_ref=event.actor_ref,
            external_event_id=event_key,
            metadata=message_metadata,
            now=datetime.fromisoformat(event.occurred_at),
        )
        self.repository._link_inbound_event(connection, event_key, case["id"], "admitted")
        self.repository._schedule_job(
            connection,
            "process_inbound",
            f"inbound-run:{message['id']}",
            {
                "case_id": case["id"],
                "message_id": message["id"],
                "event_id": event_key,
            },
            datetime.now(UTC),
            case["id"],
        )
        external_message_ref = event.reply_address.get("reply_to")
        if external_message_ref:
            self.repository._link_external_message(
                connection,
                event.channel,
                event.channel_instance,
                str(external_message_ref),
                case["id"],
                event_key,
                direction="inbound",
                message_kind="image" if attachment_descriptors else "text",
                internal_message_id=message["id"],
                parent_message_ref=(
                    str(event.reply_address.get("parent_id"))
                    if event.reply_address.get("parent_id")
                    else None
                ),
                root_message_ref=(
                    str(event.reply_address.get("root_id")) if event.reply_address.get("root_id") else None
                ),
                thread_ref=(
                    str(event.reply_address.get("thread_id"))
                    if event.reply_address.get("thread_id")
                    else None
                ),
                lifecycle_state="received",
                channel_revision=(
                    event.reply_address.get("channel_revision")
                    if isinstance(event.reply_address.get("channel_revision"), int)
                    else None
                ),
            )
        return self.repository._get_case(connection, case["id"]), message, False

    def _conversation_context(
        self,
        connection: sqlite3.Connection,
        event: InboundEvent,
    ) -> tuple[str, sqlite3.Row | None, str | None]:
        binding_actor = self._binding_actor(event)
        binding = None
        parent_case_id = None
        parent_refs = event.reply_address.get("parent_refs", [])
        if not isinstance(parent_refs, list):
            parent_refs = []
        refs = [str(ref) for ref in parent_refs if ref]
        if event.parent_event_ref and event.parent_event_ref not in refs:
            refs.append(event.parent_event_ref)
        if event.scope_kind in {"group", "thread"}:
            for parent_ref in refs:
                linked = self.repository._external_message_context(
                    connection, event.channel, event.channel_instance, parent_ref
                )
                if linked:
                    parent_case_id = linked["case_id"]
                    break
        if event.scope_kind != "group":
            binding = self.repository._find_binding(
                connection,
                event.channel,
                event.channel_instance,
                event.scope_kind,
                event.scope_ref,
                binding_actor,
                event.agent_id,
            )
        return binding_actor, binding, parent_case_id

    @staticmethod
    def _assert_group_conversation_admitted(event: InboundEvent) -> None:
        if event.scope_kind not in {"group", "thread"}:
            return
        if not event.reply_address.get("require_mention_in_group"):
            return
        if event.reply_address.get("mentioned_bot"):
            return
        raise InboundNotAdmitted("not_mentioned")

    def reset_binding(self, event: InboundEvent) -> str | None:
        """Close and unbind the current Case without creating another one."""

        if event.command not in {"new_case", "clear"}:
            raise ValueError("reset binding requires new_case or clear")
        with self.repository.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                binding = None
                if event.scope_kind != "group":
                    binding = self.repository._find_binding(
                        connection,
                        event.channel,
                        event.channel_instance,
                        event.scope_kind,
                        event.scope_ref,
                        self._binding_actor(event),
                        event.agent_id,
                    )
                affected_case_id = binding["case_id"] if binding else None
                if binding:
                    reset_reason = (
                        "conversation_replaced" if event.command == "new_case" else "context_cleared"
                    )
                    self.repository._close_case(connection, affected_case_id, reset_reason)
                    self.repository._deactivate_binding(connection, binding["id"], reset_reason)
                connection.commit()
            except BaseException:
                connection.rollback()
                raise
        return affected_case_id

    @staticmethod
    def _binding_actor(event: InboundEvent) -> str:
        if event.scope_kind == "thread":
            return ""
        if event.scope_kind in {"dm", "group"}:
            return event.actor_ref
        return event.actor_ref

    @staticmethod
    def _title(content: str) -> str:
        value = " ".join(content.strip().split())
        return value[:80] or "新问诊"

    @staticmethod
    def _event_key(event: InboundEvent, event_id: str) -> str:
        return f"{event.channel}:{event.channel_instance}:{event_id}"


class InboundEventInProgress(RuntimeError):
    pass


class InboundNotAdmitted(ValueError):
    pass
