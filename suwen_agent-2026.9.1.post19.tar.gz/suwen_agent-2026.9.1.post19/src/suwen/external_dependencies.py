"""Host-owned bindings for ordinary external CLI dependencies."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from .capability_api import CapabilityExternalRequest, CapabilityExternalResult
from .db import Database
from .repository import iso, new_id

_STABLE_ID = re.compile(r"^[a-z][a-z0-9-]{1,63}$")
_SUBCOMMAND = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$")
_HTTP_STATUS = re.compile(
    r"(?ix)(?:"
    r"\b(?:HTTP(?:\s+(?:status|error))?|status(?:_code)?|response\s+status)"
    r"\s*[:=]?\s*(?P<explicit>401|403|429|5\d\d)\b|"
    r"\b(?P<denied>401|403)\b.{0,32}\b(?:Forbidden|Unauthorized|Client\s+Error)\b|"
    r"\b(?P<rate>429)\b.{0,32}\b(?:Too\s+Many\s+Requests|rate.?limit)\b|"
    r"\b(?P<server>5\d\d)\b.{0,32}\b(?:Server\s+Error|Bad\s+Gateway|"
    r"Service\s+Unavailable|Gateway\s+Timeout)\b)"
)
_NON_RETRYABLE_FAILURES = frozenset({"source_access_denied"})
_MAX_RUN_BLOCKED_SUBCOMMANDS = 4_096


class ExternalDependencyError(ValueError):
    """A CLI binding does not satisfy the host's bounded execution contract."""


class ExternalDependencyManager:
    def __init__(self, database: Database) -> None:
        self.database = database
        self._run_blocked_subcommands: dict[tuple[str, str, int, str], str] = {}

    def preview(
        self,
        dependency_id: str,
        contract: str,
        command: str,
        *,
        version_arguments: tuple[str, ...] = ("--version",),
    ) -> dict[str, Any]:
        """Resolve a normal command and optionally observe standard version output."""
        self._validate_identity(dependency_id, contract)
        normalized_command, resolved = self._resolve_command(command)
        version = self._observe_version(resolved, version_arguments)
        return {
            "operation": "preview",
            "dependency_id": dependency_id,
            "contract": contract,
            "command": normalized_command,
            "resolved_executable": resolved,
            "version": version,
            "version_observed": version is not None,
            "source_called": False,
        }

    def configure(
        self,
        dependency_id: str,
        contract: str,
        command: str,
        actor: str,
        *,
        allowed_subcommands: tuple[str, ...],
        timeout_seconds: float = 30.0,
        max_output_bytes: int = 128 * 1024,
        version_arguments: tuple[str, ...] = ("--version",),
    ) -> dict[str, Any]:
        preview = self.preview(
            dependency_id, contract, command, version_arguments=version_arguments
        )
        subcommands = self._validate_policy(
            allowed_subcommands, timeout_seconds, max_output_bytes
        )
        policy = {
            "allowed_subcommands": list(subcommands),
            "timeout_seconds": float(timeout_seconds),
            "max_output_bytes": int(max_output_bytes),
        }
        policy_digest = hashlib.sha256(self._canonical_json(policy).encode()).hexdigest()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                """SELECT id FROM external_dependency_bindings
                   WHERE dependency_id=? AND contract=? AND active=1
                     AND command=? AND resolved_executable=?
                     AND COALESCE(version, '')=COALESCE(?, '') AND policy_digest=?""",
                (
                    dependency_id,
                    contract,
                    preview["command"],
                    preview["resolved_executable"],
                    preview["version"],
                    policy_digest,
                ),
            ).fetchone()
            if existing is not None:
                connection.commit()
                return {**self.binding_view(str(existing["id"])), "idempotent": True}
            generation = int(
                connection.execute(
                    """SELECT COALESCE(MAX(generation), 0) FROM external_dependency_bindings
                       WHERE dependency_id=? AND contract=?""",
                    (dependency_id, contract),
                ).fetchone()[0]
            ) + 1
            now = iso()
            connection.execute(
                """UPDATE external_dependency_bindings SET active=0, disabled_at=?
                   WHERE dependency_id=? AND contract=? AND active=1""",
                (now, dependency_id, contract),
            )
            binding_id = new_id("externalbinding")
            connection.execute(
                """INSERT INTO external_dependency_bindings(
                   id, dependency_id, contract, command, resolved_executable, version,
                   generation, allowed_subcommands_json, timeout_seconds,
                   max_output_bytes, policy_digest, active, configured_by, configured_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)""",
                (
                    binding_id,
                    dependency_id,
                    contract,
                    preview["command"],
                    preview["resolved_executable"],
                    preview["version"],
                    generation,
                    json.dumps(list(subcommands), ensure_ascii=False),
                    timeout_seconds,
                    max_output_bytes,
                    policy_digest,
                    actor,
                    now,
                ),
            )
            connection.commit()
        return {**self.binding_view(binding_id), "idempotent": False}

    def disable(self, dependency_id: str, contract: str, actor: str) -> dict[str, Any]:
        self._validate_identity(dependency_id, contract)
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT id FROM external_dependency_bindings
                   WHERE dependency_id=? AND contract=? AND active=1""",
                (dependency_id, contract),
            ).fetchone()
            if row is None:
                previous = connection.execute(
                    """SELECT id FROM external_dependency_bindings
                       WHERE dependency_id=? AND contract=?
                       ORDER BY generation DESC LIMIT 1""",
                    (dependency_id, contract),
                ).fetchone()
                if previous is None:
                    raise KeyError(f"{dependency_id}:{contract}")
                return {**self.binding_view(str(previous["id"])), "idempotent": True}
            connection.execute(
                """UPDATE external_dependency_bindings
                   SET active=0, disabled_at=?, configured_by=? WHERE id=?""",
                (iso(), actor, row["id"]),
            )
        return {**self.binding_view(str(row["id"])), "idempotent": False}

    def executor_for(
        self,
        run_id: str | None,
        declared_dependencies: tuple[dict[str, str], ...],
        *,
        provided_bindings: tuple[dict[str, Any], ...] = (),
    ):
        contracts = {item["id"]: item["contract"] for item in declared_dependencies}
        providers = {item["id"]: dict(item) for item in provided_bindings}

        async def execute(request: CapabilityExternalRequest) -> CapabilityExternalResult:
            contract = contracts.get(request.dependency_id)
            if contract is None:
                return CapabilityExternalResult(
                    state="unavailable", failure_kind="undeclared_dependency"
                )
            provider = providers.get(request.dependency_id)
            if provider is not None:
                if provider.get("contract") != contract:
                    return CapabilityExternalResult(
                        state="failed", failure_kind="provided_contract_mismatch"
                    )
                binding = self._freeze_provided(run_id, provider)
                if binding is None:
                    return CapabilityExternalResult(
                        state="failed", failure_kind="provided_binding_conflict"
                    )
                blocked_key = self._blocked_key(run_id, request, binding)
                if blocked_key is not None and blocked_key in self._run_blocked_subcommands:
                    return CapabilityExternalResult(
                        state="failed",
                        failure_kind=self._run_blocked_subcommands[blocked_key],
                    )
                result = self._execute_provided(binding, request)
                if run_id is not None:
                    self._record_call(run_id, request.dependency_id, result)
                    if blocked_key is not None and result.failure_kind in _NON_RETRYABLE_FAILURES:
                        self._run_blocked_subcommands[blocked_key] = str(result.failure_kind)
                return result
            binding = self._resolve_binding(run_id, request.dependency_id, contract)
            if binding is None:
                return CapabilityExternalResult(
                    state="unavailable", failure_kind="external_dependency_unavailable"
                )
            blocked_key = self._blocked_key(run_id, request, binding)
            if blocked_key is not None and blocked_key in self._run_blocked_subcommands:
                return CapabilityExternalResult(
                    state="failed",
                    failure_kind=self._run_blocked_subcommands[blocked_key],
                )
            result = self._execute(binding, request)
            if run_id is not None:
                self._record_call(run_id, request.dependency_id, result)
                if blocked_key is not None and result.failure_kind in _NON_RETRYABLE_FAILURES:
                    self._run_blocked_subcommands[blocked_key] = str(result.failure_kind)
                    if len(self._run_blocked_subcommands) > _MAX_RUN_BLOCKED_SUBCOMMANDS:
                        self._run_blocked_subcommands.pop(next(iter(self._run_blocked_subcommands)))
            return result

        return execute

    def _freeze_provided(
        self,
        run_id: str | None,
        provider: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Freeze one executable entrypoint supplied by the installed capability.

        This is not a mutable operator binding.  Its identity is the exact
        capability version, content digest, code root and entrypoint already
        selected by the Agent version for this Run.
        """

        allowed_subcommands = tuple(provider["allowed_subcommands"])
        timeout_seconds = float(provider["timeout_seconds"])
        max_output_bytes = int(provider["max_output_bytes"])
        policy = {
            "allowed_subcommands": list(allowed_subcommands),
            "timeout_seconds": timeout_seconds,
            "max_output_bytes": max_output_bytes,
            "provider_entrypoint": provider["entrypoint"],
            "capability_digest": provider["capability_digest"],
        }
        policy_digest = hashlib.sha256(self._canonical_json(policy).encode()).hexdigest()
        code_root = str(Path(str(provider["code_root"])).resolve())
        command = self._canonical_json(
            {
                "kind": "installed-capability-provider",
                "code_root": code_root,
                "entrypoint": provider["entrypoint"],
            }
        )
        version = (
            f"{provider['capability_id']}@{provider['capability_version']}"
            f"+sha256:{str(provider['capability_digest'])[:16]}"
        )
        binding = {
            **provider,
            "code_root": code_root,
            "command": command,
            "resolved_executable": str(Path(sys.executable).resolve()),
            "version": version,
            "generation": 0,
            "binding_generation": 0,
            "allowed_subcommands_json": json.dumps(list(allowed_subcommands)),
            "timeout_seconds": timeout_seconds,
            "max_output_bytes": max_output_bytes,
            "policy_digest": policy_digest,
        }
        if run_id is None:
            return binding
        with self.database.connect() as connection:
            existing = connection.execute(
                """SELECT * FROM run_external_dependencies
                   WHERE run_id=? AND dependency_id=?""",
                (run_id, provider["id"]),
            ).fetchone()
            if existing is None:
                connection.execute(
                    """INSERT INTO run_external_dependencies(
                       run_id, dependency_id, contract, binding_id, binding_generation,
                       command, resolved_executable, version, policy_digest, state, frozen_at
                    ) VALUES (?, ?, ?, NULL, 0, ?, ?, ?, ?, 'bound', ?)""",
                    (
                        run_id,
                        provider["id"],
                        provider["contract"],
                        command,
                        binding["resolved_executable"],
                        version,
                        policy_digest,
                        iso(),
                    ),
                )
            else:
                frozen_identity = (
                    existing["contract"],
                    existing["command"],
                    existing["resolved_executable"],
                    existing["version"],
                    existing["policy_digest"],
                )
                expected_identity = (
                    provider["contract"],
                    command,
                    binding["resolved_executable"],
                    version,
                    policy_digest,
                )
                if frozen_identity != expected_identity:
                    return None
        return binding

    @staticmethod
    def _execute_provided(
        binding: dict[str, Any],
        request: CapabilityExternalRequest,
    ) -> CapabilityExternalResult:
        allowed = json.loads(binding["allowed_subcommands_json"])
        if request.arguments[0] not in allowed:
            return CapabilityExternalResult(
                state="failed", failure_kind="subcommand_not_allowed"
            )
        code_root = Path(str(binding["code_root"])).resolve()
        entrypoint = str(binding["entrypoint"])
        module_name, separator, function_name = entrypoint.partition(":")
        module_path = code_root.joinpath(*module_name.split("."))
        module_file = module_path.with_suffix(".py")
        module_init = module_path / "__init__.py"
        selected_module = module_file if module_file.is_file() else module_init
        try:
            selected_module.resolve().relative_to(code_root)
        except (OSError, ValueError):
            return CapabilityExternalResult(
                state="failed", failure_kind="provided_entrypoint_unavailable"
            )
        if not separator or not function_name or not selected_module.is_file():
            return CapabilityExternalResult(
                state="failed", failure_kind="provided_entrypoint_unavailable"
            )
        timeout = min(float(binding["timeout_seconds"]), request.timeout_seconds)
        output_limit = min(int(binding["max_output_bytes"]), request.max_output_bytes)
        bootstrap = (
            "import importlib,sys;"
            "root,entry=sys.argv[1:3];"
            "sys.path.insert(0,root);"
            "module,name=entry.split(':',1);"
            "target=getattr(importlib.import_module(module),name);"
            "sys.argv=[entry,*sys.argv[3:]];"
            "result=target();"
            "raise SystemExit(result if isinstance(result,int) else 0)"
        )
        environment = os.environ.copy()
        environment["PYTHONNOUSERSITE"] = "1"
        try:
            completed = subprocess.run(
                [
                    str(binding["resolved_executable"]),
                    "-I",
                    "-c",
                    bootstrap,
                    str(code_root),
                    entrypoint,
                    *request.arguments,
                ],
                capture_output=True,
                check=False,
                timeout=timeout,
                env=environment,
                cwd="/tmp",
            )
        except subprocess.TimeoutExpired:
            return CapabilityExternalResult(
                state="timed_out", failure_kind="external_timeout"
            )
        except OSError:
            return CapabilityExternalResult(
                state="failed", failure_kind="external_exec_failed"
            )
        raw_stdout = completed.stdout[:output_limit]
        remaining = max(0, output_limit - len(raw_stdout))
        raw_stderr = completed.stderr[:remaining]
        truncated = len(completed.stdout) + len(completed.stderr) > output_limit
        try:
            stdout = raw_stdout.decode("utf-8")
            stderr = raw_stderr.decode("utf-8")
        except UnicodeDecodeError:
            return CapabilityExternalResult(
                state="output_rejected", failure_kind="output_not_utf8"
            )
        if "\x00" in stdout or "\x00" in stderr:
            return CapabilityExternalResult(
                state="output_rejected", failure_kind="output_unsafe"
            )
        if completed.returncode != 0:
            return CapabilityExternalResult(
                state="failed",
                stdout=stdout,
                stderr=stderr,
                exit_code=completed.returncode,
                failure_kind=ExternalDependencyManager._failure_kind(stdout, stderr),
                output_truncated=truncated,
            )
        return CapabilityExternalResult(
            state="succeeded",
            stdout=stdout,
            stderr=stderr,
            exit_code=0,
            output_truncated=truncated,
        )

    def active_binding(self, dependency_id: str, contract: str) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT id FROM external_dependency_bindings
                   WHERE dependency_id=? AND contract=? AND active=1""",
                (dependency_id, contract),
            ).fetchone()
        return self.binding_view(str(row["id"])) if row else None

    def binding_view(self, binding_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT * FROM external_dependency_bindings WHERE id=?", (binding_id,)
            ).fetchone()
        if not row:
            raise KeyError(binding_id)
        item = dict(row)
        item["active"] = bool(item["active"])
        item["allowed_subcommands"] = json.loads(item.pop("allowed_subcommands_json"))
        return item

    def list_bindings(self) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT id FROM external_dependency_bindings ORDER BY dependency_id, contract, generation"
            ).fetchall()
        return [self.binding_view(str(row["id"])) for row in rows]

    def _resolve_binding(self, run_id: str | None, dependency_id: str, contract: str) -> Any:
        with self.database.connect() as connection:
            if run_id is not None:
                frozen = connection.execute(
                    """SELECT red.*, edb.allowed_subcommands_json, edb.timeout_seconds,
                              edb.max_output_bytes
                       FROM run_external_dependencies red
                       LEFT JOIN external_dependency_bindings edb ON edb.id=red.binding_id
                       WHERE red.run_id=? AND red.dependency_id=?""",
                    (run_id, dependency_id),
                ).fetchone()
                if frozen:
                    return frozen if frozen["state"] != "unavailable" else None
            active = connection.execute(
                """SELECT * FROM external_dependency_bindings
                   WHERE dependency_id=? AND contract=? AND active=1""",
                (dependency_id, contract),
            ).fetchone()
            if run_id is not None:
                connection.execute(
                    """INSERT INTO run_external_dependencies(
                       run_id, dependency_id, contract, binding_id, binding_generation,
                       command, resolved_executable, version, policy_digest, state, frozen_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(run_id, dependency_id) DO NOTHING""",
                    (
                        run_id,
                        dependency_id,
                        contract,
                        active["id"] if active else None,
                        active["generation"] if active else None,
                        active["command"] if active else None,
                        active["resolved_executable"] if active else None,
                        active["version"] if active else None,
                        active["policy_digest"] if active else None,
                        "bound" if active else "unavailable",
                        iso(),
                    ),
                )
                frozen = connection.execute(
                    """SELECT red.*, edb.allowed_subcommands_json, edb.timeout_seconds,
                              edb.max_output_bytes
                       FROM run_external_dependencies red
                       LEFT JOIN external_dependency_bindings edb ON edb.id=red.binding_id
                       WHERE red.run_id=? AND red.dependency_id=?""",
                    (run_id, dependency_id),
                ).fetchone()
                return frozen if frozen and frozen["state"] != "unavailable" else None
            return active

    @staticmethod
    def _execute(binding: Any, request: CapabilityExternalRequest) -> CapabilityExternalResult:
        allowed = json.loads(binding["allowed_subcommands_json"])
        if request.arguments[0] not in allowed:
            return CapabilityExternalResult(state="failed", failure_kind="subcommand_not_allowed")
        timeout = min(float(binding["timeout_seconds"]), request.timeout_seconds)
        output_limit = min(int(binding["max_output_bytes"]), request.max_output_bytes)
        try:
            completed = subprocess.run(
                [str(binding["resolved_executable"]), *request.arguments],
                capture_output=True,
                check=False,
                timeout=timeout,
                env=os.environ.copy(),
            )
        except subprocess.TimeoutExpired:
            return CapabilityExternalResult(state="timed_out", failure_kind="external_timeout")
        except OSError:
            return CapabilityExternalResult(state="failed", failure_kind="external_exec_failed")
        raw_stdout = completed.stdout[:output_limit]
        remaining = max(0, output_limit - len(raw_stdout))
        raw_stderr = completed.stderr[:remaining]
        truncated = len(completed.stdout) + len(completed.stderr) > output_limit
        try:
            stdout = raw_stdout.decode("utf-8")
            stderr = raw_stderr.decode("utf-8")
        except UnicodeDecodeError:
            return CapabilityExternalResult(state="output_rejected", failure_kind="output_not_utf8")
        if "\x00" in stdout or "\x00" in stderr:
            return CapabilityExternalResult(state="output_rejected", failure_kind="output_unsafe")
        if completed.returncode != 0:
            return CapabilityExternalResult(
                state="failed",
                stdout=stdout,
                stderr=stderr,
                exit_code=completed.returncode,
                failure_kind=ExternalDependencyManager._failure_kind(stdout, stderr),
                output_truncated=truncated,
            )
        return CapabilityExternalResult(
            state="succeeded", stdout=stdout, stderr=stderr, exit_code=0,
            output_truncated=truncated
        )

    def _record_call(self, run_id: str, dependency_id: str, result: CapabilityExternalResult) -> None:
        state = {
            "succeeded": "called",
            "timed_out": "timed-out",
            "unavailable": "unavailable",
        }.get(result.state, "failed")
        with self.database.connect() as connection:
            connection.execute(
                """UPDATE run_external_dependencies SET state=?, call_count=call_count+1,
                       first_called_at=COALESCE(first_called_at, ?)
                   WHERE run_id=? AND dependency_id=?""",
                (state, iso(), run_id, dependency_id),
            )

    @staticmethod
    def _blocked_key(
        run_id: str | None,
        request: CapabilityExternalRequest,
        binding: Any,
    ) -> tuple[str, str, int, str] | None:
        if run_id is None:
            return None
        generation = binding["binding_generation"]
        if generation is None:
            generation = binding["generation"] if "generation" in binding.keys() else 0
        return (
            run_id,
            request.dependency_id,
            int(generation or 0),
            request.arguments[0],
        )

    @staticmethod
    def _failure_kind(stdout: str, stderr: str) -> str:
        match = _HTTP_STATUS.search(f"{stderr}\n{stdout}")
        if match is None:
            return "external_nonzero_exit"
        status = int(next(value for value in match.groupdict().values() if value is not None))
        if status in {401, 403}:
            return "source_access_denied"
        if status == 429:
            return "source_rate_limited"
        return "source_unavailable"

    @staticmethod
    def _resolve_command(command: str) -> tuple[str, str]:
        if not isinstance(command, str) or not command.strip() or "\x00" in command:
            raise ExternalDependencyError("external CLI command is invalid")
        normalized = command.strip()
        candidate = shutil.which(normalized)
        if candidate is None:
            direct = Path(normalized).expanduser()
            if direct.is_file() and os.access(direct, os.X_OK):
                candidate = str(direct)
        if candidate is None:
            raise ExternalDependencyError("external CLI command is not executable")
        return normalized, str(Path(candidate).resolve())

    @staticmethod
    def _observe_version(resolved: str, arguments: tuple[str, ...]) -> str | None:
        if not arguments:
            return None
        if any(not isinstance(item, str) or "\x00" in item for item in arguments):
            raise ExternalDependencyError("version arguments are invalid")
        try:
            completed = subprocess.run(
                [resolved, *arguments], capture_output=True, check=False, timeout=5,
                env=os.environ.copy(),
            )
        except (OSError, subprocess.TimeoutExpired):
            return None
        raw = completed.stdout or completed.stderr
        if completed.returncode != 0 or len(raw) > 16 * 1024:
            return None
        try:
            value = raw.decode("utf-8").strip()
        except UnicodeDecodeError:
            return None
        return value[:500] or None

    @staticmethod
    def _validate_identity(dependency_id: str, contract: str) -> None:
        if not _STABLE_ID.fullmatch(dependency_id):
            raise ExternalDependencyError("external dependency id is invalid")
        if not contract or len(contract) > 100 or "/" in contract or "\\" in contract:
            raise ExternalDependencyError("external dependency contract is invalid")

    @staticmethod
    def _validate_policy(
        allowed_subcommands: tuple[str, ...], timeout_seconds: float, max_output_bytes: int
    ) -> tuple[str, ...]:
        if not allowed_subcommands or len(allowed_subcommands) > 64:
            raise ExternalDependencyError("allowed subcommands must contain 1 to 64 values")
        normalized = tuple(dict.fromkeys(allowed_subcommands))
        if any(not isinstance(item, str) or not _SUBCOMMAND.fullmatch(item) for item in normalized):
            raise ExternalDependencyError("allowed subcommand is invalid")
        if not 0 < timeout_seconds <= 300:
            raise ExternalDependencyError("CLI timeout must be between 0 and 300 seconds")
        if not 1 <= max_output_bytes <= 2 * 1024 * 1024:
            raise ExternalDependencyError("CLI output bound must be between 1 byte and 2 MiB")
        return normalized

    @staticmethod
    def _canonical_json(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


__all__ = ["ExternalDependencyError", "ExternalDependencyManager"]
