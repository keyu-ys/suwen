from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from typing import Any

from .db import Database
from .packs import PackInspection, PackRegistry, pack_catalog_manifest
from .repository import iso, new_id
from .tools import ToolRegistry

_STABLE_ID = re.compile(r"^[a-z][a-z0-9-]{1,63}$")


def _digest(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _loads(value: str | None, fallback: Any) -> Any:
    return json.loads(value) if value else fallback


def _semantic_version_key(value: str) -> tuple[int, int, int, int, str]:
    match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?", value)
    if not match:
        return (-1, -1, -1, 0, value)
    major, minor, patch, prerelease = match.groups()
    return (
        int(major),
        int(minor),
        int(patch),
        1 if prerelease is None else 0,
        prerelease or "",
    )


class CapabilityRegistry:
    """Versioned Prompt/Pack management without exposing reference bodies or secrets."""

    def __init__(
        self,
        database: Database,
        packs: PackRegistry,
        tools: ToolRegistry,
    ):
        self.database = database
        self.packs = packs
        self.tools = tools

    def sync_loaded_catalog(self, actor: str = "system:pack-loader") -> dict[str, Any]:
        """Register versions already loaded from the deployment-controlled Pack directory.

        Loading and trust checks happen before this method. This method only records the
        immutable catalog metadata; it never downloads content or executes code.
        """
        created_packs: list[str] = []
        created_versions: list[str] = []
        now = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                for loaded in self.packs.list():
                    pack = connection.execute(
                        "SELECT id, trust_level FROM capability_packs WHERE id=?",
                        (loaded.id,),
                    ).fetchone()
                    if pack and pack["trust_level"] != loaded.trust_level:
                        raise ValueError(
                            f"loaded Pack trust level changed for {loaded.id}; create a new Pack id"
                        )
                    if not pack:
                        connection.execute(
                            """INSERT INTO capability_packs(
                               id, name, description, trust_level, status,
                               created_at, updated_at
                            ) VALUES (?, ?, ?, ?, 'installed', ?, ?)""",
                            (
                                loaded.id,
                                loaded.name,
                                loaded.description,
                                loaded.trust_level,
                                now,
                                now,
                            ),
                        )
                        created_packs.append(loaded.id)
                    existing = connection.execute(
                        """SELECT id, digest, source_ref FROM capability_pack_versions
                           WHERE pack_id=? AND version=?""",
                        (loaded.id, loaded.version),
                    ).fetchone()
                    if existing:
                        if existing["digest"] != loaded.digest:
                            raise ValueError(
                                f"loaded Pack version content changed in place: {loaded.id}@{loaded.version}"
                            )
                        continue
                    manifest = pack_catalog_manifest(loaded)
                    version_id = new_id("packver")
                    connection.execute(
                        """INSERT INTO capability_pack_versions(
                           id, pack_id, version, manifest_json, digest, source_ref,
                           compatible_core_range, created_by, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (
                            version_id,
                            loaded.id,
                            loaded.version,
                            json.dumps(manifest, ensure_ascii=False, sort_keys=True),
                            loaded.digest,
                            f"catalog:{loaded.publisher}",
                            loaded.compatible_core_range,
                            actor,
                            now,
                        ),
                    )
                    connection.execute(
                        "UPDATE capability_packs SET updated_at=? WHERE id=?",
                        (now, loaded.id),
                    )
                    self._audit(
                        connection,
                        actor,
                        "capability_pack.version_registered",
                        loaded.id,
                        loaded.version,
                        loaded.digest,
                        "succeeded",
                        {"pack_version_id": version_id, "source": "controlled_catalog"},
                    )
                    created_versions.append(version_id)
                connection.commit()
            except BaseException:
                connection.rollback()
                raise
        return {
            "created_packs": created_packs,
            "created_versions": created_versions,
            "loaded_versions": len(self.packs.list()),
        }

    def install_inspection(self, inspection: PackInspection, actor: str) -> dict[str, Any]:
        """Persist one safely inspected exact Pack version before runtime activation."""
        self._stable_id(inspection.id)
        manifest = pack_catalog_manifest(inspection)
        now = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                pack = connection.execute(
                    "SELECT id, trust_level, status FROM capability_packs WHERE id=?",
                    (inspection.id,),
                ).fetchone()
                created_pack = pack is None
                if pack:
                    if pack["trust_level"] != inspection.trust_level:
                        raise ValueError(
                            "Pack trust level changed; publish the new capability under a new Pack id"
                        )
                    if pack["status"] == "retired":
                        raise ValueError("retired Pack cannot receive a new version")
                else:
                    connection.execute(
                        """INSERT INTO capability_packs(
                           id, name, description, trust_level, status,
                           created_at, updated_at
                        ) VALUES (?, ?, ?, ?, 'installed', ?, ?)""",
                        (
                            inspection.id,
                            inspection.name,
                            inspection.description,
                            inspection.trust_level,
                            now,
                            now,
                        ),
                    )
                existing = connection.execute(
                    """SELECT id, digest FROM capability_pack_versions
                       WHERE pack_id=? AND version=?""",
                    (inspection.id, inspection.version),
                ).fetchone()
                if existing:
                    if existing["digest"] != inspection.digest:
                        raise ValueError(f"Pack version content changed in place: {inspection.trust_ref}")
                    connection.commit()
                    return {
                        "pack_id": inspection.id,
                        "pack_version_id": existing["id"],
                        "version": inspection.version,
                        "content_digest": inspection.digest,
                        "created_pack": False,
                        "created_version": False,
                    }
                version_id = new_id("packver")
                connection.execute(
                    """INSERT INTO capability_pack_versions(
                       id, pack_id, version, manifest_json, digest, source_ref,
                       compatible_core_range, created_by, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        version_id,
                        inspection.id,
                        inspection.version,
                        json.dumps(manifest, ensure_ascii=False, sort_keys=True),
                        inspection.digest,
                        f"catalog:{inspection.publisher}",
                        inspection.compatible_core_range,
                        actor,
                        now,
                    ),
                )
                connection.execute(
                    """UPDATE capability_packs
                       SET name=?, description=?, updated_at=? WHERE id=?""",
                    (inspection.name, inspection.description, now, inspection.id),
                )
                self._audit(
                    connection,
                    actor,
                    "capability_pack.version_installed",
                    inspection.id,
                    inspection.version,
                    inspection.digest,
                    "succeeded",
                    {
                        "pack_version_id": version_id,
                        "source": "controlled_directory",
                        "trusted_code": inspection.trusted_code,
                        "skill_count": len(inspection.skills),
                        "tool_count": len(inspection.tool_names),
                    },
                )
                connection.commit()
            except BaseException:
                connection.rollback()
                raise
        return {
            "pack_id": inspection.id,
            "pack_version_id": version_id,
            "version": inspection.version,
            "content_digest": inspection.digest,
            "created_pack": created_pack,
            "created_version": True,
        }

    def list_packs(self) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM capability_packs ORDER BY updated_at DESC, id"
            ).fetchall()
            return [self._pack_view(connection, row) for row in rows]

    def get_pack(self, pack_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute("SELECT * FROM capability_packs WHERE id=?", (pack_id,)).fetchone()
            if not row:
                raise KeyError(pack_id)
            return self._pack_view(connection, row)

    def _pack_view(self, connection: sqlite3.Connection, pack_row: sqlite3.Row) -> dict[str, Any]:
        result = dict(pack_row)
        loaded_by_version = {item.version: item for item in self.packs.list() if item.id == pack_row["id"]}
        versions = connection.execute(
            """SELECT * FROM capability_pack_versions
               WHERE pack_id=? ORDER BY created_at DESC, version DESC""",
            (pack_row["id"],),
        ).fetchall()
        version_views: list[dict[str, Any]] = []
        for version in versions:
            item = dict(version)
            item["manifest"] = _loads(item.pop("manifest_json"), {})
            loaded = loaded_by_version.get(item["version"])
            item["loaded"] = loaded is not None
            item["loaded_content_digest"] = loaded.digest if loaded else None
            item["loaded_skill_count"] = len(loaded.skills) if loaded else 0
            item["loaded_tool_count"] = len(loaded.tool_names) if loaded else 0
            item["loaded_reference_count"] = (
                sum(len(skill.references) for skill in loaded.skills) if loaded else 0
            )
            item["loaded_skills"] = (
                [
                    {
                        "id": skill.id,
                        "version": skill.version,
                        "name": skill.name,
                        "description": skill.description,
                        "applicability": skill.applicability,
                        "fallback": skill.fallback,
                        "source_revision": skill.source_revision,
                        "content_digest": skill.content_digest,
                        "references": [
                            {
                                "id": reference.id,
                                "title": reference.title,
                                "description": reference.description,
                            }
                            for reference in skill.references
                        ],
                    }
                    for skill in loaded.skills
                ]
                if loaded
                else []
            )
            item["loaded_tool_names"] = list(loaded.tool_names) if loaded else []
            item["loaded_trusted_code"] = bool(loaded and loaded.trusted_code)
            item["loaded_process_authority"] = (
                "same_as_suwen_process" if loaded and loaded.trusted_code else "not_applicable"
            )
            usage = connection.execute(
                """SELECT av.agent_id, av.id AS agent_version_id, av.version,
                          av.status AS agent_version_status, a.status AS agent_status
                   FROM agent_version_packs avp
                   JOIN agent_versions av ON av.id=avp.agent_version_id
                   JOIN agents a ON a.id=av.agent_id
                   WHERE avp.pack_version_id=? AND avp.enabled=1
                   ORDER BY av.agent_id, av.version""",
                (item["id"],),
            ).fetchall()
            item["agent_usage"] = [dict(row) for row in usage]
            validation = connection.execute(
                """SELECT status, findings_json, created_at, finished_at
                   FROM config_validation_runs
                   WHERE target_type='capability_pack_version' AND target_id=?
                   ORDER BY created_at DESC LIMIT 1""",
                (item["id"],),
            ).fetchone()
            item["last_validation"] = None
            if validation:
                item["last_validation"] = dict(validation)
                item["last_validation"]["findings"] = _loads(item["last_validation"].pop("findings_json"), [])
            version_views.append(item)
        version_views.sort(
            key=lambda item: _semantic_version_key(str(item["version"])),
            reverse=True,
        )
        result["versions"] = version_views
        return result

    def validate_pack_version(self, pack_version_id: str, actor: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT cpv.*, cp.trust_level, cp.status AS pack_status
                   FROM capability_pack_versions cpv
                   JOIN capability_packs cp ON cp.id=cpv.pack_id
                   WHERE cpv.id=?""",
                (pack_version_id,),
            ).fetchone()
            if not row:
                raise KeyError(pack_version_id)
            findings = self._pack_findings(row)
            validation_id = new_id("validation")
            now = iso()
            status = "passed" if not findings else "failed"
            connection.execute(
                """INSERT INTO config_validation_runs(
                   id, target_type, target_id, target_digest, status,
                   findings_json, actor_ref, created_at, finished_at
                ) VALUES (?, 'capability_pack_version', ?, ?, ?, ?, ?, ?, ?)""",
                (
                    validation_id,
                    pack_version_id,
                    row["digest"],
                    status,
                    json.dumps(findings, ensure_ascii=False),
                    actor,
                    now,
                    now,
                ),
            )
            self._audit(
                connection,
                actor,
                "capability_pack.validated",
                row["pack_id"],
                row["version"],
                row["digest"],
                status,
                {"validation_run_id": validation_id, "findings": findings},
            )
            connection.commit()
        return {
            "id": validation_id,
            "target_id": pack_version_id,
            "status": status,
            "findings": findings,
            "created_at": now,
            "finished_at": now,
        }

    def _pack_findings(self, row: sqlite3.Row) -> list[dict[str, str]]:
        findings: list[dict[str, str]] = []
        loaded = next(
            (
                item
                for item in self.packs.list()
                if item.id == row["pack_id"] and item.version == row["version"]
            ),
            None,
        )
        if loaded is None:
            return [{"code": "pack_content_not_loaded", "level": "error"}]
        manifest = _loads(row["manifest_json"], {})
        if row["pack_status"] != "installed":
            findings.append({"code": "pack_not_installed", "level": "error"})
        if row["digest"] != loaded.digest:
            findings.append({"code": "pack_content_digest_mismatch", "level": "error"})
        if row["trust_level"] != loaded.trust_level:
            findings.append({"code": "pack_trust_level_mismatch", "level": "error"})
        if manifest.get("source_revision", loaded.source_revision) != loaded.source_revision:
            findings.append({"code": "pack_source_revision_mismatch", "level": "error"})
        declared_skills = manifest.get("skills")
        if declared_skills is not None and set(declared_skills) != {skill.id for skill in loaded.skills}:
            findings.append({"code": "pack_skill_inventory_mismatch", "level": "error"})
        declared_tools = manifest.get("tools")
        if declared_tools is not None and set(declared_tools) != set(loaded.tool_names):
            findings.append({"code": "pack_tool_inventory_mismatch", "level": "error"})
        return findings

    def set_pack_status(
        self,
        pack_id: str,
        status: str,
        actor: str,
        *,
        reason: str = "",
        replacement_pack_version_id: str | None = None,
    ) -> dict[str, Any]:
        if status not in {"installed", "disabled", "retired"}:
            raise ValueError("unsupported Pack status")
        reason = reason.strip()
        if status == "retired" and (not reason or not replacement_pack_version_id):
            raise ValueError("retiring a Pack requires a reason and replacement Pack version")
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT status FROM capability_packs WHERE id=?", (pack_id,)).fetchone()
            if not row:
                raise KeyError(pack_id)
            if row["status"] == "retired" and status != "retired":
                raise ValueError("retired Pack cannot be re-enabled")
            if replacement_pack_version_id:
                replacement = connection.execute(
                    """SELECT id, pack_id FROM capability_pack_versions WHERE id=?""",
                    (replacement_pack_version_id,),
                ).fetchone()
                if not replacement:
                    raise KeyError(replacement_pack_version_id)
                if status == "retired" and replacement["pack_id"] == pack_id:
                    raise ValueError("retired Pack replacement must belong to another Pack id")
            if status != "installed":
                used = connection.execute(
                    """SELECT 1 FROM agent_version_packs avp
                       JOIN capability_pack_versions cpv ON cpv.id=avp.pack_version_id
                       JOIN agent_versions av ON av.id=avp.agent_version_id
                       JOIN agents a ON a.id=av.agent_id
                       WHERE cpv.pack_id=? AND avp.enabled=1
                         AND av.status='published' AND a.active_version_id=av.id
                       LIMIT 1""",
                    (pack_id,),
                ).fetchone()
                if used:
                    raise ValueError("Pack is referenced by an active published Agent")
            now = iso()
            connection.execute(
                """UPDATE capability_packs
                   SET status=?, retirement_reason=?, replacement_pack_version_id=?,
                       retired_at=?, updated_at=? WHERE id=?""",
                (
                    status,
                    reason if status == "retired" else None,
                    replacement_pack_version_id if status == "retired" else None,
                    now if status == "retired" else None,
                    now,
                    pack_id,
                ),
            )
            self._audit(
                connection,
                actor,
                "capability_pack.status_changed",
                pack_id,
                None,
                None,
                "succeeded",
                {
                    "before": row["status"],
                    "after": status,
                    "reason": reason if status == "retired" else None,
                    "replacement_pack_version_id": (
                        replacement_pack_version_id if status == "retired" else None
                    ),
                },
            )
            connection.commit()
        return self.get_pack(pack_id)

    def list_prompt_bundles(self) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute("SELECT * FROM prompt_bundles ORDER BY updated_at DESC, id").fetchall()
            results: list[dict[str, Any]] = []
            for row in rows:
                item = dict(row)
                versions = connection.execute(
                    """SELECT id, prompt_bundle_id, version, content_json, digest,
                              source_ref, created_by, created_at
                       FROM prompt_bundle_versions WHERE prompt_bundle_id=?
                       ORDER BY version DESC""",
                    (row["id"],),
                ).fetchall()
                item["versions"] = []
                for version in versions:
                    view = dict(version)
                    view["content"] = _loads(view.pop("content_json"), {})
                    view["agent_usage"] = [
                        dict(usage)
                        for usage in connection.execute(
                            """SELECT agent_id, id AS agent_version_id, version, status
                               FROM agent_versions WHERE prompt_bundle_version_id=?
                               ORDER BY agent_id, version""",
                            (view["id"],),
                        ).fetchall()
                    ]
                    item["versions"].append(view)
                results.append(item)
            return results

    def create_prompt_bundle(
        self,
        bundle_id: str,
        name: str,
        description: str,
        content: dict[str, Any],
        source_ref: str,
        actor: str,
    ) -> dict[str, Any]:
        bundle_id = self._stable_id(bundle_id)
        if not name.strip():
            raise ValueError("Prompt Bundle name is required")
        self._validate_prompt_content(content)
        now = iso()
        digest = _digest(content)
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                connection.execute(
                    """INSERT INTO prompt_bundles(
                       id, name, description, status, created_at, updated_at
                    ) VALUES (?, ?, ?, 'draft', ?, ?)""",
                    (bundle_id, name.strip(), description.strip(), now, now),
                )
                connection.execute(
                    """INSERT INTO prompt_bundle_versions(
                       id, prompt_bundle_id, version, content_json, digest,
                       source_ref, created_by, created_at
                    ) VALUES (?, ?, 1, ?, ?, ?, ?, ?)""",
                    (
                        new_id("promptver"),
                        bundle_id,
                        json.dumps(content, ensure_ascii=False),
                        digest,
                        source_ref.strip(),
                        actor,
                        now,
                    ),
                )
                self._audit(
                    connection,
                    actor,
                    "prompt_bundle.created",
                    bundle_id,
                    "1",
                    digest,
                    "succeeded",
                )
                connection.commit()
            except BaseException:
                connection.rollback()
                raise
        return next(item for item in self.list_prompt_bundles() if item["id"] == bundle_id)

    def create_prompt_version(
        self,
        bundle_id: str,
        content: dict[str, Any],
        source_ref: str,
        actor: str,
    ) -> dict[str, Any]:
        self._validate_prompt_content(content)
        now = iso()
        digest = _digest(content)
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            bundle = connection.execute("SELECT id FROM prompt_bundles WHERE id=?", (bundle_id,)).fetchone()
            if not bundle:
                raise KeyError(bundle_id)
            latest = connection.execute(
                "SELECT COALESCE(MAX(version), 0) FROM prompt_bundle_versions WHERE prompt_bundle_id=?",
                (bundle_id,),
            ).fetchone()[0]
            if connection.execute(
                "SELECT 1 FROM prompt_bundle_versions WHERE prompt_bundle_id=? AND digest=?",
                (bundle_id, digest),
            ).fetchone():
                raise ValueError("identical Prompt content already has a version")
            version = int(latest) + 1
            connection.execute(
                """INSERT INTO prompt_bundle_versions(
                   id, prompt_bundle_id, version, content_json, digest,
                   source_ref, created_by, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    new_id("promptver"),
                    bundle_id,
                    version,
                    json.dumps(content, ensure_ascii=False),
                    digest,
                    source_ref.strip(),
                    actor,
                    now,
                ),
            )
            connection.execute("UPDATE prompt_bundles SET updated_at=? WHERE id=?", (now, bundle_id))
            self._audit(
                connection,
                actor,
                "prompt_bundle.version_created",
                bundle_id,
                str(version),
                digest,
                "succeeded",
            )
            connection.commit()
        return next(item for item in self.list_prompt_bundles() if item["id"] == bundle_id)

    def set_prompt_status(
        self,
        bundle_id: str,
        status: str,
        actor: str,
    ) -> dict[str, Any]:
        if status not in {"active", "disabled"}:
            raise ValueError("unsupported Prompt Bundle status")
        now = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            bundle = connection.execute(
                "SELECT status FROM prompt_bundles WHERE id=?",
                (bundle_id,),
            ).fetchone()
            if not bundle:
                raise KeyError(bundle_id)
            if status == "disabled":
                used = connection.execute(
                    """SELECT 1 FROM agent_versions av
                       JOIN agents a ON a.id=av.agent_id
                       JOIN prompt_bundle_versions pbv
                         ON pbv.id=av.prompt_bundle_version_id
                       WHERE pbv.prompt_bundle_id=?
                         AND av.status='published' AND a.active_version_id=av.id
                       LIMIT 1""",
                    (bundle_id,),
                ).fetchone()
                if used:
                    raise ValueError("Prompt Bundle is referenced by an active published Agent")
            connection.execute(
                "UPDATE prompt_bundles SET status=?, updated_at=? WHERE id=?",
                (status, now, bundle_id),
            )
            self._audit(
                connection,
                actor,
                "prompt_bundle.status_changed",
                bundle_id,
                None,
                None,
                "succeeded",
                {"before": bundle["status"], "after": status},
            )
            connection.commit()
        return next(item for item in self.list_prompt_bundles() if item["id"] == bundle_id)

    @staticmethod
    def _validate_prompt_content(content: dict[str, Any]) -> None:
        if not isinstance(content, dict) or not content:
            raise ValueError("Prompt content must be a non-empty object")
        allowed = {"system_prompt", "soul", "rules", "output_rules", "source_revision"}
        if set(content) - allowed:
            raise ValueError("Prompt content contains unsupported sections")
        for key in ("system_prompt", "soul", "source_revision"):
            if key in content and not isinstance(content[key], str):
                raise ValueError(f"Prompt {key} must be text")
        for key in ("rules", "output_rules"):
            value = content.get(key, [])
            if not isinstance(value, list) or any(
                not isinstance(item, str) or not item.strip() for item in value
            ):
                raise ValueError(f"Prompt {key} must be a list of non-empty text items")
        effective = any(
            isinstance(content.get(key), str) and content[key].strip() for key in ("system_prompt", "soul")
        ) or bool(content.get("rules"))
        if not effective:
            raise ValueError("Prompt content has no effective instructions")
        encoded = json.dumps(content, ensure_ascii=False)
        if len(encoded) > 200_000:
            raise ValueError("Prompt content exceeds the configured size limit")

    @staticmethod
    def _stable_id(value: str) -> str:
        selected = value.strip()
        if not _STABLE_ID.fullmatch(selected):
            raise ValueError("id must use 2-64 lowercase letters, digits, or hyphens")
        return selected

    @staticmethod
    def _audit(
        connection: sqlite3.Connection,
        actor: str,
        action: str,
        target_id: str,
        target_version: str | None,
        after_digest: str | None,
        result: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        connection.execute(
            """INSERT INTO audit_events(
               actor_type, actor_ref, action, target_type, target_id,
               target_version, after_digest, result, metadata_json, created_at
            ) VALUES ('admin', ?, ?, 'capability', ?, ?, ?, ?, ?, ?)""",
            (
                actor,
                action,
                target_id,
                target_version,
                after_digest,
                result,
                json.dumps(metadata or {}, ensure_ascii=False),
                iso(),
            ),
        )
