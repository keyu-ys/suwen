from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

# Producer-declared answer-bearing paths are persisted inside Evidence data so
# they survive the immutable ledger without a database-schema migration.  The
# reserved key is Runtime-owned and never treated as a business answer field.
ANSWER_CONTRACT_DATA_KEY = "__suwen_answer_contract__"


class Lifecycle(StrEnum):
    OPEN = "open"
    CLOSED = "closed"


class Disposition(StrEnum):
    UNKNOWN = "unknown"
    INVESTIGATING = "investigating"
    ANSWERED = "answered"
    UNRESOLVED = "unresolved"
    ESCALATED = "escalated"
    RESOLVED = "resolved"


class EvidenceState(StrEnum):
    OBSERVED = "observed"
    ZERO_MATCHES = "zero_matches"
    QUERY_FAILED = "query_failed"
    TRUNCATED = "truncated"
    CONFLICT = "conflict"
    NOT_OBSERVABLE = "not_observable"
    INPUT_REJECTED = "input_rejected"


class ToolRisk(StrEnum):
    READ_ONLY = "read_only"
    CONTROLLED_ACTION = "controlled_action"
    EXTERNAL_WRITE = "external_write"
    UNCLASSIFIED = "unclassified"


ToolEquivalenceKey = Callable[[dict[str, Any]], Any | None]


class ReviewStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


@dataclass(frozen=True)
class InboundAttachment:
    kind: str
    external_ref: str
    media_type: str | None = None
    content: bytes | None = field(default=None, repr=False, compare=False)
    text_extraction: Mapping[str, Any] | None = field(default=None, repr=False, compare=False)


@dataclass(frozen=True)
class InboundContext:
    """One user-selected external message carried into the immutable Case input."""

    kind: str
    external_ref: str
    content: str
    state: EvidenceState = EvidenceState.OBSERVED
    limitations: tuple[str, ...] = ()
    attachments: tuple[InboundAttachment, ...] = ()


@dataclass(frozen=True)
class InboundEvent:
    event_id: str
    channel: str
    channel_instance: str
    scope_kind: str
    scope_ref: str
    actor_ref: str
    content: str
    occurred_at: str
    agent_id: str = "suwen"
    parent_event_ref: str | None = None
    reply_address: dict[str, Any] = field(default_factory=dict)
    command: str | None = None
    attachments: tuple[InboundAttachment, ...] = ()
    contexts: tuple[InboundContext, ...] = ()


@dataclass(frozen=True)
class ToolDefinition:
    name: str
    description: str
    input_schema: dict[str, Any]
    risk: ToolRisk
    timeout_seconds: float = 30.0
    result_contract: str = "model-evidence.v2"
    provider_id: str = "local"
    resource_class: str = "standard"
    run_call_limit: int | None = None
    run_call_limit_range: tuple[int, int] | None = None
    equivalence_key: ToolEquivalenceKey | None = field(default=None, repr=False, compare=False)


@dataclass(frozen=True)
class ToolRequest:
    call_id: str
    name: str
    arguments: dict[str, Any]


@dataclass(frozen=True)
class ModelTurn:
    content: str = ""
    tool_requests: tuple[ToolRequest, ...] = ()
    finish_reason: str = "stop"
    usage: dict[str, int] | None = None
    # Provider-separated reasoning is never persisted or exposed.  Only its
    # bounded size is retained so an empty visible response remains diagnosable.
    reasoning_chars: int = 0
    reasoning_control_applied: bool | None = None


@dataclass(frozen=True)
class CapabilityArtifactPayload:
    """Runtime-only text payload offered by a first-party capability.

    Capability code supplies content and descriptive metadata, while the
    Runtime owns storage, Run binding, expiry, and the model-visible handle.
    The payload itself must never be serialized as Evidence.
    """

    key: str
    content: str | bytes = field(repr=False, compare=False)
    media_type: str = "text/plain"
    suffix: str = ".txt"
    source_ref: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class EvidenceEnvelope:
    state: EvidenceState
    summary: str
    data: dict[str, Any] = field(default_factory=dict)
    coverage_state: str = "bounded"
    source_ref: str | None = None
    contract_version: str = "model-evidence.v2"
    truncation_state: str = "complete"
    source_role: str = "current_observation"
    limitations: tuple[str, ...] = ()
    safe_statements: tuple[str, ...] = ()
    continuation: dict[str, Any] | None = None
    tool_call_id: str | None = None
    observed_at: str | None = None
    # Runtime-only inputs to deterministic storage/action boundaries.
    provider_observation: dict[str, Any] | None = field(default=None, repr=False, compare=False)
    action_token: str | None = field(default=None, repr=False, compare=False)
    artifact_payloads: tuple[CapabilityArtifactPayload, ...] = field(
        default=(), repr=False, compare=False
    )


@dataclass(frozen=True)
class RunResult:
    run_id: str
    reply: str
    status: str
    stop_reason: str
    tool_calls: int
