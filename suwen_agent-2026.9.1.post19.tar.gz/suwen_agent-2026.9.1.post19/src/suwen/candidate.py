from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import shutil
import sqlite3
import time
from collections.abc import Callable
from dataclasses import replace
from pathlib import Path
from typing import Any

from .canary import (
    CANDIDATE_ALWAYS_AVAILABLE_SUPPORT_TOOLS,
    CANDIDATE_INTERNAL_SUPPORT_TOOLS,
    HUMAN_REVIEW_DIMENSIONS,
    RetentionScenario,
    candidate_manifest,
    load_retention_suite,
)
from .config import Settings
from .connectors import validate_compatible_catalog_update
from .db import KEYU_MTP_PROFILE_ID, LOCAL_PROVIDER_ID, SUWEN_AGENT_ID, Database
from .harness import DiagnosticHarness
from .model_registry import ModelRegistry, SecretResolver
from .models import ModelProvider, build_model
from .repository import Repository, iso, new_id

INFRASTRUCTURE_STOP_REASONS = frozenset(
    {"model_timeout", "model_protocol_error", "model_or_tool_failure", "run_timeout"}
)


class CandidateAlreadyAttempted(ValueError):
    pass


class CandidateModelTurnBudgetExceeded(RuntimeError):
    pass


class CandidateRegistry:
    def __init__(self, database: Database):
        self.database = database

    def list_attempts(self, status: str | None = None) -> list[dict[str, Any]]:
        query = "SELECT id FROM candidate_attempts"
        params: tuple[Any, ...] = ()
        if status:
            query += " WHERE status=?"
            params = (status,)
        query += " ORDER BY created_at DESC, id DESC"
        with self.database.connect() as connection:
            rows = connection.execute(query, params).fetchall()
        return [self.get_attempt(row["id"]) for row in rows]

    def list_attempts_page(
        self,
        status: str | None = None,
        *,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        limit = max(1, min(limit, 500))
        offset = max(0, min(offset, 1_000_000))
        where = " WHERE status=?" if status else ""
        params: list[Any] = [status] if status else []
        with self.database.connect() as connection:
            total = int(
                connection.execute(
                    f"SELECT COUNT(*) FROM candidate_attempts{where}",
                    params,
                ).fetchone()[0]
            )
            rows = connection.execute(
                f"""SELECT id FROM candidate_attempts{where}
                    ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?""",
                [*params, limit, offset],
            ).fetchall()
        items = [self.get_attempt(row["id"]) for row in rows]
        return {
            "items": items,
            "page": {
                "total": total,
                "limit": limit,
                "offset": offset,
                "has_previous": offset > 0,
                "has_next": offset + len(items) < total,
            },
        }

    def get_attempt(self, attempt_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute("SELECT * FROM candidate_attempts WHERE id=?", (attempt_id,)).fetchone()
            review = connection.execute(
                """SELECT * FROM candidate_human_reviews
                   WHERE candidate_attempt_id=?""",
                (attempt_id,),
            ).fetchone()
        if not row:
            raise KeyError(attempt_id)
        item = dict(row)
        item["pack_digests"] = json.loads(item.pop("pack_digests_json"))
        item["manifest"] = json.loads(item.pop("manifest_json"))
        item["scorecard"] = json.loads(item.pop("scorecard_json")) if item["scorecard_json"] else None
        item["scorecard_digest"] = _digest(item["scorecard"]) if item["scorecard"] else None
        item["human_review"] = None
        if review:
            item["human_review"] = dict(review)
            review_payload = json.loads(item["human_review"].pop("dimensions_json"))
            if review_payload.get("schema_version") in {
                "suwen-candidate-review.v2",
                "suwen-candidate-review.v3",
            }:
                item["human_review"].update(review_payload)
            else:
                # Read-only compatibility for an early local fixture review.  New
                # reviews are always episode-scoped and use the v2 payload.
                item["human_review"]["dimensions"] = review_payload
        return item

    def review_template(self, attempt_id: str) -> dict[str, Any]:
        attempt = self.get_attempt(attempt_id)
        if attempt["status"] not in {
            "completed_pending_human_review",
            "contract_failed",
        }:
            raise ValueError("candidate attempt is not ready for human review")
        episodes = [
            item
            for item in (attempt.get("scorecard") or {}).get("episodes", [])
            if item.get("status") == "completed"
        ]
        if not episodes:
            raise ValueError("candidate attempt has no completed episode to review")
        episode_ids = [str(item["scenario_id"]) for item in episodes]
        scorecard = attempt["scorecard"]
        return {
            "schema_version": "suwen-candidate-review-input.v3",
            "candidate_attempt_id": attempt_id,
            "scorecard_digest": _digest(scorecard),
            "review_context": {
                str(item["scenario_id"]): {
                    "category": item.get("category"),
                    "expected_skill": item.get("expected_skill"),
                    "expected_skill_delivered": bool(item.get("expected_skill_delivered")),
                    "expected_skill_read": bool(item.get("expected_skill_read")),
                    "allowed_tools": list(item.get("allowed_tools") or []),
                    "actual_tools": list(item.get("actual_tools") or []),
                    "provenance_passed": bool(item.get("provenance_passed")),
                    "run_states": list(item.get("run_states") or []),
                    "stop_reasons": list(item.get("stop_reasons") or []),
                    "answer_excerpts": list(item.get("answer_excerpts") or []),
                    "boundary_for_human_review": item.get("boundary_for_human_review"),
                }
                for item in episodes
            },
            "episode_dimensions": {
                episode_id: {dimension: None for dimension in HUMAN_REVIEW_DIMENSIONS}
                for episode_id in episode_ids
            },
            "skill_influence_observed": {episode_id: None for episode_id in episode_ids},
            "tool_influence_observed": {episode_id: None for episode_id in episode_ids},
            "influence_notes": {episode_id: "" for episode_id in episode_ids},
            "note": "",
        }

    def human_review(
        self,
        attempt_id: str,
        reviewer_ref: str,
        decision: str,
        scorecard_digest: str,
        episode_dimensions: dict[str, dict[str, str]],
        skill_influence_observed: dict[str, bool],
        tool_influence_observed: dict[str, bool | None],
        influence_notes: dict[str, str],
        note: str = "",
    ) -> dict[str, Any]:
        if decision not in {"approved", "rejected"}:
            raise ValueError("decision must be approved or rejected")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            attempt = connection.execute(
                "SELECT status, scorecard_json FROM candidate_attempts WHERE id=?",
                (attempt_id,),
            ).fetchone()
            if not attempt:
                raise KeyError(attempt_id)
            if attempt["status"] not in {
                "completed_pending_human_review",
                "contract_failed",
            }:
                raise ValueError("candidate attempt is not ready for human review")
            if connection.execute(
                "SELECT 1 FROM candidate_human_reviews WHERE candidate_attempt_id=?",
                (attempt_id,),
            ).fetchone():
                raise ValueError("candidate attempt already has a human review")
            scorecard = json.loads(attempt["scorecard_json"] or "{}")
            if scorecard_digest != _digest(scorecard):
                raise ValueError("candidate review does not match the current scorecard")
            if decision == "approved" and not scorecard.get("deterministic_contract_passed"):
                raise ValueError("deterministic contract failure cannot be overridden")
            if decision == "approved" and not scorecard.get("claims", {}).get("candidate_loaded"):
                raise ValueError("fixture or unloaded candidate cannot be approved")
            episode_ids = {
                item["scenario_id"]
                for item in scorecard.get("episodes", [])
                if item.get("status") == "completed"
            }
            if not episode_ids or set(episode_dimensions) != episode_ids:
                raise ValueError("every completed candidate episode requires a six-dimension review")
            if set(skill_influence_observed) != episode_ids:
                raise ValueError("every completed candidate episode requires a Skill influence observation")
            if set(tool_influence_observed) != episode_ids:
                raise ValueError("every completed candidate episode requires a Tool influence observation")
            if set(influence_notes) != episode_ids:
                raise ValueError("every completed candidate episode requires an influence evidence note")
            for dimensions in episode_dimensions.values():
                if set(dimensions) != set(HUMAN_REVIEW_DIMENSIONS):
                    raise ValueError("all six dimensions are required for every candidate episode")
                if any(value not in {"passed", "failed"} for value in dimensions.values()):
                    raise ValueError("candidate review dimensions must be passed or failed")
            if any(type(value) is not bool for value in skill_influence_observed.values()):
                raise ValueError("candidate Skill influence observations must be boolean")
            if any(
                not isinstance(value, str) or not value.strip() or len(value) > 1000
                for value in influence_notes.values()
            ):
                raise ValueError(
                    "candidate influence evidence notes must be non-empty and at most 1000 characters"
                )
            actual_tools_by_episode = {
                str(item["scenario_id"]): list(item.get("actual_tools") or [])
                for item in scorecard.get("episodes", [])
                if item.get("status") == "completed"
            }
            called_episode_ids = {
                episode_id for episode_id, actual_tools in actual_tools_by_episode.items() if actual_tools
            }
            for episode_id, observed in tool_influence_observed.items():
                if episode_id in called_episode_ids and type(observed) is not bool:
                    raise ValueError("candidate Tool influence must be observed when a Tool was called")
                if episode_id not in called_episode_ids and observed is not None:
                    raise ValueError("candidate Tool influence must be null when no Tool was called")
            all_dimensions_passed = all(
                value == "passed"
                for dimensions in episode_dimensions.values()
                for value in dimensions.values()
            )
            all_skill_influence_observed = all(skill_influence_observed.values())
            any_tool_influence_observed = bool(called_episode_ids)
            all_called_tool_influence_observed = bool(
                called_episode_ids
                and all(tool_influence_observed[episode_id] for episode_id in called_episode_ids)
            )
            all_influence_observed = bool(all_skill_influence_observed and all_called_tool_influence_observed)
            if decision == "approved" and not all_dimensions_passed:
                raise ValueError("approved candidate requires every episode dimension to pass")
            if decision == "approved" and not all_skill_influence_observed:
                raise ValueError("approved candidate requires observable Skill influence in every episode")
            if decision == "approved" and not all_called_tool_influence_observed:
                raise ValueError(
                    "approved candidate requires at least one actual Tool call and observable influence"
                )
            dimension_summary = {
                dimension: (
                    "passed"
                    if all(values[dimension] == "passed" for values in episode_dimensions.values())
                    else "failed"
                )
                for dimension in HUMAN_REVIEW_DIMENSIONS
            }
            review_payload = {
                "schema_version": "suwen-candidate-review.v3",
                "reviewed_scorecard_digest": scorecard_digest,
                "episode_dimensions": episode_dimensions,
                "skill_influence_observed": skill_influence_observed,
                "tool_influence_observed": tool_influence_observed,
                "influence_notes": {
                    episode_id: _safe_excerpt(value.strip(), 1000)
                    for episode_id, value in influence_notes.items()
                },
                "dimension_summary": dimension_summary,
                "reviewed_episode_count": len(episode_ids),
                "tool_called_episode_count": len(called_episode_ids),
            }
            review_id = new_id("candidate_review")
            connection.execute(
                """INSERT INTO candidate_human_reviews(
                   id, candidate_attempt_id, reviewer_ref, dimensions_json,
                   decision, note, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    review_id,
                    attempt_id,
                    reviewer_ref,
                    json.dumps(review_payload, sort_keys=True),
                    decision,
                    _safe_excerpt(note, 1000),
                    at,
                ),
            )
            scorecard["human_review_status"] = decision
            scorecard["reviewed_episode_count"] = len(episode_ids)
            scorecard.setdefault("claims", {})["skill_influence_observed"] = all_skill_influence_observed
            scorecard["claims"]["tool_influence_observed"] = all_called_tool_influence_observed
            scorecard["claims"]["influence_observed"] = all_influence_observed
            scorecard["claims"]["outcome_reviewed"] = True
            connection.execute(
                "UPDATE candidate_attempts SET status=?, scorecard_json=? WHERE id=?",
                (
                    "outcome_reviewed" if decision == "approved" else "review_rejected",
                    json.dumps(scorecard, ensure_ascii=False, sort_keys=True),
                    attempt_id,
                ),
            )
            self._audit(
                connection,
                reviewer_ref,
                "candidate.human_reviewed",
                attempt_id,
                decision,
                {
                    "reviewed_episode_count": len(episode_ids),
                    "reviewed_scorecard_digest": scorecard_digest,
                    "dimension_summary": dimension_summary,
                    "all_skill_influence_observed": all_skill_influence_observed,
                    "any_tool_influence_observed": any_tool_influence_observed,
                    "all_called_tool_influence_observed": (all_called_tool_influence_observed),
                    "tool_called_episode_count": len(called_episode_ids),
                    "automatic_rerun": False,
                },
            )
            connection.commit()
        return self.get_attempt(attempt_id)

    @staticmethod
    def _audit(
        connection: sqlite3.Connection,
        actor: str,
        action: str,
        target_id: str,
        result: str,
        metadata: dict[str, Any],
    ) -> None:
        connection.execute(
            """INSERT INTO audit_events(
               actor_type, actor_ref, action, target_type, target_id,
               result, metadata_json, created_at
            ) VALUES ('reviewer', ?, ?, 'candidate_attempt', ?, ?, ?, ?)""",
            (
                actor,
                action,
                target_id,
                result,
                json.dumps(metadata, sort_keys=True),
                iso(),
            ),
        )


class _CountingModel(ModelProvider):
    def __init__(self, delegate: ModelProvider, max_turns: int):
        self.delegate = delegate
        self.max_turns = max_turns
        self.calls = 0
        self.exhausted = False

    async def complete(self, messages, tools):
        if self.calls >= self.max_turns:
            self.exhausted = True
            raise CandidateModelTurnBudgetExceeded("frozen candidate model-turn budget exhausted")
        self.calls += 1
        return await self.delegate.complete(messages, tools)

    async def close(self) -> None:
        close = getattr(self.delegate, "close", None)
        if close:
            await close()


class CandidateRunner:
    """One-shot local model candidate runner with an isolated data directory."""

    def __init__(
        self,
        settings: Settings,
        *,
        model_factory: Callable[[Any], ModelProvider] | None = None,
        allow_fixture_model: bool = False,
        database: Database | None = None,
        initialize_database: bool = True,
    ) -> None:
        if model_factory is not None and not allow_fixture_model:
            raise ValueError("injected candidate models are fixture-only and cannot claim a loaded candidate")
        self.settings = settings
        self.injected_model_factory = model_factory is not None
        self.execution_environment = "fixture_runner" if allow_fixture_model else "local_candidate"
        self.database = database or Database(
            settings.database_path,
            enable_test_fixture_agent=settings.enable_test_fixture_agent,
        )
        if initialize_database:
            self.database.initialize()
        elif not self.database.check()["ready"]:
            raise RuntimeError("candidate runner requires an initialized current database")
        self.models = ModelRegistry(self.database)
        self.registry = CandidateRegistry(self.database)
        self.model_factory = model_factory or build_model
        self.allow_fixture_model = allow_fixture_model

    def preflight(self, agent_id: str = SUWEN_AGENT_ID) -> dict[str, Any]:
        """Inspect candidate readiness without reserving or consuming an attempt."""

        snapshot = self._target_snapshot(agent_id)
        _, configuration = self._configuration_fingerprint(snapshot)
        findings = self._preflight_findings(snapshot)
        return {
            "status": "ready" if not findings else "blocked",
            "consumes_candidate_attempt": False,
            "model_calls": 0,
            "source_calls": 0,
            "external_writes": 0,
            "target": {
                "agent_id": snapshot["agent_id"],
                "agent_status": snapshot["agent_status"],
                "agent_version_id": snapshot["agent_version_id"],
                "model_profile_version_id": snapshot["model_profile_version_id"],
                "provider_version_id": snapshot["provider_version_id"],
                "prompt_bundle_digest": snapshot["prompt_bundle_digest"],
                "pack_digests": snapshot["pack_digests"],
                "tool_schema_digest": snapshot["tool_schema_digest"],
            },
            "configuration": configuration,
            "findings": findings,
        }

    async def run(
        self,
        *,
        agent_id: str = SUWEN_AGENT_ID,
        actor: str = "cli:candidate-runner",
    ) -> dict[str, Any]:
        suite = load_retention_suite()
        snapshot = self._target_snapshot(agent_id)
        live_probe: dict[str, Any] | None = None
        cached_findings = self._preflight_findings(snapshot)
        probe_only_codes = {
            "model_probe_not_passed",
            "model_probe_stale",
            "model_tool_calling_not_observed",
        }
        non_probe_findings = [item for item in cached_findings if item["code"] not in probe_only_codes]
        if not self.allow_fixture_model and not non_probe_findings:
            live_probe = await self.models.probe(
                snapshot["model_profile_version_id"],
                f"{actor}:candidate-live-preflight",
            )
            if live_probe["status"] != "passed":
                return {
                    "schema_version": "suwen-candidate-live-preflight.v1",
                    "status": "live_preflight_blocked",
                    "consumes_candidate_attempt": False,
                    "candidate_attempt_id": None,
                    "candidate_model_calls": 0,
                    "source_calls": 0,
                    "external_writes": 0,
                    "target": {
                        "agent_id": snapshot["agent_id"],
                        "agent_version_id": snapshot["agent_version_id"],
                        "model_profile_version_id": snapshot["model_profile_version_id"],
                    },
                    "probe": live_probe,
                    "findings": [
                        {
                            "code": "candidate_live_model_probe_failed",
                            "level": "error",
                            "next_action": "restore_model_endpoint_then_start_new_candidate",
                        }
                    ],
                }
            # Refresh the snapshot after the probe updated readiness evidence.
            snapshot = self._target_snapshot(agent_id)
        code_revision = _repository_revision()
        configuration_fingerprint, configuration_metadata = self._configuration_fingerprint(snapshot)
        key_payload = {
            "suite_digest": suite.digest,
            "agent_version_id": snapshot["agent_version_id"],
            "agent_version_digest": snapshot["agent_version_digest"],
            "model_profile_version_id": snapshot["model_profile_version_id"],
            "model_profile_digest": snapshot["model_profile_digest"],
            "provider_version_id": snapshot["provider_version_id"],
            "provider_version_digest": snapshot["provider_version_digest"],
            "prompt_bundle_digest": snapshot["prompt_bundle_digest"],
            "pack_digests": snapshot["pack_digests"],
            "capability_digests": snapshot["capability_digests"],
            "agent_profile": {
                key: value
                for key, value in snapshot["agent_config"].items()
                if key.startswith("agent_profile_")
            },
            "persona": snapshot["persona"],
            "tool_schema_digest": snapshot["tool_schema_digest"],
            "connector_catalogs": snapshot["connector_catalogs"],
            "code_revision": code_revision,
            "configuration_fingerprint": configuration_fingerprint,
            "execution_environment": self.execution_environment,
        }
        candidate_key = _digest(key_payload)
        attempt_id = f"candidate_{candidate_key[:24]}"
        workspace = (self.settings.data_dir / "candidates" / attempt_id).resolve()
        manifest = {
            **candidate_manifest(
                max_model_turns=self.settings.candidate.max_model_turns,
                max_elapsed_seconds=self.settings.candidate.max_elapsed_seconds,
            ),
            "status": "attempt_frozen",
            "candidate_key": candidate_key,
            "attempt_id": attempt_id,
            "target": key_payload,
            "configuration": configuration_metadata,
            "execution_environment": self.execution_environment,
            "model_execution_attestation": {
                "configured_provider_path": not self.injected_model_factory,
                "injected_fixture": self.injected_model_factory,
                "promotion_eligible": (not self.injected_model_factory and not self.allow_fixture_model),
            },
            "live_model_preflight": (
                {
                    "validation_id": live_probe["id"],
                    "status": live_probe["status"],
                    "finished_at": live_probe["finished_at"],
                }
                if live_probe
                else {"status": "not_required_for_fixture"}
            ),
            "workspace_policy": {
                "isolated_database": True,
                "copies_case_or_message_data": False,
                "secret_values_in_scorecard": False,
            },
            "review_dimensions": list(HUMAN_REVIEW_DIMENSIONS),
            "stop_conditions": [
                "preflight_invalid",
                "unauthorized_source_observed",
                "external_write_observed",
                "model_turn_budget_exhausted",
                "elapsed_time_budget_exhausted",
                "infrastructure_failure",
                "deterministic_contract_failure",
            ],
            "budgets": {
                "max_elapsed_seconds": self.settings.candidate.max_elapsed_seconds,
                "max_model_turns": self.settings.candidate.max_model_turns,
                "source_calls": 0,
                "external_writes": 0,
            },
        }
        self._reserve_attempt(
            attempt_id,
            candidate_key,
            snapshot,
            code_revision,
            configuration_fingerprint,
            workspace,
            manifest,
            actor,
        )
        try:
            workspace.mkdir(mode=0o700, parents=True, exist_ok=False)
            _write_json_exclusive(workspace / "manifest.json", manifest)
            findings = self._preflight_findings(snapshot)
            if findings:
                scorecard = self._blocked_scorecard(attempt_id, manifest, findings)
                _write_json_exclusive(workspace / "scorecard.json", scorecard)
                self._finish_attempt(
                    attempt_id,
                    "preflight_blocked",
                    scorecard,
                    failure_class="configuration",
                )
                return self.registry.get_attempt(attempt_id)

            candidate_settings = self._clone_candidate_configuration(workspace, snapshot)
            self._mark_started(attempt_id)
            scorecard = await self._execute_suite(
                attempt_id,
                manifest,
                candidate_settings,
                snapshot,
                suite.scenarios,
            )
            _write_json_exclusive(workspace / "scorecard.json", scorecard)
            status = scorecard["status"]
            self._finish_attempt(
                attempt_id,
                status,
                scorecard,
                model_calls=scorecard["totals"]["model_turns"],
                source_calls=scorecard["totals"]["source_calls"],
                external_writes=scorecard["totals"]["external_writes"],
                failure_class=("contract" if status == "contract_failed" else None),
            )
            return self.registry.get_attempt(attempt_id)
        except BaseException as exc:
            self._finish_attempt(
                attempt_id,
                "interrupted",
                {
                    "schema_version": "suwen-scorecard.v1",
                    "attempt_id": attempt_id,
                    "status": "interrupted",
                    "failure_class": _failure_class(exc),
                    "automatic_rerun": False,
                },
                failure_class=_failure_class(exc),
            )
            raise

    def _target_snapshot(self, agent_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT a.id AS agent_id, a.status AS agent_status,
                          a.active_version_id, av.id AS agent_version_id,
                          av.version AS agent_version,
                          av.digest AS agent_version_digest,
                          av.runtime_policy_json,
                          binding.revision AS model_binding_revision,
                          persona.persona_id,
                          persona.revision AS persona_binding_revision,
                          mpv.id AS model_profile_version_id,
                          av.prompt_bundle_version_id, av.tool_schema_digest, av.config_json,
                          mpv.model_profile_id, mpv.model_id,
                          mpv.digest AS model_profile_digest,
                          mpv.provider_version_id, mpv.max_input_length,
                          pv.provider_id, pv.digest AS provider_version_digest,
                          pv.endpoint_ref, pv.secret_ref_id,
                          p.protocol, mp.status AS model_profile_status,
                          p.status AS provider_status,
                          pbv.digest AS prompt_bundle_digest
                   FROM agents a
                   LEFT JOIN agent_versions av ON av.id=COALESCE(
                       a.active_version_id,
                       (SELECT av2.id FROM agent_versions av2
                        WHERE av2.agent_id=a.id ORDER BY av2.version DESC LIMIT 1)
                   )
                   LEFT JOIN agent_model_bindings binding ON binding.agent_id=a.id
                   LEFT JOIN agent_persona_bindings persona ON persona.agent_id=a.id
                   LEFT JOIN model_profile_versions mpv
                     ON mpv.id=(
                          SELECT current_model.id
                            FROM model_profile_versions current_model
                           WHERE current_model.model_profile_id=binding.model_profile_id
                           ORDER BY current_model.version DESC LIMIT 1
                        )
                   LEFT JOIN model_profiles mp ON mp.id=mpv.model_profile_id
                   LEFT JOIN model_provider_versions pv
                     ON pv.id=mpv.provider_version_id
                   LEFT JOIN model_providers p ON p.id=pv.provider_id
                   LEFT JOIN prompt_bundle_versions pbv
                     ON pbv.id=av.prompt_bundle_version_id
                   WHERE a.id=?""",
                (agent_id,),
            ).fetchone()
            if not row:
                raise KeyError(agent_id)
            snapshot = dict(row)
            packs = connection.execute(
                """SELECT avp.pack_version_id, cpv.pack_id, cpv.version,
                          cpv.digest, cpv.manifest_json
                   FROM agent_version_packs avp
                   JOIN capability_pack_versions cpv ON cpv.id=avp.pack_version_id
                   WHERE avp.agent_version_id=? AND avp.enabled=1
                   ORDER BY avp.position, cpv.id""",
                (snapshot["agent_version_id"],),
            ).fetchall()
            capabilities = connection.execute(
                """SELECT avc.*, cp.id AS capability_id, cp.kind, cp.status,
                          cpv.version, cpv.content_digest, cpv.lifecycle_state,
                          cpv.workspace_path
                   FROM agent_version_capabilities avc
                   JOIN capability_package_versions cpv ON cpv.id=avc.capability_version_id
                   JOIN capability_packages cp ON cp.id=cpv.capability_id
                   WHERE avc.agent_version_id=? AND avc.enabled=1
                   ORDER BY avc.position, avc.capability_version_id""",
                (snapshot["agent_version_id"],),
            ).fetchall()
            agent_config = json.loads(snapshot.get("config_json") or "{}")
            connectors: list[dict[str, Any]] = []
            for binding in agent_config.get("connector_bindings", []):
                if not isinstance(binding, dict) or not isinstance(binding.get("provider_id"), str):
                    continue
                provider = connection.execute(
                    """SELECT id, provider_type, status, binding_generation,
                              runtime_metadata_json
                       FROM tool_providers WHERE id=? AND archived_at IS NULL""",
                    (binding["provider_id"],),
                ).fetchone()
                schema = connection.execute(
                    """SELECT id, digest, observed_at, schema_json FROM tool_schema_versions
                       WHERE id=? AND tool_provider_id=?""",
                    (binding.get("schema_version_id"), binding["provider_id"]),
                ).fetchone()
                current_schema = connection.execute(
                    """SELECT id, digest, observed_at, schema_json
                       FROM tool_schema_versions WHERE tool_provider_id=?
                       ORDER BY version DESC LIMIT 1""",
                    (binding["provider_id"],),
                ).fetchone()
                baseline_matches_binding = bool(
                    schema and schema["digest"] == binding.get("schema_digest")
                )
                catalog_matches = bool(
                    baseline_matches_binding
                    and schema
                    and current_schema
                    and schema["id"] == current_schema["id"]
                    and schema["digest"] == current_schema["digest"]
                )
                catalog_compatible = catalog_matches
                compatibility_error: str | None = None
                if baseline_matches_binding and schema and current_schema and not catalog_matches:
                    try:
                        baseline_catalog = json.loads(schema["schema_json"])
                        latest_catalog = json.loads(current_schema["schema_json"])
                        if not isinstance(baseline_catalog, list) or not isinstance(
                            latest_catalog,
                            list,
                        ):
                            raise ValueError("Connector catalog is invalid")
                        validate_compatible_catalog_update(
                            str(binding["provider_id"]),
                            baseline_catalog,
                            latest_catalog,
                        )
                    except (TypeError, ValueError, json.JSONDecodeError) as exc:
                        compatibility_error = str(exc)
                    else:
                        catalog_compatible = True
                elif not baseline_matches_binding:
                    compatibility_error = "Connector catalog baseline does not match Agent binding"
                connectors.append(
                    {
                        **binding,
                        "provider_type": str(provider["provider_type"]) if provider else None,
                        "status": str(provider["status"]) if provider else "missing",
                        "binding_generation": int(provider["binding_generation"]) if provider else None,
                        "catalog_observed": bool(
                            current_schema and current_schema["observed_at"]
                        ),
                        "catalog_matches": catalog_matches,
                        "catalog_compatible": catalog_compatible,
                        "catalog_state": (
                            "exact"
                            if catalog_matches
                            else "compatible_update"
                            if catalog_compatible
                            else "breaking_or_unavailable"
                        ),
                        "catalog_compatibility_error": compatibility_error,
                        "current_schema_version_id": (
                            str(current_schema["id"]) if current_schema else None
                        ),
                        "current_schema_digest": (
                            str(current_schema["digest"]) if current_schema else None
                        ),
                        "runtime_metadata": (
                            json.loads(provider["runtime_metadata_json"] or "{}") if provider else {}
                        ),
                    }
                )
        snapshot["packs"] = [dict(pack) for pack in packs]
        snapshot["pack_digests"] = [pack["digest"] for pack in packs]
        snapshot["capabilities"] = [dict(item) for item in capabilities]
        snapshot["capability_digests"] = [item["content_digest"] for item in capabilities]
        snapshot["agent_config"] = agent_config
        snapshot["persona"] = {
            "id": snapshot["persona_id"],
            "binding_revision": snapshot["persona_binding_revision"],
        }
        snapshot["connectors"] = connectors
        snapshot["connector_catalogs"] = [
            {
                "provider_id": item["provider_id"],
                "schema_version_id": item.get("current_schema_version_id"),
                "schema_digest": item.get("current_schema_digest"),
            }
            for item in connectors
        ]
        return snapshot

    def _configuration_fingerprint(self, snapshot: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        secret_metadata = []
        for purpose, ref_id in (
            ("endpoint", snapshot.get("endpoint_ref")),
            ("api_key", snapshot.get("secret_ref_id")),
        ):
            if not ref_id:
                continue
            try:
                metadata = self.models.secrets.metadata(ref_id)
                secret_metadata.append(
                    {
                        "purpose": purpose,
                        "ref_id": ref_id,
                        "resolver": metadata["resolver"],
                        "version": metadata["version"],
                        "status": metadata["status"],
                        "configured": metadata["configured"],
                    }
                )
            except KeyError:
                secret_metadata.append({"purpose": purpose, "ref_id": ref_id, "configured": False})
        metadata = {
            "candidate_budget": {
                "max_elapsed_seconds": self.settings.candidate.max_elapsed_seconds,
                "max_model_turns": self.settings.candidate.max_model_turns,
            },
            "secret_refs": secret_metadata,
            "model_profile_status": snapshot.get("model_profile_status"),
            "provider_status": snapshot.get("provider_status"),
            "persona": snapshot["persona"],
            "agent_profile": {
                key: value
                for key, value in snapshot["agent_config"].items()
                if key.startswith("agent_profile_")
            },
            "capabilities": [
                {
                    "id": item["capability_id"],
                    "version": item["version"],
                    "role": item["role"],
                    "content_digest": item["content_digest"],
                    "artifact_digest": item["artifact_digest"],
                    "installation_id": item["installation_id"],
                }
                for item in snapshot["capabilities"]
            ],
            "connectors": [
                {
                    "provider_id": item["provider_id"],
                    "schema_version_id": item.get("schema_version_id"),
                    "schema_digest": item.get("schema_digest"),
                    "selection": item.get("selection"),
                    "provider_type": item.get("provider_type"),
                    "status": item.get("status"),
                    "binding_generation": item.get("binding_generation"),
                    "catalog_observed": item.get("catalog_observed"),
                    "catalog_matches": item.get("catalog_matches"),
                    "catalog_compatible": item.get("catalog_compatible"),
                    "catalog_state": item.get("catalog_state"),
                    "current_schema_version_id": item.get("current_schema_version_id"),
                    "current_schema_digest": item.get("current_schema_digest"),
                    "runtime_metadata": item.get("runtime_metadata", {}),
                }
                for item in snapshot["connectors"]
            ],
        }
        if snapshot.get("model_profile_version_id"):
            readiness = self.models.probe_readiness(snapshot["model_profile_version_id"])
            probe = readiness.get("probe") or {}
            observed = next(
                (
                    item.get("observed", {})
                    for item in probe.get("findings", [])
                    if item.get("code") == "probe_observed"
                ),
                {},
            )
            metadata["model_probe"] = {
                "readiness": readiness["status"],
                "status": probe.get("status", "not_run"),
                "stale": probe.get("stale", False),
                "tool_calling_observed": bool(observed.get("tool_calling_observed")),
            }
        return _digest(metadata), metadata

    def _preflight_findings(self, snapshot: dict[str, Any]) -> list[dict[str, str]]:
        findings: list[dict[str, str]] = []
        agent_published = snapshot.get("agent_status") == "published"
        checks = (
            (agent_published, "agent_not_published", "validate_and_publish_agent"),
            (
                bool(snapshot.get("agent_version_id")),
                "agent_active_version_missing",
                "restore_active_agent_version",
            ),
            (
                snapshot.get("model_profile_status") == "active",
                "model_profile_not_active",
                "enable_model_profile",
            ),
            (
                snapshot.get("provider_status") == "active",
                "provider_not_active",
                "enable_model_provider",
            ),
            (
                not agent_published or bool(snapshot.get("tool_schema_digest")),
                "tool_schema_digest_missing",
                "republish_agent_version",
            ),
            (
                bool(snapshot["agent_config"].get("agent_profile_id")),
                "native_agent_profile_missing",
                "apply_native_agent_profile",
            ),
            (
                bool(snapshot["capabilities"])
                and all(
                    item["status"] == "available"
                    and item["lifecycle_state"] == "workspace-installed"
                    and item["installation_id"]
                    and item["artifact_digest"]
                    for item in snapshot["capabilities"]
                ),
                "native_capability_composition_unavailable",
                "install_and_apply_native_agent_profile",
            ),
            (
                bool(snapshot["connectors"])
                and all(
                    item["provider_type"] in {"mcp_http", "mcp_stdio"}
                    and item["status"] == "connected"
                    and item["catalog_observed"]
                    and item["catalog_compatible"]
                    for item in snapshot["connectors"]
                ),
                "mcp_connector_composition_unavailable",
                "connect_and_reapply_native_agent_profile",
            ),
            (
                bool(snapshot["agent_config"].get("agent_profile_composition_lock_digest")),
                "native_profile_composition_lock_missing",
                "reinstall_and_apply_native_agent_profile",
            ),
        )
        for passed, code, next_action in checks:
            if not passed:
                findings.append({"code": code, "level": "error", "next_action": next_action})
        runtime = json.loads(snapshot.get("runtime_policy_json") or "{}")
        if (
            runtime.get("max_tool_calls"),
            runtime.get("max_tool_waves"),
            runtime.get("max_concurrency"),
        ) != (60, 30, 6):
            findings.append(
                {
                    "code": "candidate_runtime_budget_mismatch",
                    "level": "error",
                    "next_action": "restore_candidate_runtime_budget",
                }
            )
        if not self.allow_fixture_model and (
            snapshot.get("provider_id") != LOCAL_PROVIDER_ID
            or snapshot.get("model_profile_id") != KEYU_MTP_PROFILE_ID
            or snapshot.get("model_id") != "keyu-mtp"
            or snapshot.get("max_input_length") != 130000
            or snapshot.get("protocol") != "openai-compatible"
        ):
            findings.append(
                {
                    "code": "target_model_is_not_local_keyu_mtp",
                    "level": "error",
                    "next_action": "bind_local_keyu_mtp",
                }
            )
        if snapshot.get("model_profile_version_id"):
            status = self.models.configuration_status(snapshot["model_profile_version_id"])
            normalized = {
                "endpoint_ref_unresolved": (
                    "model_endpoint_unresolved",
                    "configure_model_endpoint",
                ),
                "api_key_ref_unresolved": (
                    "model_api_key_unresolved",
                    "configure_model_api_key",
                ),
                "profile_not_active": ("model_profile_not_active", "enable_model_profile"),
                "provider_not_active": ("provider_not_active", "enable_model_provider"),
                "tool_calling_not_declared": (
                    "tool_calling_not_declared",
                    "select_tool_capable_model",
                ),
            }
            for finding in status["findings"]:
                code, next_action = normalized.get(
                    finding["code"],
                    (finding["code"], "inspect_model_configuration"),
                )
                findings.append({"code": code, "level": finding["level"], "next_action": next_action})
            if status["status"] == "valid":
                readiness = self.models.probe_readiness(snapshot["model_profile_version_id"])
                if readiness["finding"]:
                    probe_actions = {
                        "model_probe_not_passed": "run_model_probe",
                        "model_probe_stale": "rerun_model_probe",
                        "model_tool_calling_not_observed": ("rerun_model_tool_calling_probe"),
                    }
                    code = readiness["finding"]["code"]
                    findings.append(
                        {
                            "code": code,
                            "level": "error",
                            "next_action": probe_actions[code],
                        }
                    )
        return _dedupe_findings(findings)

    def _reserve_attempt(
        self,
        attempt_id: str,
        candidate_key: str,
        snapshot: dict[str, Any],
        code_revision: str,
        configuration_fingerprint: str,
        workspace: Path,
        manifest: dict[str, Any],
        actor: str,
    ) -> None:
        try:
            workspace_ref = workspace.relative_to(self.settings.data_dir.resolve()).as_posix()
        except ValueError as exc:
            raise ValueError("candidate workspace must stay inside data_dir") from exc
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT id, status FROM candidate_attempts WHERE candidate_key=?",
                (candidate_key,),
            ).fetchone()
            if existing:
                connection.rollback()
                raise CandidateAlreadyAttempted(
                    f"candidate revision already attempted as {existing['id']} ({existing['status']})"
                )
            connection.execute(
                """INSERT INTO candidate_attempts(
                   id, candidate_key, suite_digest, agent_id, agent_version_id,
                   model_profile_version_id, provider_version_id,
                   prompt_bundle_digest, pack_digests_json, tool_schema_digest,
                   code_revision, configuration_fingerprint, workspace_ref,
                   status, manifest_json, created_by, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                          'reserved', ?, ?, ?)""",
                (
                    attempt_id,
                    candidate_key,
                    manifest["suite_digest"],
                    snapshot["agent_id"],
                    snapshot["agent_version_id"],
                    snapshot["model_profile_version_id"],
                    snapshot["provider_version_id"],
                    snapshot["prompt_bundle_digest"],
                    json.dumps(snapshot["pack_digests"], sort_keys=True),
                    snapshot["tool_schema_digest"] or "not-frozen",
                    code_revision,
                    configuration_fingerprint,
                    workspace_ref,
                    json.dumps(manifest, ensure_ascii=False, sort_keys=True),
                    actor,
                    iso(),
                ),
            )
            connection.execute(
                """INSERT INTO audit_events(
                   actor_type, actor_ref, action, target_type, target_id,
                   target_version, result, metadata_json, created_at
                ) VALUES ('admin', ?, 'candidate.reserved', 'candidate_attempt',
                          ?, ?, 'succeeded', ?, ?)""",
                (
                    actor,
                    attempt_id,
                    candidate_key[:16],
                    json.dumps(
                        {
                            "suite_digest": manifest["suite_digest"],
                            "external_writes": 0,
                            "automatic_reruns": 0,
                        },
                        sort_keys=True,
                    ),
                    iso(),
                ),
            )
            connection.commit()

    def _clone_candidate_configuration(
        self,
        workspace: Path,
        snapshot: dict[str, Any],
    ) -> Settings:
        data_dir = workspace / "data"
        database_path = data_dir / "candidate.db"
        candidate_database = Database(database_path)
        candidate_database.initialize()
        self._copy_configuration_rows(candidate_database, snapshot)
        candidate_secrets = SecretResolver(candidate_database)
        values: dict[str, str] = {}
        for ref_id, required in (
            (snapshot.get("endpoint_ref"), True),
            (snapshot.get("secret_ref_id"), False),
        ):
            if not ref_id:
                continue
            value = self.models.secrets.resolve(ref_id, required=required)
            if value:
                values[ref_id] = value
        if values:
            candidate_secrets.store_private_values(values, "system:candidate-clone")
        return replace(
            self.settings,
            data_dir=data_dir,
            database_path=database_path,
            feishu=replace(self.settings.feishu, enabled=False, sender="capture"),
        )

    def _copy_configuration_rows(
        self,
        candidate_database: Database,
        snapshot: dict[str, Any],
    ) -> None:
        with self.database.connect() as source, candidate_database.connect() as target:
            target.execute("BEGIN IMMEDIATE")
            for ref_id in (snapshot.get("endpoint_ref"), snapshot.get("secret_ref_id")):
                if not ref_id:
                    continue
                source_row = source.execute("SELECT * FROM secret_refs WHERE id=?", (ref_id,)).fetchone()
                if not source_row:
                    raise RuntimeError("candidate Secret Ref metadata is missing")
                safe_row = dict(source_row)
                safe_row.update(
                    {
                        "resolver": "env",
                        "locator": f"DIAGNOSTIC_CANDIDATE_UNUSED_{ref_id.upper().replace('-', '_')}",
                        "status": "unverified",
                        "version": 1,
                        "last_verified_at": None,
                    }
                )
                _upsert(target, "secret_refs", safe_row)

            dependencies = (
                ("model_providers", "id", snapshot["provider_id"]),
                ("model_provider_versions", "id", snapshot["provider_version_id"]),
                ("model_profiles", "id", snapshot["model_profile_id"]),
                ("model_profile_versions", "id", snapshot["model_profile_version_id"]),
                (
                    "prompt_bundles",
                    "id",
                    source.execute(
                        "SELECT prompt_bundle_id FROM prompt_bundle_versions WHERE id=?",
                        (snapshot["prompt_bundle_version_id"],),
                    ).fetchone()["prompt_bundle_id"],
                ),
                ("prompt_bundle_versions", "id", snapshot["prompt_bundle_version_id"]),
            )
            for table, key, value in dependencies:
                row = source.execute(f"SELECT * FROM {table} WHERE {key}=?", (value,)).fetchone()
                if not row:
                    raise RuntimeError(f"candidate dependency missing: {table}")
                _upsert(target, table, dict(row))

            for pack in snapshot["packs"]:
                candidate_pack = target.execute(
                    """SELECT digest FROM capability_pack_versions WHERE id=?""",
                    (pack["pack_version_id"],),
                ).fetchone()
                if not candidate_pack or candidate_pack["digest"] != pack["digest"]:
                    raise RuntimeError("candidate Pack revision is not present in bundled code")

            for capability in snapshot["capabilities"]:
                package_row = source.execute(
                    "SELECT * FROM capability_packages WHERE id=?",
                    (capability["capability_id"],),
                ).fetchone()
                version_row = source.execute(
                    "SELECT * FROM capability_package_versions WHERE id=?",
                    (capability["capability_version_id"],),
                ).fetchone()
                installation_row = source.execute(
                    "SELECT * FROM native_workspace_installations WHERE id=?",
                    (capability["installation_id"],),
                ).fetchone()
                if not package_row or not version_row or not installation_row:
                    raise RuntimeError("candidate native capability installation is incomplete")
                artifact_row = source.execute(
                    "SELECT * FROM native_release_artifacts WHERE id=?",
                    (installation_row["artifact_id"],),
                ).fetchone()
                transaction_row = source.execute(
                    "SELECT * FROM native_install_transactions WHERE id=?",
                    (installation_row["transaction_id"],),
                ).fetchone()
                if not artifact_row or not transaction_row:
                    raise RuntimeError("candidate native release provenance is incomplete")

                source_workspace = Path(installation_row["workspace_path"]).resolve()
                candidate_workspace = (
                    candidate_database.path.parent
                    / "native-releases"
                    / "installations"
                    / "capability"
                    / capability["capability_id"]
                    / capability["version"]
                    / artifact_row["artifact_digest"]
                ).resolve()
                if not source_workspace.is_dir():
                    raise RuntimeError("candidate native capability workspace is unavailable")
                candidate_workspace.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                shutil.copytree(source_workspace, candidate_workspace)

                source_artifact = Path(artifact_row["artifact_path"]).resolve()
                candidate_artifact = (
                    candidate_database.path.parent
                    / "native-releases"
                    / "catalog"
                    / f"{artifact_row['artifact_digest']}.suwenpkg"
                ).resolve()
                candidate_artifact.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                shutil.copy2(source_artifact, candidate_artifact)

                _upsert(target, "capability_packages", dict(package_row))
                version_copy = dict(version_row)
                version_copy["artifact_path"] = str(candidate_artifact)
                version_copy["workspace_path"] = str(candidate_workspace / "source")
                _upsert(target, "capability_package_versions", version_copy)
                artifact_copy = dict(artifact_row)
                artifact_copy["artifact_path"] = str(candidate_artifact)
                _upsert(target, "native_release_artifacts", artifact_copy)
                _upsert(target, "native_install_transactions", dict(transaction_row))
                installation_copy = dict(installation_row)
                installation_copy["workspace_path"] = str(candidate_workspace)
                _upsert(target, "native_workspace_installations", installation_copy)

            for connector in snapshot["connectors"]:
                provider_row = source.execute(
                    "SELECT * FROM tool_providers WHERE id=?",
                    (connector["provider_id"],),
                ).fetchone()
                schema_ids = {
                    str(value)
                    for value in (
                        connector.get("schema_version_id"),
                        connector.get("current_schema_version_id"),
                    )
                    if value
                }
                schema_rows = [
                    source.execute(
                        "SELECT * FROM tool_schema_versions WHERE id=?",
                        (schema_id,),
                    ).fetchone()
                    for schema_id in sorted(schema_ids)
                ]
                if not provider_row or not schema_rows or any(row is None for row in schema_rows):
                    raise RuntimeError("candidate MCP Connector provenance is incomplete")
                provider_copy = dict(provider_row)
                provider_copy["status"] = "configured"
                provider_copy["binding_generation"] = 0
                provider_copy["runtime_metadata_json"] = "{}"
                _upsert(target, "tool_providers", provider_copy)
                for schema_row in schema_rows:
                    _upsert(target, "tool_schema_versions", dict(schema_row))

            agent = dict(
                source.execute("SELECT * FROM agents WHERE id=?", (snapshot["agent_id"],)).fetchone()
            )
            version = dict(
                source.execute(
                    "SELECT * FROM agent_versions WHERE id=?",
                    (snapshot["agent_version_id"],),
                ).fetchone()
            )
            agent["active_version_id"] = None
            _upsert(target, "agents", agent)
            _upsert(target, "agent_versions", version)
            persona_binding = source.execute(
                "SELECT * FROM agent_persona_bindings WHERE agent_id=?",
                (snapshot["agent_id"],),
            ).fetchone()
            if not persona_binding:
                raise RuntimeError("candidate Persona binding is missing")
            _upsert(
                target,
                "agent_persona_bindings",
                dict(persona_binding),
                key_columns=("agent_id",),
            )
            target.execute(
                "DELETE FROM agent_version_packs WHERE agent_version_id=?",
                (snapshot["agent_version_id"],),
            )
            for row in source.execute(
                """SELECT * FROM agent_version_packs
                   WHERE agent_version_id=? ORDER BY position""",
                (snapshot["agent_version_id"],),
            ).fetchall():
                _upsert(
                    target,
                    "agent_version_packs",
                    dict(row),
                    key_columns=("agent_version_id", "pack_version_id"),
                )
            for row in source.execute(
                """SELECT * FROM agent_version_capabilities
                   WHERE agent_version_id=? ORDER BY position""",
                (snapshot["agent_version_id"],),
            ).fetchall():
                _upsert(
                    target,
                    "agent_version_capabilities",
                    dict(row),
                    key_columns=("agent_version_id", "capability_version_id"),
                )
            target.execute(
                """UPDATE agents SET active_version_id=?, status='published'
                   WHERE id=?""",
                (snapshot["agent_version_id"], snapshot["agent_id"]),
            )
            target.execute(
                """INSERT OR REPLACE INTO system_settings(
                   key, value_json, version, updated_by, updated_at
                ) VALUES ('default_agent_id', ?, 1, 'system:candidate-clone', ?)""",
                (json.dumps(snapshot["agent_id"]), iso()),
            )
            target.commit()

    async def _execute_suite(
        self,
        attempt_id: str,
        manifest: dict[str, Any],
        settings: Settings,
        target: dict[str, Any],
        scenarios: tuple[RetentionScenario, ...],
    ) -> dict[str, Any]:
        # Import here to avoid coupling the API control plane to the runner lifecycle.
        from .api import AppState

        state = AppState(settings)
        await state.tool_providers.connect_configured("system:candidate-connector")
        resolved = state.runtime_resolver.resolve(
            state.repository.create_case("candidate-preflight", agent_id=target["agent_id"])["id"]
        )
        expected_catalogs = sorted(
            target.get("connector_catalogs", []),
            key=lambda item: str(item.get("provider_id")),
        )
        resolved_catalogs = sorted(
            [
                {
                    "provider_id": item["provider_id"],
                    "schema_version_id": item.get("schema_version_id"),
                    "schema_digest": item.get("schema_digest"),
                }
                for item in resolved.snapshot.get("connectors", [])
            ],
            key=lambda item: str(item.get("provider_id")),
        )
        if resolved_catalogs != expected_catalogs:
            raise RuntimeError("candidate Connector catalog changed after attempt freeze")
        runtime_target = {
            **target,
            "effective_tool_schema_digest": resolved.snapshot["tool_schema_digest"],
        }
        delegate = self.model_factory(resolved.model_config)
        model = _CountingModel(delegate, self.settings.candidate.max_model_turns)
        start = time.monotonic()
        episodes: list[dict[str, Any]] = []
        stop_reason: str | None = None
        try:
            for scenario in scenarios:
                remaining_seconds = self.settings.candidate.max_elapsed_seconds - (
                    time.monotonic() - start
                )
                if remaining_seconds <= 0:
                    stop_reason = "elapsed_time_budget_exhausted"
                    break
                try:
                    episode = await asyncio.wait_for(
                        self._execute_episode(state, model, runtime_target, scenario),
                        timeout=remaining_seconds,
                    )
                except TimeoutError:
                    stop_reason = "elapsed_time_budget_exhausted"
                    break
                except CandidateModelTurnBudgetExceeded:
                    stop_reason = "model_turn_budget_exhausted"
                    break
                episodes.append(episode)
                if model.exhausted:
                    stop_reason = "model_turn_budget_exhausted"
                    break
                if episode["source_calls"]:
                    stop_reason = "unauthorized_source_observed"
                    break
                if episode["external_writes"]:
                    stop_reason = "external_write_observed"
                    break
                if episode["infrastructure_failure"]:
                    stop_reason = "infrastructure_failure"
                    break
                if not episode["contract_passed"]:
                    stop_reason = "deterministic_contract_failure"
                    break
        finally:
            # A cancelled isolated candidate is a runner/process interruption,
            # not an end-user `/stop` of a live diagnostic Case.
            state.repository.recover_interrupted_runs(reclassify_cancelled=True)
            state.repository.recover_interrupted_actions()
            await model.close()
            await state.tool_providers.close()
        completed_ids = {episode["scenario_id"] for episode in episodes}
        for scenario in scenarios:
            if scenario.id not in completed_ids:
                episodes.append(
                    {
                        "scenario_id": scenario.id,
                        "category": scenario.category,
                        "status": "not_run_after_stop",
                        "contract_passed": False,
                        "stop_reason": stop_reason,
                    }
                )
        totals = {
            "episodes": len(episodes),
            "completed_episodes": sum(item["status"] == "completed" for item in episodes),
            "model_turns": model.calls,
            "tool_calls": sum(item.get("tool_calls", 0) for item in episodes),
            "source_calls": sum(item.get("source_calls", 0) for item in episodes),
            "external_writes": sum(item.get("external_writes", 0) for item in episodes),
            "elapsed_ms": round((time.monotonic() - start) * 1000),
        }
        deterministic_pass = bool(
            len(episodes) == len(scenarios)
            and all(item.get("contract_passed") for item in episodes)
            and totals["source_calls"] == 0
            and totals["external_writes"] == 0
            and stop_reason is None
        )
        candidate_loaded = bool(
            not self.allow_fixture_model
            and deterministic_pass
            and totals["model_turns"] > 0
            and all(
                item.get("status") == "completed"
                and item.get("provenance_passed")
                and item.get("expected_skill_delivered")
                and item.get("expected_skill_read")
                for item in episodes
            )
        )
        if deterministic_pass and candidate_loaded:
            scorecard_status = "completed_pending_human_review"
            human_review_status = "pending"
        elif deterministic_pass:
            scorecard_status = "fixture_contract_verified"
            human_review_status = "not_applicable_fixture"
        else:
            scorecard_status = "contract_failed"
            human_review_status = "not_ready"
        return {
            "schema_version": "suwen-scorecard.v1",
            "attempt_id": attempt_id,
            "candidate_key": manifest["candidate_key"],
            "suite_digest": manifest["suite_digest"],
            "target": manifest["target"],
            "resolved_runtime": {
                "tool_schema_digest": runtime_target["effective_tool_schema_digest"],
                "connector_catalogs": resolved_catalogs,
            },
            "status": scorecard_status,
            "deterministic_contract_passed": deterministic_pass,
            "human_review_status": human_review_status,
            "review_dimensions": list(HUMAN_REVIEW_DIMENSIONS),
            "review_rubric": manifest["human_review_rubric"],
            "stop_reason": stop_reason,
            "totals": totals,
            "episodes": episodes,
            "claims": {
                "candidate_loaded": candidate_loaded,
                "skill_influence_observed": False,
                "tool_influence_observed": False,
                "influence_observed": False,
                "source_observed": False,
                "outcome_reviewed": False,
                "channel_observed": False,
            },
        }

    async def _execute_episode(
        self,
        state: Any,
        model: _CountingModel,
        target: dict[str, Any],
        scenario: RetentionScenario,
    ) -> dict[str, Any]:
        case = state.repository.create_case(f"candidate:{scenario.id}", agent_id=target["agent_id"])
        results = []
        for turn_index, content in enumerate(scenario.turns, start=1):
            message = state.repository.add_message(
                case["id"],
                "user",
                content,
                actor_ref=f"synthetic:{scenario.id}:turn-{turn_index}",
            )
            resolved = state.runtime_resolver.resolve(case["id"])
            candidate_tools = resolved.tools.subset(
                _candidate_tool_surface(scenario.allowed_tools, resolved.tools.names())
            )
            harness = DiagnosticHarness(
                state.repository,
                model,
                resolved.model_config,
                resolved.harness_config,
                resolved.skills,
                candidate_tools,
                state.actions,
                system_prompt=resolved.system_prompt,
                persona_prompt=resolved.persona_prompt,
                runtime_snapshot=resolved.snapshot,
                heavy_media_semaphore=asyncio.Semaphore(1),
                artifacts=state.artifacts,
            )
            result = await harness.run(case["id"], message["id"])
            results.append(result)
            if result.status == "failed":
                break
        runs = state.repository.list_runs(case["id"])
        calls = state.repository.list_tool_calls(case["id"])
        evidence = state.repository.list_evidence(case["id"])
        messages = state.repository.list_messages(case["id"])
        outbox_count = self._count(state.repository, "outbox", case["id"])
        committed_actions = self._count(
            state.repository,
            "actions",
            case["id"],
            "status IN ('succeeded','failed','outcome_unknown')",
        )
        actual_tools, support_tools, forbidden_tools = _candidate_tool_summary(
            [item["tool_name"] for item in calls],
            scenario.allowed_tools,
        )
        tool_provider_ids = {
            definition.name: definition.provider_id for definition in state.tools.definitions()
        }
        external_provider_ids = {
            item["id"]
            for item in state.tool_providers.list_providers()
            if str(item.get("provider_type") or "").startswith("mcp_")
        }
        source_calls = _candidate_source_call_count(
            evidence,
            calls,
            tool_provider_ids,
            external_provider_ids,
        )
        provenance_pass = all(
            item["agent_version_id"] == target["agent_version_id"]
            and item["model_profile_version_id"] == target["model_profile_version_id"]
            and item["provider_version_id"] == target["provider_version_id"]
            and item["prompt_bundle_digest"] == target["prompt_bundle_digest"]
            and json.loads(item["pack_digests_json"]) == target["pack_digests"]
            and item["tool_schema_digest"]
            == target.get("effective_tool_schema_digest", target["tool_schema_digest"])
            for item in runs
        )
        expected_skill_delivered = all(
            scenario.expected_skill
            in {
                skill["id"]
                for skill in json.loads(item["context_json"])["runtime_snapshot"]["skill_delivery"]
            }
            for item in runs
        )
        expected_skill_read = any(
            item.get("state") == "observed"
            and item.get("source_ref") == f"skill:{scenario.expected_skill}"
            and item.get("source_role") == "capability_instruction"
            for item in evidence
        )
        replies = [item for item in messages if item["role"] == "assistant"]
        all_runs_completed = all(item.status == "completed" for item in results)
        all_runs_stopped_normally = all(item.stop_reason == "model_stop" for item in results)
        infrastructure_failure = any(
            item.status == "failed" and item.stop_reason in INFRASTRUCTURE_STOP_REASONS for item in results
        )
        contract_pass = bool(
            len(runs) == 2
            and len(replies) == 2
            and all_runs_completed
            and all_runs_stopped_normally
            and all(item["content"].strip() for item in replies)
            and provenance_pass
            and expected_skill_delivered
            and (expected_skill_read or self.allow_fixture_model)
            and not forbidden_tools
            and len(calls) <= 48
            and source_calls == 0
            and outbox_count == 0
            and committed_actions == 0
            and not infrastructure_failure
        )
        return {
            "scenario_id": scenario.id,
            "category": scenario.category,
            "status": "completed",
            "contract_passed": contract_pass,
            "expected_skill": scenario.expected_skill,
            "expected_skill_delivered": expected_skill_delivered,
            "expected_skill_read": expected_skill_read,
            "allowed_tools": list(scenario.allowed_tools),
            "actual_tools": actual_tools,
            "support_tools": support_tools,
            "forbidden_tools": forbidden_tools,
            "run_refs": [item["id"] for item in runs],
            "run_states": [item["status"] for item in runs],
            "stop_reasons": [item["stop_reason"] for item in runs],
            "tool_calls": len(calls),
            "support_tool_calls": len(support_tools),
            "source_calls": source_calls,
            "external_writes": outbox_count + committed_actions,
            "provenance_passed": provenance_pass,
            "infrastructure_failure": infrastructure_failure,
            "answer_excerpts": [_safe_excerpt(item["content"], 500) for item in replies],
            "boundary_for_human_review": scenario.boundary,
            "human_review": "pending",
        }

    @staticmethod
    def _count(
        repository: Repository,
        table: str,
        case_id: str,
        extra: str = "1=1",
    ) -> int:
        if table not in {"outbox", "actions"}:
            raise ValueError("unsupported candidate count table")
        with repository.database.connect() as connection:
            return connection.execute(
                f"SELECT COUNT(*) FROM {table} WHERE case_id=? AND {extra}",
                (case_id,),
            ).fetchone()[0]

    @staticmethod
    def _blocked_scorecard(
        attempt_id: str,
        manifest: dict[str, Any],
        findings: list[dict[str, str]],
    ) -> dict[str, Any]:
        return {
            "schema_version": "suwen-scorecard.v1",
            "attempt_id": attempt_id,
            "candidate_key": manifest["candidate_key"],
            "suite_digest": manifest["suite_digest"],
            "target": manifest["target"],
            "status": "preflight_blocked",
            "deterministic_contract_passed": False,
            "findings": findings,
            "totals": {
                "episodes": 0,
                "completed_episodes": 0,
                "model_turns": 0,
                "tool_calls": 0,
                "source_calls": 0,
                "external_writes": 0,
                "elapsed_ms": 0,
            },
            "claims": {
                "candidate_loaded": False,
                "skill_influence_observed": False,
                "tool_influence_observed": False,
                "influence_observed": False,
                "source_observed": False,
                "outcome_reviewed": False,
                "channel_observed": False,
            },
        }

    def _mark_started(self, attempt_id: str) -> None:
        with self.database.connect() as connection:
            connection.execute(
                """UPDATE candidate_attempts
                   SET status='running', started_at=? WHERE id=? AND status='reserved'""",
                (iso(), attempt_id),
            )

    def _finish_attempt(
        self,
        attempt_id: str,
        status: str,
        scorecard: dict[str, Any],
        *,
        failure_class: str | None = None,
        model_calls: int = 0,
        source_calls: int = 0,
        external_writes: int = 0,
    ) -> None:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """UPDATE candidate_attempts
                   SET status=?, scorecard_json=?, failure_class=?, model_calls=?,
                       source_calls=?, external_writes=?, finished_at=? WHERE id=?""",
                (
                    status,
                    json.dumps(scorecard, ensure_ascii=False, sort_keys=True),
                    failure_class,
                    model_calls,
                    source_calls,
                    external_writes,
                    iso(),
                    attempt_id,
                ),
            )
            connection.commit()


def _upsert(
    connection: sqlite3.Connection,
    table: str,
    row: dict[str, Any],
    *,
    key_columns: tuple[str, ...] = ("id",),
) -> None:
    safe_tables = {
        "secret_refs",
        "model_providers",
        "model_provider_versions",
        "model_profiles",
        "model_profile_versions",
        "prompt_bundles",
        "prompt_bundle_versions",
        "agents",
        "agent_versions",
        "agent_persona_bindings",
        "agent_version_packs",
        "capability_packages",
        "capability_package_versions",
        "native_release_artifacts",
        "native_install_transactions",
        "native_workspace_installations",
        "agent_version_capabilities",
        "tool_providers",
        "tool_schema_versions",
    }
    if table not in safe_tables:
        raise ValueError("candidate configuration table is not allowlisted")
    columns = tuple(row)
    updates = [column for column in columns if column not in key_columns]
    placeholders = ",".join("?" for _ in columns)
    conflict = ",".join(key_columns)
    update_sql = ",".join(f"{column}=excluded.{column}" for column in updates)
    connection.execute(
        f"INSERT INTO {table} ({','.join(columns)}) VALUES ({placeholders}) "
        f"ON CONFLICT({conflict}) DO UPDATE SET {update_sql}",
        tuple(row[column] for column in columns),
    )


def _repository_revision(module_path: Path | None = None) -> str:
    module = (module_path or Path(__file__)).resolve()
    package_dir = module.parent
    source_root = package_dir.parents[1]
    source_package = source_root / "src" / "suwen"
    digest = hashlib.sha256()
    if source_package.is_dir() and source_package.resolve() == package_dir:
        root = source_root
        targets = [
            root / "src",
            root / "packs",
            root / "pyproject.toml",
            root / "uv.lock",
        ]
    else:
        # A product release runs from site-packages, not a source checkout.
        # Hash the actual installed package tree so a Runtime byte change creates
        # a distinct one-shot candidate key instead of the empty SHA-256 digest.
        root = package_dir.parent
        targets = [package_dir]
    files: list[Path] = []
    for target in targets:
        if target.is_dir():
            files.extend(
                path for path in target.rglob("*") if path.is_file() and "__pycache__" not in path.parts
            )
        elif target.is_file():
            files.append(target)
    for path in sorted(set(files)):
        digest.update(path.relative_to(root).as_posix().encode())
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def _write_json_exclusive(path: Path, payload: dict[str, Any]) -> None:
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2).encode()
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())
            os.fchmod(handle.fileno(), 0o600)
    except BaseException:
        path.unlink(missing_ok=True)
        raise


def _safe_excerpt(value: str, limit: int) -> str:
    value = re.sub(r"https?://\S+", "[redacted-url]", value)
    value = re.sub(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", "[redacted-email]", value)
    value = re.sub(
        r"(?i)(api[_ -]?key|token|secret|password)\s*[:=]\s*\S+",
        r"\1=[redacted]",
        value,
    )
    return value[:limit]


def _candidate_tool_summary(
    tool_names: list[str],
    allowed_tools: tuple[str, ...],
) -> tuple[list[str], list[str], list[str]]:
    """Separate capability-reference support from Sj behavior Tool evidence."""

    support_names = set(CANDIDATE_INTERNAL_SUPPORT_TOOLS)
    support_tools = [name for name in tool_names if name in support_names]
    behavior_tools = [name for name in tool_names if name not in support_names]
    forbidden_tools = sorted(set(behavior_tools) - set(allowed_tools))
    return behavior_tools, support_tools, forbidden_tools


def _candidate_tool_surface(
    allowed_tools: tuple[str, ...],
    available_tools: frozenset[str],
) -> list[str]:
    """Expose only the tools frozen by this scenario, including named support tools."""

    frozen = set(allowed_tools) | set(CANDIDATE_ALWAYS_AVAILABLE_SUPPORT_TOOLS)
    return sorted(frozen & set(available_tools))


def _candidate_source_call_count(
    evidence: list[dict[str, Any]],
    calls: list[dict[str, Any]],
    tool_provider_ids: dict[str, str],
    external_provider_ids: set[str],
) -> int:
    """Count observed external Provider calls, excluding local Runtime evidence."""

    call_providers = {
        item["id"]: tool_provider_ids.get(str(item.get("tool_name") or ""), "") for item in calls
    }
    return sum(
        1
        for item in evidence
        if item["state"] in {"observed", "zero_matches", "conflict"}
        and call_providers.get(item.get("tool_call_id")) in external_provider_ids
    )


def _digest(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode()
    return hashlib.sha256(encoded).hexdigest()


def _dedupe_findings(findings: list[dict[str, str]]) -> list[dict[str, str]]:
    return list({item["code"]: item for item in findings}.values())


def _failure_class(exc: BaseException) -> str:
    if isinstance(exc, CandidateAlreadyAttempted):
        return "already_attempted"
    if isinstance(exc, (ValueError, KeyError, FileNotFoundError)):
        return "configuration"
    if isinstance(exc, TimeoutError):
        return "timeout"
    return "runtime"
