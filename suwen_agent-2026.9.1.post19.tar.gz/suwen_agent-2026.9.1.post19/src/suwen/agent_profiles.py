"""Source-managed first-party Agent assembly Profiles.

An Agent Profile is deliberately a small, immutable recipe.  It resolves
logical id/version/digest references to the workspace-installed components
which an Agent Version already knows how to freeze.  It never imports package
source from ``profiles/`` and it never becomes a Run-time dependency.
"""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .agent_composition import AgentCompositionError, ComposedAgentSurface, compose_agent_surface
from .capability_packages import CapabilityBinding, CapabilityPackageRegistry
from .connectors import ConnectorResolution, resolve_connector_bindings
from .packs import PackRegistry
from .tools import ToolRegistry

AGENT_PROFILE_SCHEMA = "suwen-agent-profile.v2"
_STABLE_ID = re.compile(r"^[a-z][a-z0-9-]{1,63}$")
_SEMVER = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?$")
_DIGEST = re.compile(r"^[0-9a-f]{64}$")
_PROFILE_FIELDS = frozenset(
    {
        "schema",
        "id",
        "version",
        "name",
        "description",
        "language",
        "max_tool_risk",
        "host_prompt",
        "packs",
        "capabilities",
        "connectors",
    }
)
_PROMPT_FIELDS = frozenset({"id", "version", "digest"})
_PACK_FIELDS = frozenset({"id", "version", "digest"})
_CAPABILITY_FIELDS = frozenset({"id", "version", "role", "digest"})
_CONNECTOR_FIELDS = frozenset({"id", "catalog_digest", "selection"})


class AgentProfileError(ValueError):
    """The Profile source or exact reference is invalid."""


@dataclass(frozen=True)
class PromptReference:
    id: str
    version: int
    digest: str


@dataclass(frozen=True)
class PackageReference:
    id: str
    version: str
    digest: str


@dataclass(frozen=True)
class CapabilityReference:
    id: str
    version: str
    role: str
    digest: str


@dataclass(frozen=True)
class ConnectorReference:
    id: str
    catalog_digest: str
    selection: str


@dataclass(frozen=True)
class AgentProfile:
    id: str
    version: str
    name: str
    description: str
    language: str
    max_tool_risk: str
    host_prompt: PromptReference
    packs: tuple[PackageReference, ...]
    capabilities: tuple[CapabilityReference, ...]
    connectors: tuple[ConnectorReference, ...]
    digest: str

    def manifest(self) -> dict[str, Any]:
        return {
            "schema": AGENT_PROFILE_SCHEMA,
            "id": self.id,
            "version": self.version,
            "name": self.name,
            "description": self.description,
            "language": self.language,
            "max_tool_risk": self.max_tool_risk,
            "host_prompt": {
                "id": self.host_prompt.id,
                "version": self.host_prompt.version,
                "digest": self.host_prompt.digest,
            },
            "packs": [{"id": item.id, "version": item.version, "digest": item.digest} for item in self.packs],
            "capabilities": [
                {
                    "id": item.id,
                    "version": item.version,
                    "role": item.role,
                    "digest": item.digest,
                }
                for item in self.capabilities
            ],
            "connectors": [
                {
                    "id": item.id,
                    "catalog_digest": item.catalog_digest,
                    "selection": item.selection,
                }
                for item in self.connectors
            ],
        }


@dataclass(frozen=True)
class AgentProfileResolution:
    profile: AgentProfile
    state: str
    findings: tuple[dict[str, str], ...]
    prompt_bundle_version_id: str | None = None
    pack_version_ids: tuple[str, ...] = ()
    capability_bindings: tuple[CapabilityBinding, ...] = ()
    connector_bindings: tuple[dict[str, Any], ...] = ()
    connector_provenance: tuple[dict[str, Any], ...] = ()
    tool_allowlist: tuple[str, ...] = ()
    composition: ComposedAgentSurface | None = None
    artifact_digest: str | None = None
    installation_id: str | None = None
    install_digest: str | None = None
    composition_lock_digest: str | None = None

    @property
    def ready(self) -> bool:
        return self.state == "ready"

    def public_view(self, *, include_composition: bool = False) -> dict[str, Any]:
        item: dict[str, Any] = {
            "id": self.profile.id,
            "version": self.profile.version,
            "digest": self.profile.digest,
            "name": self.profile.name,
            "description": self.profile.description,
            "language": self.profile.language,
            "max_tool_risk": self.profile.max_tool_risk,
            "status": self.state,
            "ready": self.ready,
            "findings": [dict(finding) for finding in self.findings],
            "references": self.profile.manifest(),
        }
        if include_composition and self.composition is not None:
            item["composition"] = {
                "digest": self.composition.digest,
                "tool_allowlist": list(self.tool_allowlist),
                "tool_schema_digest": hashlib.sha256(
                    json.dumps(
                        [
                            {
                                "name": tool.name,
                                "risk": tool.risk.value,
                                "provider_id": tool.provider_id,
                            }
                            for tool in self.composition.tools.definitions()
                        ],
                        ensure_ascii=False,
                        sort_keys=True,
                        separators=(",", ":"),
                    ).encode("utf-8")
                ).hexdigest(),
                "skill_ids": [item.id for item in self.composition.skills.list()],
                "capability_tool_owners": dict(self.composition.capability_tool_owners),
                "connectors": [dict(item) for item in self.connector_provenance],
            }
        item["release"] = (
            {
                "artifact_digest": self.artifact_digest,
                "installation_id": self.installation_id,
                "install_digest": self.install_digest,
                "composition_lock_digest": self.composition_lock_digest,
                "state": "workspace-installed",
            }
            if self.installation_id
            else None
        )
        return item


def bundled_agent_profiles_root() -> Path:
    packaged = Path(__file__).resolve().parent / "_bundled" / "profiles"
    if packaged.is_dir():
        return packaged
    return Path(__file__).resolve().parents[2] / "profiles"


class AgentProfileRegistry:
    """Resolve first-party Profile source against exact current workspace state."""

    def __init__(
        self,
        database: Any,
        packs: PackRegistry,
        runtime_tools: ToolRegistry,
        capability_packages: CapabilityPackageRegistry,
        root: Path | None = None,
        installed_root: Path | None = None,
    ) -> None:
        self.database = database
        self.packs = packs
        self.runtime_tools = runtime_tools
        self.capability_packages = capability_packages
        self.root = (root or bundled_agent_profiles_root()).resolve()
        self.installed_root = installed_root.resolve() if installed_root else None

    def list(self) -> list[dict[str, Any]]:
        definitions, invalid = self._definitions()
        result: list[dict[str, Any]] = [
            {
                "id": item["id"],
                "version": item["version"],
                "digest": None,
                "name": item["name"],
                "description": "",
                "language": "zh-CN",
                "max_tool_risk": "read_only",
                "status": "invalid",
                "ready": False,
                "findings": [self._finding("profile_schema_invalid", item["detail"])],
                "references": None,
            }
            for item in invalid
        ]
        with self.database.connect() as connection:
            result.extend(
                self._resolve_in_connection(connection, profile).public_view() for profile in definitions
            )
        return sorted(result, key=lambda item: (item["id"], item["version"]))

    def get(self, profile_id: str, version: str, digest: str) -> AgentProfileResolution:
        profile = self._definition(profile_id, version, digest)
        with self.database.connect() as connection:
            return self._resolve_in_connection(connection, profile)

    def validate_version_binding(
        self,
        connection: sqlite3.Connection,
        version: sqlite3.Row,
    ) -> list[dict[str, str]]:
        """Validate source Profile ownership during Draft validation/publish only.

        A Run never calls this method.  Published Agent Versions retain expanded
        references and remain executable even after later Profile source changes.
        """

        try:
            config = json.loads(version["config_json"] or "{}")
        except json.JSONDecodeError:
            return [self._finding("profile_provenance_invalid")]
        keys = ("agent_profile_id", "agent_profile_version", "agent_profile_digest")
        present = [key for key in keys if config.get(key) is not None]
        if not present:
            return []
        if len(present) != len(keys):
            return [self._finding("profile_provenance_incomplete")]
        try:
            profile = self._definition(
                str(config["agent_profile_id"]),
                str(config["agent_profile_version"]),
                str(config["agent_profile_digest"]),
            )
        except AgentProfileError as exc:
            return [self._finding("profile_provenance_invalid", str(exc))]
        resolution = self._resolve_in_connection(connection, profile)
        if not resolution.ready:
            return [dict(item) for item in resolution.findings]
        expected_packs = list(resolution.pack_version_ids)
        actual_packs = [
            str(row["pack_version_id"])
            for row in connection.execute(
                """SELECT pack_version_id FROM agent_version_packs
                   WHERE agent_version_id=? AND enabled=1 ORDER BY position, pack_version_id""",
                (version["id"],),
            ).fetchall()
        ]
        expected_capabilities = [
            (item.capability_version_id, item.role, item.position) for item in resolution.capability_bindings
        ]
        actual_capabilities = [
            (str(row["capability_version_id"]), str(row["role"]), int(row["position"]))
            for row in connection.execute(
                """SELECT capability_version_id, role, position
                   FROM agent_version_capabilities
                   WHERE agent_version_id=? AND enabled=1
                   ORDER BY position, capability_version_id""",
                (version["id"],),
            ).fetchall()
        ]
        findings: list[dict[str, str]] = []
        if version["prompt_bundle_version_id"] != resolution.prompt_bundle_version_id:
            findings.append(self._finding("profile_binding_prompt_mismatch"))
        if actual_packs != expected_packs:
            findings.append(self._finding("profile_binding_pack_mismatch"))
        if actual_capabilities != expected_capabilities:
            findings.append(self._finding("profile_binding_capability_mismatch"))
        if config.get("connector_bindings", []) != list(resolution.connector_bindings):
            findings.append(self._finding("profile_binding_connector_mismatch"))
        if config.get("max_tool_risk") != profile.max_tool_risk:
            findings.append(self._finding("profile_binding_tool_risk_mismatch"))
        if config.get("tool_allowlist") != list(resolution.tool_allowlist):
            findings.append(self._finding("profile_binding_tool_allowlist_mismatch"))
        return findings

    def _definition(self, profile_id: str, version: str, digest: str) -> AgentProfile:
        if (
            not _STABLE_ID.fullmatch(profile_id)
            or not _SEMVER.fullmatch(version)
            or not _DIGEST.fullmatch(digest)
        ):
            raise AgentProfileError("Profile reference is invalid")
        for profile in self._definitions()[0]:
            if profile.id == profile_id and profile.version == version:
                if profile.digest != digest:
                    raise AgentProfileError("Profile content digest does not match")
                return profile
        raise AgentProfileError("Agent Profile version is unavailable")

    def _definitions(self) -> tuple[list[AgentProfile], list[dict[str, str]]]:
        manifest_paths: list[Path] = []
        if self.root.is_dir():
            manifest_paths.extend(
                child / "profile.toml"
                for child in sorted(self.root.iterdir())
                if child.is_dir()
                and not child.is_symlink()
                and (child / "profile.toml").is_file()
                and not (child / "profile.toml").is_symlink()
            )
        if self.installed_root and self.installed_root.is_dir():
            manifest_paths.extend(
                path
                for path in sorted(self.installed_root.glob("*/*/*/source/profile.toml"))
                if path.is_file() and not path.is_symlink()
            )
        definitions: list[AgentProfile] = []
        invalid: list[dict[str, str]] = []
        for manifest_path in manifest_paths:
            try:
                profile = _parse_profile(manifest_path)
            except (OSError, tomllib.TOMLDecodeError, AgentProfileError) as exc:
                candidate_id = manifest_path.parent.name
                invalid.append(
                    {
                        "id": candidate_id if _STABLE_ID.fullmatch(candidate_id) else "invalid-profile",
                        "version": "0.0.0",
                        "name": candidate_id,
                        "detail": str(exc),
                    }
                )
                continue
            definitions.append(profile)
        conflicts = {
            identity
            for identity in {(item.id, item.version) for item in definitions}
            if len({item.digest for item in definitions if (item.id, item.version) == identity}) > 1
        }
        if conflicts:
            definitions = [item for item in definitions if (item.id, item.version) not in conflicts]
            invalid.extend(
                {
                    "id": profile_id,
                    "version": version,
                    "name": profile_id,
                    "detail": "conflicting Agent Profile id/version",
                }
                for profile_id, version in sorted(conflicts)
            )
        unique = {(item.id, item.version, item.digest): item for item in definitions}
        return list(unique.values()), invalid

    def _resolve_in_connection(
        self,
        connection: sqlite3.Connection,
        profile: AgentProfile,
    ) -> AgentProfileResolution:
        findings: list[dict[str, str]] = []
        prompt_id = self._resolve_prompt(connection, profile.host_prompt, findings)
        pack_ids = self._resolve_packs(connection, profile.packs, findings)
        capability_bindings = self._resolve_capabilities(connection, profile.capabilities, findings)
        connector_resolution = self._resolve_connectors(connection, profile.connectors, findings)
        release = connection.execute(
            """SELECT nra.artifact_digest, nwi.id AS installation_id,
                      nwi.install_digest, apr.composition_lock_digest
               FROM agent_profile_releases apr
               JOIN native_release_artifacts nra ON nra.id=apr.artifact_id
               JOIN native_workspace_installations nwi ON nwi.id=apr.installation_id
               WHERE apr.profile_id=? AND apr.version=? AND apr.source_content_digest=?
                 AND apr.status='installed' AND nwi.status='installed'""",
            (profile.id, profile.version, profile.digest),
        ).fetchone()
        if findings:
            return AgentProfileResolution(
                profile,
                "blocked",
                tuple(findings),
                artifact_digest=str(release["artifact_digest"]) if release else None,
                installation_id=str(release["installation_id"]) if release else None,
                install_digest=str(release["install_digest"]) if release else None,
                composition_lock_digest=str(release["composition_lock_digest"]) if release else None,
            )
        try:
            composition = compose_agent_surface(
                packs=self.packs,
                runtime_tools=self.runtime_tools,
                capability_packages=self.capability_packages,
                pack_refs=[
                    {
                        "pack_version_id": version_id,
                        "pack_id": reference.id,
                        "version": reference.version,
                        "digest": reference.digest,
                    }
                    for reference, version_id in zip(profile.packs, pack_ids, strict=True)
                ],
                capability_bindings=list(capability_bindings),
                prompt_content_json=self._prompt_content(connection, prompt_id),
            )
            baseline_tools = ToolRegistry()
            baseline_tools.merge_from(composition.tools)
            baseline_tools.merge_from(connector_resolution.baseline_tools)
            composition.tools.merge_from(connector_resolution.tools)
        except AgentCompositionError as exc:
            text = str(exc)
            code = (
                "profile_tool_conflict"
                if "Tool" in text
                else "profile_prompt_or_skill_conflict"
                if "Prompt" in text or "Skill" in text
                else "profile_composition_invalid"
            )
            return AgentProfileResolution(
                profile,
                "blocked",
                (self._finding(code, text),),
            )
        except ValueError as exc:
            return AgentProfileResolution(
                profile,
                "blocked",
                (self._finding("profile_connector_tool_conflict", str(exc)),),
            )
        allowed = tuple(
            sorted(
                item.name
                for item in baseline_tools.definitions()
                if item.risk.value == profile.max_tool_risk
                or (profile.max_tool_risk == "controlled_action" and item.risk.value == "read_only")
            )
        )
        return AgentProfileResolution(
            profile,
            "ready",
            (),
            prompt_bundle_version_id=prompt_id,
            pack_version_ids=tuple(pack_ids),
            capability_bindings=tuple(capability_bindings),
            connector_bindings=connector_resolution.bindings,
            connector_provenance=connector_resolution.provenance,
            tool_allowlist=allowed,
            composition=composition,
            artifact_digest=str(release["artifact_digest"]) if release else None,
            installation_id=str(release["installation_id"]) if release else None,
            install_digest=str(release["install_digest"]) if release else None,
            composition_lock_digest=str(release["composition_lock_digest"]) if release else None,
        )

    def _resolve_prompt(
        self,
        connection: sqlite3.Connection,
        reference: PromptReference,
        findings: list[dict[str, str]],
    ) -> str | None:
        rows = connection.execute(
            """SELECT pbv.id, pbv.digest, pb.status
               FROM prompt_bundle_versions pbv
               JOIN prompt_bundles pb ON pb.id=pbv.prompt_bundle_id
               WHERE pbv.prompt_bundle_id=? AND pbv.version=?""",
            (reference.id, reference.version),
        ).fetchall()
        if not rows:
            findings.append(
                self._finding("profile_dependency_missing", f"prompt:{reference.id}@{reference.version}")
            )
            return None
        row = next((item for item in rows if item["digest"] == reference.digest), None)
        if row is None:
            findings.append(
                self._finding(
                    "profile_dependency_digest_mismatch", f"prompt:{reference.id}@{reference.version}"
                )
            )
            return None
        if row["status"] != "active":
            findings.append(
                self._finding("profile_dependency_unavailable", f"prompt:{reference.id}@{reference.version}")
            )
            return None
        return str(row["id"])

    def _resolve_packs(
        self,
        connection: sqlite3.Connection,
        references: tuple[PackageReference, ...],
        findings: list[dict[str, str]],
    ) -> list[str]:
        result: list[str] = []
        for reference in references:
            rows = connection.execute(
                """SELECT cpv.id, cpv.digest, cp.status
                   FROM capability_pack_versions cpv
                   JOIN capability_packs cp ON cp.id=cpv.pack_id
                   WHERE cpv.pack_id=? AND cpv.version=?""",
                (reference.id, reference.version),
            ).fetchall()
            if not rows:
                findings.append(
                    self._finding("profile_dependency_missing", f"pack:{reference.id}@{reference.version}")
                )
                continue
            row = next((item for item in rows if item["digest"] == reference.digest), None)
            if row is None:
                findings.append(
                    self._finding(
                        "profile_dependency_digest_mismatch", f"pack:{reference.id}@{reference.version}"
                    )
                )
                continue
            if row["status"] != "installed":
                findings.append(
                    self._finding(
                        "profile_dependency_unavailable", f"pack:{reference.id}@{reference.version}"
                    )
                )
                continue
            result.append(str(row["id"]))
        return result

    def _resolve_capabilities(
        self,
        connection: sqlite3.Connection,
        references: tuple[CapabilityReference, ...],
        findings: list[dict[str, str]],
    ) -> list[CapabilityBinding]:
        result: list[CapabilityBinding] = []
        for position, reference in enumerate(references):
            rows = connection.execute(
                """SELECT cpv.id, cpv.content_digest, cpv.lifecycle_state,
                          cp.id AS capability_id, cp.kind, cp.status
                   FROM capability_package_versions cpv
                   JOIN capability_packages cp ON cp.id=cpv.capability_id
                   WHERE cp.id=? AND cpv.version=?""",
                (reference.id, reference.version),
            ).fetchall()
            if not rows:
                findings.append(
                    self._finding(
                        "profile_dependency_missing", f"capability:{reference.id}@{reference.version}"
                    )
                )
                continue
            row = next((item for item in rows if item["content_digest"] == reference.digest), None)
            if row is None:
                findings.append(
                    self._finding(
                        "profile_dependency_digest_mismatch", f"capability:{reference.id}@{reference.version}"
                    )
                )
                continue
            if row["kind"] != reference.role:
                findings.append(self._finding("profile_dependency_role_mismatch", reference.id))
                continue
            if row["status"] != "available" or row["lifecycle_state"] != "workspace-installed":
                findings.append(
                    self._finding(
                        "profile_dependency_not_installed", f"capability:{reference.id}@{reference.version}"
                    )
                )
                continue
            result.append(CapabilityBinding(str(row["id"]), reference.role, position))
        return result

    def _resolve_connectors(
        self,
        connection: sqlite3.Connection,
        references: tuple[ConnectorReference, ...],
        findings: list[dict[str, str]],
    ) -> ConnectorResolution:
        try:
            resolution = resolve_connector_bindings(
                connection,
                self.runtime_tools,
                [
                    {
                        "provider_id": reference.id,
                        "schema_digest": reference.catalog_digest,
                        "selection": reference.selection,
                    }
                    for reference in references
                ],
                normalize=False,
            )
        except ValueError as exc:
            findings.append(self._finding("profile_connector_unavailable", str(exc)))
            return ConnectorResolution((), ToolRegistry(), ())
        return resolution

    @staticmethod
    def _prompt_content(connection: sqlite3.Connection, version_id: str | None) -> str | None:
        if not version_id:
            return None
        row = connection.execute(
            "SELECT content_json FROM prompt_bundle_versions WHERE id=?", (version_id,)
        ).fetchone()
        return str(row["content_json"]) if row else None

    @staticmethod
    def _finding(code: str, detail: str = "") -> dict[str, str]:
        item = {"code": code, "level": "error"}
        if detail:
            item["detail"] = detail[:1_000]
        return item


def _parse_profile(path: Path) -> AgentProfile:
    with path.open("rb") as handle:
        raw = tomllib.load(handle)
    if not isinstance(raw, dict):
        raise AgentProfileError("Agent Profile must be a TOML table")
    unknown = set(raw) - _PROFILE_FIELDS
    if unknown:
        raise AgentProfileError(f"Agent Profile contains unsupported field {sorted(unknown)[0]}")
    if raw.get("schema") != AGENT_PROFILE_SCHEMA:
        raise AgentProfileError("unsupported Agent Profile schema")
    profile_id = _stable(raw.get("id"), "Agent Profile id")
    version = _semver(raw.get("version"), "Agent Profile version")
    name = _text(raw.get("name"), "Agent Profile name", 200)
    description = _text(raw.get("description"), "Agent Profile description", 5_000)
    language = _text(raw.get("language", "zh-CN"), "Agent Profile language", 32)
    risk = raw.get("max_tool_risk")
    if risk not in {"read_only", "controlled_action"}:
        raise AgentProfileError("Agent Profile max_tool_risk must be read_only or controlled_action")
    host_prompt_raw = _table(raw.get("host_prompt"), _PROMPT_FIELDS, "Agent Profile host_prompt")
    prompt_version = host_prompt_raw.get("version")
    if not isinstance(prompt_version, int) or isinstance(prompt_version, bool) or prompt_version < 1:
        raise AgentProfileError("Agent Profile host_prompt version must be a positive integer")
    prompt = PromptReference(
        _stable(host_prompt_raw.get("id"), "Agent Profile host_prompt id"),
        prompt_version,
        _digest(host_prompt_raw.get("digest"), "Agent Profile host_prompt digest"),
    )
    packs_raw = raw.get("packs")
    if not isinstance(packs_raw, list) or not packs_raw:
        raise AgentProfileError("Agent Profile packs must be a non-empty array")
    packs = tuple(
        PackageReference(
            _stable(item.get("id"), "Agent Profile Pack id"),
            _semver(item.get("version"), "Agent Profile Pack version"),
            _digest(item.get("digest"), "Agent Profile Pack digest"),
        )
        for item in (_table(value, _PACK_FIELDS, "Agent Profile Pack") for value in packs_raw)
    )
    if len({item.id for item in packs}) != len(packs):
        raise AgentProfileError("Agent Profile cannot select multiple versions of one Pack")
    capabilities_raw = raw.get("capabilities", [])
    if not isinstance(capabilities_raw, list):
        raise AgentProfileError("Agent Profile capabilities must be an array")
    capabilities = tuple(
        _capability_reference(_table(value, _CAPABILITY_FIELDS, "Agent Profile capability"))
        for value in capabilities_raw
    )
    if len({item.id for item in capabilities}) != len(capabilities):
        raise AgentProfileError("Agent Profile cannot select multiple versions of one capability")
    connectors_raw = raw.get("connectors", [])
    if not isinstance(connectors_raw, list):
        raise AgentProfileError("Agent Profile connectors must be an array")
    connectors = tuple(
        _connector_reference(_table(value, _CONNECTOR_FIELDS, "Agent Profile Connector"))
        for value in connectors_raw
    )
    if len({item.id for item in connectors}) != len(connectors):
        raise AgentProfileError("Agent Profile cannot select one Connector more than once")
    manifest = {
        "schema": AGENT_PROFILE_SCHEMA,
        "id": profile_id,
        "version": version,
        "name": name,
        "description": description,
        "language": language,
        "max_tool_risk": risk,
        "host_prompt": {"id": prompt.id, "version": prompt.version, "digest": prompt.digest},
        "packs": [{"id": item.id, "version": item.version, "digest": item.digest} for item in packs],
        "capabilities": [
            {"id": item.id, "version": item.version, "role": item.role, "digest": item.digest}
            for item in capabilities
        ],
        "connectors": [
            {
                "id": item.id,
                "catalog_digest": item.catalog_digest,
                "selection": item.selection,
            }
            for item in connectors
        ],
    }
    digest = hashlib.sha256(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return AgentProfile(
        profile_id,
        version,
        name,
        description,
        language,
        str(risk),
        prompt,
        packs,
        capabilities,
        connectors,
        digest,
    )


def inspect_agent_profile_source(path: Path) -> AgentProfile:
    """Parse an Agent Profile authoring source without resolving Runtime state."""

    try:
        return _parse_profile(path.resolve())
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise AgentProfileError(str(exc)) from exc


def _capability_reference(value: dict[str, Any]) -> CapabilityReference:
    role = value.get("role")
    if role not in {"tools", "domain"}:
        raise AgentProfileError("Agent Profile capability role must be tools or domain")
    return CapabilityReference(
        _stable(value.get("id"), "Agent Profile capability id"),
        _semver(value.get("version"), "Agent Profile capability version"),
        str(role),
        _digest(value.get("digest"), "Agent Profile capability digest"),
    )


def _connector_reference(value: dict[str, Any]) -> ConnectorReference:
    selection = value.get("selection")
    if selection != "all_read_only":
        raise AgentProfileError("Agent Profile Connector selection must be all_read_only")
    return ConnectorReference(
        _stable(value.get("id"), "Agent Profile Connector id"),
        _digest(value.get("catalog_digest"), "Agent Profile Connector catalog digest"),
        str(selection),
    )


def _table(value: Any, allowed: frozenset[str], label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise AgentProfileError(f"{label} must be a TOML table")
    unknown = set(value) - allowed
    if unknown:
        raise AgentProfileError(f"{label} contains unsupported field {sorted(unknown)[0]}")
    return value


def _stable(value: Any, label: str) -> str:
    if not isinstance(value, str) or not _STABLE_ID.fullmatch(value):
        raise AgentProfileError(f"{label} must be a stable lowercase identifier")
    return value


def _semver(value: Any, label: str) -> str:
    if not isinstance(value, str) or not _SEMVER.fullmatch(value):
        raise AgentProfileError(f"{label} must be semantic version")
    return value


def _digest(value: Any, label: str) -> str:
    if not isinstance(value, str) or not _DIGEST.fullmatch(value):
        raise AgentProfileError(f"{label} must be a sha256 hex digest")
    return value


def _text(value: Any, label: str, maximum: int) -> str:
    if not isinstance(value, str) or not value.strip() or len(value.strip()) > maximum:
        raise AgentProfileError(f"{label} must be non-empty text within {maximum} characters")
    return value.strip()


__all__ = [
    "AGENT_PROFILE_SCHEMA",
    "AgentProfile",
    "AgentProfileError",
    "AgentProfileRegistry",
    "AgentProfileResolution",
    "bundled_agent_profiles_root",
    "inspect_agent_profile_source",
]
