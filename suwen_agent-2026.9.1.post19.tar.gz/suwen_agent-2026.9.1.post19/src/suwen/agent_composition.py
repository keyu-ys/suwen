"""Deterministic Agent Prompt/Skill/Tool composition.

The same surface must be used when an Agent Draft is validated and when a
published Agent Version is resolved for a Run.  Keeping this boundary outside
the Profile catalog prevents a Profile from becoming a second Runtime.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any

from .capability_packages import (
    CapabilityBinding,
    CapabilityPackageRegistry,
    LoadedCapability,
    capability_prompt_text,
    capability_skill_registry,
)
from .packs import Pack, PackRegistry
from .skills import CORE_SYSTEM_PROMPT, SkillRegistry
from .tools import ToolRegistry, tool_schema_digest


class AgentCompositionError(ValueError):
    """One exact set of Agent components cannot form a safe Runtime surface."""


@dataclass(frozen=True)
class ComposedAgentSurface:
    system_prompt: str
    skills: SkillRegistry
    tools: ToolRegistry
    loaded_packs: tuple[Pack, ...]
    loaded_capabilities: tuple[LoadedCapability, ...]
    capability_tool_owners: dict[str, str]
    digest: str


def system_prompt_from_content(content_json: str | None) -> str:
    """Return the Runtime-owned Prompt text for one immutable Prompt version."""

    if not content_json:
        return CORE_SYSTEM_PROMPT
    try:
        content = json.loads(content_json)
    except json.JSONDecodeError as exc:
        raise AgentCompositionError("Prompt Bundle content is invalid") from exc
    if not isinstance(content, dict):
        raise AgentCompositionError("Prompt Bundle content must be an object")
    sections: list[str] = []
    for key in ("system_prompt", "soul", "rules", "output_rules"):
        value = content.get(key)
        if isinstance(value, str) and value.strip():
            sections.append(value.strip())
        elif isinstance(value, list):
            sections.extend(str(item).strip() for item in value if str(item).strip())
    return "\n\n".join(sections) if sections else CORE_SYSTEM_PROMPT


def compose_agent_surface(
    *,
    packs: PackRegistry,
    runtime_tools: ToolRegistry,
    capability_packages: CapabilityPackageRegistry | None,
    pack_refs: list[dict[str, Any]],
    capability_bindings: list[CapabilityBinding],
    prompt_content_json: str | None,
) -> ComposedAgentSurface:
    """Build the exact native composition before policy filtering.

    This function covers the Prompt/Pack/native-capability surface that Profile
    readiness, publish validation, and Runtime resolution must agree on.
    """

    try:
        loaded_packs = tuple(packs.resolve_refs(pack_refs))
        selected_skills = packs.skills_for(pack_refs)
        selected_tools = packs.tools_for(pack_refs, runtime_tools)
    except (KeyError, ValueError) as exc:
        raise AgentCompositionError(str(exc)) from exc

    if capability_bindings and capability_packages is None:
        raise AgentCompositionError("first-party capability package runtime is unavailable")
    try:
        loaded_capabilities = (
            capability_packages.load_bindings(capability_bindings)
            if capability_bindings and capability_packages is not None
            else ()
        )
    except (KeyError, RuntimeError, ValueError) as exc:
        raise AgentCompositionError(str(exc)) from exc

    capability_tool_owners: dict[str, str] = {}
    for capability in loaded_capabilities:
        if capability.manifest.kind != "tools":
            continue
        names = {item.name for item in capability.tools.definitions()}
        conflict = sorted(names.intersection(selected_tools.names()))
        if conflict:
            raise AgentCompositionError(
                "first-party capability Tool conflicts with selected Pack/Runtime Tool: " + conflict[0]
            )
        try:
            selected_tools.merge_from(capability.tools)
        except ValueError as exc:
            raise AgentCompositionError(str(exc)) from exc
        capability_tool_owners.update({name: capability.version_id for name in names})

    system_prompt = system_prompt_from_content(prompt_content_json)
    try:
        domain_skills = capability_skill_registry(loaded_capabilities)
        domain_skill_items = domain_skills.list()
        existing_skills = selected_skills.list()
        existing_ids = {skill.id for skill in existing_skills}
        existing_names = {skill.name for skill in existing_skills}
        for domain_skill in domain_skill_items:
            if domain_skill.id in existing_ids or domain_skill.name in existing_names:
                raise AgentCompositionError("native domain Skill conflicts with selected Pack Skill")
        # A native domain package owns the fallback for its own Agent surface.
        # Keeping the host's generic fallback alongside it lets the model choose
        # generic guidance for an otherwise clearly in-domain question.  Retain
        # non-fallback host Skills, but replace host fallbacks when the selected
        # native domain supplies its required fallback.
        if any(skill.fallback for skill in domain_skill_items):
            existing_skills = [skill for skill in existing_skills if not skill.fallback]
        domain_prompt = capability_prompt_text(loaded_capabilities)
        if domain_prompt:
            system_prompt = "\n\n".join(
                section for section in (system_prompt.strip(), domain_prompt) if section
            )
        selected_skills = SkillRegistry([*domain_skill_items, *existing_skills])
    except (ValueError, AgentCompositionError) as exc:
        if isinstance(exc, AgentCompositionError):
            raise
        raise AgentCompositionError(str(exc)) from exc

    # Reference handlers must be bound to this selected, frozen Skill catalog;
    # the global process catalog may contain unrelated Pack/legacy Skills.
    selected_reference_tools = ToolRegistry()
    selected_skills.register_reference_tools(selected_reference_tools)
    try:
        selected_tools.merge_from(selected_reference_tools, replace=True)
    except ValueError as exc:
        raise AgentCompositionError(str(exc)) from exc

    digest_payload = {
        "system_prompt_digest": hashlib.sha256(system_prompt.encode("utf-8")).hexdigest(),
        "tool_schema_digest": tool_schema_digest(selected_tools),
        "skills": selected_skills.delivery_manifest(),
        "packs": [{"id": pack.id, "version": pack.version, "digest": pack.digest} for pack in loaded_packs],
        "capabilities": [
            {
                "version_id": capability.version_id,
                "id": capability.manifest.id,
                "kind": capability.manifest.kind,
                "version": capability.manifest.version,
                "digest": capability.content_digest,
            }
            for capability in loaded_capabilities
        ],
    }
    digest = hashlib.sha256(
        json.dumps(digest_payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return ComposedAgentSurface(
        system_prompt=system_prompt,
        skills=selected_skills,
        tools=selected_tools,
        loaded_packs=loaded_packs,
        loaded_capabilities=loaded_capabilities,
        capability_tool_owners=capability_tool_owners,
        digest=digest,
    )
