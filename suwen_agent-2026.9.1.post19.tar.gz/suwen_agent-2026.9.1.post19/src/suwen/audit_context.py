from __future__ import annotations

import json
import re
import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Any

_REQUEST_ID: ContextVar[str | None] = ContextVar("suwen_request_id", default=None)
_AUTHORIZATION_SOURCE: ContextVar[str | None] = ContextVar(
    "suwen_authorization_source",
    default=None,
)
_SAFE_REQUEST_ID = re.compile(
    r"^(?:req_[0-9a-fA-F]{32}|[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$"
)


def request_id_from_header(value: str | None) -> str:
    """Accept a UUID-shaped correlation ID or replace it with a local one."""
    candidate = (value or "").strip()
    if candidate and _SAFE_REQUEST_ID.fullmatch(candidate):
        return candidate
    return f"req_{uuid.uuid4().hex}"


@contextmanager
def bind_audit_context(request_id: str, authorization_source: str) -> Iterator[None]:
    request_token = _REQUEST_ID.set(request_id)
    authorization_token = _AUTHORIZATION_SOURCE.set(authorization_source)
    try:
        yield
    finally:
        _AUTHORIZATION_SOURCE.reset(authorization_token)
        _REQUEST_ID.reset(request_token)


def current_request_id() -> str | None:
    return _REQUEST_ID.get()


def authorization_source(actor_type: str, actor_ref: str) -> str:
    current = _AUTHORIZATION_SOURCE.get()
    if current:
        return current
    if actor_type == "system":
        return "system_internal"
    if actor_ref.startswith("cli:"):
        return "local_cli"
    if actor_ref.endswith(":local"):
        return "local_management_without_token"
    if actor_type == "admin":
        return "management_actor"
    if actor_type == "api":
        return "runtime_api"
    if actor_type == "channel":
        return "channel_adapter"
    return f"{actor_type}_internal"


def failure_class(result: str, metadata_json: str | None) -> str | None:
    if result == "succeeded":
        return None
    metadata: dict[str, Any] = {}
    try:
        decoded = json.loads(metadata_json or "{}")
        if isinstance(decoded, dict):
            metadata = decoded
    except (TypeError, ValueError, json.JSONDecodeError):
        pass
    for key in ("failure_class", "error_class", "code", "reason"):
        value = metadata.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()[:120]
    return result[:120]
