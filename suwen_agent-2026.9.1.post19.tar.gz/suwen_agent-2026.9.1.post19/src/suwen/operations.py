from __future__ import annotations

import hashlib
import json
import re
import uuid
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from .db import Database
from .health_protocol import (
    HEALTH_CONTRACT_VERSION,
    HEALTH_SERVICE_ID,
    has_suwen_health_identity,
)
from .management_acceptance import (
    MANAGEMENT_E2E_REQUIRED_CHECKS,
    validate_management_e2e_artifact,
)
from .personas import normalize_persona_snapshot
from .privacy import sanitize_provider_payload
from .repository import iso
from .security import redact_sensitive

_BACKUP_NAME = re.compile(r"^suwen-(\d{8}T\d{6}Z)-([0-9a-f]{8})\.db$")
_MIN_STABILITY_INTERVAL_SECONDS = 5.0

# Read-only compatibility for immutable Runs created before semantic second
# judges were retired. These names only render historical trace rows; the
# current Runtime never creates or executes either check.
_INTERNAL_MODEL_ROUND_KINDS = {
    "suwen_goal_completion": "goal_completion_check",
    "suwen_answer_consistency": "answer_consistency_check",
}


def _duration_ms(started_at: str | None, finished_at: str | None) -> int | None:
    if not started_at or not finished_at:
        return None
    try:
        started = datetime.fromisoformat(started_at.replace("Z", "+00:00"))
        finished = datetime.fromisoformat(finished_at.replace("Z", "+00:00"))
    except ValueError:
        return None
    return max(0, round((finished - started).total_seconds() * 1000))


def _usage_tokens(raw: str | None) -> tuple[int, int, int]:
    """Normalize common provider usage shapes for the management summary."""

    try:
        usage = json.loads(raw or "null")
    except json.JSONDecodeError:
        usage = None
    if not isinstance(usage, dict):
        return 0, 0, 0

    def token_value(*keys: str) -> int:
        for key in keys:
            value = usage.get(key)
            if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
                return value
        return 0

    input_tokens = token_value("input_tokens", "prompt_tokens")
    output_tokens = token_value("output_tokens", "completion_tokens")
    total_tokens = token_value("total_tokens") or input_tokens + output_tokens
    return input_tokens, output_tokens, total_tokens


def _model_round_response_format_name(turn: dict[str, Any]) -> str | None:
    request = turn.get("request")
    response_format = request.get("response_format") if isinstance(request, dict) else None
    json_schema = (
        response_format.get("json_schema")
        if isinstance(response_format, dict)
        else None
    )
    name = json_schema.get("name") if isinstance(json_schema, dict) else None
    return name if isinstance(name, str) and name else None


def _model_round_recovery_policy(turn: dict[str, Any]) -> str | None:
    request = turn.get("request")
    context_management = (
        request.get("context_management") if isinstance(request, dict) else None
    )
    value = (
        context_management.get("recovery_policy")
        if isinstance(context_management, dict)
        else None
    )
    return value if isinstance(value, str) and value else None


def _internal_model_round_summary(kind: str, response_text: str | None) -> str:
    try:
        decision = json.loads(response_text or "null")
    except (TypeError, ValueError, json.JSONDecodeError):
        decision = None
    if not isinstance(decision, dict):
        return "内部检查已执行；结构化原文保留在技术记录中。"
    if kind == "goal_completion_check":
        if decision.get("ready") is True:
            return "已确认候选答复覆盖了用户明确要求的交付项。"
        unresolved = decision.get("unresolved_requirements")
        viable = decision.get("viable_tools")
        unresolved_count = len(unresolved) if isinstance(unresolved, list) else 0
        if isinstance(viable, list) and viable:
            return (
                f"发现 {unresolved_count or 1} 项交付缺口，运行将只补充能改变结论的最小证据。"
            )
        return "目标检查发现答复仍有未完成项；运行将按现有证据边界收口。"
    if decision.get("ready") is True:
        return "候选答复已通过证据一致性检查。"
    if isinstance(decision.get("repaired_reply"), str) and decision["repaired_reply"].strip():
        return "候选答复存在证据边界问题，系统已改用修正版对外答复。"
    return "候选答复未通过证据一致性检查，系统已按安全边界处理。"


def _model_round_presentation(
    turn: dict[str, Any],
    *,
    response_text: str | None,
    executions: list[dict[str, Any]],
    reply_content: str | None,
) -> dict[str, Any]:
    format_name = _model_round_response_format_name(turn)
    recovery_policy = _model_round_recovery_policy(turn)
    internal_kind = _INTERNAL_MODEL_ROUND_KINDS.get(format_name or "")
    if internal_kind is None:
        internal_kind = {
            "goal_completion_check": "goal_completion_check",
            "answer_basis_terminal_acceptance": "answer_consistency_check",
        }.get(recovery_policy or "")
    if internal_kind:
        return {
            "kind": "internal_check",
            "title": (
                "目标完成检查"
                if internal_kind == "goal_completion_check"
                else "答复证据校验"
            ),
            "summary": _internal_model_round_summary(internal_kind, response_text),
            "summary_source": "model_check_projection",
            "technical_only": True,
            "internal_kind": internal_kind,
        }

    normalized_text = response_text.strip() if isinstance(response_text, str) else ""
    if executions:
        readable_progress = (
            normalized_text
            and len(normalized_text) <= 600
            and not normalized_text.lstrip().startswith(("{", "["))
        )
        if readable_progress:
            summary = normalized_text
            source = "model"
        else:
            count = len(executions)
            summary = (
                f"本轮已发起 {count} 项只读检查；"
                + (
                    "模型正文不符合简短阶段说明要求，已从主阅读流收起。"
                    if normalized_text
                    else "该历史模型回合没有留存阶段说明。"
                )
                + "可从折叠步骤查看检查对象。"
            )
            source = "runtime_projection"
        return {
            "kind": "investigation",
            "title": f"调查阶段 {turn['turn_index']}",
            "summary": summary,
            "summary_source": source,
            "technical_only": False,
        }

    if turn.get("finish_reason") == "length" and not normalized_text:
        return {
            "kind": "recovery",
            "title": "答复生成未完成",
            "summary": "本轮达到输出长度上限且没有形成可读答复；运行随后进入有界收敛。",
            "summary_source": "runtime_projection",
            "technical_only": False,
        }

    normalized_reply = reply_content.strip() if isinstance(reply_content, str) else ""
    if normalized_text and normalized_reply and normalized_text == normalized_reply:
        return {
            "kind": "public_answer",
            "title": "对外答复",
            "summary": normalized_text,
            "summary_source": "model",
            "technical_only": False,
        }
    if normalized_text and normalized_reply:
        return {
            "kind": "candidate_answer",
            "title": "候选答复",
            "summary": (
                "模型生成了一版候选答复，随后经过准出检查；实际送达内容以“对外答复”为准。"
            ),
            "summary_source": "runtime_projection",
            "technical_only": False,
        }
    if normalized_text:
        return {
            "kind": "model_response",
            "title": "模型答复",
            "summary": normalized_text[:1_000],
            "summary_source": "model",
            "technical_only": False,
        }
    return {
        "kind": "model_event",
        "title": f"模型回合 {turn['turn_index']}",
        "summary": "本回合没有形成可读文本，也没有发起新的检查。",
        "summary_source": "runtime_projection",
        "technical_only": False,
    }


def _management_model_rounds(
    model_turns: list[dict[str, Any]],
    tool_calls: list[dict[str, Any]],
    evidence: list[dict[str, Any]],
    *,
    model: dict[str, Any],
    reply_content: str | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Project persisted model turns into the management conversation view.

    Tool executions are associated only through the provider call ID recorded
    in both the normalized model response and the Tool Call.  Timestamps never
    create a relationship; ambiguous or missing references remain explicit.
    """

    evidence_counts: dict[str, int] = {}
    for item in evidence:
        tool_call_id = item.get("tool_call_id")
        if isinstance(tool_call_id, str) and tool_call_id:
            evidence_counts[tool_call_id] = evidence_counts.get(tool_call_id, 0) + 1

    calls_by_provider_id: dict[str, list[dict[str, Any]]] = {}
    for call in tool_calls:
        provider_call_id = call.get("provider_call_id")
        if isinstance(provider_call_id, str) and provider_call_id:
            calls_by_provider_id.setdefault(provider_call_id, []).append(call)

    requests_by_turn: dict[str, list[dict[str, Any]]] = {}
    request_references: dict[str, list[tuple[str, int]]] = {}
    for turn in model_turns:
        response = turn.get("response")
        raw_requests = response.get("tool_requests") if isinstance(response, dict) else None
        requests = (
            [item for item in raw_requests if isinstance(item, dict)]
            if isinstance(raw_requests, list)
            else []
        )
        requests_by_turn[turn["id"]] = requests
        for request_index, request in enumerate(requests):
            provider_call_id = request.get("call_id")
            if isinstance(provider_call_id, str) and provider_call_id:
                request_references.setdefault(provider_call_id, []).append(
                    (turn["id"], request_index)
                )

    linked_tool_call_ids: set[str] = set()
    rounds: list[dict[str, Any]] = []
    for turn in model_turns:
        executions: list[dict[str, Any]] = []
        for request_index, request in enumerate(requests_by_turn[turn["id"]]):
            provider_call_id = request.get("call_id")
            request_name = request.get("name")
            candidates = (
                calls_by_provider_id.get(provider_call_id, [])
                if isinstance(provider_call_id, str) and provider_call_id
                else []
            )
            references = (
                request_references.get(provider_call_id, [])
                if isinstance(provider_call_id, str) and provider_call_id
                else []
            )
            call: dict[str, Any] | None = None
            if not isinstance(provider_call_id, str) or not provider_call_id:
                association_state = "missing_provider_call_id"
                execution_status = "not_recorded"
            elif len(references) != 1 or len(candidates) > 1:
                association_state = "ambiguous_model_round_reference"
                execution_status = "not_observable"
            elif not candidates:
                association_state = "missing_tool_call_record"
                execution_status = "not_recorded"
            else:
                call = candidates[0]
                association_state = "matched_provider_call_id"
                execution_status = str(call["status"])
                linked_tool_call_ids.add(str(call["id"]))
            tool_call_id = str(call["id"]) if call else None
            executions.append(
                {
                    "id": f"execution:{turn['id']}:{request_index}",
                    "tool_call_id": tool_call_id,
                    "provider_call_id": provider_call_id,
                    "tool_name": (
                        str(call["tool_name"])
                        if call
                        else str(request_name or "未记录工具")
                    ),
                    "status": execution_status,
                    "evidence_count": evidence_counts.get(tool_call_id, 0) if tool_call_id else 0,
                    "association_state": association_state,
                }
            )

        response = turn.get("response")
        response_text = response.get("content") if isinstance(response, dict) else None
        if not isinstance(response_text, str):
            response_text = None
        association_states = {item["association_state"] for item in executions}
        execution_association = (
            "not_applicable"
            if not executions
            else "complete"
            if association_states == {"matched_provider_call_id"}
            else "partial"
            if "matched_provider_call_id" in association_states
            else "not_observable"
        )
        rounds.append(
            {
                "id": turn["id"],
                "turn_index": turn["turn_index"],
                "status": turn["status"],
                "finish_reason": turn["finish_reason"],
                "started_at": turn["started_at"],
                "finished_at": turn["finished_at"],
                "duration_ms": _duration_ms(turn["started_at"], turn["finished_at"]),
                "model": model,
                "request_chars": turn["request_chars"],
                "response_chars": turn["response_chars"],
                "tool_request_count": turn["tool_request_count"],
                "usage_state": turn["usage_state"],
                "usage": turn["usage"],
                "failure_class": turn["failure_class"],
                "response_text": response_text,
                "presentation": _model_round_presentation(
                    turn,
                    response_text=response_text,
                    executions=executions,
                    reply_content=reply_content,
                ),
                "observability": {
                    "request_state": "recorded" if turn.get("request") is not None else "not_recorded",
                    "response_state": "recorded" if response is not None else "not_recorded",
                    "execution_association": execution_association,
                },
                "execution_group": {
                    "id": f"executions:{turn['id']}",
                    "items": executions,
                    "evidence_count": sum(item["evidence_count"] for item in executions),
                },
            }
        )

    unlinked: list[dict[str, Any]] = []
    for call in tool_calls:
        tool_call_id = str(call["id"])
        if tool_call_id in linked_tool_call_ids:
            continue
        provider_call_id = call.get("provider_call_id")
        references = (
            request_references.get(provider_call_id, [])
            if isinstance(provider_call_id, str) and provider_call_id
            else []
        )
        candidates = (
            calls_by_provider_id.get(provider_call_id, [])
            if isinstance(provider_call_id, str) and provider_call_id
            else []
        )
        association_state = (
            "missing_provider_call_id"
            if not isinstance(provider_call_id, str) or not provider_call_id
            else "model_round_reference_not_recorded"
            if not references
            else "ambiguous_model_round_reference"
            if len(references) > 1
            else "ambiguous_tool_call_record"
            if len(candidates) > 1
            else "not_observable"
        )
        unlinked.append(
            {
                "id": f"execution:unlinked:{tool_call_id}",
                "tool_call_id": tool_call_id,
                "provider_call_id": provider_call_id,
                "tool_name": call["tool_name"],
                "status": call["status"],
                "evidence_count": evidence_counts.get(tool_call_id, 0),
                "association_state": association_state,
            }
        )
    return rounds, unlinked


class OperationsView:
    """Management operating views plus bounded, non-overwriting local backups."""

    def __init__(self, database: Database, data_dir: str | Path):
        self.database = database
        self.data_dir = Path(data_dir)
        self.backup_dir = self.data_dir / "backups"

    def list_backups(self) -> dict[str, Any]:
        items: list[dict[str, Any]] = []
        evidence = self._recorded_backup_evidence()
        if self.backup_dir.is_dir():
            for path in self.backup_dir.iterdir():
                if path.is_symlink() or not path.is_file() or not _BACKUP_NAME.fullmatch(path.name):
                    continue
                items.append(
                    self._backup_view(
                        path,
                        recorded=evidence.get(path.name),
                    )
                )
        items.sort(key=lambda item: (item["created_at"], item["id"]), reverse=True)
        return {
            "items": items[:50],
            "count": len(items),
            "automatic_backup_configured": False,
            "arbitrary_destination_allowed": False,
        }

    def create_backup(self, actor: str) -> dict[str, Any]:
        now = datetime.now(UTC)
        backup_id = f"suwen-{now.strftime('%Y%m%dT%H%M%SZ')}-{uuid.uuid4().hex[:8]}.db"
        target = self.backup_dir / backup_id
        try:
            created = self.database.backup(target)
            item = self._backup_view(created, verify=True)
            if not item["restorable"]:
                raise RuntimeError("backup verification failed")
        except BaseException as exc:
            self._audit_backup(actor, backup_id, "failed", {"failure_class": type(exc).__name__})
            raise
        self._audit_backup(
            actor,
            backup_id,
            "succeeded",
            {
                "bytes": item["bytes"],
                "sha256": item["sha256"],
                "overwritten": False,
                "verification": item["verification"],
            },
        )
        return item

    def verify_backup_file(self, path: str | Path) -> dict[str, Any]:
        """Verify a caller-selected local backup without registering it as managed."""

        target = Path(path)
        if target.is_symlink() or not target.is_file():
            raise ValueError("backup verification requires a regular file")
        return self._backup_view(target, verify=True)

    @staticmethod
    def _sha256_file(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    def _backup_view(
        self,
        path: Path,
        *,
        verify: bool = False,
        recorded: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        stat = path.stat()
        file_digest = self._sha256_file(path)
        verification = recorded.get("verification") if recorded else None
        digest_matches_record = bool(
            verify
            or (recorded and recorded.get("sha256") == file_digest and recorded.get("bytes") == stat.st_size)
        )
        if verify:
            try:
                report = Database(path).check()
            except BaseException as exc:
                verification = {
                    "schema_version": None,
                    "quick_check": "failed",
                    "foreign_key_violations": None,
                    "ready": False,
                    "failure_class": type(exc).__name__,
                }
            else:
                verification = {
                    "schema_version": report["schema_version"],
                    "quick_check": report["quick_check"],
                    "foreign_key_violations": report["foreign_key_violations"],
                    "ready": report["ready"],
                    "failure_class": "DatabaseCheckError" if report.get("error") else None,
                }
        if verification is None:
            verification = {
                "schema_version": None,
                "quick_check": "not_run",
                "foreign_key_violations": None,
                "ready": False,
                "failure_class": None,
            }
        elif not digest_matches_record:
            verification = {
                **verification,
                "ready": False,
                "failure_class": "BackupDigestMismatch",
            }
        return {
            "id": path.name,
            "created_at": datetime.fromtimestamp(stat.st_mtime, UTC).isoformat(),
            "bytes": stat.st_size,
            "sha256": file_digest,
            "mode": oct(stat.st_mode & 0o777),
            "restorable": bool(verification["ready"] and digest_matches_record),
            "verification": verification,
            "digest_matches_record": digest_matches_record,
            "secret_values_included": False,
        }

    def _recorded_backup_evidence(self) -> dict[str, dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                """SELECT target_id, result, metadata_json
                   FROM audit_events
                   WHERE action='system.backup_created'
                     AND target_type='database_backup'
                   ORDER BY created_at DESC, id DESC"""
            ).fetchall()
        result: dict[str, dict[str, Any]] = {}
        for row in rows:
            if row["target_id"] in result:
                continue
            metadata = json.loads(row["metadata_json"] or "{}")
            verification = metadata.get("verification")
            if (
                row["result"] == "succeeded"
                and isinstance(verification, dict)
                and isinstance(verification.get("ready"), bool)
                and isinstance(metadata.get("sha256"), str)
                and isinstance(metadata.get("bytes"), int)
            ):
                result[row["target_id"]] = {
                    "verification": verification,
                    "sha256": metadata["sha256"],
                    "bytes": metadata["bytes"],
                }
        return result

    def _audit_backup(
        self,
        actor: str,
        backup_id: str,
        result: str,
        metadata: dict[str, Any],
    ) -> None:
        with self.database.connect() as connection:
            connection.execute(
                """INSERT INTO audit_events(
                   actor_type, actor_ref, action, target_type, target_id,
                   result, metadata_json, created_at
                ) VALUES ('admin', ?, 'system.backup_created', 'database_backup',
                          ?, ?, ?, ?)""",
                (actor, backup_id, result, json.dumps(metadata, sort_keys=True), iso()),
            )

    def runtime_target(self, agent_id: str) -> dict[str, Any]:
        """Return the redacted exact runtime revision selected for one Agent."""

        with self.database.connect() as connection:
            agent = connection.execute(
                """SELECT a.id, a.status, a.active_version_id,
                          binding.model_profile_id,
                          binding.revision AS model_binding_revision,
                          mpv.id AS model_profile_version_id,
                          mpv.provider_version_id,
                          av.prompt_bundle_version_id,
                          pbv.digest AS prompt_bundle_digest,
                          av.tool_schema_digest,
                          av.digest AS agent_version_digest
                   FROM agents a
                   LEFT JOIN agent_versions av ON av.id=a.active_version_id
                   LEFT JOIN agent_model_bindings binding ON binding.agent_id=a.id
                   LEFT JOIN model_profile_versions mpv
                     ON mpv.id=(
                          SELECT current_model.id
                            FROM model_profile_versions current_model
                           WHERE current_model.model_profile_id=binding.model_profile_id
                           ORDER BY current_model.version DESC LIMIT 1
                        )
                   LEFT JOIN prompt_bundle_versions pbv
                     ON pbv.id=av.prompt_bundle_version_id
                   WHERE a.id=?""",
                (agent_id,),
            ).fetchone()
            pack_rows = (
                connection.execute(
                    """SELECT cp.id, cpv.version, cpv.digest
                       FROM agent_version_packs avp
                       JOIN capability_pack_versions cpv ON cpv.id=avp.pack_version_id
                       JOIN capability_packs cp ON cp.id=cpv.pack_id
                       WHERE avp.agent_version_id=? AND avp.enabled=1
                       ORDER BY avp.position, cp.id, cpv.version""",
                    (agent["active_version_id"],),
                ).fetchall()
                if agent and agent["active_version_id"]
                else []
            )
        if not agent:
            raise KeyError(agent_id)
        target = {
            "agent_id": agent_id,
            "agent_status": agent["status"],
            "agent_version_id": agent["active_version_id"],
            "agent_version_digest": agent["agent_version_digest"],
            "model_profile_id": agent["model_profile_id"],
            "model_binding_revision": agent["model_binding_revision"],
            "model_profile_version_id": agent["model_profile_version_id"],
            "provider_version_id": agent["provider_version_id"],
            "prompt_bundle_version_id": agent["prompt_bundle_version_id"],
            "prompt_bundle_digest": agent["prompt_bundle_digest"],
            "tool_schema_digest": agent["tool_schema_digest"],
            "pack_refs": [f"{row['id']}@{row['version']}" for row in pack_rows],
            "pack_digests": [row["digest"] for row in pack_rows],
        }
        target["runtime_revision_digest"] = hashlib.sha256(
            json.dumps(target, ensure_ascii=False, sort_keys=True).encode()
        ).hexdigest()
        return target

    def default_runtime_target(self) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT value_json FROM system_settings WHERE key='default_agent_id'"
            ).fetchone()
        if not row:
            raise RuntimeError("default Agent is not configured")
        return self.runtime_target(json.loads(row["value_json"]))

    def stability_target(self, agent_id: str) -> dict[str, Any]:
        """Resolve the exact published/default target before spending observation time."""

        target = self.runtime_target(agent_id)
        with self.database.connect() as connection:
            settings = {
                row["key"]: json.loads(row["value_json"])
                for row in connection.execute(
                    """SELECT key, value_json FROM system_settings
                       WHERE key='default_agent_id'"""
                ).fetchall()
            }
        if target["agent_status"] != "published" or not target["agent_version_id"]:
            raise ValueError("stability observation requires a published Agent")
        if settings.get("default_agent_id") != agent_id:
            raise ValueError("stability observation target must be the default Agent")
        if not target["tool_schema_digest"]:
            raise ValueError("stability observation requires a frozen tool schema")
        return target

    @staticmethod
    def validate_stability_sample(sample: object, target: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(sample, dict):
            raise ValueError("stability sample must be an object")
        observed_at = sample.get("observed_at")
        health = sample.get("health")
        if not isinstance(observed_at, str) or not isinstance(health, dict):
            raise ValueError("stability sample requires observed_at and health")
        if not has_suwen_health_identity(health):
            raise ValueError("stability sample service identity does not match Suwen")
        try:
            parsed_at = datetime.fromisoformat(observed_at).astimezone(UTC)
        except (TypeError, ValueError) as exc:
            raise ValueError("stability sample observed_at is invalid") from exc
        if (
            health.get("status") != "ready"
            or health.get("database") != "ready"
            or health.get("scheduler") != "running"
        ):
            raise ValueError("stability sample requires ready service, database, and scheduler")
        process_instance_id = health.get("process_instance_id")
        process_started_at = health.get("process_started_at")
        if not isinstance(process_instance_id, str) or not process_instance_id:
            raise ValueError("stability sample requires process_instance_id")
        if not isinstance(process_started_at, str) or not process_started_at:
            raise ValueError("stability sample requires process_started_at")
        try:
            parsed_started_at = datetime.fromisoformat(process_started_at).astimezone(UTC)
        except (TypeError, ValueError) as exc:
            raise ValueError("stability sample process_started_at is invalid") from exc
        if parsed_started_at > parsed_at:
            raise ValueError("stability sample cannot predate the process start")
        default_model = health.get("default_model")
        if not isinstance(default_model, dict):
            raise ValueError("stability sample requires default_model")
        if default_model.get("profile_version_id") != target["model_profile_version_id"]:
            raise ValueError("stability sample model version does not match the target Agent")
        if (
            default_model.get("configured") is not True
            or default_model.get("probe_readiness") != "ready"
            or default_model.get("tool_calling_observed") is not True
        ):
            raise ValueError("stability sample requires configured and probed tool-capable model")
        default_agent = health.get("default_agent")
        if not isinstance(default_agent, dict):
            raise ValueError("stability sample requires default_agent runtime revision")
        expected_runtime = {
            key: target[key]
            for key in (
                "agent_id",
                "agent_status",
                "agent_version_id",
                "agent_version_digest",
                "model_profile_id",
                "model_binding_revision",
                "model_profile_version_id",
                "provider_version_id",
                "prompt_bundle_version_id",
                "prompt_bundle_digest",
                "tool_schema_digest",
                "pack_refs",
                "pack_digests",
                "runtime_revision_digest",
            )
        }
        if default_agent != expected_runtime:
            raise ValueError("stability sample Agent runtime revision does not match local target")
        raw_packs = health.get("packs")
        if not isinstance(raw_packs, list):
            raise ValueError("stability sample requires loaded pack versions")
        loaded_pack_refs = {
            f"{item.get('id')}@{item.get('version')}"
            for item in raw_packs
            if isinstance(item, dict)
            and isinstance(item.get("id"), str)
            and isinstance(item.get("version"), str)
        }
        if not set(target["pack_refs"]).issubset(loaded_pack_refs):
            raise ValueError("stability sample does not contain all target Agent packs")
        projection = {
            "service_id": HEALTH_SERVICE_ID,
            "contract_version": HEALTH_CONTRACT_VERSION,
            "status": health["status"],
            "database": health["database"],
            "scheduler": health["scheduler"],
            "sender": health.get("sender"),
            "process_instance_id": process_instance_id,
            "process_started_at": process_started_at,
            "default_model": {
                "profile_version_id": default_model["profile_version_id"],
                "configured": default_model["configured"],
                "probe_readiness": default_model["probe_readiness"],
                "tool_calling_observed": default_model["tool_calling_observed"],
            },
            "default_agent": default_agent,
            "pack_refs": sorted(loaded_pack_refs),
        }
        digest = hashlib.sha256(
            json.dumps(projection, ensure_ascii=False, sort_keys=True).encode()
        ).hexdigest()
        return {
            "observed_at": parsed_at,
            "process_instance_id": process_instance_id,
            "process_started_at": process_started_at,
            "health_digest": digest,
        }

    def record_stability_observation(
        self,
        actor: str,
        agent_id: str,
        samples: list[dict[str, Any]],
    ) -> dict[str, Any]:
        target = self.stability_target(agent_id)
        if len(samples) != 2:
            raise ValueError("stability observation requires exactly two samples")
        validated = [self.validate_stability_sample(sample, target) for sample in samples]
        interval_seconds = (validated[1]["observed_at"] - validated[0]["observed_at"]).total_seconds()
        if interval_seconds < _MIN_STABILITY_INTERVAL_SECONDS:
            raise ValueError("stability observation interval must be at least 5 seconds")
        if interval_seconds > 3600:
            raise ValueError("stability observation interval must not exceed 3600 seconds")
        if validated[0]["process_instance_id"] != validated[1]["process_instance_id"]:
            raise ValueError("stability observation samples must come from one process instance")
        if validated[0]["process_started_at"] != validated[1]["process_started_at"]:
            raise ValueError("stability observation process start time changed between samples")
        metadata = {
            **target,
            "process_instance_id": validated[0]["process_instance_id"],
            "process_started_at": validated[0]["process_started_at"],
            "sample_observed_at": [iso(item["observed_at"]) for item in validated],
            "health_digests": [item["health_digest"] for item in validated],
            "interval_seconds": interval_seconds,
            "sample_count": 2,
            "minimum_interval_seconds": _MIN_STABILITY_INTERVAL_SECONDS,
            "secret_values_included": False,
        }
        evidence_digest = hashlib.sha256(
            json.dumps(metadata, ensure_ascii=False, sort_keys=True).encode()
        ).hexdigest()
        with self.database.connect() as connection:
            cursor = connection.execute(
                """INSERT INTO audit_events(
                   actor_type, actor_ref, action, target_type, target_id,
                   target_version, after_digest, result, metadata_json, created_at
                ) VALUES ('operator', ?, 'delivery.stability_observed',
                          'delivery_observation', ?, ?, ?, 'passed', ?, ?)""",
                (
                    actor,
                    agent_id,
                    target["agent_version_id"],
                    evidence_digest,
                    json.dumps(metadata, ensure_ascii=False, sort_keys=True),
                    iso(),
                ),
            )
            event_id = int(cursor.lastrowid)
        return {
            "id": event_id,
            "status": "passed",
            "evidence_digest": evidence_digest,
            **metadata,
        }

    def stability_observation(
        self,
        agent_id: str,
        process_instance_id: str | None,
    ) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT id, target_version, after_digest, metadata_json, created_at
                   FROM audit_events
                   WHERE action='delivery.stability_observed'
                     AND target_type='delivery_observation'
                     AND target_id=?
                     AND result='passed'
                   ORDER BY id DESC LIMIT 1""",
                (agent_id,),
            ).fetchone()
        if not row:
            return {"status": "not_run", "passed": False, "evidence": {"sample_count": 0}}
        metadata = json.loads(row["metadata_json"] or "{}")
        try:
            target = self.stability_target(agent_id)
        except (KeyError, ValueError):
            target = None
        revision_matches = bool(
            target
            and metadata.get("agent_id") == agent_id
            and metadata.get("agent_version_id") == target["agent_version_id"]
            and metadata.get("runtime_revision_digest") == target["runtime_revision_digest"]
        )
        process_matches = bool(
            process_instance_id and metadata.get("process_instance_id") == process_instance_id
        )
        passed = revision_matches and process_matches
        return {
            "status": "passed" if passed else "stale" if process_instance_id else "not_observed",
            "passed": passed,
            "evidence": {
                "event_id": row["id"],
                "agent_version_id": metadata.get("agent_version_id"),
                "model_profile_version_id": metadata.get("model_profile_version_id"),
                "runtime_revision_digest": metadata.get("runtime_revision_digest"),
                "sample_count": metadata.get("sample_count", 0),
                "interval_seconds": metadata.get("interval_seconds"),
                "same_process_instance": process_matches,
                "revision_matches": revision_matches,
                "observed_at": metadata.get("sample_observed_at", []),
                "evidence_digest": row["after_digest"],
                "secret_values_included": False,
            },
        }

    def record_management_e2e_observation(
        self,
        actor: str,
        agent_id: str,
        process_instance_id: str,
        process_started_at: str,
        asset_digest: str,
        artifact: object,
    ) -> dict[str, Any]:
        target = self.runtime_target(agent_id)
        if target["agent_status"] != "published" or not target["agent_version_id"]:
            raise ValueError("management E2E observation requires a published Agent")
        validated = validate_management_e2e_artifact(
            artifact,
            agent_id=agent_id,
            process_instance_id=process_instance_id,
            process_started_at=process_started_at,
            asset_digest=asset_digest,
        )
        metadata = {
            **validated,
            "agent_version_id": target["agent_version_id"],
            "runtime_revision_digest": target["runtime_revision_digest"],
        }
        evidence_digest = hashlib.sha256(
            json.dumps(metadata, ensure_ascii=False, sort_keys=True).encode()
        ).hexdigest()
        with self.database.connect() as connection:
            cursor = connection.execute(
                """INSERT INTO audit_events(
                   actor_type, actor_ref, action, target_type, target_id,
                   target_version, after_digest, result, metadata_json, created_at
                ) VALUES ('admin', ?, 'delivery.management_e2e_observed',
                          'delivery_observation', ?, ?, ?, 'passed', ?, ?)""",
                (
                    actor,
                    agent_id,
                    target["agent_version_id"],
                    evidence_digest,
                    json.dumps(metadata, ensure_ascii=False, sort_keys=True),
                    iso(),
                ),
            )
            event_id = int(cursor.lastrowid)
        return {
            "id": event_id,
            "status": "observed",
            "evidence_digest": evidence_digest,
            **metadata,
        }

    def management_e2e_observation(
        self,
        agent_id: str,
        asset_digest: str,
    ) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT id, target_version, after_digest, metadata_json, created_at
                   FROM audit_events
                   WHERE action='delivery.management_e2e_observed'
                     AND target_type='delivery_observation'
                     AND target_id=?
                     AND result='passed'
                   ORDER BY id DESC LIMIT 1""",
                (agent_id,),
            ).fetchone()
        if not row:
            return {
                "status": "not_run",
                "passed": False,
                "evidence": {
                    "required_check_count": len(MANAGEMENT_E2E_REQUIRED_CHECKS),
                    "observed_check_count": 0,
                    "secret_values_included": False,
                },
            }
        metadata = json.loads(row["metadata_json"] or "{}")
        try:
            target = self.runtime_target(agent_id)
        except KeyError:
            target = None
        revision_matches = bool(
            target
            and metadata.get("agent_version_id") == target["agent_version_id"]
            and metadata.get("runtime_revision_digest") == target["runtime_revision_digest"]
        )
        asset_matches = metadata.get("management_asset_digest") == asset_digest
        passed = revision_matches and asset_matches
        checks = metadata.get("checks") if isinstance(metadata.get("checks"), dict) else {}
        return {
            "status": "observed" if passed else "stale",
            "passed": passed,
            "evidence": {
                "event_id": row["id"],
                "runner": metadata.get("runner"),
                "agent_version_id": metadata.get("agent_version_id"),
                "runtime_revision_digest": metadata.get("runtime_revision_digest"),
                "management_asset_digest": metadata.get("management_asset_digest"),
                "process_instance_id": metadata.get("process_instance_id"),
                "process_started_at": metadata.get("process_started_at"),
                "required_check_count": len(MANAGEMENT_E2E_REQUIRED_CHECKS),
                "observed_check_count": sum(status == "passed" for status in checks.values()),
                "revision_matches": revision_matches,
                "asset_matches": asset_matches,
                "started_at": metadata.get("started_at"),
                "finished_at": metadata.get("finished_at"),
                "evidence_digest": row["after_digest"],
                "external_writes": metadata.get("external_writes"),
                "secret_values_included": False,
            },
        }

    def release_rollback_status(self, agent_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            agent = connection.execute(
                "SELECT active_version_id FROM agents WHERE id=?",
                (agent_id,),
            ).fetchone()
            latest = connection.execute(
                """SELECT id, from_version_id, to_version_id, kind, created_at
                   FROM publish_events WHERE agent_id=?
                   ORDER BY created_at DESC, id DESC LIMIT 1""",
                (agent_id,),
            ).fetchone()
            rollback_count = int(
                connection.execute(
                    """SELECT COUNT(*) FROM publish_events
                       WHERE agent_id=? AND kind='rollback'""",
                    (agent_id,),
                ).fetchone()[0]
            )
        passed = bool(
            agent
            and latest
            and latest["kind"] == "rollback"
            and latest["to_version_id"] == agent["active_version_id"]
        )
        return {
            "status": "passed" if passed else "stale" if rollback_count else "not_run",
            "passed": passed,
            "evidence": {
                "rollback_event_count": rollback_count,
                "latest_event_id": latest["id"] if latest else None,
                "latest_event_kind": latest["kind"] if latest else None,
                "from_version_id": latest["from_version_id"] if latest else None,
                "to_version_id": latest["to_version_id"] if latest else None,
                "active_version_matches": bool(
                    agent and latest and latest["to_version_id"] == agent["active_version_id"]
                ),
                "observed_at": latest["created_at"] if latest else None,
            },
        }

    def overview(self) -> dict[str, Any]:
        with self.database.connect() as connection:

            def scalar(query: str, params: tuple[Any, ...] = ()) -> int:
                return int(connection.execute(query, params).fetchone()[0])

            run_states = {
                row["status"]: row["count"]
                for row in connection.execute(
                    """SELECT status, COUNT(*) AS count FROM runs
                       GROUP BY status ORDER BY status"""
                ).fetchall()
            }
            provider_health = [
                dict(row)
                for row in connection.execute(
                    """SELECT p.id, p.name, p.status,
                              COALESCE(
                                (SELECT cvr.status FROM config_validation_runs cvr
                                 JOIN model_profile_versions mpv ON mpv.id=cvr.target_id
                                 JOIN model_profiles mp ON mp.id=mpv.model_profile_id
                                 WHERE cvr.target_type='model_probe' AND mp.provider_id=p.id
                                 ORDER BY cvr.created_at DESC LIMIT 1),
                                'not_run'
                              ) AS last_probe_status
                       FROM model_providers p ORDER BY p.id"""
                ).fetchall()
            ]
            recent_failures = [
                dict(row)
                for row in connection.execute(
                    """SELECT id, case_id, agent_version_id, status, stop_reason,
                              started_at, finished_at
                       FROM runs WHERE status<>'completed'
                       ORDER BY started_at DESC LIMIT 10"""
                ).fetchall()
            ]
            return {
                "agents": {
                    "published": scalar("SELECT COUNT(*) FROM agents WHERE status='published'"),
                    "draft": scalar("SELECT COUNT(*) FROM agents WHERE status='draft'"),
                    "disabled": scalar("SELECT COUNT(*) FROM agents WHERE status='disabled'"),
                },
                "cases": {
                    "open": scalar("SELECT COUNT(*) FROM cases WHERE lifecycle='open'"),
                    "closed": scalar("SELECT COUNT(*) FROM cases WHERE lifecycle='closed'"),
                },
                "runs": run_states,
                "pending": {
                    "reviews": scalar("SELECT COUNT(*) FROM reviews WHERE status='pending'"),
                    "jobs": scalar("SELECT COUNT(*) FROM jobs WHERE status IN ('pending','running')"),
                    "outbox": scalar("SELECT COUNT(*) FROM outbox WHERE status IN ('pending','sending')"),
                    "actions": scalar(
                        """SELECT COUNT(*) FROM actions
                           WHERE status IN ('prepared','awaiting_confirmation','executing')"""
                    ),
                },
                "provider_health": provider_health,
                "tool_provider_health": [
                    dict(row)
                    for row in connection.execute(
                        """SELECT tp.id, tp.name, tp.provider_type, tp.status,
                                  (SELECT tsv.digest FROM tool_schema_versions tsv
                                   WHERE tsv.tool_provider_id=tp.id
                                   ORDER BY tsv.version DESC LIMIT 1) AS schema_digest,
                                  (SELECT tsv.observed_at FROM tool_schema_versions tsv
                                   WHERE tsv.tool_provider_id=tp.id
                                   ORDER BY tsv.version DESC LIMIT 1) AS observed_at
                           FROM tool_providers tp ORDER BY tp.id"""
                    ).fetchall()
                ],
                "channel_health": [
                    dict(row)
                    for row in connection.execute(
                        """SELECT id, channel_type, status, health_state,
                                  validated_at, last_error_class
                           FROM channel_instances ORDER BY id"""
                    ).fetchall()
                ],
                "pack_health": [
                    dict(row)
                    for row in connection.execute(
                        """SELECT id, status, trust_level FROM capability_packs ORDER BY id"""
                    ).fetchall()
                ],
                "recent_failures": recent_failures,
                "candidate_status": [
                    dict(row)
                    for row in connection.execute(
                        """SELECT id, agent_id, status, model_calls, source_calls,
                                  external_writes, created_at, finished_at
                           FROM candidate_attempts ORDER BY created_at DESC LIMIT 5"""
                    ).fetchall()
                ],
            }

    def list_runs(
        self,
        *,
        agent_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        limit = max(1, min(limit, 500))
        offset = max(0, min(offset, 1_000_000))
        query = """SELECT r.id, r.case_id, c.title AS case_title, c.agent_id,
                          r.trigger_message_id, r.agent_version_id,
                          r.model_profile_version_id, r.provider_version_id,
                          mpv.model_id, pv.provider_id, r.status, r.stop_reason,
                          r.prompt_bundle_digest, r.pack_digests_json,
                          r.tool_schema_digest, r.context_token_estimate,
                          r.usage_state, r.usage_json, r.started_at, r.finished_at
                   FROM runs r
                   JOIN cases c ON c.id=r.case_id
                   JOIN model_profile_versions mpv ON mpv.id=r.model_profile_version_id
                   JOIN model_provider_versions pv ON pv.id=r.provider_version_id
                   WHERE 1=1"""
        params: list[Any] = []
        if agent_id:
            query += " AND c.agent_id=?"
            params.append(agent_id)
        if status:
            query += " AND r.status=?"
            params.append(status)
        count_query = """SELECT COUNT(*) FROM runs r
                         JOIN cases c ON c.id=r.case_id WHERE 1=1"""
        count_params: list[Any] = []
        if agent_id:
            count_query += " AND c.agent_id=?"
            count_params.append(agent_id)
        if status:
            count_query += " AND r.status=?"
            count_params.append(status)
        query += " ORDER BY r.started_at DESC, r.id DESC LIMIT ? OFFSET ?"
        params.extend((limit, offset))
        with self.database.connect() as connection:
            total = int(connection.execute(count_query, count_params).fetchone()[0])
            rows = connection.execute(query, params).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["pack_digests"] = json.loads(item.pop("pack_digests_json"))
            item["usage"] = json.loads(item.pop("usage_json") or "null")
            result.append(item)
        return {"items": result, "page": self._page(total, limit, offset, len(result))}

    def agent_usage_summary(self, agent_id: str, *, days: int = 30) -> dict[str, Any]:
        """Return Agent-scoped operating and token usage for the management console."""

        days = max(1, min(days, 90))
        period_end = datetime.now(UTC)
        period_start = period_end - timedelta(days=days - 1)
        period_start = period_start.replace(hour=0, minute=0, second=0, microsecond=0)
        with self.database.connect() as connection:
            agent = connection.execute(
                "SELECT id, name FROM agents WHERE id=?", (agent_id,)
            ).fetchone()
            if not agent:
                raise KeyError(agent_id)
            case_count = int(
                connection.execute(
                    "SELECT COUNT(*) FROM cases WHERE agent_id=? AND created_at>=?",
                    (agent_id, period_start.isoformat()),
                ).fetchone()[0]
            )
            message_count = int(
                connection.execute(
                    """SELECT COUNT(*) FROM messages m
                       JOIN cases c ON c.id=m.case_id
                       WHERE c.agent_id=? AND m.created_at>=?""",
                    (agent_id, period_start.isoformat()),
                ).fetchone()[0]
            )
            runs = connection.execute(
                """SELECT r.id, r.started_at FROM runs r
                   JOIN cases c ON c.id=r.case_id
                   WHERE c.agent_id=? AND r.started_at>=?
                   ORDER BY r.started_at""",
                (agent_id, period_start.isoformat()),
            ).fetchall()
            turns = connection.execute(
                """SELECT mt.started_at, mt.usage_state, mt.usage_json
                   FROM model_turns mt
                   JOIN runs r ON r.id=mt.run_id
                   JOIN cases c ON c.id=r.case_id
                   WHERE c.agent_id=? AND mt.started_at>=?
                   ORDER BY mt.started_at""",
                (agent_id, period_start.isoformat()),
            ).fetchall()
            tool_calls = connection.execute(
                """SELECT tc.created_at FROM tool_calls tc
                   JOIN runs r ON r.id=tc.run_id
                   JOIN cases c ON c.id=r.case_id
                   WHERE c.agent_id=? AND tc.created_at>=?
                   ORDER BY tc.created_at""",
                (agent_id, period_start.isoformat()),
            ).fetchall()

        daily: dict[str, dict[str, Any]] = {}
        for offset in range(days):
            date = (period_start + timedelta(days=offset)).date().isoformat()
            daily[date] = {
                "date": date,
                "runs": 0,
                "model_calls": 0,
                "tool_calls": 0,
                "input_tokens": 0,
                "output_tokens": 0,
                "total_tokens": 0,
            }
        for run in runs:
            date = str(run["started_at"])[:10]
            if date in daily:
                daily[date]["runs"] += 1
        observed_turns = 0
        input_tokens = 0
        output_tokens = 0
        total_tokens = 0
        for turn in turns:
            date = str(turn["started_at"])[:10]
            turn_input, turn_output, turn_total = _usage_tokens(turn["usage_json"])
            if turn["usage_state"] == "observed" or turn_total > 0:
                observed_turns += 1
            input_tokens += turn_input
            output_tokens += turn_output
            total_tokens += turn_total
            if date in daily:
                daily[date]["model_calls"] += 1
                daily[date]["input_tokens"] += turn_input
                daily[date]["output_tokens"] += turn_output
                daily[date]["total_tokens"] += turn_total
        for tool_call in tool_calls:
            date = str(tool_call["created_at"])[:10]
            if date in daily:
                daily[date]["tool_calls"] += 1

        return {
            "contract": "suwen-agent-usage.v1",
            "agent": {"id": agent["id"], "name": agent["name"]},
            "period": {
                "days": days,
                "start": period_start.isoformat(),
                "end": period_end.isoformat(),
                "time_zone": "UTC",
            },
            "totals": {
                "cases": case_count,
                "messages": message_count,
                "runs": len(runs),
                "model_calls": len(turns),
                "tool_calls": len(tool_calls),
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": total_tokens,
            },
            "observability": {
                "observed_model_calls": observed_turns,
                "unobserved_model_calls": len(turns) - observed_turns,
                "token_coverage": (
                    "complete"
                    if turns and observed_turns == len(turns)
                    else "partial"
                    if observed_turns
                    else "not_observable"
                ),
            },
            "daily": list(daily.values()),
        }

    def list_cases(self, limit: int = 100, offset: int = 0) -> dict[str, Any]:
        limit = max(1, min(limit, 500))
        offset = max(0, min(offset, 1_000_000))
        with self.database.connect() as connection:
            total = int(connection.execute("SELECT COUNT(*) FROM cases").fetchone()[0])
            rows = connection.execute(
                """SELECT c.id, c.title, c.lifecycle, c.disposition, c.agent_id,
                          a.name AS agent_name, c.pinned_agent_version_id,
                          c.persona_snapshot_json,
                          c.created_at, c.updated_at, c.last_external_at,
                          (SELECT COUNT(*) FROM messages m WHERE m.case_id=c.id)
                            AS message_count,
                          (SELECT COUNT(*) FROM runs r WHERE r.case_id=c.id)
                            AS run_count,
                          (SELECT COUNT(*) FROM evidence e
                           JOIN runs r ON r.id=e.run_id WHERE r.case_id=c.id)
                            AS evidence_count,
                          (SELECT COUNT(*) FROM reviews rv WHERE rv.case_id=c.id)
                            AS review_count,
                          (SELECT COUNT(*) FROM feedback f WHERE f.case_id=c.id)
                            AS feedback_count,
                          (SELECT COUNT(*) FROM actions ac WHERE ac.case_id=c.id)
                            AS action_count,
                          (SELECT j.status FROM jobs j
                           WHERE j.case_id=c.id AND j.kind='process_inbound'
                           ORDER BY j.created_at DESC, j.id DESC LIMIT 1)
                            AS latest_message_status,
                          (SELECT j.last_error FROM jobs j
                           WHERE j.case_id=c.id AND j.kind='process_inbound'
                           ORDER BY j.created_at DESC, j.id DESC LIMIT 1)
                            AS latest_message_error,
                          (SELECT r.status FROM runs r WHERE r.case_id=c.id
                           ORDER BY r.started_at DESC, r.id DESC LIMIT 1)
                            AS latest_run_status,
                          (SELECT r.stop_reason FROM runs r WHERE r.case_id=c.id
                           ORDER BY r.started_at DESC, r.id DESC LIMIT 1)
                            AS latest_run_stop_reason
                   FROM cases c JOIN agents a ON a.id=c.agent_id
                   ORDER BY c.updated_at DESC, c.id DESC LIMIT ? OFFSET ?""",
                (limit, offset),
            ).fetchall()
        items = []
        for row in rows:
            item = dict(row)
            item["persona"] = normalize_persona_snapshot(item.pop("persona_snapshot_json"))
            items.append(item)
        return {"items": items, "page": self._page(total, limit, offset, len(items))}

    def get_case(self, case_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            case = connection.execute(
                """SELECT c.id, c.title, c.lifecycle, c.disposition, c.agent_id,
                          a.name AS agent_name, c.pinned_agent_version_id,
                          c.persona_snapshot_json,
                          c.created_at, c.updated_at, c.last_external_at,
                          (SELECT COUNT(*) FROM messages m WHERE m.case_id=c.id)
                            AS message_count,
                          (SELECT COUNT(*) FROM runs r WHERE r.case_id=c.id)
                            AS run_count,
                          (SELECT COUNT(*) FROM evidence e
                           JOIN runs r ON r.id=e.run_id WHERE r.case_id=c.id)
                            AS evidence_count,
                          (SELECT COUNT(*) FROM reviews rv WHERE rv.case_id=c.id)
                            AS review_count,
                          (SELECT COUNT(*) FROM feedback f WHERE f.case_id=c.id)
                            AS feedback_count,
                          (SELECT COUNT(*) FROM actions ac WHERE ac.case_id=c.id)
                            AS action_count
                   FROM cases c JOIN agents a ON a.id=c.agent_id WHERE c.id=?""",
                (case_id,),
            ).fetchone()
            if not case:
                raise KeyError(case_id)
            runs = [
                dict(row)
                for row in connection.execute(
                    """SELECT r.id, r.agent_version_id, r.model_profile_version_id,
                              mpv.model_id, r.status, r.stop_reason,
                              r.context_token_estimate, r.usage_state,
                              r.started_at, r.finished_at
                       FROM runs r
                       JOIN model_profile_versions mpv ON mpv.id=r.model_profile_version_id
                       WHERE r.case_id=? ORDER BY r.started_at DESC LIMIT 100""",
                    (case_id,),
                ).fetchall()
            ]
            evidence_states = {
                row["state"]: row["count"]
                for row in connection.execute(
                    """SELECT e.state, COUNT(*) AS count FROM evidence e
                       JOIN runs r ON r.id=e.run_id
                       WHERE r.case_id=? GROUP BY e.state ORDER BY e.state""",
                    (case_id,),
                ).fetchall()
            }
            bindings = []
            for row in connection.execute(
                """SELECT channel, channel_instance, scope_kind, scope_ref,
                          created_at, updated_at
                   FROM channel_bindings WHERE case_id=? ORDER BY created_at""",
                (case_id,),
            ).fetchall():
                item = dict(row)
                scope_ref = item.pop("scope_ref")
                item["scope_ref_digest"] = hashlib.sha256(scope_ref.encode()).hexdigest()
                bindings.append(item)
            review_states = {
                row["status"]: row["count"]
                for row in connection.execute(
                    """SELECT status, COUNT(*) AS count FROM reviews
                       WHERE case_id=? GROUP BY status ORDER BY status""",
                    (case_id,),
                ).fetchall()
            }
            action_states = {
                row["status"]: row["count"]
                for row in connection.execute(
                    """SELECT status, COUNT(*) AS count FROM actions
                       WHERE case_id=? GROUP BY status ORDER BY status""",
                    (case_id,),
                ).fetchall()
            }
            message_executions = [
                dict(row)
                for row in connection.execute(
                    """SELECT j.id AS job_id, j.status, j.attempts, j.last_error,
                              j.due_at, j.created_at, j.finished_at,
                              m.id AS message_id, ie.state AS ingress_state,
                              (SELECT r.id FROM runs r WHERE r.trigger_message_id=m.id
                               ORDER BY r.started_at DESC, r.id DESC LIMIT 1) AS run_id,
                              (SELECT r.status FROM runs r WHERE r.trigger_message_id=m.id
                               ORDER BY r.started_at DESC, r.id DESC LIMIT 1) AS run_status,
                              (SELECT r.stop_reason FROM runs r WHERE r.trigger_message_id=m.id
                               ORDER BY r.started_at DESC, r.id DESC LIMIT 1) AS run_stop_reason,
                              (SELECT am.id FROM messages am
                               WHERE am.case_id=m.case_id AND am.role='assistant'
                                 AND json_extract(am.metadata_json, '$.trigger_message_id')=m.id
                                 AND json_extract(am.metadata_json, '$.terminal_fallback')=1
                               ORDER BY am.seq DESC LIMIT 1) AS terminal_reply_id,
                              CASE
                                WHEN EXISTS(
                                  SELECT 1 FROM outbox o
                                  WHERE o.idempotency_key IN (
                                    'card-finish:' || m.id,
                                    'reply-fallback:' || m.id
                                  ) AND o.status IN ('sent','captured')
                                ) THEN 'sent'
                                ELSE COALESCE(
                                  (SELECT o.status FROM outbox o
                                   WHERE o.idempotency_key='reply-fallback:' || m.id
                                   ORDER BY o.created_at DESC LIMIT 1),
                                  (SELECT o.status FROM outbox o
                                   WHERE o.idempotency_key='card-finish:' || m.id
                                   ORDER BY o.created_at DESC LIMIT 1)
                                )
                              END AS terminal_delivery_status
                       FROM jobs j
                       JOIN messages m
                         ON m.id=json_extract(j.payload_json, '$.message_id')
                       LEFT JOIN inbound_events ie ON ie.event_id=m.external_event_id
                       WHERE j.case_id=? AND j.kind='process_inbound'
                       ORDER BY j.created_at""",
                    (case_id,),
                ).fetchall()
            ]
        case_view = dict(case)
        case_view["persona"] = normalize_persona_snapshot(
            case_view.pop("persona_snapshot_json")
        )
        return {
            "case": case_view,
            "runs": runs,
            "message_executions": message_executions,
            "evidence_states": evidence_states,
            "review_states": review_states,
            "action_states": action_states,
            "channel_bindings": bindings,
            "message_bodies_included": False,
        }

    def get_run(self, run_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            run = connection.execute(
                """SELECT r.id, r.case_id, c.agent_id, c.persona_snapshot_json,
                          r.agent_version_id,
                          r.model_profile_version_id, r.provider_version_id,
                          mpv.model_id, pv.provider_id, r.trigger_message_id,
                          r.status, r.stop_reason, r.model_profile_json,
                          r.prompt_bundle_digest, r.pack_digests_json,
                          r.tool_schema_digest, r.context_layers_json,
                          r.context_chars, r.context_token_estimate,
                          r.usage_state, r.usage_json, r.started_at, r.finished_at
                   FROM runs r
                   JOIN cases c ON c.id=r.case_id
                   JOIN model_profile_versions mpv ON mpv.id=r.model_profile_version_id
                   JOIN model_provider_versions pv ON pv.id=r.provider_version_id
                   WHERE r.id=?""",
                (run_id,),
            ).fetchone()
            if not run:
                raise KeyError(run_id)
            tool_calls = connection.execute(
                """SELECT id, provider_call_id, tool_name, risk, arguments_json,
                          status, result_json, created_at, finished_at,
                          call_fingerprint, result_kind, duplicate_of_tool_call_id,
                          reused_evidence_id
                   FROM tool_calls WHERE run_id=? ORDER BY created_at""",
                (run_id,),
            ).fetchall()
            evidence = connection.execute(
                """SELECT e.id, e.tool_call_id, e.state, e.coverage_state, e.summary,
                          e.data_json, e.source_ref, e.contract_version, e.truncation_state,
                          e.source_role, e.limitations_json, e.safe_statements_json,
                          e.continuation_json, e.observed_at, e.created_at,
                          e.content_digest, e.unchanged_from_evidence_id,
                          eo.payload_json AS observation_payload_json,
                          eo.sensitivity AS observation_sensitivity
                   FROM evidence e
                   LEFT JOIN evidence_observations eo ON eo.id=e.observation_id
                   WHERE e.run_id=? ORDER BY e.created_at""",
                (run_id,),
            ).fetchall()
            model_turns = connection.execute(
                """SELECT id, turn_index, status, finish_reason, tool_request_count,
                          request_chars, response_chars, latency_ms, usage_state,
                          usage_json, failure_class, started_at, finished_at,
                          request_json, response_json, context_generation_id
                   FROM model_turns WHERE run_id=? ORDER BY turn_index""",
                (run_id,),
            ).fetchall()
            context_generations = connection.execute(
                """SELECT cg.*, dc.content_json AS checkpoint_json,
                          dc.content_digest AS checkpoint_digest,
                          dc.through_message_seq
                   FROM context_generations cg
                   LEFT JOIN diagnostic_checkpoints dc ON dc.id=cg.checkpoint_id
                   WHERE cg.run_id=? ORDER BY cg.turn_index""",
                (run_id,),
            ).fetchall()
            reply = connection.execute(
                """SELECT id, seq, content, created_at FROM messages
                   WHERE case_id=? AND role='assistant'
                     AND json_extract(metadata_json, '$.run_id')=?
                   ORDER BY seq DESC LIMIT 1""",
                (run["case_id"], run_id),
            ).fetchone()
            trigger = connection.execute(
                """SELECT id, role, content, length(content) AS content_chars, created_at
                   FROM messages WHERE id=? AND case_id=?""",
                (run["trigger_message_id"], run["case_id"]),
            ).fetchone()
            deliveries = connection.execute(
                """SELECT id, case_id, agent_id, channel, idempotency_key,
                          status, outcome_state,
                          attempts, created_at, sent_at, finished_at, last_error,
                          external_message_ref, address_json, payload_json
                   FROM outbox WHERE idempotency_key IN (?, ?, ?)
                   ORDER BY created_at, id""",
                (
                    f"card-start:{run['trigger_message_id']}",
                    f"card-finish:{run_id}",
                    f"reply:{run_id}",
                ),
            ).fetchall()
        run_view = dict(run)
        run_view["persona"] = normalize_persona_snapshot(
            run_view.pop("persona_snapshot_json")
        )
        run_view["model_profile"] = sanitize_provider_payload(
            json.loads(run_view.pop("model_profile_json") or "{}")
        )
        run_view["pack_digests"] = json.loads(run_view.pop("pack_digests_json"))
        run_view["context_layers"] = json.loads(run_view.pop("context_layers_json") or "[]")
        run_view["usage"] = json.loads(run_view.pop("usage_json") or "null")
        turn_views = []
        for row in model_turns:
            item = dict(row)
            item["usage"] = json.loads(item.pop("usage_json") or "null")
            item["request"] = redact_sensitive(json.loads(item.pop("request_json") or "null"))
            item["response"] = redact_sensitive(json.loads(item.pop("response_json") or "null"))
            turn_views.append(item)
        context_generation_views = []
        for row in context_generations:
            item = dict(row)
            item["budget"] = json.loads(item.pop("budget_json") or "{}")
            item["evidence_refs"] = json.loads(item.pop("evidence_refs_json") or "[]")
            item["checkpoint"] = json.loads(item.pop("checkpoint_json") or "null")
            context_generation_views.append(item)
        call_views = []
        for row in tool_calls:
            item = dict(row)
            item["arguments"] = redact_sensitive(json.loads(item.pop("arguments_json") or "{}"))
            item["result"] = redact_sensitive(json.loads(item.pop("result_json") or "{}"))
            call_views.append(item)
        evidence_views = []
        for row in evidence:
            item = dict(row)
            item["source_ref"] = redact_sensitive(item["source_ref"])
            for field in (
                "data_json",
                "limitations_json",
                "safe_statements_json",
                "continuation_json",
            ):
                value = item.pop(field)
                item[field.removesuffix("_json")] = redact_sensitive(json.loads(value) if value else None)
            observation = item.pop("observation_payload_json")
            item["provider_observation"] = redact_sensitive(json.loads(observation) if observation else None)
            evidence_views.append(item)
        trigger_view = dict(trigger) if trigger else None
        model_rounds, unlinked_executions = _management_model_rounds(
            turn_views,
            call_views,
            evidence_views,
            model={
                "model_id": run_view["model_id"],
                "provider_id": run_view["provider_id"],
                "model_profile_version_id": run_view["model_profile_version_id"],
                "provider_version_id": run_view["provider_version_id"],
            },
            reply_content=str(reply["content"]) if reply else None,
        )
        delivery_views = []
        for row in deliveries:
            item = dict(row)
            address = item.pop("address_json")
            payload = item.pop("payload_json")
            item["address_digest"] = hashlib.sha256(address.encode()).hexdigest()
            item["payload_digest"] = hashlib.sha256(payload.encode()).hexdigest()
            item["payload_bytes"] = len(payload.encode())
            item["address"] = redact_sensitive(json.loads(address))
            item["payload"] = redact_sensitive(json.loads(payload))
            delivery_views.append(item)
        trace_nodes: list[dict[str, Any]] = []

        def append_node(
            *,
            node_id: str,
            kind: str,
            label: str,
            status: str,
            started_at: str | None,
            finished_at: str | None,
            input_view: Any,
            output_view: Any,
            metadata: dict[str, Any] | None = None,
            limitations: list[str] | None = None,
            parent_id: str | None = None,
        ) -> None:
            trace_nodes.append(
                {
                    "id": node_id,
                    "parent_id": parent_id,
                    "kind": kind,
                    "label": label,
                    "status": status,
                    "started_at": started_at,
                    "finished_at": finished_at,
                    "duration_ms": _duration_ms(started_at, finished_at),
                    "input": input_view,
                    "output": output_view,
                    "metadata": metadata or {},
                    "limitations": limitations or [],
                }
            )

        if trigger:
            append_node(
                node_id=trigger["id"],
                parent_id=run["case_id"],
                kind="trigger_message",
                label="触发消息",
                status="observed",
                started_at=trigger["created_at"],
                finished_at=trigger["created_at"],
                input_view={
                    "message_id": trigger["id"],
                    "role": trigger["role"],
                    "content_chars": trigger["content_chars"],
                    "content_included": True,
                    "content": trigger["content"],
                },
                output_view={"run_id": run_id},
            )
        append_node(
            node_id=f"context:{run_id}",
            parent_id=run_id,
            kind="context_assembly",
            label="上下文装配",
            status="completed" if run["context_chars"] else "not_observed",
            started_at=run["started_at"],
            finished_at=run["started_at"],
            input_view={
                "trigger_message_id": run["trigger_message_id"],
                "layers": json.loads(run["context_layers_json"] or "[]"),
            },
            output_view={
                "context_chars": run["context_chars"],
                "context_token_estimate": run["context_token_estimate"],
            },
            metadata={
                "prompt_bundle_digest": run["prompt_bundle_digest"],
                "persona_id": run_view["persona"]["id"],
                "persona_digest": run_view["persona"]["digest"],
                "persona_binding_revision": run_view["persona"]["binding_revision"],
                "pack_digests": json.loads(run["pack_digests_json"]),
                "tool_schema_digest": run["tool_schema_digest"],
            },
            limitations=["实际送入模型的完整上下文请查看各模型回合的 Input。"],
        )

        execution_nodes: list[tuple[str, int, str, dict[str, Any]]] = []
        for generation in context_generation_views:
            execution_nodes.append(
                (
                    generation["created_at"],
                    5,
                    generation["id"],
                    {"kind": "context_generation", "item": generation},
                )
            )
        for turn in turn_views:
            execution_nodes.append((turn["started_at"], 10, turn["id"], {"kind": "turn", "item": turn}))
        for call in call_views:
            execution_nodes.append((call["created_at"], 20, call["id"], {"kind": "call", "item": call}))
        for evidence_item in evidence_views:
            execution_nodes.append(
                (
                    evidence_item["created_at"],
                    30,
                    evidence_item["id"],
                    {"kind": "evidence", "item": evidence_item},
                )
            )
        execution_nodes.sort(key=lambda item: (item[0] or "", item[1], item[2]))
        for _at, _order, _node_id, payload in execution_nodes:
            item = payload["item"]
            if payload["kind"] == "context_generation":
                append_node(
                    node_id=item["id"],
                    parent_id=run_id,
                    kind="context_generation",
                    label=f"上下文代次 {item['turn_index']}",
                    status=(
                        "limit_exceeded"
                        if item["pressure_tier"] == "hard_limit"
                        else "completed"
                    ),
                    started_at=item["created_at"],
                    finished_at=item["created_at"],
                    input_view={
                        "source_message_count": item["source_message_count"],
                        "checkpoint": item["checkpoint"],
                        "evidence_refs": item["evidence_refs"],
                    },
                    output_view={
                        "projected_message_count": item["projected_message_count"],
                        "strategy": item["strategy"],
                        "budget": item["budget"],
                    },
                    metadata={
                        "checkpoint_id": item["checkpoint_id"],
                        "checkpoint_digest": item["checkpoint_digest"],
                        "through_message_seq": item["through_message_seq"],
                        "omitted_protocol_groups": item["omitted_protocol_groups"],
                        "omitted_history_messages": item["omitted_history_messages"],
                    },
                    limitations=["这是模型输入投影，不是新的业务 Evidence。"],
                )
            elif payload["kind"] == "turn":
                limitations: list[str] = []
                request_view = item["request"]
                response_view = item["response"]
                if request_view is None:
                    request_view = {
                        "state": "not_recorded",
                        "request_chars": item["request_chars"],
                    }
                    limitations.append("该历史回合创建时尚未保存模型请求正文。")
                if response_view is None:
                    response_view = {
                        "state": "not_recorded",
                        "response_chars": item["response_chars"],
                        "failure_class": item["failure_class"],
                    }
                    limitations.append("模型调用失败或该历史回合创建时尚未保存模型返回内容。")
                append_node(
                    node_id=item["id"],
                    parent_id=run_id,
                    kind="model_turn",
                    label=f"模型回合 {item['turn_index']}",
                    status=item["status"],
                    started_at=item["started_at"],
                    finished_at=item["finished_at"],
                    input_view=request_view,
                    output_view=response_view,
                    metadata={
                        "turn_index": item["turn_index"],
                        "latency_ms": item["latency_ms"],
                        "request_chars": item["request_chars"],
                        "response_chars": item["response_chars"],
                        "finish_reason": item["finish_reason"],
                        "tool_request_count": item["tool_request_count"],
                        "usage_state": item["usage_state"],
                        "usage": item["usage"],
                        "failure_class": item["failure_class"],
                    },
                    limitations=limitations,
                )
            elif payload["kind"] == "call":
                append_node(
                    node_id=item["id"],
                    parent_id=run_id,
                    kind="tool_call",
                    label=f"工具 · {item['tool_name']}",
                    status=item["status"],
                    started_at=item["created_at"],
                    finished_at=item["finished_at"],
                    input_view=item["arguments"],
                    output_view=item["result"],
                    metadata={
                        "provider_call_id": item["provider_call_id"],
                        "tool_name": item["tool_name"],
                        "risk": item["risk"],
                        "result_kind": item["result_kind"],
                        "duplicate_of_tool_call_id": item["duplicate_of_tool_call_id"],
                        "reused_evidence_id": item["reused_evidence_id"],
                    },
                    limitations=["仅隐藏密钥、令牌和鉴权字段。"],
                )
            else:
                append_node(
                    node_id=item["id"],
                    parent_id=item["tool_call_id"] or run_id,
                    kind="evidence",
                    label="证据投影",
                    status=item["state"],
                    started_at=item["created_at"],
                    finished_at=item["observed_at"] or item["created_at"],
                    input_view={
                        "tool_call_id": item["tool_call_id"],
                        "source_ref": item["source_ref"],
                        "source_role": item["source_role"],
                    },
                    output_view={
                        "provider_observation": item["provider_observation"],
                        "projection": {
                            "state": item["state"],
                            "coverage_state": item["coverage_state"],
                            "summary": item["summary"],
                            "data": item["data"],
                            "safe_statements": item["safe_statements"],
                            "continuation": item["continuation"],
                        },
                    },
                    metadata={
                        "contract_version": item["contract_version"],
                        "truncation_state": item["truncation_state"],
                        "observation_sensitivity": item["observation_sensitivity"],
                        "content_digest": item["content_digest"],
                        "unchanged_from_evidence_id": item["unchanged_from_evidence_id"],
                    },
                    limitations=(
                        item["limitations"]
                        if item["provider_observation"] is not None
                        else [*item["limitations"], "Tool Provider 未提供独立原始观测记录。"]
                    ),
                )

        reply_view = dict(reply) if reply else None
        if reply_view:
            append_node(
                node_id=reply_view["id"],
                parent_id=run_id,
                kind="assistant_reply",
                label="公开答复",
                status="completed",
                started_at=reply_view["created_at"],
                finished_at=reply_view["created_at"],
                input_view={"run_id": run_id, "evidence_ids": [item["id"] for item in evidence_views]},
                output_view={"message_id": reply_view["id"], "content": reply_view["content"]},
                metadata={"message_seq": reply_view["seq"]},
                limitations=["这里只展示本次 Run 生成的公开答复，不包含其他会话正文。"],
            )
        for delivery in delivery_views:
            append_node(
                node_id=delivery["id"],
                parent_id=reply_view["id"] if reply_view else run_id,
                kind="outbox_delivery",
                label=f"投递 · {delivery['channel']}",
                status=delivery["status"],
                started_at=delivery["created_at"],
                finished_at=delivery["finished_at"] or delivery["sent_at"],
                input_view={
                    "address": delivery["address"],
                    "payload": delivery["payload"],
                    "payload_digest": delivery["payload_digest"],
                    "payload_bytes": delivery["payload_bytes"],
                    "address_digest": delivery["address_digest"],
                },
                output_view={
                    "status": delivery["status"],
                    "outcome_state": delivery["outcome_state"],
                    "attempts": delivery["attempts"],
                    "last_error": delivery["last_error"],
                    "external_message_ref": delivery["external_message_ref"],
                },
                metadata={"channel": delivery["channel"]},
                limitations=["仅隐藏密钥、令牌和鉴权字段。"],
            )
        append_node(
            node_id=run_id,
            parent_id=run["case_id"],
            kind="run_completion",
            label="运行结束" if run["finished_at"] else "运行中",
            status=run["status"],
            started_at=run["started_at"],
            finished_at=run["finished_at"],
            input_view={"trace_node_count": len(trace_nodes) + 1},
            output_view={
                "status": run["status"],
                "stop_reason": run["stop_reason"],
                "usage_state": run["usage_state"],
                "usage": json.loads(run["usage_json"] or "null"),
            },
            metadata={
                "agent_version_id": run["agent_version_id"],
                "model_profile_version_id": run["model_profile_version_id"],
                "provider_version_id": run["provider_version_id"],
            },
        )
        return {
            "run": run_view,
            "trigger_message": trigger_view,
            "model_turns": turn_views,
            "context_generations": context_generation_views,
            "model_rounds": model_rounds,
            "unlinked_executions": unlinked_executions,
            "tool_calls": call_views,
            "evidence": evidence_views,
            "reply": reply_view,
            "outbox_deliveries": delivery_views,
            "trace": {
                "schema_version": "suwen-run-trace.v2",
                "run_id": run_id,
                "case_id": run["case_id"],
                "view": "management_observability",
                "ordering": "recorded_timestamps_then_stable_id",
                "relationships": "stable_ids_only",
                "raw_inputs_included": True,
                "credential_values_included": False,
                "nodes": trace_nodes,
            },
            "private_provider_observations_included": any(
                item["provider_observation"] is not None for item in evidence_views
            ),
        }

    def list_jobs(
        self,
        *,
        status: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        limit = max(1, min(limit, 500))
        offset = max(0, min(offset, 1_000_000))
        query = """SELECT id, kind, case_id, agent_id, due_at, status,
                          lease_until, attempts, last_error, created_at, finished_at
                   FROM jobs"""
        count_query = "SELECT COUNT(*) FROM jobs"
        params: list[Any] = []
        count_params: list[Any] = []
        if status:
            query += " WHERE status=?"
            params.append(status)
            count_query += " WHERE status=?"
            count_params.append(status)
        query += " ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?"
        params.extend((limit, offset))
        with self.database.connect() as connection:
            total = int(connection.execute(count_query, count_params).fetchone()[0])
            rows = connection.execute(query, params).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            error = item.pop("last_error")
            item["failure_class"] = error.split(":", 1)[0][:80] if error else None
            result.append(item)
        return {"items": result, "page": self._page(total, limit, offset, len(result))}

    @staticmethod
    def _page(total: int, limit: int, offset: int, returned: int) -> dict[str, Any]:
        return {
            "total": total,
            "limit": limit,
            "offset": offset,
            "has_previous": offset > 0,
            "has_next": offset + returned < total,
        }

    def list_audit(
        self,
        *,
        action: str | None = None,
        target_type: str | None = None,
        actor_ref: str | None = None,
        result: str | None = None,
        created_from: str | None = None,
        created_to: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        limit = max(1, min(limit, 200))
        offset = max(0, min(offset, 1_000_000))
        query = """SELECT id, actor_type, actor_ref, action, target_type,
                          target_id, target_version, request_id, before_digest,
                          after_digest, result, authorization_source,
                          failure_class, metadata_json, created_at
                   FROM audit_events WHERE 1=1"""
        count_query = "SELECT COUNT(*) FROM audit_events WHERE 1=1"
        params: list[Any] = []
        clauses: list[str] = []
        if action:
            clauses.append("action=?")
            params.append(action)
        if target_type:
            clauses.append("target_type=?")
            params.append(target_type)
        if actor_ref:
            clauses.append("actor_ref=?")
            params.append(actor_ref)
        if result:
            clauses.append("result=?")
            params.append(result)
        if created_from:
            clauses.append("created_at>=?")
            params.append(created_from)
        if created_to:
            clauses.append("created_at<=?")
            params.append(created_to)
        suffix = "".join(f" AND {clause}" for clause in clauses)
        query += suffix + " ORDER BY id DESC LIMIT ? OFFSET ?"
        count_query += suffix
        with self.database.connect() as connection:
            total = int(connection.execute(count_query, params).fetchone()[0])
            rows = connection.execute(query, [*params, limit, offset]).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["metadata"] = sanitize_provider_payload(json.loads(item.pop("metadata_json") or "{}"))
            result.append(item)
        return {
            "items": result,
            "page": {
                "total": total,
                "limit": limit,
                "offset": offset,
                "has_previous": offset > 0,
                "has_next": offset + len(result) < total,
            },
        }

    def system(self) -> dict[str, Any]:
        with self.database.connect() as connection:
            baseline = connection.execute("SELECT value FROM schema_meta WHERE key='baseline'").fetchone()
            validations = [
                dict(row)
                for row in connection.execute(
                    """SELECT id, target_type, target_id, target_digest,
                              status, created_at, finished_at
                       FROM config_validation_runs
                       ORDER BY created_at DESC LIMIT 50"""
                ).fetchall()
            ]
            settings = [
                {
                    "key": row["key"],
                    "version": row["version"],
                    "updated_by": row["updated_by"],
                    "updated_at": row["updated_at"],
                }
                for row in connection.execute(
                    """SELECT key, version, updated_by, updated_at
                       FROM system_settings ORDER BY key"""
                ).fetchall()
            ]
        return {
            "database": self.database.check(),
            "schema_baseline": baseline["value"] if baseline else None,
            "recent_validations": validations,
            "settings_metadata": settings,
            "backups": self.list_backups(),
            "secret_values_included": False,
        }
