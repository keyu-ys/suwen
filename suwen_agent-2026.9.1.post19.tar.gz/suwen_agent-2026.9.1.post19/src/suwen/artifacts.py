from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime, timedelta
from pathlib import Path
from urllib.parse import parse_qsl, urlsplit

from .repository import Repository, iso, new_id
from .tools import ToolRegistry
from .types import (
    CapabilityArtifactPayload,
    EvidenceEnvelope,
    EvidenceState,
    InboundAttachment,
    ToolDefinition,
    ToolRisk,
)

_ARTIFACT_KEY = re.compile(r"^[a-z][a-z0-9_.-]{0,63}$")
_CAPABILITY_ARTIFACT_MEDIA_TYPES = frozenset({"text/plain", "application/json"})
_CAPABILITY_ARTIFACT_SUFFIXES = frozenset({".txt", ".json"})
_MAX_CAPABILITY_ARTIFACTS = 8
_MAX_CAPABILITY_ARTIFACT_BYTES = 2 * 1024 * 1024
_MAX_CAPABILITY_ARTIFACT_TOTAL_BYTES = 8 * 1024 * 1024
_MAX_CAPABILITY_ARTIFACT_METADATA_BYTES = 16 * 1024
_ARTIFACT_MEDIA_TYPES = {
    ".json": "application/json",
    ".txt": "text/plain; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".webp": "image/webp",
    ".svg": "image/svg+xml",
}
_MODEL_IMAGE_MEDIA_TYPES = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/webp": ".webp",
}
_MAX_MESSAGE_IMAGES = 4
_ORPHAN_GRACE_SECONDS = 60 * 60
_CREDENTIAL_KEYS = frozenset(
    {
        "api_key",
        "apikey",
        "access_token",
        "refresh_token",
        "token",
        "secret",
        "password",
        "authorization",
        "cookie",
        "signature",
    }
)
_CREDENTIAL_QUERY = re.compile(
    r"(?i)(?:^|[?&])(?:api[_-]?key|access[_-]?token|refresh[_-]?token|token|secret|"
    r"password|authorization|cookie|signature)="
)


class ArtifactStore:
    def __init__(
        self,
        repository: Repository,
        data_dir: Path,
        max_bytes: int,
        retention_hours: int,
    ) -> None:
        self.repository = repository
        self.data_root = data_dir.resolve()
        self.data_root.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(self.data_root, 0o700)
        self.root = (self.data_root / "artifacts").resolve()
        if not _is_within(self.root, self.data_root):
            raise ValueError("artifact directory escapes configured data root")
        self.max_bytes = max_bytes
        self.retention_hours = retention_hours
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(self.root, 0o700)
        self.staging_root = (self.data_root / "artifact-staging").resolve()
        if not _is_within(self.staging_root, self.data_root):
            raise ValueError("artifact staging directory escapes configured data root")
        self.staging_root.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(self.staging_root, 0o700)
        database_path = self.repository.database.path.resolve()
        if database_path.exists() and _is_within(database_path, self.data_root):
            os.chmod(database_path, 0o600)

    def write(
        self,
        content: bytes,
        *,
        case_id: str | None = None,
        run_id: str | None = None,
        suffix: str = ".bin",
        sensitive: bool = True,
        now: datetime | None = None,
        connection: sqlite3.Connection | None = None,
    ) -> dict[str, object]:
        if len(content) > self.max_bytes:
            raise ValueError("artifact exceeds configured size limit")
        allowed_suffix_chars = ".-_abcdefghijklmnopqrstuvwxyz0123456789"
        if not suffix.startswith(".") or any(char not in allowed_suffix_chars for char in suffix.lower()):
            raise ValueError("invalid artifact suffix")
        suffix = suffix.lower()
        now = now or datetime.now(UTC)
        artifact_id = new_id("artifact")
        target = (self.root / f"{artifact_id}{suffix}").resolve()
        if self.root not in target.parents:
            raise ValueError("artifact path escapes configured data root")
        staged = (self.staging_root / f"{artifact_id}.part").resolve()
        descriptor = os.open(staged, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
                os.fchmod(handle.fileno(), 0o600)
            os.replace(staged, target)
            os.chmod(target, 0o600)
        except Exception:
            staged.unlink(missing_ok=True)
            target.unlink(missing_ok=True)
            raise
        digest = hashlib.sha256(content).hexdigest()
        expires = now + timedelta(hours=self.retention_hours)
        relative_path = target.relative_to(self.root).as_posix()

        def insert(active: sqlite3.Connection) -> None:
            active.execute(
                """INSERT INTO artifacts(
                   id, case_id, agent_id, run_id, relative_path, sha256, size_bytes,
                   sensitive, created_at, expires_at
                ) VALUES (?, ?, (SELECT agent_id FROM cases WHERE id=?), ?, ?, ?, ?, ?, ?, ?)""",
                (
                    artifact_id,
                    case_id,
                    case_id,
                    run_id,
                    relative_path,
                    digest,
                    len(content),
                    1 if sensitive else 0,
                    iso(now),
                    iso(expires),
                ),
            )
        try:
            if connection is None:
                with self.repository.database.connect() as active:
                    insert(active)
            else:
                insert(connection)
        except Exception:
            target.unlink(missing_ok=True)
            raise
        return {
            "id": artifact_id,
            "sha256": digest,
            "size_bytes": len(content),
            "expires_at": iso(expires),
        }

    def cleanup(self, now: datetime | None = None) -> int:
        now = now or datetime.now(UTC)
        removed = 0
        with self.repository.database.connect() as connection:
            rows = connection.execute(
                "SELECT id, relative_path FROM artifacts WHERE expires_at<=?", (iso(now),)
            ).fetchall()
            for row in rows:
                target = (self.root / row["relative_path"]).resolve()
                if self.root in target.parents:
                    target.unlink(missing_ok=True)
                connection.execute("DELETE FROM artifacts WHERE id=?", (row["id"],))
                removed += 1
            registered = {
                str(row["relative_path"])
                for row in connection.execute("SELECT relative_path FROM artifacts").fetchall()
            }
        orphan_before = now.timestamp() - _ORPHAN_GRACE_SECONDS
        for target in self.root.iterdir():
            if not target.is_file() or target.name in registered:
                continue
            try:
                if target.stat().st_mtime <= orphan_before:
                    target.unlink(missing_ok=True)
                    removed += 1
            except OSError:
                continue
        for target in self.staging_root.iterdir():
            if not target.is_file():
                continue
            try:
                if target.stat().st_mtime <= orphan_before:
                    target.unlink(missing_ok=True)
                    removed += 1
            except OSError:
                continue
        return removed

    def write_image(
        self,
        content: bytes,
        *,
        case_id: str,
        run_id: str | None = None,
        declared_media_type: str | None = None,
        now: datetime | None = None,
        connection: sqlite3.Connection | None = None,
    ) -> dict[str, object]:
        media_type = _image_media_type(content)
        if declared_media_type and declared_media_type.lower() != media_type:
            raise ValueError("image content does not match its declared media type")
        saved = self.write(
            content,
            case_id=case_id,
            run_id=run_id,
            suffix=_MODEL_IMAGE_MEDIA_TYPES[media_type],
            sensitive=True,
            now=now,
            connection=connection,
        )
        return {
            "kind": "image",
            "artifact_id": saved["id"],
            "media_type": media_type,
            "sha256": saved["sha256"],
            "size_bytes": saved["size_bytes"],
            "expires_at": saved["expires_at"],
        }

    def materialize_inbound_images(
        self,
        attachments: Sequence[InboundAttachment],
        *,
        case_id: str,
        connection: sqlite3.Connection,
        now: datetime | None = None,
    ) -> list[dict[str, object]]:
        if len(attachments) > _MAX_MESSAGE_IMAGES:
            raise ValueError("a message cannot contain more than four images")
        descriptors: list[dict[str, object]] = []
        for attachment in attachments:
            if attachment.kind != "image" or not isinstance(attachment.content, bytes):
                raise ValueError("inbound attachment is not a materialized image")
            descriptor = self.write_image(
                attachment.content,
                case_id=case_id,
                declared_media_type=attachment.media_type,
                now=now,
                connection=connection,
            )
            descriptor["source"] = "channel_download"
            descriptor["source_ref_sha256"] = hashlib.sha256(
                attachment.external_ref.encode("utf-8")
            ).hexdigest()
            if isinstance(attachment.text_extraction, Mapping):
                descriptor["text_extraction"] = {
                    key: attachment.text_extraction[key]
                    for key in (
                        "state",
                        "engine",
                        "text",
                        "line_count",
                        "average_confidence",
                        "truncation_state",
                        "limitations",
                    )
                    if key in attachment.text_extraction
                }
            descriptors.append(descriptor)
        return descriptors

    def image_descriptors(
        self,
        artifact_ids: Sequence[str],
        *,
        case_id: str,
        now: datetime | None = None,
    ) -> list[dict[str, object]]:
        unique_ids = list(dict.fromkeys(str(item) for item in artifact_ids if item))
        if not unique_ids or len(unique_ids) != len(artifact_ids):
            raise ValueError("image Artifact ids must be non-empty and unique")
        if len(unique_ids) > _MAX_MESSAGE_IMAGES:
            raise ValueError("a message cannot contain more than four images")
        descriptors: list[dict[str, object]] = []
        for artifact_id in unique_ids:
            item = self.read_content(artifact_id, case_id, now=now)
            media_type = str(item["media_type"])
            if media_type not in _MODEL_IMAGE_MEDIA_TYPES:
                raise ValueError("message attachment is not a supported raster image")
            descriptors.append(
                {
                    "kind": "image",
                    "artifact_id": artifact_id,
                    "media_type": media_type,
                    "sha256": item["sha256"],
                    "size_bytes": item["size_bytes"],
                    "expires_at": item["expires_at"],
                    "source": "runtime_upload",
                }
            )
        return descriptors

    def bind_message_images_to_run(self, message: Mapping[str, object], run_id: str) -> int:
        metadata = _message_metadata(message)
        attachments = metadata.get("attachments", [])
        if not isinstance(attachments, list):
            attachments = []
        reply_contexts = metadata.get("reply_contexts", [])
        if isinstance(reply_contexts, list):
            for context in reply_contexts:
                if not isinstance(context, dict):
                    continue
                context_attachments = context.get("attachments", [])
                if isinstance(context_attachments, list):
                    attachments.extend(context_attachments)
        artifact_ids = [
            str(item.get("artifact_id"))
            for item in attachments
            if isinstance(item, dict) and item.get("kind") == "image" and item.get("artifact_id")
        ]
        if not artifact_ids:
            return 0
        placeholders = ",".join("?" for _item in artifact_ids)
        with self.repository.database.connect() as connection:
            cursor = connection.execute(
                f"""UPDATE artifacts SET run_id=COALESCE(run_id, ?)
                    WHERE case_id=? AND id IN ({placeholders})""",
                (run_id, str(message.get("case_id") or ""), *artifact_ids),
            )
        return int(cursor.rowcount)

    def discard(self, artifact_ids: Sequence[str]) -> None:
        for artifact_id in artifact_ids:
            if not isinstance(artifact_id, str) or not artifact_id.startswith("artifact_"):
                continue
            with self.repository.database.connect() as connection:
                registered = connection.execute(
                    "SELECT 1 FROM artifacts WHERE id=?", (artifact_id,)
                ).fetchone()
            if registered:
                continue
            for target in self.root.glob(f"{artifact_id}.*"):
                resolved = target.resolve()
                if _is_within(resolved, self.root) and resolved.is_file():
                    resolved.unlink(missing_ok=True)
            staged = (self.staging_root / f"{artifact_id}.part").resolve()
            if _is_within(staged, self.staging_root):
                staged.unlink(missing_ok=True)

    def materialize_capability_payloads(
        self,
        payloads: Sequence[CapabilityArtifactPayload],
        *,
        case_id: str,
        run_id: str,
        now: datetime | None = None,
    ) -> list[dict[str, object]]:
        """Validate and store one capability result without leaking raw content.

        All payloads are validated before the first write. If a later storage
        operation fails, already-created rows and files from this batch are
        removed before the failure is returned to the Harness.
        """

        if not case_id or not run_id:
            raise ValueError("capability Artifact requires Case and Run context")
        if not payloads or len(payloads) > _MAX_CAPABILITY_ARTIFACTS:
            raise ValueError("capability Artifact count is outside the allowed range")
        normalized = [self._normalize_capability_payload(item) for item in payloads]
        keys = [item[0].key for item in normalized]
        if len(set(keys)) != len(keys):
            raise ValueError("capability Artifact keys must be unique")
        if sum(len(item[1]) for item in normalized) > _MAX_CAPABILITY_ARTIFACT_TOTAL_BYTES:
            raise ValueError("capability Artifact payloads exceed the total size limit")

        descriptors: list[dict[str, object]] = []
        created_ids: list[str] = []
        try:
            for payload, content, metadata in normalized:
                saved = self.write(
                    content,
                    case_id=case_id,
                    run_id=run_id,
                    suffix=payload.suffix,
                    sensitive=True,
                    now=now,
                )
                artifact_id = str(saved["id"])
                created_ids.append(artifact_id)
                descriptors.append(
                    {
                        "key": payload.key,
                        "artifact_id": artifact_id,
                        "sha256": saved["sha256"],
                        "size_bytes": saved["size_bytes"],
                        "media_type": payload.media_type,
                        "source_ref": payload.source_ref,
                        "expires_at": saved["expires_at"],
                        "metadata": metadata,
                    }
                )
        except Exception:
            for artifact_id in reversed(created_ids):
                self._delete_materialized(artifact_id, run_id)
            raise
        return descriptors

    def _normalize_capability_payload(
        self,
        payload: CapabilityArtifactPayload,
    ) -> tuple[CapabilityArtifactPayload, bytes, dict[str, object]]:
        if not isinstance(payload, CapabilityArtifactPayload):
            raise ValueError("capability Artifact payload has an invalid type")
        if not _ARTIFACT_KEY.fullmatch(payload.key):
            raise ValueError("capability Artifact key is invalid")
        if payload.media_type not in _CAPABILITY_ARTIFACT_MEDIA_TYPES:
            raise ValueError("capability Artifact media type is unsupported")
        if payload.suffix not in _CAPABILITY_ARTIFACT_SUFFIXES:
            raise ValueError("capability Artifact suffix is unsupported")
        if payload.media_type == "application/json" and payload.suffix != ".json":
            raise ValueError("JSON capability Artifact must use the .json suffix")
        if payload.media_type == "text/plain" and payload.suffix != ".txt":
            raise ValueError("text capability Artifact must use the .txt suffix")

        if isinstance(payload.content, str):
            text = payload.content
        elif isinstance(payload.content, bytes):
            try:
                text = payload.content.decode("utf-8")
            except UnicodeDecodeError as exc:
                raise ValueError("capability Artifact content must be UTF-8") from exc
        else:
            raise ValueError("capability Artifact content must be text or UTF-8 bytes")
        if not text or "\x00" in text:
            raise ValueError("capability Artifact content must be non-empty UTF-8 text")
        if payload.media_type == "application/json":
            try:
                parsed = json.loads(text)
                text = json.dumps(
                    parsed,
                    ensure_ascii=False,
                    allow_nan=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
            except (TypeError, ValueError) as exc:
                raise ValueError("capability JSON Artifact must be canonicalizable") from exc
        content = text.encode("utf-8")
        if len(content) > min(self.max_bytes, _MAX_CAPABILITY_ARTIFACT_BYTES):
            raise ValueError("capability Artifact exceeds the per-item size limit")

        if payload.source_ref is not None:
            _validate_descriptor_string(payload.source_ref, "Artifact source_ref", maximum=4_096)
            _reject_credential_bearing_reference(payload.source_ref)
        if not isinstance(payload.metadata, Mapping):
            raise ValueError("capability Artifact metadata must be an object")
        metadata = dict(payload.metadata)
        _reject_credential_metadata(metadata)
        try:
            encoded_metadata = json.dumps(
                metadata,
                ensure_ascii=False,
                allow_nan=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
        except (TypeError, ValueError) as exc:
            raise ValueError("capability Artifact metadata must be bounded JSON") from exc
        if len(encoded_metadata) > _MAX_CAPABILITY_ARTIFACT_METADATA_BYTES:
            raise ValueError("capability Artifact metadata exceeds the size limit")
        return payload, content, metadata

    def _delete_materialized(self, artifact_id: str, run_id: str) -> None:
        with self.repository.database.connect() as connection:
            row = connection.execute(
                "SELECT relative_path FROM artifacts WHERE id=? AND run_id=?",
                (artifact_id, run_id),
            ).fetchone()
            if not row:
                return
            target = (self.root / row["relative_path"]).resolve()
            connection.execute("DELETE FROM artifacts WHERE id=? AND run_id=?", (artifact_id, run_id))
        if _is_within(target, self.root):
            target.unlink(missing_ok=True)

    def read_chunk(
        self,
        artifact_id: str,
        run_id: str,
        *,
        offset: int = 0,
        max_chars: int = 12_000,
        now: datetime | None = None,
    ) -> EvidenceEnvelope:
        if not artifact_id or not run_id:
            raise ValueError("artifact and Run context are required")
        if not isinstance(offset, int) or isinstance(offset, bool) or not 0 <= offset <= 8_388_608:
            raise ValueError("artifact offset is outside the allowed range")
        if not isinstance(max_chars, int) or isinstance(max_chars, bool) or not 1_000 <= max_chars <= 20_000:
            raise ValueError("artifact chunk size is outside the allowed range")
        now = now or datetime.now(UTC)
        with self.repository.database.connect() as connection:
            row = connection.execute(
                """SELECT id, run_id, relative_path, sha256, size_bytes,
                          sensitive, created_at, expires_at
                   FROM artifacts WHERE id=?""",
                (artifact_id,),
            ).fetchone()
            if not row:
                raise ValueError("artifact handle is unknown")
            if row["run_id"] != run_id:
                raise ValueError("artifact handle does not belong to this Run")
            if row["expires_at"] <= iso(now):
                raise ValueError("artifact handle has expired")
            target = (self.root / row["relative_path"]).resolve()
            if not _is_within(target, self.root) or target.is_symlink() or not target.is_file():
                raise ValueError("artifact storage target is unavailable")
            payload = target.read_bytes()
            if len(payload) != row["size_bytes"] or hashlib.sha256(payload).hexdigest() != row["sha256"]:
                raise ValueError("artifact integrity check failed")
            try:
                text = payload.decode("utf-8")
            except UnicodeDecodeError as exc:
                raise ValueError("artifact is not a readable text continuation") from exc
            chunk = text[offset : offset + max_chars]
            next_offset = offset + len(chunk)
            partial = next_offset < len(text)
            continuation = (
                {
                    "artifact_id": artifact_id,
                    "offset": next_offset,
                    "max_chars": max_chars,
                }
                if partial
                else None
            )
            connection.execute(
                """INSERT INTO audit_events(
                   actor_type, actor_ref, action, target_type, target_id,
                   request_id, result, metadata_json, created_at
                ) VALUES ('runtime', 'artifact-continuation', 'artifact.chunk_read',
                          'artifact', ?, ?, 'succeeded', ?, ?)""",
                (
                    artifact_id,
                    run_id,
                    json.dumps(
                        {
                            "offset": offset,
                            "returned_chars": len(chunk),
                            "partial": partial,
                        }
                    ),
                    iso(now),
                ),
            )
        return EvidenceEnvelope(
            state=EvidenceState.TRUNCATED if partial else EvidenceState.OBSERVED,
            summary=(
                "已读取受控 Artifact 的一个有界续读片段。" if chunk else "续读位置已到达 Artifact 末尾。"
            ),
            data={"text": chunk, "offset": offset, "returned_chars": len(chunk)},
            coverage_state="bounded" if partial else "proven_total",
            source_ref=f"artifact:{artifact_id}",
            truncation_state="partial" if partial else "complete",
            source_role="current_observation",
            limitations=(("artifact_continuation_required",) if partial else ()),
            safe_statements=("片段仅属于创建它的当前 Run",),
            continuation=continuation,
        )

    def find_text(
        self,
        artifact_id: str,
        run_id: str,
        query: str,
        *,
        max_matches: int = 8,
        now: datetime | None = None,
    ) -> EvidenceEnvelope:
        if not isinstance(query, str) or not query.strip() or "\x00" in query or len(query) > 512:
            raise ValueError("artifact search text is outside the allowed range")
        if (
            not isinstance(max_matches, int)
            or isinstance(max_matches, bool)
            or not 1 <= max_matches <= 20
        ):
            raise ValueError("artifact match count is outside the allowed range")
        now = now or datetime.now(UTC)
        row, text = self._load_text(artifact_id, run_id, now=now)
        matches: list[dict[str, object]] = []
        cursor = 0
        more = False
        while True:
            start = text.find(query, cursor)
            if start < 0:
                break
            end = start + len(query)
            if len(matches) >= max_matches:
                more = True
                break
            snippet_start = max(0, start - 240)
            snippet_end = min(len(text), end + 240)
            matches.append(
                {
                    "start": start,
                    "end": end,
                    "snippet_start": snippet_start,
                    "snippet_end": snippet_end,
                    "text": text[snippet_start:snippet_end],
                }
            )
            cursor = end
        with self.repository.database.connect() as connection:
            connection.execute(
                """INSERT INTO audit_events(
                   actor_type, actor_ref, action, target_type, target_id,
                   request_id, result, metadata_json, created_at
                ) VALUES ('runtime', 'artifact-continuation', 'artifact.text_find',
                          'artifact', ?, ?, 'succeeded', ?, ?)""",
                (
                    artifact_id,
                    run_id,
                    json.dumps(
                        {
                            "query_chars": len(query),
                            "returned_matches": len(matches),
                            "partial": more,
                        }
                    ),
                    iso(now),
                ),
            )
        state = EvidenceState.OBSERVED if matches else EvidenceState.ZERO_MATCHES
        return EvidenceEnvelope(
            state=state,
            summary=(
                f"在当前 Run 的 Artifact 中找到 {len(matches)} 个有界文本命中。"
                if matches
                else "当前 Run 的 Artifact 中未找到该精确文本。"
            ),
            data={
                "query": query,
                "matches": matches,
                "returned_matches": len(matches),
                "more_matches": more,
                "content_sha256": row["sha256"],
                "content_chars": len(text),
            },
            coverage_state="bounded" if more else "proven_total",
            source_ref=f"artifact:{artifact_id}",
            truncation_state="partial" if more else "complete",
            source_role="current_observation",
            limitations=(("additional_matches_not_returned",) if more else ()),
            safe_statements=("匹配仅来自创建它的当前 Run 的完整性校验文本",),
        )

    def _load_text(
        self,
        artifact_id: str,
        run_id: str,
        *,
        now: datetime,
    ) -> tuple[object, str]:
        if not artifact_id or not run_id:
            raise ValueError("artifact and Run context are required")
        with self.repository.database.connect() as connection:
            row = connection.execute(
                """SELECT id, run_id, relative_path, sha256, size_bytes,
                          sensitive, created_at, expires_at
                   FROM artifacts WHERE id=?""",
                (artifact_id,),
            ).fetchone()
        if not row:
            raise ValueError("artifact handle is unknown")
        if row["run_id"] != run_id:
            raise ValueError("artifact handle does not belong to this Run")
        if row["expires_at"] <= iso(now):
            raise ValueError("artifact handle has expired")
        target = (self.root / row["relative_path"]).resolve()
        if not _is_within(target, self.root) or target.is_symlink() or not target.is_file():
            raise ValueError("artifact storage target is unavailable")
        payload = target.read_bytes()
        if len(payload) != row["size_bytes"] or hashlib.sha256(payload).hexdigest() != row["sha256"]:
            raise ValueError("artifact integrity check failed")
        try:
            text = payload.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("artifact is not a readable text continuation") from exc
        return row, text

    def register_continuation_tool(self, registry: ToolRegistry) -> None:
        def read(arguments: dict[str, object]) -> EvidenceEnvelope:
            context = arguments.get("_runtime_context")
            if not isinstance(context, dict) or not isinstance(context.get("run_id"), str):
                raise ValueError("trusted Run context is unavailable")
            return self.read_chunk(
                str(arguments["artifact_id"]),
                context["run_id"],
                offset=int(arguments.get("offset", 0)),
                max_chars=int(arguments.get("max_chars", 12_000)),
            )

        registry.register(artifact_continuation_tool_definition(), read)

        def find(arguments: dict[str, object]) -> EvidenceEnvelope:
            context = arguments.get("_runtime_context")
            if not isinstance(context, dict) or not isinstance(context.get("run_id"), str):
                raise ValueError("trusted Run context is unavailable")
            return self.find_text(
                str(arguments["artifact_id"]),
                context["run_id"],
                str(arguments["query"]),
                max_matches=int(arguments.get("max_matches", 8)),
            )

        registry.register(artifact_find_tool_definition(), find)

    def list_for_case(self, case_id: str) -> list[dict[str, object]]:
        with self.repository.database.connect() as connection:
            rows = connection.execute(
                """SELECT id, case_id, run_id, relative_path, sha256, size_bytes, sensitive,
                          created_at, expires_at FROM artifacts
                   WHERE case_id=? ORDER BY created_at""",
                (case_id,),
            ).fetchall()
        items: list[dict[str, object]] = []
        for row in rows:
            item = dict(row)
            suffix = Path(str(item.pop("relative_path"))).suffix.lower()
            item["media_type"] = _ARTIFACT_MEDIA_TYPES.get(suffix, "application/octet-stream")
            item["displayable"] = suffix in {".png", ".jpg", ".webp", ".svg"}
            items.append(item)
        return items

    def read_content(
        self,
        artifact_id: str,
        case_id: str,
        *,
        now: datetime | None = None,
    ) -> dict[str, object]:
        """Read one integrity-checked Artifact through its owning Case boundary."""

        if not artifact_id or not case_id:
            raise ValueError("artifact and Case context are required")
        now = now or datetime.now(UTC)
        with self.repository.database.connect() as connection:
            row = connection.execute(
                """SELECT id, case_id, run_id, relative_path, sha256, size_bytes,
                          sensitive, created_at, expires_at
                   FROM artifacts WHERE id=?""",
                (artifact_id,),
            ).fetchone()
        if not row:
            raise KeyError(artifact_id)
        if row["case_id"] != case_id:
            raise KeyError(artifact_id)
        if row["expires_at"] <= iso(now):
            raise ValueError("artifact handle has expired")
        target = (self.root / row["relative_path"]).resolve()
        if not _is_within(target, self.root) or target.is_symlink() or not target.is_file():
            raise ValueError("artifact storage target is unavailable")
        payload = target.read_bytes()
        if len(payload) != row["size_bytes"] or hashlib.sha256(payload).hexdigest() != row["sha256"]:
            raise ValueError("artifact integrity check failed")
        return {
            "id": row["id"],
            "case_id": row["case_id"],
            "run_id": row["run_id"],
            "sha256": row["sha256"],
            "size_bytes": row["size_bytes"],
            "media_type": _ARTIFACT_MEDIA_TYPES.get(target.suffix.lower(), "application/octet-stream"),
            "expires_at": row["expires_at"],
            "content": payload,
        }


def _image_media_type(content: bytes) -> str:
    if not content:
        raise ValueError("image content must be non-empty")
    if content.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if len(content) >= 4 and content.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if len(content) >= 12 and content.startswith(b"RIFF") and content[8:12] == b"WEBP":
        return "image/webp"
    raise ValueError("unsupported image encoding; use PNG, JPEG, or WebP")


def _message_metadata(message: Mapping[str, object]) -> dict[str, object]:
    raw = message.get("metadata_json")
    if isinstance(raw, dict):
        return dict(raw)
    if not isinstance(raw, str):
        return {}
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return value if isinstance(value, dict) else {}


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
    except ValueError:
        return False
    return True


def _validate_descriptor_string(value: object, label: str, *, maximum: int) -> None:
    if not isinstance(value, str) or "\x00" in value or len(value) > maximum:
        raise ValueError(f"{label} must be a bounded safe string")


def _reject_credential_bearing_reference(value: str) -> None:
    if _CREDENTIAL_QUERY.search(value):
        raise ValueError("Artifact source_ref cannot contain credential query fields")
    parsed = urlsplit(value)
    if parsed.scheme in {"http", "https"}:
        if parsed.username is not None or parsed.password is not None:
            raise ValueError("Artifact source_ref cannot contain URL userinfo")
        for key, _value in parse_qsl(parsed.query, keep_blank_values=True):
            if key.lower().replace("-", "_") in _CREDENTIAL_KEYS:
                raise ValueError("Artifact source_ref cannot contain credential query fields")


def _reject_credential_metadata(value: object) -> None:
    if isinstance(value, Mapping):
        for key, item in value.items():
            if not isinstance(key, str):
                raise ValueError("Artifact metadata keys must be strings")
            normalized = key.lower().replace("-", "_")
            if normalized in _CREDENTIAL_KEYS:
                raise ValueError("Artifact metadata cannot contain credential fields")
            _reject_credential_metadata(item)
    elif isinstance(value, list | tuple):
        for item in value:
            _reject_credential_metadata(item)
    elif isinstance(value, str):
        _validate_descriptor_string(value, "Artifact metadata string", maximum=8_192)
        if _CREDENTIAL_QUERY.search(value):
            raise ValueError("Artifact metadata cannot contain credential query fields")


def artifact_continuation_tool_definition() -> ToolDefinition:
    """Return the canonical continuation Tool contract without touching storage."""

    return ToolDefinition(
        name="read_artifact_chunk",
        description=(
            "Read one bounded UTF-8 chunk from an unexpired Artifact created by "
            "this exact Run; arbitrary paths and cross-Run handles are rejected."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "artifact_id": {"type": "string", "minLength": 1},
                "offset": {"type": "integer", "minimum": 0, "maximum": 8_388_608},
                "max_chars": {"type": "integer", "minimum": 1_000, "maximum": 20_000},
            },
            "required": ["artifact_id"],
            "additionalProperties": False,
        },
        risk=ToolRisk.READ_ONLY,
        provider_id="runtime-core",
    )


def artifact_find_tool_definition() -> ToolDefinition:
    """Return the generic current-Run literal text lookup contract."""

    return ToolDefinition(
        name="find_artifact_text",
        description=(
            "Find exact literal text inside one unexpired UTF-8 Artifact created by this exact "
            "Run and return bounded snippets with character offsets; paths and regular expressions "
            "are not accepted."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "artifact_id": {"type": "string", "minLength": 1},
                "query": {"type": "string", "minLength": 1, "maxLength": 512},
                "max_matches": {"type": "integer", "minimum": 1, "maximum": 20},
            },
            "required": ["artifact_id", "query"],
            "additionalProperties": False,
        },
        risk=ToolRisk.READ_ONLY,
        provider_id="runtime-core",
    )
