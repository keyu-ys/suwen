from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from typing import Any
from urllib.parse import urlsplit

from .channels import FeishuRuntimeConfig
from .db import Database
from .model_registry import SecretResolver
from .repository import iso, new_id

_STABLE_ID = re.compile(r"^[a-z][a-z0-9-]{1,63}$")
_CHANNEL_TYPES = {"web", "api", "console", "capture", "feishu"}
_FEISHU_CONFIG_KEYS = {
    "domain",
    "mode",
    "sender",
    "external_instance_ref",
    "bot_open_id",
    "require_mention_in_group",
    "allowed_actor_refs",
    "allowed_chat_refs",
    "external_writes",
    "outbound_mode",
    "approval_note",
    "api_base_url",
}
_LEGACY_CHANNEL_CONFIG_KEYS = {
    "web": {"ingress_enabled", "management_only", "sender"},
    "api": {"mode", "sender"},
    "console": {"mode", "sender", "formal_metrics"},
    "capture": {"mode", "sender", "formal_metrics"},
}
_FEISHU_SECRET_PURPOSES = {
    "app_id",
    "app_secret",
    "verification_token",
    "encrypt_key",
}
_FEISHU_API_BASE_URLS = {
    "feishu": "https://open.feishu.cn/open-apis",
    "lark": "https://open.larksuite.com/open-apis",
}
_FEISHU_API_BASE_URL = _FEISHU_API_BASE_URLS["feishu"]
_SYSTEM_CHANNEL_IDS = {"api-local", "console-capture", "app-fixture"}
_SENSITIVE_MARKERS = (
    "secret",
    "token",
    "password",
    "cookie",
    "authorization",
    "encrypt_key",
    "api_key",
)


class ChannelResolutionError(ValueError):
    pass


def _digest(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


class ChannelRegistry:
    """Versioned Channel control plane and exact Agent route resolver."""

    def __init__(
        self,
        database: Database,
        secrets: SecretResolver,
        *,
        allow_fixture_ingress: bool = False,
        runtime_mode: str = "test",
    ) -> None:
        self.database = database
        self.secrets = secrets
        self.allow_fixture_ingress = allow_fixture_ingress
        self.runtime_mode = runtime_mode

    def _assert_external_channel_allowed(self, channel_type: str) -> None:
        if self.runtime_mode == "development" and channel_type == "feishu":
            raise ValueError("开发工作区只允许使用本地 HTTP/API，不得配置或启用真实 Channel")

    def list_instances(self, agent_id: str | None = None) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute("SELECT * FROM channel_instances ORDER BY channel_type, id").fetchall()
            instances = [self._view(connection, row) for row in rows]
        if agent_id is None:
            return instances
        selected: list[dict[str, Any]] = []
        for instance in instances:
            if instance["channel_type"] == "api":
                selected.append(instance)
                continue
            if not instance["user_configurable"]:
                continue
            bindings = instance.get("agent_bindings", [])
            if not bindings or any(item.get("agent_id") == agent_id for item in bindings):
                selected.append(instance)
        return selected

    def get_instance(self, instance_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute("SELECT * FROM channel_instances WHERE id=?", (instance_id,)).fetchone()
            if not row:
                raise KeyError(instance_id)
            return self._view(connection, row)

    def assert_feishu_transport_switch_available(self, instance_id: str) -> None:
        """Reject credential/region switches while an admitted reply is in flight."""

        with self.database.connect() as connection:
            if not connection.execute(
                "SELECT 1 FROM channel_instances WHERE id=?",
                (instance_id,),
            ).fetchone():
                return
            pending, running = self._feishu_inflight(connection, instance_id)
        if pending or running:
            raise ValueError("飞书凭据切换需等待当前消息处理与回复完成")

    def rename_instance(self, instance_id: str, name: str, actor: str) -> dict[str, Any]:
        normalized = name.strip()
        if not normalized or len(normalized) > 80:
            raise ValueError("Channel name must contain 1 to 80 characters")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT name FROM channel_instances WHERE id=?",
                (instance_id,),
            ).fetchone()
            if not row:
                raise KeyError(instance_id)
            connection.execute(
                "UPDATE channel_instances SET name=?, updated_at=? WHERE id=?",
                (normalized, at, instance_id),
            )
            self._audit(
                connection,
                actor,
                "channel_instance.renamed",
                instance_id,
                "succeeded",
                {"from": row["name"], "to": normalized},
                at,
            )
            connection.commit()
        return self.get_instance(instance_id)

    def create_instance(
        self,
        instance_id: str,
        channel_type: str,
        name: str,
        config: dict[str, Any],
        secret_bindings: dict[str, str],
        actor: str,
    ) -> dict[str, Any]:
        instance_id = self._stable_id(instance_id)
        if instance_id in _SYSTEM_CHANNEL_IDS:
            raise ValueError("reserved Channel id cannot be created or reconfigured")
        if channel_type not in _CHANNEL_TYPES:
            raise ValueError("unsupported Channel type")
        if channel_type == "web":
            raise ValueError("Web 只用于管理，不能创建为消息渠道")
        self._assert_external_channel_allowed(channel_type)
        if not self.database.enable_test_fixture_agent and channel_type != "feishu":
            raise ValueError("产品模式只能创建受管飞书渠道；API 是固定运行接口")
        if not name.strip():
            raise ValueError("Channel Instance name is required")
        config = self._safe_config(channel_type, config)
        self._validate_secret_binding_shape(channel_type, secret_bindings)
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            self._assert_secret_refs(connection, secret_bindings)
            connection.execute(
                """INSERT INTO channel_instances(
                   id, channel_type, name, status, config_json, revision,
                   health_state, created_at, updated_at
                ) VALUES (?, ?, ?, 'draft', ?, 1, 'unknown', ?, ?)""",
                (
                    instance_id,
                    channel_type,
                    name.strip(),
                    json.dumps(config, ensure_ascii=False, sort_keys=True),
                    at,
                    at,
                ),
            )
            self._insert_version(connection, instance_id, 1, config, actor, at)
            self._replace_secret_bindings(connection, instance_id, secret_bindings, at)
            self._audit(
                connection,
                actor,
                "channel_instance.created",
                instance_id,
                "succeeded",
                {"channel_type": channel_type, "revision": 1},
                at,
            )
            connection.commit()
        return self.get_instance(instance_id)

    def create_version(
        self,
        instance_id: str,
        config: dict[str, Any],
        secret_bindings: dict[str, str],
        actor: str,
    ) -> dict[str, Any]:
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT revision, status, channel_type FROM channel_instances WHERE id=?",
                (instance_id,),
            ).fetchone()
            if not row:
                raise KeyError(instance_id)
            self._assert_external_channel_allowed(str(row["channel_type"]))
            if not self.database.enable_test_fixture_agent and row["channel_type"] != "feishu":
                raise ValueError("该内置运行入口不支持从管理端创建配置版本")
            config = self._safe_config(row["channel_type"], config)
            self._validate_secret_binding_shape(row["channel_type"], secret_bindings)
            self._assert_secret_refs(connection, secret_bindings)
            revision = int(row["revision"]) + 1
            config_json = json.dumps(config, ensure_ascii=False, sort_keys=True)
            connection.execute(
                """UPDATE channel_instances SET config_json=?, revision=?,
                          status='draft', health_state='unknown', validated_at=NULL,
                          last_error_class=NULL, updated_at=? WHERE id=?""",
                (config_json, revision, at, instance_id),
            )
            self._insert_version(connection, instance_id, revision, config, actor, at)
            self._replace_secret_bindings(connection, instance_id, secret_bindings, at)
            self._audit(
                connection,
                actor,
                "channel_instance.version_created",
                instance_id,
                "succeeded",
                {"from_revision": row["revision"], "to_revision": revision},
                at,
            )
            connection.commit()
        return self.get_instance(instance_id)

    def apply_feishu_configuration(
        self,
        instance_id: str,
        name: str,
        config: dict[str, Any],
        secret_bindings: dict[str, str],
        agent_id: str | None,
        enabled: bool,
        actor: str,
    ) -> dict[str, Any]:
        """Atomically publish one fully verified first-party Feishu configuration."""

        instance_id = self._stable_id(instance_id)
        if instance_id in _SYSTEM_CHANNEL_IDS and not self.database.enable_test_fixture_agent:
            raise ValueError("内置运行入口不能保存为真实飞书渠道")
        normalized_name = name.strip()
        if not normalized_name or len(normalized_name) > 80:
            raise ValueError("Channel name must contain 1 to 80 characters")
        self._assert_external_channel_allowed("feishu")
        config = self._safe_config("feishu", config)
        self._validate_secret_binding_shape("feishu", secret_bindings)
        for purpose in ("app_id", "app_secret"):
            if not self._secret_configured(secret_bindings.get(purpose)):
                raise ValueError(f"feishu_{purpose}_missing")
        if enabled:
            if not agent_id:
                raise ValueError("启用飞书渠道必须绑定一个已发布智能体")
            if (
                config.get("mode") != "long_connection"
                or config.get("sender") != "feishu"
                or config.get("external_writes") != 1
                or config.get("outbound_mode") != "reply_only"
                or not str(config.get("approval_note") or "").strip()
            ):
                raise ValueError("启用飞书渠道必须同时开启长连接和仅回复入站消息")
        elif (
            config.get("sender") != "capture"
            or config.get("external_writes") != 0
            or config.get("outbound_mode") != "disabled"
        ):
            raise ValueError("停用飞书渠道必须关闭真实回复")

        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT * FROM channel_instances WHERE id=?",
                (instance_id,),
            ).fetchone()
            if row and row["channel_type"] != "feishu":
                raise ValueError("channel_type_mismatch")
            self._assert_secret_refs(connection, secret_bindings)

            if enabled:
                agent = connection.execute(
                    "SELECT status, active_version_id FROM agents WHERE id=?",
                    (agent_id,),
                ).fetchone()
                if not agent:
                    raise KeyError(str(agent_id))
                if agent["status"] != "published" or not agent["active_version_id"]:
                    raise ValueError("binding requires a published Agent")
                active_version = connection.execute(
                    "SELECT channel_policy_json FROM agent_versions WHERE id=?",
                    (agent["active_version_id"],),
                ).fetchone()
                channel_policy = json.loads(active_version["channel_policy_json"] or "{}")
                allowed_instances = channel_policy.get("channel_instance_ids", [])
                if allowed_instances and instance_id not in allowed_instances:
                    raise ValueError("Agent Channel Policy does not allow this Channel Instance")

            current_bindings = (
                {
                    item["purpose"]: item["secret_ref_id"]
                    for item in connection.execute(
                        """SELECT purpose, secret_ref_id FROM channel_secret_bindings
                           WHERE channel_instance_id=?""",
                        (instance_id,),
                    ).fetchall()
                }
                if row
                else {}
            )
            current_agents = (
                {
                    item["agent_id"]
                    for item in connection.execute(
                        """SELECT agent_id FROM agent_channel_bindings
                           WHERE channel_instance_id=? AND active=1""",
                        (instance_id,),
                    ).fetchall()
                }
                if row
                else set()
            )
            current_config = json.loads(row["config_json"] or "{}") if row else None
            desired_status = "active" if enabled else "disabled"
            desired_agents = {str(agent_id)} if enabled and agent_id else set()
            transport_changed = (
                row is None
                or current_bindings != secret_bindings
                or current_config.get("domain") != config.get("domain")
            )
            if enabled and row is not None and transport_changed:
                pending, running = self._feishu_inflight(connection, instance_id)
                if pending or running:
                    raise ValueError("飞书凭据切换需等待当前消息处理与回复完成")
            runtime_changed = (
                row is None
                or current_config != config
                or current_bindings != secret_bindings
                or row["status"] != desired_status
            )
            changed = (
                runtime_changed
                or row is None
                or row["name"] != normalized_name
                or current_agents != desired_agents
            )

            if not changed:
                connection.rollback()
                result = self.get_instance(instance_id)
                result["configuration_changed"] = False
                return result

            if row is None:
                revision = 1
                health_state = "connecting" if enabled else "credential_verified"
                connection.execute(
                    """INSERT INTO channel_instances(
                       id, channel_type, name, status, config_json, revision,
                       health_state, validated_at, created_at, updated_at
                    ) VALUES (?, 'feishu', ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        instance_id,
                        normalized_name,
                        desired_status,
                        json.dumps(config, ensure_ascii=False, sort_keys=True),
                        revision,
                        health_state,
                        at,
                        at,
                        at,
                    ),
                )
                self._insert_version(connection, instance_id, revision, config, actor, at)
                self._audit(
                    connection,
                    actor,
                    "channel_instance.configured",
                    instance_id,
                    "succeeded",
                    {"revision": revision, "enabled": enabled},
                    at,
                )
            else:
                revision = int(row["revision"]) + (1 if runtime_changed else 0)
                connection_start_required = enabled and (
                    row["status"] != "active" or transport_changed
                )
                health_state = (
                    "connecting"
                    if connection_start_required
                    else ("credential_verified" if not enabled else row["health_state"])
                )
                connection.execute(
                    """UPDATE channel_instances SET name=?, status=?, config_json=?,
                              revision=?, health_state=?, validated_at=?,
                              last_error_class=NULL, updated_at=? WHERE id=?""",
                    (
                        normalized_name,
                        desired_status,
                        json.dumps(config, ensure_ascii=False, sort_keys=True),
                        revision,
                        health_state,
                        at,
                        at,
                        instance_id,
                    ),
                )
                if runtime_changed:
                    self._insert_version(connection, instance_id, revision, config, actor, at)
                self._audit(
                    connection,
                    actor,
                    "channel_instance.configuration_changed",
                    instance_id,
                    "succeeded",
                    {
                        "from_revision": row["revision"],
                        "to_revision": revision,
                        "enabled": enabled,
                    },
                    at,
                )

            if runtime_changed:
                self._replace_secret_bindings(connection, instance_id, secret_bindings, at)
            for purpose in ("app_id", "app_secret"):
                connection.execute(
                    """UPDATE secret_refs SET status='verified', last_verified_at=?,
                              updated_at=? WHERE id=?""",
                    (at, at, secret_bindings[purpose]),
                )
            connection.execute(
                """UPDATE agent_channel_bindings SET active=0, updated_at=?
                   WHERE channel_instance_id=? AND active=1""",
                (at, instance_id),
            )
            if enabled and agent_id:
                connection.execute(
                    """INSERT INTO agent_channel_bindings(
                       id, agent_id, channel_instance_id, policy_json, active,
                       created_at, updated_at
                    ) VALUES (?, ?, ?, '{}', 1, ?, ?)
                    ON CONFLICT(agent_id, channel_instance_id) DO UPDATE SET
                      policy_json='{}', active=1, updated_at=excluded.updated_at""",
                    (new_id("agentchannel"), agent_id, instance_id, at, at),
                )
            connection.commit()

        result = self.get_instance(instance_id)
        result["configuration_changed"] = True
        return result

    def validate(self, instance_id: str, actor: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT * FROM channel_instances WHERE id=?", (instance_id,)).fetchone()
            if not row:
                raise KeyError(instance_id)
            config = json.loads(row["config_json"] or "{}")
            bindings = {
                item["purpose"]: item["secret_ref_id"]
                for item in connection.execute(
                    """SELECT purpose, secret_ref_id FROM channel_secret_bindings
                       WHERE channel_instance_id=?""",
                    (instance_id,),
                ).fetchall()
            }
            findings: list[dict[str, str]] = []
            mode = str(config.get("mode") or "")
            sender = str(config.get("sender") or "none")
            if row["channel_type"] == "feishu":
                if mode not in {"fixture", "verified", "long_connection"}:
                    findings.append({"code": "feishu_mode_invalid", "level": "error"})
                if mode == "fixture" and not self.allow_fixture_ingress:
                    findings.append({"code": "feishu_fixture_ingress_disabled", "level": "error"})
                if mode == "verified" and not any(
                    self._secret_configured(bindings.get(purpose))
                    for purpose in ("verification_token", "encrypt_key")
                ):
                    findings.append({"code": "feishu_verification_secret_missing", "level": "error"})
                if sender not in {"capture", "feishu"}:
                    findings.append({"code": "feishu_sender_invalid", "level": "error"})
                if mode == "long_connection":
                    for purpose in ("app_id", "app_secret"):
                        if not self._secret_configured(bindings.get(purpose)):
                            findings.append({"code": f"feishu_{purpose}_missing", "level": "error"})
                external_writes = config.get("external_writes", 0)
                if not isinstance(external_writes, int) or isinstance(external_writes, bool):
                    findings.append({"code": "feishu_external_writes_invalid", "level": "error"})
                if sender == "feishu":
                    if mode not in {"verified", "long_connection"}:
                        findings.append(
                            {
                                "code": "feishu_real_sender_requires_authenticated_mode",
                                "level": "error",
                            }
                        )
                    for purpose in ("app_id", "app_secret"):
                        if not self._secret_configured(bindings.get(purpose)):
                            findings.append({"code": f"feishu_{purpose}_missing", "level": "error"})
                    if external_writes != 1:
                        findings.append({"code": "feishu_external_write_gate_missing", "level": "error"})
                    if config.get("outbound_mode") != "reply_only":
                        findings.append({"code": "feishu_sender_must_be_reply_only", "level": "error"})
                    approval_note = config.get("approval_note")
                    if (
                        not isinstance(approval_note, str)
                        or not approval_note.strip()
                        or len(approval_note) > 500
                    ):
                        findings.append({"code": "feishu_sender_approval_note_missing", "level": "error"})
                    api_base_url = config.get("api_base_url", "https://open.feishu.cn/open-apis")
                    if not isinstance(api_base_url, str) or urlsplit(api_base_url).scheme != "https":
                        findings.append({"code": "feishu_api_base_url_invalid", "level": "error"})
                elif config.get("external_writes") not in {None, 0}:
                    findings.append(
                        {
                            "code": "capture_sender_external_writes_must_be_zero",
                            "level": "error",
                        }
                    )
                if "require_mention_in_group" in config and not isinstance(
                    config["require_mention_in_group"], bool
                ):
                    findings.append({"code": "feishu_require_mention_in_group_invalid", "level": "error"})
                for key in ("allowed_actor_refs", "allowed_chat_refs"):
                    if key in config:
                        try:
                            self._config_csv(config, key)
                        except ValueError:
                            findings.append({"code": f"feishu_{key}_invalid", "level": "error"})
            elif sender not in {"none", "capture"}:
                findings.append({"code": "non_feishu_sender_denied", "level": "error"})
            status = "validated" if not findings else "draft"
            health = (
                "fixture_ready"
                if not findings and mode == "fixture"
                else ("configured" if not findings else "misconfigured")
            )
            at = iso()
            connection.execute(
                """UPDATE channel_instances SET status=?, health_state=?,
                          validated_at=?, last_error_class=?, updated_at=? WHERE id=?""",
                (
                    status,
                    health,
                    at if not findings else None,
                    findings[0]["code"] if findings else None,
                    at,
                    instance_id,
                ),
            )
            self._audit(
                connection,
                actor,
                "channel_instance.validated",
                instance_id,
                "passed" if not findings else "failed",
                {"findings": findings, "revision": row["revision"]},
                at,
            )
            connection.commit()
        return {"status": "passed" if not findings else "failed", "findings": findings}

    def set_status(self, instance_id: str, status: str, actor: str) -> dict[str, Any]:
        if status not in {"active", "disabled"}:
            raise ValueError("Channel status must be active or disabled")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT status, channel_type, config_json FROM channel_instances WHERE id=?",
                (instance_id,),
            ).fetchone()
            if not row:
                raise KeyError(instance_id)
            if status == "active":
                self._assert_external_channel_allowed(str(row["channel_type"]))
            if status == "active" and row["status"] not in {"validated", "active"}:
                raise ValueError("Channel Instance must pass validation before activation")
            config = json.loads(row["config_json"] or "{}")
            if status == "active" and row["channel_type"] == "feishu" and config.get("sender") == "feishu":
                pending = connection.execute(
                    """SELECT COUNT(*) FROM outbox
                       WHERE channel='feishu' AND status IN ('pending','sending')
                         AND json_extract(address_json, '$.channel_instance')=?""",
                    (instance_id,),
                ).fetchone()[0]
                if pending:
                    raise ValueError("real Channel sender activation requires an empty pending outbox")
            connection.execute(
                "UPDATE channel_instances SET status=?, updated_at=? WHERE id=?",
                (status, at, instance_id),
            )
            if status == "disabled":
                connection.execute(
                    """UPDATE agent_channel_bindings SET active=0, updated_at=?
                       WHERE channel_instance_id=?""",
                    (at, instance_id),
                )
            self._audit(
                connection,
                actor,
                "channel_instance.status_changed",
                instance_id,
                "succeeded",
                {"from": row["status"], "to": status},
                at,
            )
            connection.commit()
        return self.get_instance(instance_id)

    def bind_agent(
        self,
        instance_id: str,
        agent_id: str,
        policy: dict[str, Any],
        actor: str,
    ) -> dict[str, Any]:
        policy = self._safe_binding_policy(policy)
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            instance = connection.execute(
                "SELECT status, channel_type FROM channel_instances WHERE id=?", (instance_id,)
            ).fetchone()
            agent = connection.execute("SELECT status FROM agents WHERE id=?", (agent_id,)).fetchone()
            if not instance:
                raise KeyError(instance_id)
            self._assert_external_channel_allowed(str(instance["channel_type"]))
            if not agent:
                raise KeyError(agent_id)
            if instance["status"] != "active":
                raise ValueError("binding requires an active Channel Instance")
            if agent["status"] != "published":
                raise ValueError("binding requires a published Agent")
            active_version = connection.execute(
                """SELECT av.channel_policy_json FROM agents a
                   JOIN agent_versions av ON av.id=a.active_version_id
                   WHERE a.id=?""",
                (agent_id,),
            ).fetchone()
            channel_policy = json.loads(active_version["channel_policy_json"] or "{}")
            allowed_instances = channel_policy.get("channel_instance_ids", [])
            if allowed_instances and instance_id not in allowed_instances:
                raise ValueError("Agent Channel Policy does not allow this Channel Instance")
            existing = connection.execute(
                """SELECT agent_id, policy_json FROM agent_channel_bindings
                   WHERE channel_instance_id=? AND active=1 AND agent_id<>?""",
                (instance_id, agent_id),
            ).fetchall()
            route_ref = policy.get("route_ref")
            if existing:
                existing_routes = {
                    json.loads(item["policy_json"] or "{}").get("route_ref") for item in existing
                }
                if not route_ref or None in existing_routes or route_ref in existing_routes:
                    raise ValueError("multiple Agent bindings require unique exact route_ref values")
            binding_id = new_id("agentchannel")
            connection.execute(
                """INSERT INTO agent_channel_bindings(
                   id, agent_id, channel_instance_id, policy_json, active,
                   created_at, updated_at
                ) VALUES (?, ?, ?, ?, 1, ?, ?)
                ON CONFLICT(agent_id, channel_instance_id) DO UPDATE SET
                  policy_json=excluded.policy_json, active=1, updated_at=excluded.updated_at""",
                (
                    binding_id,
                    agent_id,
                    instance_id,
                    json.dumps(policy, ensure_ascii=False, sort_keys=True),
                    at,
                    at,
                ),
            )
            self._audit(
                connection,
                actor,
                "agent_channel_binding.enabled",
                instance_id,
                "succeeded",
                {"agent_id": agent_id, "route_ref": route_ref},
                at,
            )
            connection.commit()
        return self.get_instance(instance_id)

    def unbind_agent(self, instance_id: str, agent_id: str, actor: str) -> dict[str, Any]:
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            changed = connection.execute(
                """UPDATE agent_channel_bindings SET active=0, updated_at=?
                   WHERE channel_instance_id=? AND agent_id=? AND active=1""",
                (at, instance_id, agent_id),
            ).rowcount
            if not changed:
                raise KeyError(agent_id)
            self._audit(
                connection,
                actor,
                "agent_channel_binding.disabled",
                instance_id,
                "succeeded",
                {"agent_id": agent_id},
                at,
            )
            connection.commit()
        return self.get_instance(instance_id)

    def resolve_agent(
        self,
        instance_id: str,
        channel_type: str,
        route_ref: str | None = None,
    ) -> str:
        with self.database.connect() as connection:
            instance = connection.execute(
                """SELECT channel_type, status FROM channel_instances WHERE id=?""",
                (instance_id,),
            ).fetchone()
            if not instance or instance["status"] != "active":
                raise ChannelResolutionError("channel_instance_not_active")
            if instance["channel_type"] != channel_type:
                raise ChannelResolutionError("channel_type_mismatch")
            rows = connection.execute(
                """SELECT acb.agent_id, acb.policy_json FROM agent_channel_bindings acb
                   JOIN agents a ON a.id=acb.agent_id
                   WHERE acb.channel_instance_id=? AND acb.active=1
                     AND a.status='published'""",
                (instance_id,),
            ).fetchall()
        matches = []
        for row in rows:
            policy = json.loads(row["policy_json"] or "{}")
            configured_route = policy.get("route_ref")
            if configured_route is None or configured_route == route_ref:
                matches.append(row["agent_id"])
        if len(matches) != 1:
            raise ChannelResolutionError(
                "channel_agent_route_ambiguous"
                if len(rows) > 1 or len(matches) > 1
                else "channel_agent_not_bound"
            )
        return str(matches[0])

    def resolve_external_agent(
        self,
        channel_type: str,
        external_instance_ref: str,
        route_ref: str | None = None,
    ) -> tuple[str, str]:
        with self.database.connect() as connection:
            rows = connection.execute(
                """SELECT id FROM channel_instances
                   WHERE channel_type=? AND status='active'
                     AND (id=? OR json_extract(config_json, '$.external_instance_ref')=?)""",
                (channel_type, external_instance_ref, external_instance_ref),
            ).fetchall()
        if len(rows) != 1:
            raise ChannelResolutionError(
                "channel_instance_ambiguous" if rows else "channel_instance_not_active"
            )
        instance_id = str(rows[0]["id"])
        return instance_id, self.resolve_agent(instance_id, channel_type, route_ref)

    def resolve_feishu_runtime(self, instance_id: str) -> FeishuRuntimeConfig:
        """Resolve one active managed Feishu instance without exposing Secret values."""

        self._assert_external_channel_allowed("feishu")

        with self.database.connect() as connection:
            row = connection.execute("SELECT * FROM channel_instances WHERE id=?", (instance_id,)).fetchone()
            if not row or row["status"] != "active":
                raise ChannelResolutionError("channel_instance_not_active")
            if row["channel_type"] != "feishu":
                raise ChannelResolutionError("channel_type_mismatch")
            bindings = {
                item["purpose"]: item["secret_ref_id"]
                for item in connection.execute(
                    """SELECT purpose, secret_ref_id FROM channel_secret_bindings
                       WHERE channel_instance_id=?""",
                    (instance_id,),
                ).fetchall()
            }
            config = json.loads(row["config_json"] or "{}")

        mode = str(config.get("mode") or "")
        sender = str(config.get("sender") or "capture")
        if mode not in {"fixture", "verified", "long_connection"} or sender not in {
            "capture",
            "feishu",
        }:
            raise ChannelResolutionError("channel_instance_misconfigured")
        if mode == "fixture" and not self.allow_fixture_ingress:
            raise ChannelResolutionError("channel_fixture_mode_disabled")

        def secret(purpose: str, *, required: bool = False) -> str:
            ref_id = bindings.get(purpose)
            if not ref_id:
                if required:
                    raise ChannelResolutionError(f"channel_{purpose}_missing")
                return ""
            try:
                return self.secrets.resolve(ref_id, required=required)
            except (KeyError, ValueError) as exc:
                raise ChannelResolutionError(f"channel_{purpose}_unresolved") from exc

        verification_token = secret("verification_token")
        encrypt_key = secret("encrypt_key")
        if mode == "verified" and not (verification_token or encrypt_key):
            raise ChannelResolutionError("channel_verification_secret_unresolved")
        credentials_required = sender == "feishu" or mode == "long_connection"
        app_id = secret("app_id", required=credentials_required)
        app_secret = secret("app_secret", required=credentials_required)
        credential_revision = _digest(
            [
                {
                    "purpose": purpose,
                    "ref_id": ref_id,
                    "version": self.secrets.metadata(ref_id)["version"],
                }
                for purpose, ref_id in sorted(bindings.items())
            ]
        )
        return FeishuRuntimeConfig(
            instance_id=instance_id,
            revision=int(row["revision"]),
            credential_revision=credential_revision,
            enabled=True,
            mode=mode,
            sender=sender,
            external_instance_ref=str(config.get("external_instance_ref") or ""),
            app_id=app_id,
            app_secret=app_secret,
            verification_token=verification_token,
            encrypt_key=encrypt_key,
            bot_open_id=str(config.get("bot_open_id") or ""),
            allow_unverified_fixture_events=mode == "fixture",
            require_mention_in_group=self._config_bool(config, "require_mention_in_group", True),
            api_base_url=str(config.get("api_base_url") or "https://open.feishu.cn/open-apis"),
            allowed_actor_refs=self._config_csv(config, "allowed_actor_refs"),
            allowed_chat_refs=self._config_csv(config, "allowed_chat_refs"),
            external_writes=self._config_int(config, "external_writes", 0),
            outbound_mode=str(config.get("outbound_mode") or "disabled"),
            approval_note=str(config.get("approval_note") or ""),
            domain=str(config.get("domain") or "feishu"),
        )

    def resolve_feishu_probe_config(self, instance_id: str) -> FeishuRuntimeConfig:
        """Resolve draft or active App credentials for a zero-message network probe."""

        self._assert_external_channel_allowed("feishu")

        with self.database.connect() as connection:
            row = connection.execute("SELECT * FROM channel_instances WHERE id=?", (instance_id,)).fetchone()
            if not row:
                raise KeyError(instance_id)
            if row["channel_type"] != "feishu":
                raise ChannelResolutionError("channel_type_mismatch")
            bindings = {
                item["purpose"]: item["secret_ref_id"]
                for item in connection.execute(
                    """SELECT purpose, secret_ref_id FROM channel_secret_bindings
                       WHERE channel_instance_id=?""",
                    (instance_id,),
                ).fetchall()
            }
            config = json.loads(row["config_json"] or "{}")

        def required_secret(purpose: str) -> str:
            ref_id = bindings.get(purpose)
            if not ref_id:
                raise ChannelResolutionError(f"channel_{purpose}_missing")
            try:
                return self.secrets.resolve(ref_id, required=True)
            except (KeyError, ValueError) as exc:
                raise ChannelResolutionError(f"channel_{purpose}_unresolved") from exc

        app_id = required_secret("app_id")
        app_secret = required_secret("app_secret")
        credential_revision = _digest(
            [
                {
                    "purpose": purpose,
                    "ref_id": ref_id,
                    "version": self.secrets.metadata(ref_id)["version"],
                }
                for purpose, ref_id in sorted(bindings.items())
            ]
        )
        return FeishuRuntimeConfig(
            instance_id=instance_id,
            revision=int(row["revision"]),
            credential_revision=credential_revision,
            enabled=row["status"] == "active",
            mode=str(config.get("mode") or "long_connection"),
            sender=str(config.get("sender") or "capture"),
            external_instance_ref=str(config.get("external_instance_ref") or ""),
            app_id=app_id,
            app_secret=app_secret,
            verification_token="",
            encrypt_key="",
            bot_open_id=str(config.get("bot_open_id") or ""),
            allow_unverified_fixture_events=False,
            require_mention_in_group=self._config_bool(config, "require_mention_in_group", True),
            api_base_url=str(config.get("api_base_url") or _FEISHU_API_BASE_URL),
            allowed_actor_refs=self._config_csv(config, "allowed_actor_refs"),
            allowed_chat_refs=self._config_csv(config, "allowed_chat_refs"),
            external_writes=self._config_int(config, "external_writes", 0),
            outbound_mode=str(config.get("outbound_mode") or "disabled"),
            approval_note=str(config.get("approval_note") or ""),
            domain=str(config.get("domain") or "feishu"),
        )

    def record_runtime_health(
        self,
        instance_id: str,
        health_state: str,
        error_class: str | None = None,
    ) -> None:
        allowed = {
            "connecting",
            "connected",
            "credential_verified",
            "credential_rejected",
            "disconnected",
            "misconfigured",
            "reconnecting",
            "stopped",
        }
        if health_state not in allowed:
            raise ValueError("unsupported Channel runtime health state")
        with self.database.connect() as connection:
            connection.execute(
                """UPDATE channel_instances
                   SET health_state=?, last_error_class=?, updated_at=? WHERE id=?""",
                (health_state, error_class, iso(), instance_id),
            )

    def record_credential_probe(
        self,
        instance_id: str,
        passed: bool,
        actor: str,
        failure_class: str | None = None,
    ) -> None:
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            if not connection.execute(
                "SELECT id FROM channel_instances WHERE id=?", (instance_id,)
            ).fetchone():
                raise KeyError(instance_id)
            if passed:
                refs = connection.execute(
                    """SELECT secret_ref_id FROM channel_secret_bindings
                       WHERE channel_instance_id=? AND purpose IN ('app_id','app_secret')""",
                    (instance_id,),
                ).fetchall()
                for row in refs:
                    connection.execute(
                        """UPDATE secret_refs SET status='verified', last_verified_at=?,
                                  updated_at=? WHERE id=?""",
                        (at, at, row["secret_ref_id"]),
                    )
            connection.execute(
                """UPDATE channel_instances SET health_state=?, last_error_class=?,
                          updated_at=? WHERE id=?""",
                (
                    "credential_verified" if passed else "credential_rejected",
                    None if passed else failure_class,
                    at,
                    instance_id,
                ),
            )
            self._audit(
                connection,
                actor,
                "channel_instance.credentials_probed",
                instance_id,
                "passed" if passed else "failed",
                {"failure_class": failure_class, "message_accessed": False, "message_sent": False},
                at,
            )
            connection.commit()

    def record_ingress(
        self,
        instance_id: str | None,
        event_ref: str | None,
        outcome: str,
        failure_class: str | None = None,
    ) -> None:
        event_hash = hashlib.sha256(event_ref.encode()).hexdigest() if event_ref else None
        with self.database.connect() as connection:
            known = None
            if instance_id:
                known = connection.execute(
                    "SELECT id FROM channel_instances WHERE id=?", (instance_id,)
                ).fetchone()
            connection.execute(
                """INSERT INTO channel_ingress_events(
                   channel_instance_id, event_ref_hash, outcome, failure_class, created_at
                ) VALUES (?, ?, ?, ?, ?)""",
                (known["id"] if known else None, event_hash, outcome, failure_class, iso()),
            )

    def list_outbox(self, limit: int = 100, offset: int = 0) -> dict[str, Any]:
        limit = max(1, min(limit, 500))
        offset = max(0, min(offset, 1_000_000))
        with self.database.connect() as connection:
            total = int(connection.execute("SELECT COUNT(*) FROM outbox").fetchone()[0])
            rows = connection.execute(
                """SELECT id, case_id, agent_id, channel, status, outcome_state,
                          attempts, created_at, sent_at, finished_at, last_error,
                          external_message_ref, address_json, payload_json
                   FROM outbox ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?""",
                (limit, offset),
            ).fetchall()
        results = []
        for row in rows:
            item = dict(row)
            address = item.pop("address_json")
            payload = item.pop("payload_json")
            item["address_digest"] = hashlib.sha256(address.encode()).hexdigest()
            item["payload_digest"] = hashlib.sha256(payload.encode()).hexdigest()
            item["payload_bytes"] = len(payload.encode())
            results.append(item)
        return {
            "items": results,
            "page": {
                "total": total,
                "limit": limit,
                "offset": offset,
                "has_previous": offset > 0,
                "has_next": offset + len(results) < total,
            },
        }

    def _view(self, connection: sqlite3.Connection, row: sqlite3.Row) -> dict[str, Any]:
        result = dict(row)
        result["system_managed"] = row["id"] in _SYSTEM_CHANNEL_IDS
        result["user_configurable"] = (
            row["channel_type"] == "feishu" and row["id"] not in _SYSTEM_CHANNEL_IDS
        )
        result["config"] = json.loads(result.pop("config_json") or "{}")
        result["versions"] = [
            {
                **dict(item),
                "config": json.loads(item["config_json"] or "{}"),
            }
            for item in connection.execute(
                """SELECT id, version, config_json, digest, created_by, created_at
                   FROM channel_instance_versions WHERE channel_instance_id=?
                   ORDER BY version DESC""",
                (row["id"],),
            ).fetchall()
        ]
        for version in result["versions"]:
            version.pop("config_json", None)
        result["secret_bindings"] = []
        for binding in connection.execute(
            """SELECT purpose, secret_ref_id FROM channel_secret_bindings
               WHERE channel_instance_id=? ORDER BY purpose""",
            (row["id"],),
        ).fetchall():
            metadata = self.secrets.metadata(binding["secret_ref_id"])
            result["secret_bindings"].append(
                {
                    "purpose": binding["purpose"],
                    "secret_ref_id": binding["secret_ref_id"],
                    "configured": metadata["configured"],
                    "version": metadata["version"],
                    "status": metadata["status"],
                }
            )
        secret_state = {
            item["purpose"]: item for item in result["secret_bindings"]
        }
        result["agent_bindings"] = [
            {
                **dict(item),
                "policy": json.loads(item["policy_json"] or "{}"),
            }
            for item in connection.execute(
                """SELECT acb.agent_id, a.name AS agent_name, a.status AS agent_status,
                          acb.active,
                          acb.policy_json, acb.created_at, acb.updated_at
                   FROM agent_channel_bindings acb
                   JOIN agents a ON a.id=acb.agent_id
                   WHERE acb.channel_instance_id=? AND acb.active=1
                     AND a.status<>'archived' ORDER BY acb.agent_id""",
                (row["id"],),
            ).fetchall()
        ]
        for binding in result["agent_bindings"]:
            binding.pop("policy_json", None)
        latest = connection.execute(
            """SELECT outcome, failure_class, created_at FROM channel_ingress_events
               WHERE channel_instance_id=? ORDER BY created_at DESC LIMIT 1""",
            (row["id"],),
        ).fetchone()
        result["last_ingress"] = dict(latest) if latest else None
        latest_outbox = connection.execute(
            """SELECT status, outcome_state, attempts, external_message_ref,
                      last_error, created_at, sent_at, finished_at
               FROM outbox
               WHERE channel=? AND json_valid(address_json)
                 AND json_extract(address_json, '$.channel_instance')=?
               ORDER BY created_at DESC, id DESC LIMIT 1""",
            (row["channel_type"], row["id"]),
        ).fetchone()
        result["last_outbox"] = dict(latest_outbox) if latest_outbox else None
        result["runtime_binding"] = "managed_instance"
        result["ingress_path"] = (
            f"/api/v1/channels/{row['id']}/feishu/events" if row["channel_type"] == "feishu" else None
        )
        if row["channel_type"] == "feishu":
            config = result["config"]
            required_secrets = [secret_state.get("app_id"), secret_state.get("app_secret")]
            credentials_configured = all(item and item["configured"] for item in required_secrets)
            credentials_verified = all(
                item and item["configured"] and item["status"] == "verified"
                for item in required_secrets
            )
            published_bindings = [
                item
                for item in result["agent_bindings"]
                if item["active"] and item["agent_status"] == "published"
            ]
            agent_bound = len(published_bindings) == 1
            reply_policy_ready = (
                config.get("mode") == "long_connection"
                and config.get("sender") == "feishu"
                and config.get("external_writes") == 1
                and config.get("outbound_mode") == "reply_only"
            )
            result["readiness"] = {
                "configuration_saved": True,
                "credentials_configured": credentials_configured,
                "credentials_verified": credentials_verified,
                "agent_bound": agent_bound,
                "connection_state": result["health_state"],
                "reply_policy_ready": reply_policy_ready,
                "reply_ready": (
                    result["status"] == "active"
                    and result["health_state"] == "connected"
                    and credentials_verified
                    and agent_bound
                    and reply_policy_ready
                ),
            }
        return result

    @staticmethod
    def _stable_id(value: str) -> str:
        value = value.strip()
        if not _STABLE_ID.fullmatch(value):
            raise ValueError("Channel id must use 2-64 lowercase letters, digits, or hyphens")
        return value

    def _safe_config(self, channel_type: str, config: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(config, dict):
            raise ValueError("Channel config must be an object")
        if len(json.dumps(config, ensure_ascii=False)) > 20_000:
            raise ValueError("Channel config is too large")
        allowed_keys = (
            _FEISHU_CONFIG_KEYS
            if channel_type == "feishu"
            else _LEGACY_CHANNEL_CONFIG_KEYS.get(channel_type, set())
        )
        if set(config) - allowed_keys:
            raise ValueError("Channel config contains fields that are not consumed by Runtime")
        for key, value in config.items():
            normalized = str(key).lower().replace("-", "_")
            if any(marker in normalized for marker in _SENSITIVE_MARKERS):
                raise ValueError("Channel config must use Secret Ref bindings")
            if isinstance(value, (dict, list)):
                raise ValueError("Channel config supports bounded scalar values only")
            if not isinstance(value, (str, int, float, bool, type(None))):
                raise ValueError("Channel config contains an unsupported value")
        if channel_type == "feishu":
            domain = config.get("domain", "feishu")
            if domain not in _FEISHU_API_BASE_URLS:
                raise ValueError("飞书区域必须是飞书或 Lark")
            if config.get("mode") not in {"fixture", "verified", "long_connection"}:
                raise ValueError("飞书渠道模式必须是长连接、已验签回调或隔离测试")
            if config.get("mode") == "fixture" and not self.allow_fixture_ingress:
                raise ValueError("产品模式未开放飞书隔离测试入口")
            if config.get("sender") not in {"capture", "feishu"}:
                raise ValueError("飞书发送方式必须是捕获或真实回复")
            if "require_mention_in_group" in config and not isinstance(
                config["require_mention_in_group"], bool
            ):
                raise ValueError("群聊精确提及开关必须是布尔值")
            external_writes = config.get("external_writes", 0)
            if (
                not isinstance(external_writes, int)
                or isinstance(external_writes, bool)
                or external_writes not in {0, 1}
            ):
                raise ValueError("飞书外部写入门只能是 0 或 1")
            api_base_url = config.get("api_base_url", _FEISHU_API_BASE_URLS[domain])
            if not isinstance(api_base_url, str) or urlsplit(api_base_url).scheme != "https":
                raise ValueError("飞书接口地址必须是 HTTPS")
            if (
                not self.database.enable_test_fixture_agent
                and api_base_url.rstrip("/") != _FEISHU_API_BASE_URLS[domain]
            ):
                raise ValueError("产品模式只允许所选区域的官方飞书接口地址")
        return dict(config)

    @staticmethod
    def _feishu_inflight(
        connection: sqlite3.Connection,
        instance_id: str,
    ) -> tuple[int, int]:
        pending = int(
            connection.execute(
                """SELECT COUNT(*) FROM outbox
                   WHERE channel='feishu' AND status IN ('pending','sending')
                     AND json_extract(address_json, '$.channel_instance')=?""",
                (instance_id,),
            ).fetchone()[0]
        )
        running = int(
            connection.execute(
                """SELECT COUNT(DISTINCT r.id) FROM runs r
                   WHERE r.status='running' AND (
                     EXISTS (
                       SELECT 1 FROM external_messages em
                       WHERE em.case_id=r.case_id AND em.channel='feishu'
                         AND em.channel_instance=?
                     ) OR EXISTS (
                       SELECT 1 FROM channel_bindings cb
                       WHERE cb.case_id=r.case_id AND cb.channel='feishu'
                         AND cb.channel_instance=?
                     )
                   )""",
                (instance_id, instance_id),
            ).fetchone()[0]
        )
        return pending, running

    @staticmethod
    def _safe_binding_policy(policy: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(policy, dict) or set(policy) - {"route_ref"}:
            raise ValueError("Channel binding policy only supports exact route_ref")
        route_ref = policy.get("route_ref")
        if route_ref is not None and (
            not isinstance(route_ref, str) or not route_ref or len(route_ref) > 200
        ):
            raise ValueError("route_ref must be a bounded exact string")
        return dict(policy)

    @staticmethod
    def _config_bool(config: dict[str, Any], key: str, default: bool) -> bool:
        value = config.get(key, default)
        if not isinstance(value, bool):
            raise ChannelResolutionError(f"channel_{key}_invalid")
        return value

    @staticmethod
    def _config_int(config: dict[str, Any], key: str, default: int) -> int:
        value = config.get(key, default)
        if not isinstance(value, int) or isinstance(value, bool):
            raise ChannelResolutionError(f"channel_{key}_invalid")
        return value

    @staticmethod
    def _config_csv(config: dict[str, Any], key: str) -> frozenset[str]:
        value = config.get(key, "")
        if not isinstance(value, str) or len(value) > 10_000:
            raise ChannelResolutionError(f"channel_{key}_invalid")
        items = [item.strip() for item in value.split(",") if item.strip()]
        if any(len(item) > 200 for item in items) or len(items) > 200:
            raise ChannelResolutionError(f"channel_{key}_invalid")
        return frozenset(items)

    @staticmethod
    def _validate_secret_binding_shape(channel_type: str, bindings: dict[str, str]) -> None:
        allowed = _FEISHU_SECRET_PURPOSES if channel_type == "feishu" else set()
        if not isinstance(bindings, dict) or set(bindings) - allowed:
            raise ValueError("Channel Secret Ref purpose is unsupported")
        if any(not isinstance(ref_id, str) or not ref_id for ref_id in bindings.values()):
            raise ValueError("Channel Secret Ref id is invalid")

    @staticmethod
    def _assert_secret_refs(
        connection: sqlite3.Connection,
        bindings: dict[str, str],
    ) -> None:
        for ref_id in bindings.values():
            if not connection.execute("SELECT 1 FROM secret_refs WHERE id=?", (ref_id,)).fetchone():
                raise KeyError(ref_id)

    @staticmethod
    def _insert_version(
        connection: sqlite3.Connection,
        instance_id: str,
        version: int,
        config: dict[str, Any],
        actor: str,
        at: str,
    ) -> None:
        connection.execute(
            """INSERT INTO channel_instance_versions(
               id, channel_instance_id, version, config_json, digest,
               created_by, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                new_id("channelver"),
                instance_id,
                version,
                json.dumps(config, ensure_ascii=False, sort_keys=True),
                _digest(config),
                actor,
                at,
            ),
        )

    @staticmethod
    def _replace_secret_bindings(
        connection: sqlite3.Connection,
        instance_id: str,
        bindings: dict[str, str],
        at: str,
    ) -> None:
        connection.execute(
            "DELETE FROM channel_secret_bindings WHERE channel_instance_id=?",
            (instance_id,),
        )
        for purpose, ref_id in sorted(bindings.items()):
            connection.execute(
                """INSERT INTO channel_secret_bindings(
                   channel_instance_id, purpose, secret_ref_id, created_at
                ) VALUES (?, ?, ?, ?)""",
                (instance_id, purpose, ref_id, at),
            )

    def _secret_configured(self, ref_id: str | None) -> bool:
        if not ref_id:
            return False
        try:
            return bool(self.secrets.metadata(ref_id)["configured"])
        except (KeyError, ValueError):
            return False

    @staticmethod
    def _audit(
        connection: sqlite3.Connection,
        actor: str,
        action: str,
        target_id: str,
        result: str,
        metadata: dict[str, Any],
        at: str,
    ) -> None:
        connection.execute(
            """INSERT INTO audit_events(
               actor_type, actor_ref, action, target_type, target_id,
               result, metadata_json, created_at
            ) VALUES ('admin', ?, ?, 'channel_instance', ?, ?, ?, ?)""",
            (
                actor,
                action,
                target_id,
                result,
                json.dumps(metadata, ensure_ascii=False),
                at,
            ),
        )
