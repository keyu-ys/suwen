from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass, field
from typing import Any

from .tools import ToolRegistry, input_schema_accepts_contract, tool_schema_digest
from .types import ToolDefinition, ToolRisk


@dataclass(frozen=True)
class ConnectorResolution:
    bindings: tuple[dict[str, Any], ...]
    tools: ToolRegistry
    provenance: tuple[dict[str, Any], ...]
    catalog_changed: bool = False
    baseline_tools: ToolRegistry = field(default_factory=ToolRegistry)
    unavailable_tool_names: frozenset[str] = field(default_factory=frozenset)


def resolve_connector_bindings(
    connection: sqlite3.Connection,
    runtime_tools: ToolRegistry,
    raw_bindings: Any,
    *,
    normalize: bool,
) -> ConnectorResolution:
    """Resolve the currently usable read-only MCP surface for a new Run.

    A published Agent keeps the catalog it was reviewed against as its baseline.
    MCP servers are nevertheless allowed to evolve independently: a new Run may
    adopt each compatible Tool from the latest observed catalog.  Connectors are
    optional runtime capabilities: an unavailable Provider or an incompatible
    Tool is excluded from the new Run and recorded in provenance instead of
    preventing the model-only Runtime from starting.  Frozen baselines remain
    fail-closed so configuration corruption cannot be mistaken for degradation.
    """

    if raw_bindings is None:
        raw_bindings = []
    if not isinstance(raw_bindings, list):
        raise ValueError("Agent Connector bindings must be an array")
    normalized: list[dict[str, Any]] = []
    provenance: list[dict[str, Any]] = []
    selected_tools = ToolRegistry()
    baseline_tools = ToolRegistry()
    unavailable_tool_names: set[str] = set()
    seen: set[str] = set()
    catalog_changed = False
    allowed_keys = {"provider_id", "schema_version_id", "schema_digest", "selection"}
    for raw in raw_bindings:
        if not isinstance(raw, dict) or set(raw) - allowed_keys:
            raise ValueError("Agent Connector binding contains unsupported fields")
        provider_id = raw.get("provider_id")
        if not isinstance(provider_id, str) or not provider_id or provider_id in seen:
            raise ValueError("Agent Connector bindings require unique provider_id values")
        seen.add(provider_id)
        selection = raw.get("selection", "all_read_only")
        if selection != "all_read_only":
            raise ValueError("Agent Connector selection must be all_read_only")
        row = connection.execute(
            """SELECT id, provider_type, status, binding_generation,
                      runtime_metadata_json, archived_at
               FROM tool_providers WHERE id=?""",
            (provider_id,),
        ).fetchone()
        if not row:
            raise ValueError(f"Agent Connector is unavailable: {provider_id}")
        if row["provider_type"] not in {"mcp_http", "mcp_stdio"}:
            raise ValueError(f"Agent Connector must use MCP: {provider_id}")
        schema = connection.execute(
            """SELECT id, version, schema_json, digest, observed_at
               FROM tool_schema_versions WHERE tool_provider_id=?
               ORDER BY version DESC LIMIT 1""",
            (provider_id,),
        ).fetchone()
        baseline = schema
        if not normalize:
            configured_digest = raw.get("schema_digest")
            configured_version_id = raw.get("schema_version_id")
            if not isinstance(configured_digest, str) or not configured_digest:
                raise ValueError(f"Agent Connector catalog baseline is missing: {provider_id}")
            if configured_version_id is not None and not isinstance(configured_version_id, str):
                raise ValueError(f"Agent Connector catalog baseline is invalid: {provider_id}")
            if configured_version_id:
                baseline = connection.execute(
                    """SELECT id, version, schema_json, digest, observed_at
                       FROM tool_schema_versions
                       WHERE id=? AND tool_provider_id=?""",
                    (configured_version_id, provider_id),
                ).fetchone()
            else:
                baseline = connection.execute(
                    """SELECT id, version, schema_json, digest, observed_at
                       FROM tool_schema_versions
                       WHERE tool_provider_id=? AND digest=?
                       ORDER BY version DESC LIMIT 1""",
                    (provider_id, configured_digest),
                ).fetchone()
            if not baseline or baseline["digest"] != configured_digest:
                raise ValueError(f"Agent Connector catalog baseline is unavailable: {provider_id}")
        elif not schema or not schema["observed_at"]:
            raise ValueError(f"Agent Connector has no observed catalog: {provider_id}")
        if not baseline:
            raise ValueError(f"Agent Connector catalog baseline is unavailable: {provider_id}")
        baseline_catalog = json.loads(baseline["schema_json"])
        if not isinstance(baseline_catalog, list):
            raise ValueError(f"Agent Connector catalog baseline is invalid: {provider_id}")
        configured_read_only = _read_only_catalog(provider_id, baseline_catalog)
        baseline_tools.merge_from(
            _catalog_registry(provider_id, configured_read_only),
        )
        binding = {
            "provider_id": provider_id,
            "schema_version_id": str(baseline["id"]),
            "schema_digest": str(baseline["digest"]),
            "selection": "all_read_only",
        }
        normalized.append(binding)
        try:
            runtime_metadata = json.loads(row["runtime_metadata_json"] or "{}")
        except json.JSONDecodeError:
            runtime_metadata = {}
        provider_available = bool(
            row["status"] == "connected"
            and not row["archived_at"]
            and schema
            and schema["observed_at"]
        )
        if not provider_available:
            if normalize:
                raise ValueError(f"Agent Connector is not connected: {provider_id}")
            unavailable = [
                {"name": name, "reason": "provider_unavailable"}
                for name in sorted(configured_read_only)
            ]
            unavailable_tool_names.update(configured_read_only)
            catalog_changed = True
            provenance.append(
                {
                    **binding,
                    "configured_schema_version_id": str(baseline["id"]),
                    "configured_schema_digest": str(baseline["digest"]),
                    "catalog_state": "provider_unavailable",
                    "provider_type": str(row["provider_type"]),
                    "provider_status": str(row["status"]),
                    "binding_generation": int(row["binding_generation"]),
                    "observed_at": str(schema["observed_at"] if schema else baseline["observed_at"]),
                    "runtime_metadata": runtime_metadata if isinstance(runtime_metadata, dict) else {},
                    "tool_names": [],
                    "configured_tool_names": sorted(configured_read_only),
                    "unavailable_tools": unavailable,
                }
            )
            continue

        try:
            catalog = json.loads(schema["schema_json"])
            if not isinstance(catalog, list):
                raise ValueError
            current_read_only = _read_only_catalog(provider_id, catalog)
        except (json.JSONDecodeError, ValueError):
            if normalize:
                raise ValueError(
                    f"Agent Connector catalog is invalid: {provider_id}"
                ) from None
            unavailable = [
                {"name": name, "reason": "catalog_invalid"}
                for name in sorted(configured_read_only)
            ]
            unavailable_tool_names.update(configured_read_only)
            catalog_changed = True
            provenance.append(
                {
                    "provider_id": provider_id,
                    "schema_version_id": str(schema["id"]),
                    "schema_digest": str(schema["digest"]),
                    "selection": "all_read_only",
                    "configured_schema_version_id": str(baseline["id"]),
                    "configured_schema_digest": str(baseline["digest"]),
                    "catalog_state": "catalog_invalid",
                    "provider_type": str(row["provider_type"]),
                    "provider_status": str(row["status"]),
                    "binding_generation": int(row["binding_generation"]),
                    "observed_at": str(schema["observed_at"]),
                    "runtime_metadata": runtime_metadata if isinstance(runtime_metadata, dict) else {},
                    "tool_names": [],
                    "configured_tool_names": sorted(configured_read_only),
                    "unavailable_tools": unavailable,
                }
            )
            continue

        changed = baseline["id"] != schema["id"] or baseline["digest"] != schema["digest"]
        incompatibilities = (
            _catalog_update_incompatibilities(configured_read_only, current_read_only)
            if changed
            else {}
        )
        if changed:
            catalog_changed = True
        read_only_names: list[str] = []
        unavailable_by_name = dict(incompatibilities)
        by_name = {
            definition.name: definition
            for definition in runtime_tools.definitions()
            if definition.provider_id == provider_id
        }
        for item in catalog:
            if not isinstance(item, dict) or item.get("risk") != ToolRisk.READ_ONLY.value:
                continue
            name = item.get("name")
            if isinstance(name, str) and name in incompatibilities:
                continue
            definition = by_name.get(name) if isinstance(name, str) else None
            if definition is None:
                if isinstance(name, str):
                    unavailable_by_name[name] = "not_process_loaded"
                continue
            if (
                definition.risk != ToolRisk.READ_ONLY
                or definition.input_schema != item.get("input_schema")
                or definition.description != item.get("description")
                or definition.result_contract != item.get("result_contract", "model-evidence.v2")
            ):
                unavailable_by_name[definition.name] = "runtime_contract_drift"
                continue
            read_only_names.append(definition.name)
        if normalize and not read_only_names:
            raise ValueError(f"Agent Connector exposes no read-only Tool: {provider_id}")
        if read_only_names:
            selected_tools.merge_from(runtime_tools.subset(read_only_names))
        unavailable_tool_names.update(unavailable_by_name)
        current_binding = {
            "provider_id": provider_id,
            "schema_version_id": str(schema["id"]),
            "schema_digest": str(schema["digest"]),
            "selection": "all_read_only",
        }
        if normalize:
            normalized[-1] = current_binding
        provenance.append(
            {
                **current_binding,
                "configured_schema_version_id": str(baseline["id"]),
                "configured_schema_digest": str(baseline["digest"]),
                "catalog_state": (
                    "degraded_update"
                    if unavailable_by_name
                    else "compatible_update" if changed else "exact"
                ),
                "provider_type": str(row["provider_type"]),
                "provider_status": str(row["status"]),
                "binding_generation": int(row["binding_generation"]),
                "observed_at": str(schema["observed_at"]),
                "runtime_metadata": runtime_metadata if isinstance(runtime_metadata, dict) else {},
                "tool_names": sorted(read_only_names),
                "configured_tool_names": sorted(configured_read_only),
                "unavailable_tools": [
                    {"name": name, "reason": reason}
                    for name, reason in sorted(unavailable_by_name.items())
                ],
            }
        )
    return ConnectorResolution(
        tuple(normalized),
        selected_tools,
        tuple(provenance),
        catalog_changed,
        baseline_tools,
        frozenset(unavailable_tool_names),
    )


def effective_connector_allowlist(
    configured_allowlist: list[str],
    resolution: ConnectorResolution,
) -> list[str]:
    """Expand ``all_read_only`` selections with compatible current additions."""

    effective = [
        name for name in configured_allowlist if name not in resolution.unavailable_tool_names
    ]
    configured_names = set(configured_allowlist)
    for connector in resolution.provenance:
        baseline_names = {
            str(name) for name in connector.get("configured_tool_names", [])
        }
        if baseline_names and baseline_names.issubset(configured_names):
            effective.extend(str(name) for name in connector.get("tool_names", []))
    return list(dict.fromkeys(effective))


def published_tool_baseline_digest(
    base_tools: ToolRegistry,
    resolution: ConnectorResolution,
    configured_allowlist: list[str],
) -> str:
    """Reconstruct the exact Tool surface reviewed by a published Agent.

    Compatibility is deliberately scoped to Connector-owned definitions.  This
    digest proves that Packs, native capabilities and the stored Connector
    baseline still match the published aggregate before a current compatible
    catalog is allowed to extend the surface for a new Run.
    """

    baseline = ToolRegistry()
    baseline.merge_from(base_tools)
    baseline.merge_from(resolution.baseline_tools)
    return tool_schema_digest(baseline.subset(configured_allowlist))


def validate_compatible_catalog_update(
    provider_id: str,
    baseline_catalog: list[Any],
    current_catalog: list[Any],
) -> None:
    """Validate stored MCP catalogs without requiring a process-loaded handler."""

    _validate_compatible_update(
        provider_id,
        _read_only_catalog(provider_id, baseline_catalog),
        _read_only_catalog(provider_id, current_catalog),
    )


def _read_only_catalog(
    provider_id: str,
    catalog: list[Any],
) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    seen_names: set[str] = set()
    for item in catalog:
        if not isinstance(item, dict):
            raise ValueError(f"Agent Connector catalog is invalid: {provider_id}")
        name = item.get("name")
        if not isinstance(name, str) or not name or name in seen_names:
            raise ValueError(f"Agent Connector catalog is invalid: {provider_id}")
        seen_names.add(name)
        if item.get("risk") == ToolRisk.READ_ONLY.value:
            result[name] = item
    return result


def _catalog_registry(
    provider_id: str,
    catalog: dict[str, dict[str, Any]],
) -> ToolRegistry:
    registry = ToolRegistry()
    for name, item in catalog.items():
        description = item.get("description")
        input_schema = item.get("input_schema")
        result_contract = item.get("result_contract", "model-evidence.v2")
        if (
            not isinstance(description, str)
            or not isinstance(input_schema, dict)
            or not isinstance(result_contract, str)
            or not result_contract
        ):
            raise ValueError(f"Agent Connector catalog baseline is invalid: {provider_id}:{name}")
        registry.register(
            ToolDefinition(
                name=name,
                description=description,
                input_schema=input_schema,
                risk=ToolRisk.READ_ONLY,
                result_contract=result_contract,
                provider_id=provider_id,
            ),
            _baseline_only_handler,
        )
    return registry


def _baseline_only_handler(_arguments: dict[str, Any]) -> Any:
    raise RuntimeError("Connector baseline Tool cannot execute")


def _validate_compatible_update(
    provider_id: str,
    baseline: dict[str, dict[str, Any]],
    current: dict[str, dict[str, Any]],
) -> None:
    incompatible = _catalog_update_incompatibilities(baseline, current)
    if incompatible:
        name = sorted(incompatible)[0]
        reason = incompatible[name]
        messages = {
            "removed_or_reclassified": "removed or reclassified Tool",
            "evidence_contract_changed": "changed Evidence contract",
            "input_schema_narrowed": "narrowed Tool input",
        }
        raise ValueError(
            f"Agent Connector catalog update {messages[reason]}: {provider_id}:{name}"
        )


def _catalog_update_incompatibilities(
    baseline: dict[str, dict[str, Any]],
    current: dict[str, dict[str, Any]],
) -> dict[str, str]:
    incompatible = {
        name: "removed_or_reclassified" for name in sorted(set(baseline) - set(current))
    }
    for name, frozen in baseline.items():
        if name not in current:
            continue
        observed = current[name]
        if observed.get("result_contract", "model-evidence.v2") != frozen.get(
            "result_contract",
            "model-evidence.v2",
        ):
            incompatible[name] = "evidence_contract_changed"
            continue
        frozen_schema = frozen.get("input_schema")
        observed_schema = observed.get("input_schema")
        if (
            not isinstance(frozen_schema, dict)
            or not isinstance(observed_schema, dict)
            or not input_schema_accepts_contract(frozen_schema, observed_schema)
        ):
            incompatible[name] = "input_schema_narrowed"
    return incompatible
