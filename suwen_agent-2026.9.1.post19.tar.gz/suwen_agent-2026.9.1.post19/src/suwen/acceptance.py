from __future__ import annotations

import json
from typing import Any

from .agent_composition import AgentCompositionError, compose_agent_surface
from .artifacts import artifact_continuation_tool_definition
from .candidate import CandidateRunner
from .capability_packages import CapabilityBinding, CapabilityPackageRegistry
from .capability_registry import CapabilityRegistry
from .case_history import case_recall_tool_definition
from .config import Settings
from .connectors import (
    effective_connector_allowlist,
    published_tool_baseline_digest,
    resolve_connector_bindings,
)
from .db import SUWEN_AGENT_ID, Database
from .diagram import diagram_tool_definition
from .management_acceptance import management_web_asset_digest
from .model_registry import ModelRegistry
from .operations import OperationsView
from .packs import (
    PackRegistry,
    bundled_investigation_glossary,
    bundled_investigation_glossary_assets_root,
    bundled_web_root,
)
from .repository import iso
from .tools import ToolRegistry

DELIVERY_BLOCKING_CHECK_IDS = frozenset(
    {
        "database_ready",
        "native_suwen",
        "capability_contract",
        "external_dependency_binding",
        "connector_binding",
        "model_configuration",
        "model_probe",
        "agent_published",
        "managed_backup",
        "scheduler_running",
        "capture_safety",
        "persistent_process",
        "stability_observed",
    }
)


class DeliveryPreflight:
    """Read-only projection of deployment invariants and advisory observations."""

    def __init__(
        self,
        database: Database,
        models: ModelRegistry,
        capabilities: CapabilityRegistry,
        capability_packages: CapabilityPackageRegistry,
        candidate_runner: CandidateRunner,
        operations: OperationsView,
        settings: Settings,
        management_asset_digest: str,
    ) -> None:
        self.database = database
        self.models = models
        self.capabilities = capabilities
        self.capability_packages = capability_packages
        self.candidate_runner = candidate_runner
        self.operations = operations
        self.settings = settings
        self.management_asset_digest = management_asset_digest

    def inspect(
        self,
        agent_id: str = SUWEN_AGENT_ID,
        *,
        scheduler_running: bool,
        process_instance_id: str | None = None,
        persistent_manager: str | dict[str, Any] = "not_observed",
    ) -> dict[str, Any]:
        database = self.database.check()
        candidate_preflight = self.candidate_runner.preflight(agent_id)
        backups = self.operations.list_backups()
        release_rollback = self.operations.release_rollback_status(agent_id)
        stability = self.operations.stability_observation(agent_id, process_instance_id)
        management_e2e = self.operations.management_e2e_observation(
            agent_id,
            self.management_asset_digest,
        )
        persistent_manager_evidence = (
            persistent_manager
            if isinstance(persistent_manager, dict)
            else {
                "status": persistent_manager,
                "manager": None,
                "label": None,
            }
        )
        persistent_manager_status = str(persistent_manager_evidence.get("status", "not_observed"))
        with self.database.connect() as connection:
            agent = connection.execute(
                "SELECT id, status, active_version_id FROM agents WHERE id=?",
                (agent_id,),
            ).fetchone()
            current_version = connection.execute(
                """SELECT av.id, mpv.id AS model_profile_version_id,
                          av.prompt_bundle_version_id,
                          config_json, tool_schema_digest
                   FROM agent_versions av
                   JOIN agent_model_bindings binding ON binding.agent_id=av.agent_id
                   JOIN model_profile_versions mpv
                     ON mpv.id=(
                          SELECT current_model.id
                            FROM model_profile_versions current_model
                           WHERE current_model.model_profile_id=binding.model_profile_id
                           ORDER BY current_model.version DESC LIMIT 1
                        )
                   WHERE av.agent_id=?
                   ORDER BY CASE WHEN av.id=(SELECT active_version_id FROM agents WHERE id=?)
                                 THEN 0 ELSE 1 END,
                            av.version DESC
                   LIMIT 1""",
                (agent_id, agent_id),
            ).fetchone()
            setting = connection.execute(
                "SELECT value_json FROM system_settings WHERE key='default_agent_id'"
            ).fetchone()
            composition = self._composition_status(connection, current_version)
            source_bindings = self._source_binding_status(connection, current_version)
            connector_bindings = self._connector_binding_status(connection, current_version)
            native_status = self._native_candidate_status(connection, agent_id)
        default_agent_id = json.loads(setting["value_json"]) if setting else None
        model_version_id = current_version["model_profile_version_id"] if current_version else None
        if model_version_id:
            model_configuration = self.models.configuration_status(model_version_id)
            model_readiness = self.models.probe_readiness(model_version_id)
        else:
            model_configuration = {
                "status": "invalid",
                "findings": [{"code": "model_profile_version_missing", "level": "error"}],
            }
            model_readiness = {
                "status": "blocked",
                "finding": {"code": "model_probe_not_passed", "level": "error"},
                "probe": None,
            }

        layers = native_status["layers"]
        latest_attempt = native_status.get("latest_attempt")
        latest_attempt_status = latest_attempt.get("status") if latest_attempt else "not_run"
        model_finding_codes = [item["code"] for item in model_configuration["findings"]]
        model_next_action = next(
            (
                action
                for code, action in (
                    ("endpoint_ref_unresolved", "configure_model_endpoint"),
                    ("api_key_ref_unresolved", "configure_model_api_key"),
                )
                if code in model_finding_codes
            ),
            "inspect_model_configuration",
        )
        preflight_findings = candidate_preflight.get("findings", [])
        candidate_action_priority = (
            "model_endpoint_unresolved",
            "model_api_key_unresolved",
            "model_probe_not_passed",
            "model_probe_stale",
            "model_tool_calling_not_observed",
            "agent_not_published",
        )
        candidate_next_action = next(
            (
                item.get("next_action", "inspect_candidate_preflight")
                for code in candidate_action_priority
                for item in preflight_findings
                if item.get("code") == code
            ),
            (
                preflight_findings[0].get("next_action", "inspect_candidate_preflight")
                if preflight_findings
                else "run_frozen_candidate"
            ),
        )
        restorable_backups = [
            item for item in backups["items"] if item["restorable"] and item["mode"] == "0o600"
        ]

        checks = [
            self._check(
                "database_ready",
                "全新运行库与结构",
                database["ready"],
                ("DAT-001", "NFR-001", "RPL-001"),
                "repair_database",
                evidence={
                    "schema_version": database["schema_version"],
                    "quick_check": database["quick_check"],
                    "foreign_key_violations": database["foreign_key_violations"],
                },
            ),
            self._check(
                "native_suwen",
                "原生素问运行身份",
                bool(
                    agent
                    and agent["id"] == SUWEN_AGENT_ID
                    and default_agent_id == SUWEN_AGENT_ID
                    and not self.settings.enable_test_fixture_agent
                ),
                ("RPL-001", "RPL-008"),
                "initialize_native_suwen",
                evidence={
                    "agent_id": agent["id"] if agent else None,
                    "default_agent_id": default_agent_id,
                    "synthetic_fixture_mode": self.settings.enable_test_fixture_agent,
                    "old_runtime_data_import_supported": False,
                },
            ),
            self._check(
                "capability_contract",
                "当前 Agent 组合合同",
                composition["passed"],
                ("AGT-019–028", "RPL-003", "RPL-004"),
                "repair_capability_contract",
                evidence=composition["evidence"],
            ),
            self._check(
                "external_dependency_binding",
                "能力包外部依赖绑定",
                source_bindings["passed"],
                ("RDY-101", "COV-101", "A2"),
                "configure_external_dependency_binding",
                evidence=source_bindings["evidence"],
            ),
            self._check(
                "connector_binding",
                "Agent MCP Connector 绑定",
                connector_bindings["passed"],
                ("AGT-019–028", "COV-101", "A2"),
                "configure_agent_connector",
                evidence=connector_bindings["evidence"],
            ),
            self._check(
                "model_configuration",
                "Agent 所选模型独立配置",
                model_configuration["status"] == "valid",
                ("RPL-002", "MOD-001–022"),
                model_next_action,
                evidence={
                    "model_profile_version_id": model_version_id,
                    "status": model_configuration["status"],
                    "finding_codes": model_finding_codes,
                },
            ),
            self._check(
                "model_probe",
                "文本与工具调用双探针",
                model_readiness["status"] == "ready",
                ("RPL-002", "ACC-004"),
                "run_model_probe",
                status=("not_run" if not model_readiness.get("probe") else "blocked"),
                evidence={
                    "readiness": model_readiness["status"],
                    "probe_status": (
                        model_readiness["probe"].get("status") if model_readiness.get("probe") else "not_run"
                    ),
                    "finding_code": (
                        model_readiness["finding"].get("code") if model_readiness.get("finding") else None
                    ),
                },
            ),
            self._check(
                "agent_published",
                "素问精确版本发布",
                bool(agent and agent["status"] == "published" and agent["active_version_id"]),
                ("AGT-001–020", "RPL-005"),
                "validate_and_publish_agent",
                status="not_run" if agent and agent["status"] == "draft" else "blocked",
                evidence={
                    "agent_status": agent["status"] if agent else "missing",
                    "active_version_id": agent["active_version_id"] if agent else None,
                    "tool_schema_frozen": bool(current_version and current_version["tool_schema_digest"]),
                },
            ),
            self._check(
                "candidate_preflight",
                "候选零消耗预检",
                candidate_preflight["status"] == "ready",
                ("ACC-004", "RPL-005"),
                candidate_next_action,
                evidence={
                    "status": candidate_preflight["status"],
                    "finding_codes": [item["code"] for item in preflight_findings],
                    "model_calls": candidate_preflight["model_calls"],
                    "source_calls": candidate_preflight["source_calls"],
                    "external_writes": candidate_preflight["external_writes"],
                },
            ),
            self._check(
                "candidate_loaded",
                "固定候选加载精确版本",
                layers.get("P2", False),
                ("RPL-005", "ACC-005"),
                "run_frozen_candidate",
                status=self._candidate_status(latest_attempt_status),
                evidence={
                    "native_stage": "candidate_loaded",
                    "latest_attempt_status": latest_attempt_status,
                },
            ),
            self._check(
                "influence_observed",
                "技能与工具影响已观测",
                layers.get("P3", False),
                ("RPL-003", "RPL-004", "ACC-007"),
                "complete_candidate_review",
                status="not_run" if not layers.get("P2", False) else "blocked",
                evidence={"native_stage": "influence_observed"},
            ),
            self._check(
                "outcome_reviewed",
                "十类场景六维结果复核",
                layers.get("P5", False),
                ("RPL-007", "ACC-010"),
                "complete_candidate_review",
                status="not_run" if not layers.get("P2", False) else "blocked",
                evidence={
                    "native_stage": "outcome_reviewed",
                    "latest_attempt_status": latest_attempt_status,
                },
            ),
            self._check(
                "managed_backup",
                "可恢复受管备份",
                bool(restorable_backups),
                ("NFR-DEPLOY", "A7"),
                "create_managed_backup",
                status="not_run",
                evidence={
                    "restorable_backup_count": len(restorable_backups),
                    "secret_values_included": False,
                },
            ),
            self._check(
                "release_rollback_drill",
                "发布与回滚演练",
                release_rollback["passed"],
                ("NFR-RELIABILITY", "A7"),
                "perform_release_rollback_drill",
                status=release_rollback["status"],
                evidence=release_rollback["evidence"],
            ),
            self._check(
                "scheduler_running",
                "调度器进程加载",
                scheduler_running,
                ("NFR-RELIABILITY", "A2"),
                "start_suwen_service",
                status="not_observed",
                evidence={"running": scheduler_running},
            ),
            self._check(
                "capture_safety",
                "本地渠道零真实外发",
                self.settings.feishu.sender == "capture",
                ("CHN-011", "ACC-009"),
                "restore_capture_sender",
                evidence={
                    "sender_mode": self.settings.feishu.sender,
                    "external_write_budget": 0,
                },
            ),
            self._check(
                "persistent_process",
                "持久进程宿主",
                persistent_manager_status == "observed",
                ("NFR-DEPLOY", "A7"),
                "select_persistent_manager",
                status=persistent_manager_status,
                requires_authorization=persistent_manager_status != "observed",
                evidence=persistent_manager_evidence,
            ),
            self._check(
                "stability_observed",
                "同一进程两次间隔健康观测",
                stability["passed"],
                ("NFR-RELIABILITY", "A7"),
                "observe_interval_health",
                status=stability["status"],
                evidence=stability["evidence"],
            ),
            self._check(
                "management_e2e",
                "管理端真实操作流程",
                management_e2e["passed"],
                ("PRD-004", "PRD-009", "A7"),
                "run_management_e2e",
                status=management_e2e["status"],
                evidence=management_e2e["evidence"],
            ),
        ]
        source_observed = native_status["source_state"] == "source_observed"
        source_layer_passed = layers.get("P4", False)
        external_gates = [
            {
                "id": "source_observation",
                "name": "真实只读来源作用链",
                "status": (
                    "passed" if source_layer_passed else "blocked" if source_observed else "not_authorized"
                ),
                "passed": source_layer_passed,
                "requirement_ids": ["RPL-006", "A4"],
                "requires_authorization": not source_observed,
                "next_action": (
                    None
                    if source_layer_passed
                    else "complete_candidate_review"
                    if source_observed
                    else "authorize_read_only_source"
                ),
                "evidence": {"source_state": native_status["source_state"]},
            },
            {
                "id": "real_channel",
                "name": "真实渠道传输",
                "status": "not_authorized",
                "passed": False,
                "requirement_ids": ["A6", "ACC-009"],
                "requires_authorization": True,
                "next_action": "authorize_test_channel",
                "evidence": {"capture_contract_passed": self.settings.feishu.sender == "capture"},
            },
            {
                "id": "git_and_deployment",
                "name": "Git 与生产部署",
                "status": "not_authorized",
                "passed": False,
                "requirement_ids": ["A7", "ACC-009"],
                "requires_authorization": True,
                "next_action": "authorize_git_and_deployment",
                "evidence": {"runtime_observation": "not_available"},
            },
        ]
        blocking = [
            item
            for item in checks
            if item["id"] in DELIVERY_BLOCKING_CHECK_IDS and not item["passed"]
        ]
        advisory = [
            item
            for item in checks
            if item["id"] not in DELIVERY_BLOCKING_CHECK_IDS and not item["passed"]
        ]
        delivery_complete = not blocking
        if delivery_complete:
            status = "delivery_complete"
        elif model_configuration["status"] != "valid":
            status = "model_configuration_required"
        elif model_readiness["status"] != "ready":
            status = "model_probe_required"
        elif not (agent and agent["status"] == "published"):
            status = "agent_publish_required"
        else:
            status = "delivery_blocked"
        next_actions: list[dict[str, Any]] = []
        seen_actions: set[str] = set()
        for item in blocking:
            action = item["next_action"]
            if not action or action in seen_actions:
                continue
            seen_actions.add(action)
            next_actions.append(
                {
                    "check_id": item["id"],
                    "action": action,
                    "requires_authorization": item["requires_authorization"],
                }
            )
        return {
            "schema_version": "suwen-delivery-preflight.v1",
            "observed_at": iso(),
            "agent_id": agent_id,
            "scope": "local_authorized",
            "status": status,
            "highest_observed_layer": native_status["highest_observed_layer"],
            "candidate_ready": candidate_preflight["status"] == "ready",
            "delivery_complete": delivery_complete,
            "checks": checks,
            "blocking_check_ids": [item["id"] for item in blocking],
            "advisory_check_ids": [item["id"] for item in advisory],
            "immediate_next_action": next_actions[0] if next_actions else None,
            "next_actions": next_actions,
            "external_gates": external_gates,
            "native_readiness": native_status,
            "candidate_preflight": candidate_preflight,
            "claims": {
                "preflight_external_writes": 0,
                "old_runtime_data_import_supported": False,
                "production_deployment": "not_inferred",
            },
        }

    @staticmethod
    def _source_binding_status(connection: Any, version: Any | None) -> dict[str, Any]:
        """Report declared logical dependencies without claiming source health."""

        if not version:
            return {
                "passed": False,
                "evidence": {
                    "required": True,
                    "dependency_count": 0,
                    "bound_count": 0,
                    "source_outcome": "not_observed",
                    "reason": "agent_version_missing",
                    "dependencies": [],
                },
            }
        rows = connection.execute(
            """SELECT cpv.manifest_json
               FROM agent_version_capabilities avc
               JOIN capability_package_versions cpv ON cpv.id=avc.capability_version_id
               WHERE avc.agent_version_id=? AND avc.enabled=1
               ORDER BY avc.position, cpv.id""",
            (version["id"],),
        ).fetchall()
        declared: dict[tuple[str, str], None] = {}
        for row in rows:
            manifest = json.loads(row["manifest_json"] or "{}")
            for dependency in manifest.get("external_dependencies") or []:
                if not isinstance(dependency, dict):
                    continue
                dependency_id = dependency.get("id")
                contract = dependency.get("contract")
                if isinstance(dependency_id, str) and isinstance(contract, str):
                    declared[(dependency_id, contract)] = None
        dependencies: list[dict[str, Any]] = []
        for dependency_id, contract in sorted(declared):
            binding = connection.execute(
                """SELECT generation, version, allowed_subcommands_json, configured_at
                   FROM external_dependency_bindings
                   WHERE dependency_id=? AND contract=? AND active=1
                   ORDER BY generation DESC LIMIT 1""",
                (dependency_id, contract),
            ).fetchone()
            dependencies.append(
                {
                    "id": dependency_id,
                    "contract": contract,
                    "binding_state": "active" if binding else "missing",
                    "generation": int(binding["generation"]) if binding else None,
                    "version_observed": bool(binding and binding["version"]),
                    "allowed_subcommand_count": (
                        len(json.loads(binding["allowed_subcommands_json"])) if binding else 0
                    ),
                    "configured_at": binding["configured_at"] if binding else None,
                }
            )
        required = bool(dependencies)
        bound_count = sum(item["binding_state"] == "active" for item in dependencies)
        return {
            # A neutral Agent has no external dependency and is valid. Native
            # source capability composition requires every declared logical binding.
            "passed": not required or bound_count == len(dependencies),
            "evidence": {
                "required": required,
                "dependency_count": len(dependencies),
                "bound_count": bound_count,
                "source_outcome": "not_observed",
                "binding_proves_source_access": False,
                "dependencies": dependencies,
            },
        }

    def _connector_binding_status(self, connection: Any, version: Any | None) -> dict[str, Any]:
        """Verify exact or compatible current catalogs without claiming source access."""

        if not version:
            return {
                "passed": False,
                "evidence": {
                    "required": True,
                    "connector_count": 0,
                    "ready_count": 0,
                    "source_outcome": "not_observed",
                    "reason": "agent_version_missing",
                    "connectors": [],
                },
            }
        try:
            config = json.loads(version["config_json"] or "{}")
        except json.JSONDecodeError:
            config = {}
        raw_bindings = config.get("connector_bindings", [])
        if not isinstance(raw_bindings, list):
            raw_bindings = []
        connectors: list[dict[str, Any]] = []
        resolution_error: str | None = None
        try:
            resolution = resolve_connector_bindings(
                connection,
                self.capabilities.tools,
                raw_bindings,
                normalize=False,
            )
        except ValueError as exc:
            resolution_error = str(exc)
            resolution = None
        if resolution is not None:
            connectors = [
                {
                    "id": item["provider_id"],
                    "binding_state": "ready",
                    "provider_type": item["provider_type"],
                    "status": "connected",
                    "binding_generation": item["binding_generation"],
                    "catalog_matches": item["catalog_state"] == "exact",
                    "catalog_compatible": True,
                    "catalog_state": item["catalog_state"],
                    "configured_schema_digest": item["configured_schema_digest"],
                    "schema_digest": item["schema_digest"],
                    "catalog_observed": True,
                }
                for item in resolution.provenance
            ]
        else:
            connectors = [
                {
                    "id": binding.get("provider_id"),
                    "binding_state": "blocked",
                    "catalog_matches": False,
                    "catalog_compatible": False,
                    "catalog_state": "breaking_or_unavailable",
                    "catalog_observed": False,
                    "reason": resolution_error,
                }
                for binding in raw_bindings
                if isinstance(binding, dict)
            ]
        required = bool(raw_bindings)
        ready_count = sum(item["binding_state"] == "ready" for item in connectors)
        return {
            "passed": not required or ready_count == len(raw_bindings),
            "evidence": {
                "required": required,
                "connector_count": len(raw_bindings),
                "ready_count": ready_count,
                "source_outcome": "not_observed",
                "binding_proves_source_access": False,
                "connectors": connectors,
            },
        }

    @staticmethod
    def _native_candidate_status(connection: Any, agent_id: str) -> dict[str, Any]:
        row = connection.execute(
            """SELECT * FROM candidate_attempts WHERE agent_id=?
               ORDER BY created_at DESC LIMIT 1""",
            (agent_id,),
        ).fetchone()
        latest = dict(row) if row else None
        scorecard = json.loads(latest.pop("scorecard_json") or "{}") if latest else {}
        if latest:
            latest["scorecard"] = scorecard
            latest["manifest"] = json.loads(latest.pop("manifest_json") or "{}")
            latest["pack_digests"] = json.loads(latest.pop("pack_digests_json") or "[]")
        claims = scorecard.get("claims", {}) if isinstance(scorecard, dict) else {}
        candidate_loaded = bool(latest and claims.get("candidate_loaded"))
        influence_observed = bool(candidate_loaded and claims.get("influence_observed"))
        outcome_reviewed = bool(
            influence_observed
            and latest
            and latest["status"] == "outcome_reviewed"
            and claims.get("outcome_reviewed")
        )
        source_count = int(
            connection.execute(
                """SELECT COUNT(DISTINCT e.id) FROM evidence e
                   JOIN runs r ON r.id=e.run_id
                   JOIN agent_versions av ON av.id=r.agent_version_id
                   JOIN run_external_dependencies red ON red.run_id=r.id
                   WHERE av.agent_id=? AND e.state IN ('observed','zero_matches','conflict')
                     AND e.source_role='current_observation'
                     AND red.call_count > 0
                     AND instr(COALESCE(e.source_ref, ''), ':' || red.dependency_id) > 0""",
                (agent_id,),
            ).fetchone()[0]
        )
        layers = {
            "P2": candidate_loaded,
            "P3": influence_observed,
            "P4": bool(influence_observed and source_count),
            "P5": outcome_reviewed,
        }
        highest = next((key for key in ("P5", "P4", "P3", "P2") if layers[key]), "none")
        return {
            "highest_observed_layer": highest,
            "layers": layers,
            "source_state": "source_observed" if source_count else "source_gated",
            "latest_attempt": latest,
        }

    def _composition_status(
        self,
        connection: Any,
        version: Any | None,
    ) -> dict[str, Any]:
        """Read-only validation for the exact Agent Version shown by preflight."""

        if not version:
            return {
                "passed": False,
                "evidence": {"reason": "agent_version_missing"},
            }
        prompt = connection.execute(
            "SELECT content_json FROM prompt_bundle_versions WHERE id=?",
            (version["prompt_bundle_version_id"],),
        ).fetchone()
        if not prompt:
            return {
                "passed": False,
                "evidence": {
                    "agent_version_id": version["id"],
                    "reason": "prompt_bundle_version_missing",
                },
            }
        pack_rows = connection.execute(
            """SELECT cpv.id, cpv.pack_id, cpv.version, cpv.digest
               FROM agent_version_packs avp
               JOIN capability_pack_versions cpv ON cpv.id=avp.pack_version_id
               WHERE avp.agent_version_id=? AND avp.enabled=1
               ORDER BY avp.position, cpv.id""",
            (version["id"],),
        ).fetchall()
        if not pack_rows:
            return {
                "passed": False,
                "evidence": {
                    "agent_version_id": version["id"],
                    "reason": "agent_pack_binding_missing",
                },
            }
        pack_refs = [
            {
                "pack_version_id": row["id"],
                "pack_id": row["pack_id"],
                "version": row["version"],
                "digest": row["digest"],
            }
            for row in pack_rows
        ]
        capability_rows = connection.execute(
            """SELECT capability_version_id, role, position
               FROM agent_version_capabilities
               WHERE agent_version_id=? AND enabled=1
               ORDER BY position, capability_version_id""",
            (version["id"],),
        ).fetchall()
        bindings = [
            CapabilityBinding(
                str(row["capability_version_id"]),
                str(row["role"]),
                int(row["position"]),
            )
            for row in capability_rows
        ]
        try:
            surface = compose_agent_surface(
                packs=self.capabilities.packs,
                runtime_tools=self.capabilities.tools,
                capability_packages=self.capability_packages,
                pack_refs=pack_refs,
                capability_bindings=bindings,
                prompt_content_json=str(prompt["content_json"]),
            )
            config = json.loads(version["config_json"] or "{}")
            allowlist = config.get("tool_allowlist", [])
            if not isinstance(allowlist, list) or not all(isinstance(item, str) for item in allowlist):
                raise AgentCompositionError("Agent Tool allowlist is invalid")
            # The first-party composition contains Pack/Capability Tools, while
            # Connector Tools are process-loaded and frozen independently in
            # the Agent config.  Validate the same combined surface that the
            # Runtime resolves for a real Run; otherwise a healthy MCP-backed
            # Agent is falsely rejected as soon as its allowlist contains a
            # Connector Tool.
            connector_resolution = resolve_connector_bindings(
                connection,
                self.capabilities.tools,
                config.get("connector_bindings"),
                normalize=False,
            )
            combined_tools = ToolRegistry()
            combined_tools.merge_from(surface.tools)
            baseline_digest = published_tool_baseline_digest(
                surface.tools,
                connector_resolution,
                allowlist,
            )
            combined_tools.merge_from(connector_resolution.tools)
            effective_allowlist = effective_connector_allowlist(allowlist, connector_resolution)
            selected = combined_tools.subset(effective_allowlist)
            frozen = version["tool_schema_digest"]
            if frozen and frozen != baseline_digest:
                raise AgentCompositionError("Agent Tool schema digest has drifted")
        except (AgentCompositionError, KeyError, ValueError, RuntimeError) as exc:
            return {
                "passed": False,
                "evidence": {
                    "agent_version_id": version["id"],
                    "reason": "agent_composition_invalid",
                    "detail": str(exc),
                },
            }
        return {
            "passed": True,
            "evidence": {
                "agent_version_id": version["id"],
                "prompt_bundle_version_id": version["prompt_bundle_version_id"],
                "pack_count": len(pack_rows),
                "native_capability_count": len(bindings),
                "skill_count": len(surface.skills.list()),
                "tool_count": len(selected.names()),
                "composition_digest": surface.digest,
                "tool_schema_frozen": bool(version["tool_schema_digest"]),
                "connector_catalog_state": (
                    "compatible_update" if connector_resolution.catalog_changed else "exact"
                ),
            },
        }

    @staticmethod
    def _check(
        check_id: str,
        name: str,
        passed: bool,
        requirement_ids: tuple[str, ...],
        next_action: str,
        *,
        status: str = "blocked",
        requires_authorization: bool = False,
        evidence: dict[str, Any],
    ) -> dict[str, Any]:
        return {
            "id": check_id,
            "name": name,
            "status": "passed" if passed else status,
            "passed": bool(passed),
            "requirement_ids": list(requirement_ids),
            "requires_authorization": requires_authorization,
            "next_action": None if passed else next_action,
            "evidence": evidence,
        }

    @staticmethod
    def _candidate_status(latest_attempt_status: str) -> str:
        if latest_attempt_status in {
            "contract_failed",
            "interrupted",
            "preflight_blocked",
            "review_rejected",
        }:
            return "failed"
        return "not_run"


def build_delivery_preflight(settings: Settings) -> DeliveryPreflight:
    """Build the offline preflight without runtime recovery or catalog writes."""

    database = Database(
        settings.database_path,
        enable_test_fixture_agent=settings.enable_test_fixture_agent,
    )
    if not database.check()["ready"]:
        raise RuntimeError("delivery preflight requires an initialized current database")
    tools = ToolRegistry()
    # Reconstruct the exact Runtime-owned Tool schemas without instantiating
    # ArtifactStore or Repository handlers.  Delivery preflight is read-only,
    # but its composition validation must still understand every frozen core
    # Tool in the active Agent Version.
    def contract_only_handler(_arguments: dict[str, Any]) -> Any:
        raise RuntimeError("contract-only Tool handler cannot execute")

    tools.register(artifact_continuation_tool_definition(), contract_only_handler)
    tools.register(diagram_tool_definition(), contract_only_handler)
    tools.register(case_recall_tool_definition(), contract_only_handler)
    installed = database.installed_pack_digests()
    packs = PackRegistry.load(
        settings.packs_dir,
        tools,
        trusted_local_pack_refs=settings.trusted_local_pack_refs,
        allowed_pack_refs=installed,
        expected_digests=installed,
    )
    packs.skills.register_reference_tools(tools)
    models = ModelRegistry(database)
    capabilities = CapabilityRegistry(database, packs, tools)
    candidate_runner = CandidateRunner(
        settings,
        database=database,
        initialize_database=False,
    )
    operations = OperationsView(database, settings.data_dir)
    capability_packages = CapabilityPackageRegistry(
        database,
        settings.data_dir / "capability-packages",
    )
    return DeliveryPreflight(
        database,
        models,
        capabilities,
        capability_packages,
        candidate_runner,
        operations,
        settings,
        management_web_asset_digest(
            bundled_web_root(),
            (
                bundled_investigation_glossary(),
                bundled_investigation_glossary_assets_root() / "suwen-overall-concept.png",
                bundled_investigation_glossary_assets_root() / "suwen-entity-relationships.png",
            ),
        ),
    )
