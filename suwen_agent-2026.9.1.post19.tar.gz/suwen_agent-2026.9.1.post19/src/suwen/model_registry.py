from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import sqlite3
import struct
import time
import uuid
import zlib
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx

from .config import (
    DEFAULT_MODEL_REASONING_EFFORT,
    MODEL_REASONING_EFFORTS,
    ModelConfig,
    _environment_value,
)
from .db import Database
from .models import ModelProtocolError, OpenAICompatibleProvider
from .repository import iso, new_id
from .types import ToolDefinition, ToolRisk

_STABLE_ID = re.compile(r"^[a-z][a-z0-9-]{1,63}$")
_SUPPORTED_PROTOCOLS = {"openai-compatible", "stub"}
_PROBE_STALE_SECONDS = 24 * 60 * 60
_PROBE_TOOL_NAME = "suwen_probe"
_MODEL_CATALOG_TIMEOUT_SECONDS = 20.0
_MODEL_CAPABILITY_KEYS = (
    "tool_calling",
    "vision",
    "structured_output",
    "local",
)
_STRUCTURED_PROBE_FORMAT = {
    "type": "json_schema",
    "json_schema": {
        "name": "suwen_structured_probe",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "status": {"type": "string", "enum": ["OK"]},
                "count": {"type": "integer"},
            },
            "required": ["status", "count"],
            "additionalProperties": False,
        },
    },
}


class ModelCatalogDiscoveryError(RuntimeError):
    def __init__(self, category: str, message: str):
        super().__init__(message)
        self.category = category


def _digest(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _json(value: str | None, fallback: Any) -> Any:
    if value is None:
        return fallback
    return json.loads(value)


def model_capabilities(value: Any) -> dict[str, Any]:
    """Project Runtime-consumed capabilities and hide retired legacy flags."""

    parsed = _json(value, {}) if isinstance(value, str) or value is None else value
    if not isinstance(parsed, dict):
        return {}
    return {key: parsed[key] for key in _MODEL_CAPABILITY_KEYS if key in parsed}


def _synthetic_vision_data_uri() -> str:
    width = height = 64
    pixels = bytearray([255] * width * height * 3)

    def darken(x: int, y: int, radius: int = 2) -> None:
        for observed_y in range(max(0, y - radius), min(height, y + radius + 1)):
            for observed_x in range(max(0, x - radius), min(width, x + radius + 1)):
                offset = (observed_y * width + observed_x) * 3
                pixels[offset : offset + 3] = b"\x00\x00\x00"

    for y in range(8, 56):
        darken(15, y)
    for step in range(34):
        darken(17 + step, 31 - (step * 23 // 33))
        darken(17 + step, 32 + (step * 23 // 33))
    scanlines = b"".join(
        b"\x00" + bytes(pixels[y * width * 3 : (y + 1) * width * 3]) for y in range(height)
    )

    def chunk(kind: bytes, payload: bytes) -> bytes:
        return (
            struct.pack(">I", len(payload))
            + kind
            + payload
            + struct.pack(">I", zlib.crc32(kind + payload) & 0xFFFFFFFF)
        )

    png = (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(scanlines, level=9))
        + chunk(b"IEND", b"")
    )
    return "data:image/png;base64," + base64.b64encode(png).decode("ascii")


def _contains_sensitive_key(value: Any) -> bool:
    if isinstance(value, dict):
        for key, item in value.items():
            normalized = str(key).lower().replace("-", "_")
            if any(marker in normalized for marker in ("api_key", "token", "secret", "password")):
                return True
            if _contains_sensitive_key(item):
                return True
    if isinstance(value, list):
        return any(_contains_sensitive_key(item) for item in value)
    return False


class SecretResolver:
    """Resolve configured references without returning values through management views."""

    def __init__(self, database: Database):
        self.database = database

    def resolve(self, ref_id: str, *, required: bool = True) -> str:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT resolver, locator FROM secret_refs WHERE id=?", (ref_id,)
            ).fetchone()
        if not row:
            raise KeyError(ref_id)
        if row["resolver"] == "env":
            value = _environment_value(row["locator"])
        elif row["resolver"] == "private_file":
            try:
                value = self._private_path(row["locator"]).read_text(encoding="utf-8").strip()
            except OSError:
                value = ""
        else:
            raise ValueError(f"unsupported Secret Ref resolver: {row['resolver']}")
        if required and not value:
            raise ValueError(f"Secret Ref {ref_id!r} is not resolvable")
        return value

    def metadata(self, ref_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT id, name, resolver, status, version, created_at,
                          updated_at, last_verified_at, locator
                   FROM secret_refs WHERE id=?""",
                (ref_id,),
            ).fetchone()
        if not row:
            raise KeyError(ref_id)
        result = dict(row)
        locator = result.pop("locator")
        result["configured"] = self.configured(result["resolver"], locator)
        return result

    def configured(self, resolver: str, locator: str) -> bool:
        if resolver == "env":
            return bool(_environment_value(locator))
        if resolver == "private_file":
            try:
                return self._private_path(locator).stat().st_size > 0
            except (FileNotFoundError, ValueError):
                return False
        return False

    @property
    def private_root(self) -> Path:
        return (self.database.path.parent / "secrets").resolve()

    @property
    def private_write_root(self) -> Path:
        database_identity = hashlib.sha256(str(self.database.path.resolve()).encode("utf-8")).hexdigest()[:16]
        return self.private_root / "databases" / database_identity

    def _private_path(self, locator: str) -> Path:
        root = self.private_root
        target = (root / locator).resolve()
        try:
            target.relative_to(root)
        except ValueError as exc:
            raise ValueError("Secret Ref private path escapes the data directory") from exc
        return target

    def store_private_values(
        self,
        values: dict[str, str],
        actor: str,
        *,
        replace: bool = False,
    ) -> dict[str, dict[str, Any]]:
        if (
            not values
            or any(not isinstance(value, str) or not value for value in values.values())
            or any(len(value.encode("utf-8")) > 64 * 1024 for value in values.values())
        ):
            raise ValueError("private Secret Ref values must be non-empty")
        root = self.private_root
        root.mkdir(mode=0o700, parents=True, exist_ok=True)
        root.chmod(0o700)
        namespace_root = self.private_write_root.parent
        namespace_root.mkdir(mode=0o700, parents=True, exist_ok=True)
        namespace_root.chmod(0o700)
        write_root = self.private_write_root
        write_root.mkdir(mode=0o700, parents=True, exist_ok=True)
        write_root.chmod(0o700)
        with self.database.connect() as connection:
            refs = {
                row["id"]: dict(row)
                for row in connection.execute(
                    f"""SELECT id, resolver, locator, version FROM secret_refs
                        WHERE id IN ({",".join("?" for _ in values)})""",
                    tuple(values),
                ).fetchall()
            }
        missing = set(values) - set(refs)
        if missing:
            raise KeyError(sorted(missing)[0])
        changed: dict[str, tuple[int, Path]] = {}
        for ref_id, row in refs.items():
            current_value = ""
            if row["resolver"] == "env":
                current_value = _environment_value(row["locator"])
            elif row["resolver"] == "private_file":
                try:
                    current_value = self._private_path(row["locator"]).read_text(encoding="utf-8")
                except OSError:
                    current_value = ""
            if current_value == values[ref_id]:
                continue
            if current_value and not replace:
                raise FileExistsError(f"private Secret Ref {ref_id!r} already has a value")
            next_version = int(row["version"]) + 1
            relative_target = write_root.relative_to(root) / f"{ref_id}.v{next_version}.secret"
            changed[ref_id] = (
                next_version,
                self._private_path(relative_target.as_posix()),
            )
        created: list[Path] = []
        try:
            for ref_id, (_next_version, target) in changed.items():
                if target.exists():
                    raise FileExistsError(f"Secret Ref version target already exists: {ref_id}")
                partial = target.parent / f".{target.name}.{new_id('partial')}"
                descriptor = os.open(partial, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                try:
                    with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                        handle.write(values[ref_id])
                        handle.flush()
                        os.fsync(handle.fileno())
                        os.fchmod(handle.fileno(), 0o600)
                except BaseException:
                    partial.unlink(missing_ok=True)
                    raise
                partial.replace(target)
                target.chmod(0o600)
                created.append(target)
            with self.database.connect() as connection:
                connection.execute("BEGIN IMMEDIATE")
                at = iso()
                for ref_id, (next_version, target) in changed.items():
                    updated = connection.execute(
                        """UPDATE secret_refs SET resolver='private_file', locator=?,
                           status='unverified', version=?, updated_at=?
                           WHERE id=? AND version=?""",
                        (
                            target.relative_to(root).as_posix(),
                            next_version,
                            at,
                            ref_id,
                            refs[ref_id]["version"],
                        ),
                    ).rowcount
                    if updated != 1:
                        raise RuntimeError("Secret Ref changed concurrently")
                    ModelRegistry._audit(
                        connection,
                        actor,
                        (
                            "secret_ref.private_value_rotated"
                            if refs[ref_id]["resolver"] == "private_file"
                            or _environment_value(refs[ref_id]["locator"])
                            else "secret_ref.private_value_stored"
                        ),
                        "secret_ref",
                        ref_id,
                        target_version=str(next_version),
                        metadata={"previous_version": refs[ref_id]["version"]},
                    )
                connection.commit()
        except BaseException:
            for target in created:
                target.unlink(missing_ok=True)
            raise
        return {ref_id: self.metadata(ref_id) for ref_id in values}


class ModelRegistry:
    def __init__(self, database: Database):
        self.database = database
        self.secrets = SecretResolver(database)

    @staticmethod
    def _stable_id(value: str) -> str:
        value = value.strip()
        if not _STABLE_ID.fullmatch(value):
            raise ValueError("id must use 2-64 lowercase letters, digits, or hyphens")
        return value

    @staticmethod
    def _audit(
        connection: sqlite3.Connection,
        actor: str,
        action: str,
        target_type: str,
        target_id: str,
        *,
        target_version: str | None = None,
        before_digest: str | None = None,
        after_digest: str | None = None,
        result: str = "succeeded",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        connection.execute(
            """INSERT INTO audit_events(
               actor_type, actor_ref, action, target_type, target_id,
               target_version, before_digest, after_digest, result,
               metadata_json, created_at
            ) VALUES ('admin', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                actor,
                action,
                target_type,
                target_id,
                target_version,
                before_digest,
                after_digest,
                result,
                json.dumps(metadata or {}, ensure_ascii=False),
                iso(),
            ),
        )

    def create_secret_ref(
        self,
        ref_id: str,
        name: str,
        env_name: str,
        actor: str,
    ) -> dict[str, Any]:
        ref_id = self._stable_id(ref_id)
        if not re.fullmatch(r"[A-Z][A-Z0-9_]{2,127}", env_name):
            raise ValueError("env_name must be an uppercase environment variable name")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """INSERT INTO secret_refs(
                   id, name, resolver, locator, status, created_at, updated_at
                ) VALUES (?, ?, 'env', ?, 'unverified', ?, ?)""",
                (ref_id, name.strip(), env_name, at, at),
            )
            self._audit(connection, actor, "secret_ref.created", "secret_ref", ref_id)
            connection.commit()
        return self.secrets.metadata(ref_id)

    def list_providers(self) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                """SELECT p.*,
                          (SELECT COUNT(*) FROM model_profiles mp
                            WHERE mp.provider_id=p.id AND mp.status<>'archived')
                            AS profile_count
                   FROM model_providers p
                   WHERE p.status<>'archived' ORDER BY p.id"""
            ).fetchall()
        return [self.get_provider(row["id"]) for row in rows]

    def list_providers_page(self, limit: int = 50, offset: int = 0) -> dict[str, Any]:
        limit = max(1, min(limit, 500))
        offset = max(0, min(offset, 1_000_000))
        with self.database.connect() as connection:
            total = int(
                connection.execute(
                    "SELECT COUNT(*) FROM model_providers WHERE status<>'archived'"
                ).fetchone()[0]
            )
            rows = connection.execute(
                """SELECT id FROM model_providers
                   WHERE status<>'archived' ORDER BY id LIMIT ? OFFSET ?""",
                (limit, offset),
            ).fetchall()
        items = [self.get_provider(row["id"]) for row in rows]
        return {
            "items": items,
            "page": {
                "total": total,
                "limit": limit,
                "offset": offset,
                "has_previous": offset > 0,
                "has_next": offset + len(items) < total,
            },
        }

    def get_provider(self, provider_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            provider = connection.execute(
                "SELECT * FROM model_providers WHERE id=?", (provider_id,)
            ).fetchone()
            versions = connection.execute(
                """SELECT id, provider_id, version, endpoint_ref, secret_ref_id,
                          config_json, digest, created_by, created_at
                   FROM model_provider_versions WHERE provider_id=? ORDER BY version DESC""",
                (provider_id,),
            ).fetchall()
            profile_count = connection.execute(
                """SELECT COUNT(*) FROM model_profiles
                   WHERE provider_id=? AND status<>'archived'""",
                (provider_id,),
            ).fetchone()[0]
        if not provider:
            raise KeyError(provider_id)
        result = dict(provider)
        result["profile_count"] = profile_count
        result["versions"] = []
        for row in versions:
            item = dict(row)
            item["config"] = _json(item.pop("config_json"), {})
            endpoint_ref = item["endpoint_ref"]
            secret_ref = item["secret_ref_id"]
            if endpoint_ref:
                endpoint = self.secrets.metadata(endpoint_ref)
                endpoint["value"] = self.secrets.resolve(endpoint_ref, required=False)
                item["endpoint"] = endpoint
            else:
                item["endpoint"] = None
            item["secret"] = self.secrets.metadata(secret_ref) if secret_ref else None
            result["versions"].append(item)
        return result

    async def discover_provider_models(
        self,
        provider_id: str,
        actor: str,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> dict[str, Any]:
        provider = self.get_provider(provider_id)
        if provider["protocol"] != "openai-compatible":
            raise ModelCatalogDiscoveryError(
                "protocol",
                "当前连接协议不支持读取模型目录。",
            )
        version = provider["versions"][0]
        try:
            base_url = self.secrets.resolve(version["endpoint_ref"])
            api_key = (
                self.secrets.resolve(version["secret_ref_id"])
                if version["secret_ref_id"]
                else ""
            )
            config = ModelConfig(
                provider="openai-compatible",
                base_url=base_url,
                api_key_env="SUWEN_MODEL_API_KEY_UNUSED",
                api_key_value=api_key,
                timeout_seconds=_MODEL_CATALOG_TIMEOUT_SECONDS,
            )
            client = OpenAICompatibleProvider(config, transport=transport)
        except (KeyError, ValueError) as exc:
            raise ModelCatalogDiscoveryError(
                "configuration",
                "模型连接配置不完整，无法读取模型目录。",
            ) from exc
        try:
            model_ids, truncated = await client.list_models()
        except httpx.HTTPStatusError as exc:
            category = "authentication" if exc.response.status_code in {401, 403} else "protocol"
            message = (
                "模型目录鉴权失败，请检查 API Key。"
                if category == "authentication"
                else "模型服务拒绝了目录请求，请检查 Endpoint 与协议兼容性。"
            )
            raise ModelCatalogDiscoveryError(category, message) from exc
        except httpx.RequestError as exc:
            raise ModelCatalogDiscoveryError(
                "network",
                "无法连接模型服务，请检查 Endpoint 与网络。",
            ) from exc
        except ModelProtocolError as exc:
            raise ModelCatalogDiscoveryError(
                "protocol",
                "模型目录响应不符合 OpenAI-compatible 协议。",
            ) from exc
        finally:
            await client.close()
        with self.database.connect() as connection:
            self._audit(
                connection,
                actor,
                "model_provider.models_discovered",
                "model_provider",
                provider_id,
                target_version=str(version["version"]),
                metadata={"count": len(model_ids), "truncated": truncated},
            )
            connection.commit()
        return {
            "provider_id": provider_id,
            "provider_version_id": version["id"],
            "protocol": provider["protocol"],
            "items": [{"id": model_id} for model_id in model_ids],
            "truncated": truncated,
        }

    def create_provider_from_values(
        self,
        provider_id: str,
        name: str,
        protocol: str,
        endpoint: str,
        api_key: str | None,
        actor: str,
        *,
        status: str = "draft",
    ) -> dict[str, Any]:
        provider_id = self._stable_id(provider_id)
        with self.database.connect() as connection:
            if connection.execute(
                "SELECT 1 FROM model_providers WHERE id=?", (provider_id,)
            ).fetchone():
                raise ValueError("model Provider already exists")
        endpoint_ref = self._materialize_provider_value(name, "endpoint", endpoint, actor)
        secret_ref_id = (
            self._materialize_provider_value(name, "api-key", api_key, actor)
            if api_key
            else None
        )
        return self.create_provider(
            provider_id,
            name,
            protocol,
            endpoint_ref,
            secret_ref_id,
            {},
            actor,
            status=status,
        )

    def create_provider_version_from_values(
        self,
        provider_id: str,
        *,
        name: str | None,
        protocol: str | None,
        endpoint: str,
        api_key: str | None,
        actor: str,
    ) -> dict[str, Any]:
        current = self.get_provider(provider_id)
        current_version = current["versions"][0]
        endpoint_ref = self._reuse_or_materialize_provider_value(
            current_version.get("endpoint_ref"),
            name or current["name"],
            "endpoint",
            endpoint,
            actor,
        )
        secret_ref_id = current_version.get("secret_ref_id")
        if api_key:
            secret_ref_id = self._reuse_or_materialize_provider_value(
                secret_ref_id,
                name or current["name"],
                "api-key",
                api_key,
                actor,
            )
        return self.create_provider_version(
            provider_id,
            name=name,
            protocol=protocol,
            endpoint_ref=endpoint_ref,
            secret_ref_id=secret_ref_id,
            config={},
            actor=actor,
        )

    def _reuse_or_materialize_provider_value(
        self,
        current_ref: str | None,
        provider_name: str,
        purpose: str,
        value: str,
        actor: str,
    ) -> str:
        if current_ref:
            try:
                if self.secrets.resolve(current_ref, required=False) == value:
                    return current_ref
            except (KeyError, ValueError):
                pass
        return self._materialize_provider_value(provider_name, purpose, value, actor)

    def _materialize_provider_value(
        self,
        provider_name: str,
        purpose: str,
        value: str,
        actor: str,
    ) -> str:
        suffix = uuid.uuid4().hex
        ref_id = f"managed-{suffix}"
        self.create_secret_ref(
            ref_id,
            f"{provider_name.strip()} {purpose} {suffix[:8]}",
            f"SUWEN_MANAGED_SECRET_{suffix.upper()}",
            actor,
        )
        self.secrets.store_private_values({ref_id: value}, actor)
        return ref_id

    def create_provider(
        self,
        provider_id: str,
        name: str,
        protocol: str,
        endpoint_ref: str,
        secret_ref_id: str | None,
        config: dict[str, Any],
        actor: str,
        *,
        status: str = "draft",
    ) -> dict[str, Any]:
        provider_id = self._stable_id(provider_id)
        if protocol not in _SUPPORTED_PROTOCOLS:
            raise ValueError("unsupported model protocol")
        if protocol == "stub" and not self.database.enable_test_fixture_agent:
            raise ValueError("stub model protocol is available only in isolated test fixtures")
        if status not in {"draft", "active"}:
            raise ValueError("provider status must be draft or active")
        self._validate_provider_config(config)
        self.secrets.metadata(endpoint_ref)
        if secret_ref_id:
            self.secrets.metadata(secret_ref_id)
        at = iso()
        version_id = new_id("providerver")
        version_config = {
            "protocol": protocol,
            "endpoint_ref": endpoint_ref,
            "secret_ref": secret_ref_id,
            **config,
        }
        digest = _digest(version_config)
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """INSERT INTO model_providers(
                   id, name, protocol, status, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?)""",
                (provider_id, name.strip(), protocol, status, at, at),
            )
            connection.execute(
                """INSERT INTO model_provider_versions(
                   id, provider_id, version, endpoint_ref, secret_ref_id,
                   config_json, digest, created_by, created_at
                ) VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?)""",
                (
                    version_id,
                    provider_id,
                    endpoint_ref,
                    secret_ref_id,
                    json.dumps(version_config),
                    digest,
                    actor,
                    at,
                ),
            )
            self._audit(
                connection,
                actor,
                "model_provider.created",
                "model_provider",
                provider_id,
                target_version="1",
                after_digest=digest,
            )
            connection.commit()
        return self.get_provider(provider_id)

    def create_provider_version(
        self,
        provider_id: str,
        *,
        name: str | None,
        protocol: str | None,
        endpoint_ref: str,
        secret_ref_id: str | None,
        config: dict[str, Any],
        actor: str,
    ) -> dict[str, Any]:
        self._validate_provider_config(config)
        self.secrets.metadata(endpoint_ref)
        if secret_ref_id:
            self.secrets.metadata(secret_ref_id)
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            provider = connection.execute(
                "SELECT * FROM model_providers WHERE id=?", (provider_id,)
            ).fetchone()
            if not provider:
                raise KeyError(provider_id)
            if provider["status"] == "archived":
                raise ValueError("deleted model Provider cannot be updated")
            effective_protocol = protocol or provider["protocol"]
            if effective_protocol not in _SUPPORTED_PROTOCOLS:
                raise ValueError("unsupported model protocol")
            if effective_protocol == "stub" and not self.database.enable_test_fixture_agent:
                raise ValueError("stub model protocol is available only in isolated test fixtures")
            previous = connection.execute(
                """SELECT version, digest FROM model_provider_versions
                   WHERE provider_id=? ORDER BY version DESC LIMIT 1""",
                (provider_id,),
            ).fetchone()
            version = previous["version"] + 1
            version_config = {
                "protocol": effective_protocol,
                "endpoint_ref": endpoint_ref,
                "secret_ref": secret_ref_id,
                **config,
            }
            digest = _digest(version_config)
            provider_version_id = new_id("providerver")
            connection.execute(
                """INSERT INTO model_provider_versions(
                   id, provider_id, version, endpoint_ref, secret_ref_id,
                   config_json, digest, created_by, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    provider_version_id,
                    provider_id,
                    version,
                    endpoint_ref,
                    secret_ref_id,
                    json.dumps(version_config),
                    digest,
                    actor,
                    at,
                ),
            )
            profile_rows = connection.execute(
                """SELECT profile.id AS model_profile_id,
                          current_version.version, current_version.model_id,
                          current_version.max_input_length,
                          current_version.max_output_tokens,
                          current_version.temperature,
                          current_version.reasoning_effort,
                          current_version.timeout_seconds,
                          current_version.capabilities_json,
                          current_version.routing_json,
                          current_version.digest
                   FROM model_profiles profile
                   JOIN model_profile_versions current_version
                     ON current_version.id=(
                          SELECT latest.id FROM model_profile_versions latest
                           WHERE latest.model_profile_id=profile.id
                           ORDER BY latest.version DESC LIMIT 1
                        )
                   WHERE profile.provider_id=? AND profile.status<>'archived'""",
                (provider_id,),
            ).fetchall()
            for current in profile_rows:
                next_model_version = int(current["version"]) + 1
                capabilities = model_capabilities(current["capabilities_json"])
                routing = _json(current["routing_json"], {})
                profile_payload = self._profile_payload(
                    provider_version_id,
                    current["model_id"],
                    current["max_input_length"],
                    current["max_output_tokens"],
                    current["temperature"],
                    current["reasoning_effort"],
                    current["timeout_seconds"],
                    capabilities,
                    routing,
                )
                profile_digest = _digest(profile_payload)
                connection.execute(
                    """INSERT INTO model_profile_versions(
                       id, model_profile_id, version, provider_version_id, model_id,
                       max_input_length, max_output_tokens, temperature, reasoning_effort,
                       timeout_seconds,
                       capabilities_json, routing_json, digest, created_by, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        new_id("modelver"),
                        current["model_profile_id"],
                        next_model_version,
                        provider_version_id,
                        current["model_id"],
                        current["max_input_length"],
                        current["max_output_tokens"],
                        current["temperature"],
                        current["reasoning_effort"],
                        current["timeout_seconds"],
                        json.dumps(capabilities),
                        current["routing_json"],
                        profile_digest,
                        actor,
                        at,
                    ),
                )
                connection.execute(
                    "UPDATE model_profiles SET updated_at=? WHERE id=?",
                    (at, current["model_profile_id"]),
                )
                self._audit(
                    connection,
                    actor,
                    "model_profile.provider_updated",
                    "model_profile",
                    current["model_profile_id"],
                    target_version=str(next_model_version),
                    before_digest=current["digest"],
                    after_digest=profile_digest,
                    metadata={"provider_id": provider_id, "provider_version": version},
                )
            connection.execute(
                """UPDATE model_providers SET name=?, protocol=?, updated_at=? WHERE id=?""",
                (name.strip() if name else provider["name"], effective_protocol, at, provider_id),
            )
            self._audit(
                connection,
                actor,
                "model_provider.version_created",
                "model_provider",
                provider_id,
                target_version=str(version),
                before_digest=previous["digest"],
                after_digest=digest,
            )
            connection.commit()
        return self.get_provider(provider_id)

    def set_provider_status(self, provider_id: str, status: str, actor: str) -> dict[str, Any]:
        if status not in {"active", "disabled"}:
            raise ValueError("provider status must be active or disabled")
        now = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            provider = connection.execute(
                "SELECT status FROM model_providers WHERE id=?", (provider_id,)
            ).fetchone()
            if not provider:
                raise KeyError(provider_id)
            if provider["status"] == "archived":
                raise ValueError("deleted model Provider cannot change status")
            if status == "disabled":
                active_agents = connection.execute(
                    """SELECT DISTINCT a.id FROM agents a
                       JOIN agent_model_bindings binding ON binding.agent_id=a.id
                       JOIN model_profiles profile ON profile.id=binding.model_profile_id
                       WHERE profile.provider_id=? AND a.status<>'archived'""",
                    (provider_id,),
                ).fetchall()
                if active_agents:
                    raise ValueError("Provider is used by an Agent")
            connection.execute(
                "UPDATE model_providers SET status=?, updated_at=? WHERE id=?",
                (status, now, provider_id),
            )
            self._audit(
                connection,
                actor,
                "model_provider.status_changed",
                "model_provider",
                provider_id,
                metadata={"before": provider["status"], "after": status},
            )
            connection.commit()
        return self.get_provider(provider_id)

    def delete_provider(self, provider_id: str, actor: str) -> dict[str, Any]:
        """Archive an unused Provider while retaining historical Run references."""

        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            provider = connection.execute(
                "SELECT id, name, status FROM model_providers WHERE id=?",
                (provider_id,),
            ).fetchone()
            if not provider:
                raise KeyError(provider_id)
            applied_profiles = connection.execute(
                """SELECT id FROM model_profiles
                   WHERE provider_id=? AND status<>'archived' ORDER BY id""",
                (provider_id,),
            ).fetchall()
            if applied_profiles:
                raise ValueError(
                    f"供应商仍被 {len(applied_profiles)} 个模型资源应用，不能删除"
                )
            deleted_at = iso()
            connection.execute(
                """UPDATE model_providers
                   SET status='archived', archived_at=?, updated_at=? WHERE id=?""",
                (deleted_at, deleted_at, provider_id),
            )
            self._audit(
                connection,
                actor,
                "model_provider.deleted",
                "model_provider",
                provider_id,
                metadata={"name": provider["name"]},
            )
            connection.commit()
        return {"id": provider_id, "deleted": True, "mode": "archived"}

    def create_profile(
        self,
        profile_id: str,
        provider_id: str,
        name: str,
        model_id: str,
        actor: str,
        *,
        max_input_length: int,
        max_output_tokens: int,
        temperature: float,
        timeout_seconds: float,
        capabilities: dict[str, bool],
        reasoning_effort: str = "high",
        routing: dict[str, Any] | None = None,
        provider_version_id: str | None = None,
        status: str = "draft",
    ) -> dict[str, Any]:
        profile_id = self._stable_id(profile_id)
        if status not in {"draft", "active"}:
            raise ValueError("profile status must be draft or active")
        self._validate_profile_values(
            model_id,
            max_input_length,
            max_output_tokens,
            temperature,
            reasoning_effort,
            timeout_seconds,
            capabilities,
            routing or {"fallback": False},
        )
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            provider = connection.execute(
                "SELECT id, status FROM model_providers WHERE id=?", (provider_id,)
            ).fetchone()
            if not provider:
                raise KeyError(provider_id)
            if provider["status"] == "archived":
                raise ValueError("deleted model Provider cannot be used")
            provider_version = self._provider_version(connection, provider_id, provider_version_id)
            payload = self._profile_payload(
                provider_version["id"],
                model_id,
                max_input_length,
                max_output_tokens,
                temperature,
                reasoning_effort,
                timeout_seconds,
                capabilities,
                routing or {"fallback": False},
            )
            digest = _digest(payload)
            connection.execute(
                """INSERT INTO model_profiles(
                   id, provider_id, name, status, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?)""",
                (profile_id, provider_id, name.strip(), status, at, at),
            )
            connection.execute(
                """INSERT INTO model_profile_versions(
                   id, model_profile_id, version, provider_version_id, model_id,
                   max_input_length, max_output_tokens, temperature, reasoning_effort,
                   timeout_seconds,
                   capabilities_json, routing_json, digest, created_by, created_at
                ) VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    new_id("modelver"),
                    profile_id,
                    provider_version["id"],
                    model_id,
                    max_input_length,
                    max_output_tokens,
                    temperature,
                    reasoning_effort,
                    timeout_seconds,
                    json.dumps(capabilities),
                    json.dumps(routing or {"fallback": False}),
                    digest,
                    actor,
                    at,
                ),
            )
            self._audit(
                connection,
                actor,
                "model_profile.created",
                "model_profile",
                profile_id,
                target_version="1",
                after_digest=digest,
            )
            connection.commit()
        return self.get_profile(profile_id)

    def create_profile_version(
        self,
        profile_id: str,
        actor: str,
        *,
        model_id: str,
        max_input_length: int,
        max_output_tokens: int,
        temperature: float,
        timeout_seconds: float,
        capabilities: dict[str, bool],
        reasoning_effort: str = "high",
        routing: dict[str, Any] | None = None,
        provider_id: str | None = None,
        provider_version_id: str | None = None,
        name: str | None = None,
    ) -> dict[str, Any]:
        routing = routing or {"fallback": False}
        self._validate_profile_values(
            model_id,
            max_input_length,
            max_output_tokens,
            temperature,
            reasoning_effort,
            timeout_seconds,
            capabilities,
            routing,
        )
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            profile = connection.execute("SELECT * FROM model_profiles WHERE id=?", (profile_id,)).fetchone()
            if not profile:
                raise KeyError(profile_id)
            if profile["status"] == "archived":
                raise ValueError("deleted model resource cannot be updated")
            previous = connection.execute(
                """SELECT * FROM model_profile_versions
                   WHERE model_profile_id=? ORDER BY version DESC LIMIT 1""",
                (profile_id,),
            ).fetchone()
            effective_provider_id = provider_id or profile["provider_id"]
            provider = connection.execute(
                "SELECT id, status FROM model_providers WHERE id=?", (effective_provider_id,)
            ).fetchone()
            if not provider:
                raise KeyError(effective_provider_id)
            if provider["status"] == "archived":
                raise ValueError("deleted model Provider cannot be used")
            provider_version = self._provider_version(
                connection, effective_provider_id, provider_version_id
            )
            version = previous["version"] + 1
            payload = self._profile_payload(
                provider_version["id"],
                model_id,
                max_input_length,
                max_output_tokens,
                temperature,
                reasoning_effort,
                timeout_seconds,
                capabilities,
                routing,
            )
            digest = _digest(payload)
            connection.execute(
                """INSERT INTO model_profile_versions(
                   id, model_profile_id, version, provider_version_id, model_id,
                   max_input_length, max_output_tokens, temperature, reasoning_effort,
                   timeout_seconds,
                   capabilities_json, routing_json, digest, created_by, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    new_id("modelver"),
                    profile_id,
                    version,
                    provider_version["id"],
                    model_id,
                    max_input_length,
                    max_output_tokens,
                    temperature,
                    reasoning_effort,
                    timeout_seconds,
                    json.dumps(capabilities),
                    json.dumps(routing),
                    digest,
                    actor,
                    at,
                ),
            )
            connection.execute(
                """UPDATE model_profiles
                   SET provider_id=?, name=?, status='active', updated_at=? WHERE id=?""",
                (
                    effective_provider_id,
                    name.strip() if name else profile["name"],
                    at,
                    profile_id,
                ),
            )
            self._audit(
                connection,
                actor,
                "model_profile.version_created",
                "model_profile",
                profile_id,
                target_version=str(version),
                before_digest=previous["digest"],
                after_digest=digest,
            )
            connection.commit()
        return self.get_profile(profile_id)

    def set_profile_status(self, profile_id: str, status: str, actor: str) -> dict[str, Any]:
        if status not in {"active", "disabled"}:
            raise ValueError("profile status must be active or disabled")
        now = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            profile = connection.execute(
                "SELECT status FROM model_profiles WHERE id=?", (profile_id,)
            ).fetchone()
            if not profile:
                raise KeyError(profile_id)
            if status == "disabled":
                active_agents = connection.execute(
                    """SELECT DISTINCT a.id FROM agents a
                       JOIN agent_model_bindings binding ON binding.agent_id=a.id
                       WHERE binding.model_profile_id=? AND a.status<>'archived'""",
                    (profile_id,),
                ).fetchall()
                if active_agents:
                    raise ValueError("Model resource is used by an Agent")
            connection.execute(
                "UPDATE model_profiles SET status=?, updated_at=? WHERE id=?",
                (status, now, profile_id),
            )
            self._audit(
                connection,
                actor,
                "model_profile.status_changed",
                "model_profile",
                profile_id,
                metadata={"before": profile["status"], "after": status},
            )
            connection.commit()
        return self.get_profile(profile_id)

    @staticmethod
    def _provider_version(
        connection: sqlite3.Connection,
        provider_id: str,
        version_id: str | None,
    ) -> sqlite3.Row:
        if version_id:
            row = connection.execute(
                """SELECT * FROM model_provider_versions
                   WHERE id=? AND provider_id=?""",
                (version_id, provider_id),
            ).fetchone()
        else:
            row = connection.execute(
                """SELECT * FROM model_provider_versions
                   WHERE provider_id=? ORDER BY version DESC LIMIT 1""",
                (provider_id,),
            ).fetchone()
        if not row:
            raise ValueError("provider version is unavailable")
        return row

    @staticmethod
    def _validate_provider_config(config: dict[str, Any]) -> None:
        if not isinstance(config, dict):
            raise ValueError("provider config must be an object")
        if set(config) & {"protocol", "endpoint_ref", "secret_ref"}:
            raise ValueError("provider config cannot override managed connection fields")
        if _contains_sensitive_key(config):
            raise ValueError("provider config must use Secret Refs instead of secret values")
        if len(json.dumps(config, ensure_ascii=False)) > 20_000:
            raise ValueError("provider config is too large")
        if config:
            raise ValueError("provider config contains fields that are not consumed by Runtime")

    @staticmethod
    def _profile_payload(
        provider_version_id: str,
        model_id: str,
        max_input_length: int,
        max_output_tokens: int,
        temperature: float,
        reasoning_effort: str | None,
        timeout_seconds: float,
        capabilities: dict[str, bool],
        routing: dict[str, Any],
    ) -> dict[str, Any]:
        return {
            "provider_version_id": provider_version_id,
            "model_id": model_id,
            "max_input_length": max_input_length,
            "max_output_tokens": max_output_tokens,
            "temperature": temperature,
            "reasoning_effort": reasoning_effort,
            "timeout_seconds": timeout_seconds,
            "capabilities": capabilities,
            "routing": routing,
        }

    @staticmethod
    def _validate_profile_values(
        model_id: str,
        max_input_length: int,
        max_output_tokens: int,
        temperature: float,
        reasoning_effort: str,
        timeout_seconds: float,
        capabilities: dict[str, bool],
        routing: dict[str, Any],
    ) -> None:
        if not model_id.strip():
            raise ValueError("model_id is required")
        if max_input_length < 1024 or max_input_length > 2_000_000:
            raise ValueError("max_input_length is outside the system limit")
        if max_output_tokens < 1 or max_output_tokens > 100_000:
            raise ValueError("max_output_tokens is outside the system limit")
        if not 0 <= temperature <= 2:
            raise ValueError("temperature must be between 0 and 2")
        if reasoning_effort not in MODEL_REASONING_EFFORTS:
            raise ValueError(
                "reasoning_effort must be one of none, low, medium, high, xhigh, or max"
            )
        if not 0.1 <= timeout_seconds <= 600:
            raise ValueError("timeout_seconds is outside the system limit")
        required_capabilities = set(_MODEL_CAPABILITY_KEYS)
        if (
            not isinstance(capabilities, dict)
            or set(capabilities) != required_capabilities
            or any(not isinstance(value, bool) for value in capabilities.values())
        ):
            raise ValueError("exactly the four Runtime-consumed model capability flags must be declared")
        if not isinstance(routing, dict) or routing != {"fallback": False}:
            raise ValueError(
                "model routing/fallback is disabled; switch models through an explicit Agent version"
            )

    def list_profiles(self) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT id FROM model_profiles WHERE status<>'archived' ORDER BY id"
            ).fetchall()
        return [self.get_profile(row["id"]) for row in rows]

    def list_profiles_page(
        self,
        limit: int = 50,
        offset: int = 0,
        *,
        provider_id: str | None = None,
    ) -> dict[str, Any]:
        limit = max(1, min(limit, 500))
        offset = max(0, min(offset, 1_000_000))
        with self.database.connect() as connection:
            if provider_id is None:
                total = int(
                    connection.execute(
                        "SELECT COUNT(*) FROM model_profiles WHERE status<>'archived'"
                    ).fetchone()[0]
                )
                rows = connection.execute(
                    """SELECT id FROM model_profiles
                       WHERE status<>'archived' ORDER BY id LIMIT ? OFFSET ?""",
                    (limit, offset),
                ).fetchall()
            else:
                total = int(
                    connection.execute(
                        """SELECT COUNT(*) FROM model_profiles
                           WHERE status<>'archived' AND provider_id=?""",
                        (provider_id,),
                    ).fetchone()[0]
                )
                rows = connection.execute(
                    """SELECT id FROM model_profiles
                       WHERE status<>'archived' AND provider_id=?
                       ORDER BY id LIMIT ? OFFSET ?""",
                    (provider_id, limit, offset),
                ).fetchall()
        items = [self.get_profile(row["id"]) for row in rows]
        return {
            "items": items,
            "page": {
                "total": total,
                "limit": limit,
                "offset": offset,
                "has_previous": offset > 0,
                "has_next": offset + len(items) < total,
            },
        }

    def selection_options(self) -> dict[str, Any]:
        with self.database.connect() as connection:
            profile_rows = connection.execute(
                """SELECT profile.id AS profile_id, profile.provider_id AS profile_provider_id,
                          profile.name AS profile_name, profile.status AS profile_status,
                          version.id, version.version, version.provider_version_id,
                          version.model_id, version.capabilities_json,
                          provider.id AS provider_id, provider.status AS provider_status,
                          provider.protocol, provider_version.endpoint_ref,
                          provider_version.secret_ref_id
                   FROM model_profiles profile
                   JOIN model_profile_versions version
                     ON version.model_profile_id=profile.id
                   JOIN model_provider_versions provider_version
                     ON provider_version.id=version.provider_version_id
                   JOIN model_providers provider ON provider.id=provider_version.provider_id
                   WHERE profile.status<>'archived'
                   ORDER BY profile.id, version.version DESC"""
            ).fetchall()
            provider_rows = connection.execute(
                """SELECT provider.id AS provider_id, provider.name,
                          provider.protocol, provider.status,
                          version.id, version.version, version.endpoint_ref,
                          version.secret_ref_id
                   FROM model_providers provider
                   LEFT JOIN model_provider_versions version
                     ON version.provider_id=provider.id
                   WHERE provider.status<>'archived'
                   ORDER BY provider.id, version.version DESC"""
            ).fetchall()
            secret_rows = connection.execute("SELECT id, resolver, locator FROM secret_refs").fetchall()
            probe_rows = connection.execute(
                """SELECT target_id, status, findings_json, created_at, finished_at
                   FROM config_validation_runs
                   WHERE target_type='model_probe'
                   ORDER BY target_id, created_at DESC, id DESC"""
            ).fetchall()

        configured_refs = {
            row["id"]: self.secrets.configured(row["resolver"], row["locator"]) for row in secret_rows
        }
        latest_probes: dict[str, dict[str, Any]] = {}
        for row in probe_rows:
            latest_probes.setdefault(row["target_id"], self._probe_view(row))

        profile_map: dict[str, dict[str, Any]] = {}
        for row in profile_rows:
            profile = profile_map.setdefault(
                row["profile_id"],
                {
                    "id": row["profile_id"],
                    "provider_id": row["profile_provider_id"],
                    "name": row["profile_name"],
                    "status": row["profile_status"],
                    "versions": [],
                },
            )
            capabilities = model_capabilities(row["capabilities_json"])
            findings: list[dict[str, str]] = []
            if row["profile_status"] != "active":
                findings.append({"code": "profile_not_active", "level": "error"})
            if row["provider_status"] != "active":
                findings.append({"code": "provider_not_active", "level": "error"})
            if row["protocol"] == "openai-compatible":
                if not configured_refs.get(row["endpoint_ref"], False):
                    findings.append({"code": "endpoint_ref_unresolved", "level": "error"})
                if row["secret_ref_id"] and not configured_refs.get(row["secret_ref_id"], False):
                    findings.append({"code": "api_key_ref_unresolved", "level": "error"})
            if not capabilities.get("tool_calling"):
                findings.append({"code": "tool_calling_not_declared", "level": "error"})
            profile["versions"].append(
                {
                    "id": row["id"],
                    "version": row["version"],
                    "provider_version_id": row["provider_version_id"],
                    "provider_id": row["provider_id"],
                    "provider_status": row["provider_status"],
                    "model_id": row["model_id"],
                    "capabilities": capabilities,
                    "configuration": {
                        "status": "valid" if not findings else "invalid",
                        "findings": findings,
                    },
                    "last_probe": latest_probes.get(row["id"]),
                }
            )

        for profile in profile_map.values():
            profile["current_version_id"] = profile["versions"][0]["id"]
            profile["current_version"] = profile["versions"][0]

        provider_map: dict[str, dict[str, Any]] = {}
        for row in provider_rows:
            provider = provider_map.setdefault(
                row["provider_id"],
                {
                    "id": row["provider_id"],
                    "name": row["name"],
                    "protocol": row["protocol"],
                    "status": row["status"],
                    "versions": [],
                },
            )
            if row["id"] is None:
                continue
            provider["versions"].append(
                {
                    "id": row["id"],
                    "version": row["version"],
                    "endpoint": (
                        {"configured": configured_refs.get(row["endpoint_ref"], False)}
                        if row["endpoint_ref"]
                        else None
                    ),
                    "secret": (
                        {"configured": configured_refs.get(row["secret_ref_id"], False)}
                        if row["secret_ref_id"]
                        else None
                    ),
                }
            )
        return {"profiles": list(profile_map.values()), "providers": list(provider_map.values())}

    def get_profile(self, profile_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            profile = connection.execute("SELECT * FROM model_profiles WHERE id=?", (profile_id,)).fetchone()
            versions = connection.execute(
                """SELECT mpv.*, mp.protocol, mp.status AS provider_status,
                          mpv2.provider_id
                   FROM model_profile_versions mpv
                   JOIN model_provider_versions mpv2 ON mpv2.id=mpv.provider_version_id
                   JOIN model_providers mp ON mp.id=mpv2.provider_id
                   WHERE mpv.model_profile_id=? ORDER BY mpv.version DESC""",
                (profile_id,),
            ).fetchall()
        if not profile:
            raise KeyError(profile_id)
        result = dict(profile)
        result["versions"] = []
        for row in versions:
            item = dict(row)
            item["capabilities"] = model_capabilities(item.pop("capabilities_json"))
            item["routing"] = _json(item.pop("routing_json"), {})
            item["used_by_agents"] = self._agents_using_version(item["id"])
            item["last_probe"] = self._last_probe(item["id"])
            item["configuration"] = self.configuration_status(item["id"])
            result["versions"].append(item)
        result["current_version_id"] = result["versions"][0]["id"] if result["versions"] else None
        result["current_version"] = result["versions"][0] if result["versions"] else None
        result["usage"] = self._profile_usage(profile_id)
        return result

    def current_profile_version(self, profile_id: str) -> dict[str, Any]:
        """Resolve the instance-level model resource revision used by new Runs."""

        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT mpv.id
                   FROM model_profiles profile
                   JOIN model_profile_versions mpv ON mpv.model_profile_id=profile.id
                   WHERE profile.id=? AND profile.status='active'
                   ORDER BY mpv.version DESC LIMIT 1""",
                (profile_id,),
            ).fetchone()
        if not row:
            raise KeyError(profile_id)
        return self.get_profile_version(row["id"])

    def _profile_usage(
        self,
        profile_id: str,
        connection: sqlite3.Connection | None = None,
    ) -> dict[str, Any]:
        if connection is None:
            with self.database.connect() as active_connection:
                return self._profile_usage(profile_id, active_connection)
        agents = connection.execute(
            """SELECT a.id, a.name, a.status, binding.revision AS binding_revision
               FROM agent_model_bindings binding
               JOIN agents a ON a.id=binding.agent_id
               WHERE binding.model_profile_id=? AND a.status<>'archived'
               ORDER BY a.id""",
            (profile_id,),
        ).fetchall()
        counts = {
            "runs": connection.execute(
                """SELECT COUNT(*) FROM runs run
                   JOIN model_profile_versions mpv ON mpv.id=run.model_profile_version_id
                   WHERE mpv.model_profile_id=?""",
                (profile_id,),
            ).fetchone()[0],
            "candidate_attempts": connection.execute(
                """SELECT COUNT(*) FROM candidate_attempts attempt
                   JOIN model_profile_versions mpv ON mpv.id=attempt.model_profile_version_id
                   WHERE mpv.model_profile_id=?""",
                (profile_id,),
            ).fetchone()[0],
            "review_engine_versions": connection.execute(
                """SELECT COUNT(*) FROM review_engine_versions engine
                   JOIN model_profile_versions mpv ON mpv.id=engine.model_profile_version_id
                   WHERE mpv.model_profile_id=?""",
                (profile_id,),
            ).fetchone()[0],
        }
        blockers = [f"{len(agents)} 个智能体当前正在使用"] if agents else []
        return {
            "agents": [dict(row) for row in agents],
            **counts,
            "deletable": not blockers,
            "delete_blockers": blockers,
        }

    def delete_profile(self, profile_id: str, actor: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            profile = connection.execute(
                "SELECT id, name FROM model_profiles WHERE id=?", (profile_id,)
            ).fetchone()
            if not profile:
                raise KeyError(profile_id)
            usage = self._profile_usage(profile_id, connection)
            if not usage["deletable"]:
                raise ValueError(
                    "模型仍被应用，不能删除：" + "、".join(usage["delete_blockers"])
                )
            deleted_at = iso()
            connection.execute(
                """UPDATE model_profiles
                   SET status='archived', archived_at=?, updated_at=? WHERE id=?""",
                (deleted_at, deleted_at, profile_id),
            )
            self._audit(
                connection,
                actor,
                "model_profile.deleted",
                "model_profile",
                profile_id,
                metadata={
                    "name": profile["name"],
                    "retained_historical_references": {
                        key: usage[key]
                        for key in (
                            "runs",
                            "candidate_attempts",
                            "review_engine_versions",
                        )
                    },
                },
            )
            connection.commit()
        return {"id": profile_id, "deleted": True, "mode": "archived"}

    def get_profile_version(self, profile_version_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT model_profile_id FROM model_profile_versions WHERE id=?""",
                (profile_version_id,),
            ).fetchone()
        if not row:
            raise KeyError(profile_version_id)
        profile = self.get_profile(row["model_profile_id"])
        version = next(item for item in profile["versions"] if item["id"] == profile_version_id)
        return {
            "profile_id": profile["id"],
            "profile_name": profile["name"],
            "profile_status": profile["status"],
            **version,
        }

    def _agents_using_version(self, profile_version_id: str) -> list[str]:
        with self.database.connect() as connection:
            rows = connection.execute(
                """SELECT DISTINCT a.id
                   FROM model_profile_versions version
                   JOIN agent_model_bindings binding
                     ON binding.model_profile_id=version.model_profile_id
                   JOIN agents a ON a.id=binding.agent_id
                   WHERE version.id=?
                     AND version.id=(
                          SELECT latest.id FROM model_profile_versions latest
                           WHERE latest.model_profile_id=version.model_profile_id
                           ORDER BY latest.version DESC LIMIT 1
                        )
                     AND a.status<>'archived' ORDER BY a.id""",
                (profile_version_id,),
            ).fetchall()
        return [row["id"] for row in rows]

    def _last_probe(self, profile_version_id: str) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT status, findings_json, created_at, finished_at
                   FROM config_validation_runs
                   WHERE target_type='model_probe' AND target_id=?
                   ORDER BY created_at DESC LIMIT 1""",
                (profile_version_id,),
            ).fetchone()
        if not row:
            return None
        return self._probe_view(row)

    @staticmethod
    def _probe_view(row: sqlite3.Row) -> dict[str, Any]:
        result = dict(row)
        result.pop("target_id", None)
        result["findings"] = _json(result.pop("findings_json"), [])
        observed_at = result.get("finished_at") or result.get("created_at")
        try:
            age_seconds = max(
                0,
                int((datetime.now(UTC) - datetime.fromisoformat(observed_at)).total_seconds()),
            )
        except (TypeError, ValueError):
            age_seconds = None
        result["age_seconds"] = age_seconds
        result["stale_after_seconds"] = _PROBE_STALE_SECONDS
        result["stale"] = bool(age_seconds is None or age_seconds > _PROBE_STALE_SECONDS)
        result["observation_state"] = "stale" if result["stale"] else "observed"
        return result

    def probe_readiness(self, profile_version_id: str) -> dict[str, Any]:
        """Return the strict model gate used by Agent publication and candidates."""

        version = self.get_profile_version(profile_version_id)
        probe = version["last_probe"]
        if version["protocol"] == "stub":
            return {"status": "ready", "finding": None, "probe": probe}
        if not probe or probe["status"] != "passed":
            return {
                "status": "blocked",
                "finding": {"code": "model_probe_not_passed", "level": "error"},
                "probe": probe,
            }
        if probe["stale"]:
            return {
                "status": "blocked",
                "finding": {"code": "model_probe_stale", "level": "error"},
                "probe": probe,
            }
        observed = next(
            (
                item.get("observed", {})
                for item in probe.get("findings", [])
                if item.get("code") == "probe_observed"
            ),
            {},
        )
        if version["capabilities"].get("tool_calling") and not observed.get("tool_calling_observed"):
            return {
                "status": "blocked",
                "finding": {
                    "code": "model_tool_calling_not_observed",
                    "level": "error",
                },
                "probe": probe,
            }
        if version["capabilities"].get("structured_output") and not observed.get(
            "structured_output_observed"
        ):
            return {
                "status": "blocked",
                "finding": {
                    "code": "model_structured_output_not_observed",
                    "level": "error",
                },
                "probe": probe,
            }
        if version["capabilities"].get("vision") and not observed.get("vision_observed"):
            return {
                "status": "blocked",
                "finding": {
                    "code": "model_vision_not_observed",
                    "level": "error",
                },
                "probe": probe,
            }
        return {"status": "ready", "finding": None, "probe": probe}

    def configuration_status(self, profile_version_id: str) -> dict[str, Any]:
        findings: list[dict[str, str]] = []
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT mp.status AS profile_status, p.status AS provider_status,
                          p.protocol, pv.endpoint_ref, pv.secret_ref_id,
                          mpv.capabilities_json
                   FROM model_profile_versions mpv
                   JOIN model_profiles mp ON mp.id=mpv.model_profile_id
                   JOIN model_provider_versions pv ON pv.id=mpv.provider_version_id
                   JOIN model_providers p ON p.id=pv.provider_id
                   WHERE mpv.id=?""",
                (profile_version_id,),
            ).fetchone()
        if not row:
            raise KeyError(profile_version_id)
        if row["profile_status"] != "active":
            findings.append({"code": "profile_not_active", "level": "error"})
        if row["provider_status"] != "active":
            findings.append({"code": "provider_not_active", "level": "error"})
        if row["protocol"] == "openai-compatible":
            try:
                self.secrets.resolve(row["endpoint_ref"])
            except (KeyError, ValueError):
                findings.append({"code": "endpoint_ref_unresolved", "level": "error"})
            if row["secret_ref_id"]:
                try:
                    self.secrets.resolve(row["secret_ref_id"])
                except (KeyError, ValueError):
                    findings.append({"code": "api_key_ref_unresolved", "level": "error"})
        capabilities = model_capabilities(row["capabilities_json"])
        if not capabilities.get("tool_calling"):
            findings.append({"code": "tool_calling_not_declared", "level": "error"})
        return {"status": "valid" if not findings else "invalid", "findings": findings}

    def resolve_model_config(self, profile_version_id: str) -> ModelConfig:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT p.protocol, pv.endpoint_ref, pv.secret_ref_id,
                          mpv.model_id, mpv.max_output_tokens, mpv.temperature,
                          mpv.reasoning_effort, mpv.timeout_seconds
                   FROM model_profile_versions mpv
                   JOIN model_provider_versions pv ON pv.id=mpv.provider_version_id
                   JOIN model_providers p ON p.id=pv.provider_id
                   WHERE mpv.id=?""",
                (profile_version_id,),
            ).fetchone()
        if not row:
            raise KeyError(profile_version_id)
        if row["protocol"] == "stub":
            return ModelConfig(
                provider="stub",
                model=row["model_id"],
                reasoning_effort=row["reasoning_effort"] or DEFAULT_MODEL_REASONING_EFFORT,
            )
        base_url = self.secrets.resolve(row["endpoint_ref"])
        api_key_value = self.secrets.resolve(row["secret_ref_id"]) if row["secret_ref_id"] else ""
        return ModelConfig(
            provider="openai-compatible",
            model=row["model_id"],
            base_url=base_url,
            api_key_env="SUWEN_MODEL_API_KEY_UNUSED",
            api_key_value=api_key_value,
            timeout_seconds=row["timeout_seconds"],
            temperature=row["temperature"],
            max_output_tokens=row["max_output_tokens"],
            reasoning_effort=row["reasoning_effort"] or DEFAULT_MODEL_REASONING_EFFORT,
        )

    async def probe(
        self,
        profile_version_id: str,
        actor: str,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> dict[str, Any]:
        run_id = new_id("validation")
        started_at = iso()
        started = time.monotonic()
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT digest, capabilities_json FROM model_profile_versions WHERE id=?",
                (profile_version_id,),
            ).fetchone()
            if not row:
                raise KeyError(profile_version_id)
            connection.execute(
                """INSERT INTO config_validation_runs(
                   id, target_type, target_id, target_digest, status,
                   findings_json, actor_ref, created_at
                ) VALUES (?, 'model_probe', ?, ?, 'running', '[]', ?, ?)""",
                (run_id, profile_version_id, row["digest"], actor, started_at),
            )
        findings: list[dict[str, Any]] = []
        status = "passed"
        provider: OpenAICompatibleProvider | None = None
        try:
            capabilities = model_capabilities(row["capabilities_json"])
            config = self.resolve_model_config(profile_version_id)
            if config.provider == "stub":
                observed = {"protocol": "stub", "content_nonempty": True}
            else:
                provider = OpenAICompatibleProvider(config, transport=transport)
                turn = await provider.complete(
                    [
                        {"role": "system", "content": "Synthetic connectivity probe."},
                        {"role": "user", "content": "Reply with OK."},
                    ],
                    [],
                )
                if not turn.content.strip() and not turn.tool_requests:
                    raise ValueError("model response has neither content nor tool calls")
                reasoning_turns = [turn]
                probe_tool = ToolDefinition(
                    name=_PROBE_TOOL_NAME,
                    description=(
                        "Synthetic Suwen capability probe. It performs no operation "
                        "and receives no business data."
                    ),
                    input_schema={
                        "type": "object",
                        "properties": {
                            "status": {"type": "string", "enum": ["OK"]},
                        },
                        "required": ["status"],
                        "additionalProperties": False,
                    },
                    risk=ToolRisk.READ_ONLY,
                    provider_id="runtime-core",
                )
                tool_turn = await provider.complete(
                    [
                        {
                            "role": "system",
                            "content": (
                                "Synthetic tool-calling probe. Call the supplied function "
                                "exactly once with status OK. Do not answer directly."
                            ),
                        },
                        {
                            "role": "user",
                            "content": "Run the synthetic capability probe now.",
                        },
                    ],
                    [probe_tool],
                    tool_choice={
                        "type": "function",
                        "function": {"name": _PROBE_TOOL_NAME},
                    },
                )
                if len(tool_turn.tool_requests) != 1:
                    raise ModelProtocolError("model response did not produce exactly one synthetic tool call")
                tool_request = tool_turn.tool_requests[0]
                if tool_request.name != _PROBE_TOOL_NAME or tool_request.arguments != {"status": "OK"}:
                    raise ModelProtocolError("model response did not follow the synthetic tool contract")
                reasoning_turns.append(tool_turn)
                followup_turn = await provider.complete(
                    [
                        {
                            "role": "system",
                            "content": (
                                "Synthetic tool follow-up probe. The tool result below only "
                                "states that a synthetic source is unavailable. Give one short "
                                "bounded answer and do not request another tool."
                            ),
                        },
                        {
                            "role": "user",
                            "content": "Check the synthetic source and summarize the boundary.",
                        },
                        {
                            "role": "assistant",
                            "content": tool_turn.content or None,
                            "tool_calls": [
                                {
                                    "id": tool_request.call_id,
                                    "type": "function",
                                    "function": {
                                        "name": tool_request.name,
                                        "arguments": json.dumps(
                                            tool_request.arguments,
                                            ensure_ascii=False,
                                        ),
                                    },
                                }
                            ],
                        },
                        {
                            "role": "tool",
                            "tool_call_id": tool_request.call_id,
                            "name": tool_request.name,
                            "content": json.dumps(
                                {
                                    "state": "not_observable",
                                    "source_ref": "source-gated:synthetic-probe",
                                    "limitations": ["source_gated"],
                                },
                                ensure_ascii=False,
                            ),
                        },
                    ],
                    [],
                )
                if not followup_turn.content.strip() or followup_turn.tool_requests:
                    raise ModelProtocolError(
                        "model did not produce a bounded answer after the synthetic tool result"
                    )
                reasoning_turns.append(followup_turn)
                synthetic_model_turns = 3
                structured_output_observed = False
                vision_observed = False
                if capabilities.get("structured_output"):
                    structured_turn = await provider.complete_structured(
                        [
                            {
                                "role": "system",
                                "content": (
                                    "Synthetic structured-output probe. Return status OK and count 1 "
                                    "using the supplied strict JSON schema."
                                ),
                            },
                            {"role": "user", "content": "Return the synthetic probe object."},
                        ],
                        [],
                        _STRUCTURED_PROBE_FORMAT,
                    )
                    try:
                        structured_value = json.loads(structured_turn.content)
                    except json.JSONDecodeError as exc:
                        raise ModelProtocolError(
                            "model did not return valid structured probe JSON"
                        ) from exc
                    if structured_value != {"status": "OK", "count": 1}:
                        raise ModelProtocolError(
                            "model did not follow the synthetic structured-output contract"
                        )
                    structured_output_observed = True
                    synthetic_model_turns += 1
                    reasoning_turns.append(structured_turn)
                if capabilities.get("vision"):
                    vision_turn = await provider.complete(
                        [
                            {
                                "role": "system",
                                "content": (
                                    "Synthetic image-input probe. Identify the single black uppercase "
                                    "Latin letter in the supplied image and reply with that letter only."
                                ),
                            },
                            {
                                "role": "user",
                                "content": [
                                    {"type": "text", "text": "Identify the displayed letter."},
                                    {
                                        "type": "image_url",
                                        "image_url": {
                                            "url": _synthetic_vision_data_uri(),
                                            "detail": "auto",
                                        },
                                    },
                                ],
                            },
                        ],
                        [],
                    )
                    if vision_turn.tool_requests or vision_turn.content.strip().upper() != "K":
                        raise ModelProtocolError(
                            "model did not follow the synthetic image-input contract"
                        )
                    vision_observed = True
                    synthetic_model_turns += 1
                    reasoning_turns.append(vision_turn)
                observed = {
                    "protocol": "openai-compatible",
                    "content_nonempty": bool(turn.content.strip()),
                    "finish_reason": turn.finish_reason,
                    "tool_calling_observed": True,
                    "tool_choice_mode": "required_named_function",
                    "tool_call_count": 1,
                    "tool_followup_observed": True,
                    "structured_output_observed": structured_output_observed,
                    "vision_observed": vision_observed,
                    "synthetic_model_turns": synthetic_model_turns,
                    "reasoning_effort": config.reasoning_effort,
                    "reasoning_control_applied": all(
                        item.reasoning_control_applied is True for item in reasoning_turns
                    ),
                }
                if provider.last_response_model:
                    observed["response_model_id"] = provider.last_response_model
            findings.append(
                {
                    "code": "probe_observed",
                    "level": "info",
                    "observed": observed,
                    "latency_ms": round((time.monotonic() - started) * 1000),
                }
            )
        except Exception as exc:
            status = "failed"
            findings.append(
                {
                    "code": "probe_failed",
                    "level": "error",
                    "failure_class": self._failure_class(exc),
                    "message": self._safe_error(exc),
                }
            )
        finally:
            if provider:
                await provider.close()
        finished_at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """UPDATE config_validation_runs
                   SET status=?, findings_json=?, finished_at=? WHERE id=?""",
                (status, json.dumps(findings, ensure_ascii=False), finished_at, run_id),
            )
            if status == "passed":
                refs = connection.execute(
                    """SELECT pv.endpoint_ref, pv.secret_ref_id
                       FROM model_profile_versions mpv
                       JOIN model_provider_versions pv ON pv.id=mpv.provider_version_id
                       WHERE mpv.id=?""",
                    (profile_version_id,),
                ).fetchone()
                for ref_id in (refs["endpoint_ref"], refs["secret_ref_id"]):
                    if ref_id:
                        connection.execute(
                            """UPDATE secret_refs SET status='verified',
                               last_verified_at=?, updated_at=? WHERE id=?""",
                            (finished_at, finished_at, ref_id),
                        )
            self._audit(
                connection,
                actor,
                "model_profile.probed",
                "model_profile_version",
                profile_version_id,
                result="succeeded" if status == "passed" else "failed",
                metadata={"validation_run_id": run_id, "status": status},
            )
            connection.commit()
        return {
            "id": run_id,
            "profile_version_id": profile_version_id,
            "status": status,
            "findings": findings,
            "created_at": started_at,
            "finished_at": finished_at,
        }

    @staticmethod
    def _failure_class(exc: Exception) -> str:
        if isinstance(exc, (KeyError, ValueError)):
            return "configuration" if "response" not in str(exc) else "protocol"
        if isinstance(exc, (httpx.ConnectError, httpx.TimeoutException)):
            return "network"
        if isinstance(exc, httpx.HTTPStatusError):
            if exc.response.status_code in {401, 403}:
                return "authentication"
            return "protocol"
        if isinstance(exc, (json.JSONDecodeError, TypeError, IndexError)):
            return "protocol"
        return "unknown"

    @staticmethod
    def _safe_error(exc: Exception) -> str:
        if isinstance(exc, httpx.HTTPStatusError):
            return f"model endpoint returned HTTP {exc.response.status_code}"
        if isinstance(exc, httpx.TimeoutException):
            return "model endpoint timed out"
        if isinstance(exc, httpx.ConnectError):
            return "model endpoint connection failed"
        if isinstance(exc, KeyError):
            return "model response is missing a required protocol field"
        message = str(exc)
        if "Secret Ref" in message:
            return message
        return "model probe failed before a valid response was observed"
