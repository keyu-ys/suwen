from __future__ import annotations

import json
import secrets
from dataclasses import dataclass, replace
from datetime import UTC, datetime, timedelta
from typing import Any

from .repository import Repository, iso, new_id
from .tools import PolicyError, ToolRegistry
from .types import EvidenceEnvelope, EvidenceState, ToolRisk


@dataclass(frozen=True)
class ActionFlow:
    action_type: str
    prepare_tool_name: str
    commit_tool_name: str
    confirmation_phrase: str
    provider_prepare_required: bool = False


class ActionService:
    """Server-side two-request gate for the only allowed external-write class.

    Provider action tokens remain in the private Action row and are never included in
    model projections, ordinary API views, Events, Audit metadata, or logs.
    """

    def __init__(
        self,
        repository: Repository,
        tools: ToolRegistry,
        confirmation_ttl_seconds: int = 600,
    ) -> None:
        if not 30 <= confirmation_ttl_seconds <= 86_400:
            raise ValueError("action confirmation TTL must be between 30 and 86400 seconds")
        self.repository = repository
        self.tools = tools
        self.confirmation_ttl_seconds = confirmation_ttl_seconds

    def prepare(
        self,
        case_id: str,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        prepared_run_id: str | None = None,
        requester_ref: str = "api:local",
        *,
        prepared_message_id: str | None = None,
        prepared_agent_version_id: str | None = None,
        tools: ToolRegistry | None = None,
        now: datetime | None = None,
    ) -> dict[str, str]:
        """Prepare a generic fixture/local controlled action without executing it.

        Provider-specific preparation, when introduced, must remain behind this
        generic server-side gate.
        """

        flow = self._flow(tool_name)
        if flow.provider_prepare_required:
            raise PolicyError("this action requires the asynchronous Provider prepare path")
        registry = tools or self.tools
        definition = registry.get(tool_name)
        if definition.risk != ToolRisk.CONTROLLED_ACTION:
            raise PolicyError("only a declared controlled action can be prepared")
        registry.validate_arguments(tool_name, arguments or {})
        return self._store_prepared(
            case_id=case_id,
            flow=flow,
            arguments=arguments or {},
            server_token=secrets.token_urlsafe(32),
            prepared_run_id=prepared_run_id,
            prepared_message_id=prepared_message_id,
            prepared_agent_version_id=prepared_agent_version_id,
            requester_ref=requester_ref,
            prepare_summary="受控动作参数已在本地校验。",
            now=now,
        )

    async def prepare_for_request(
        self,
        case_id: str,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        prepared_run_id: str | None = None,
        requester_ref: str = "api:local",
        *,
        prepared_message_id: str | None = None,
        prepared_agent_version_id: str | None = None,
        require_message_intent: bool = False,
        tools: ToolRegistry | None = None,
        now: datetime | None = None,
    ) -> tuple[dict[str, str] | None, EvidenceEnvelope]:
        registry = tools or self.tools
        flow = self._flow(tool_name)
        definition = registry.get(tool_name)
        if definition.risk != ToolRisk.CONTROLLED_ACTION:
            raise PolicyError("only a declared controlled action can be prepared")
        arguments = arguments or {}
        registry.validate_arguments(tool_name, arguments)
        if require_message_intent:
            self._validate_current_message_intent(
                case_id,
                requester_ref,
                prepared_message_id,
                flow,
            )
        if not flow.provider_prepare_required:
            action = self.prepare(
                case_id,
                tool_name,
                arguments,
                prepared_run_id,
                requester_ref,
                prepared_message_id=prepared_message_id,
                prepared_agent_version_id=prepared_agent_version_id,
                tools=registry,
                now=now,
            )
            return action, self._prepared_envelope(action)

        provider_evidence = await registry.execute(
            flow.prepare_tool_name,
            arguments,
            allow_action=True,
        )
        if provider_evidence.state != EvidenceState.OBSERVED:
            return None, provider_evidence
        if not provider_evidence.action_token:
            return None, replace(
                provider_evidence,
                state=EvidenceState.QUERY_FAILED,
                summary="Provider 未返回受控的准备令牌；未创建可确认动作。",
                data={},
                coverage_state="unknown",
                truncation_state="unknown",
                limitations=(*provider_evidence.limitations, "action_token_missing"),
                action_token=None,
            )
        action = self._store_prepared(
            case_id=case_id,
            flow=flow,
            arguments=arguments,
            server_token=provider_evidence.action_token,
            prepared_run_id=prepared_run_id,
            prepared_message_id=prepared_message_id,
            prepared_agent_version_id=prepared_agent_version_id,
            requester_ref=requester_ref,
            prepare_summary=provider_evidence.summary,
            now=now,
        )
        return action, replace(
            self._prepared_envelope(action, provider_evidence.summary),
            provider_observation=provider_evidence.provider_observation,
        )

    async def confirm_and_commit(
        self,
        action_id: str,
        confirmation: str,
        requester_ref: str = "api:local",
        *,
        case_id: str | None = None,
        confirmation_message_id: str | None = None,
        agent_version_id: str | None = None,
        tools: ToolRegistry | None = None,
        now: datetime | None = None,
    ) -> dict[str, str]:
        registry = tools or self.tools
        at = now or datetime.now(UTC)
        with self.repository.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT * FROM actions WHERE id=?", (action_id,)).fetchone()
            if not row:
                self._audit(
                    connection,
                    requester_ref,
                    "action.confirmation_rejected",
                    action_id,
                    "rejected",
                    {"reason": "unknown_action"},
                    at,
                )
                connection.commit()
                raise KeyError(action_id)
            if agent_version_id is not None and row["prepared_agent_version_id"] != agent_version_id:
                self._audit(
                    connection,
                    requester_ref,
                    "action.confirmation_rejected",
                    action_id,
                    "rejected",
                    {
                        "reason": "agent_version_changed",
                        "prepared_agent_version_id": row["prepared_agent_version_id"],
                    },
                    at,
                    request_id=confirmation_message_id,
                )
                connection.commit()
                raise ValueError("Agent Version changed after action preparation; prepare a new action")
            rejection = self._confirmation_rejection(
                connection,
                row,
                confirmation,
                requester_ref,
                case_id,
                confirmation_message_id,
                at,
            )
            if rejection:
                if rejection == "expired":
                    connection.execute(
                        """UPDATE actions SET status='expired', finished_at=?
                           WHERE id=? AND status='awaiting_confirmation'""",
                        (iso(at), action_id),
                    )
                    self.repository.event_in_transaction(
                        connection,
                        row["case_id"],
                        row["prepared_run_id"],
                        "action.expired",
                        {"action_id": action_id},
                        iso(at),
                    )
                else:
                    self.repository.event_in_transaction(
                        connection,
                        row["case_id"],
                        row["prepared_run_id"],
                        "action.confirmation_rejected",
                        {"action_id": action_id, "reason": rejection},
                        iso(at),
                    )
                self._audit(
                    connection,
                    requester_ref,
                    "action.confirmation_rejected",
                    action_id,
                    "rejected",
                    {"case_id": row["case_id"], "reason": rejection},
                    at,
                    request_id=confirmation_message_id,
                )
                connection.commit()
                raise ValueError(self._rejection_message(rejection))
            changed = connection.execute(
                """UPDATE actions SET status='executing', confirmed_at=?,
                          confirmed_message_id=?
                   WHERE id=? AND status='awaiting_confirmation'""",
                (iso(at), confirmation_message_id, action_id),
            ).rowcount
            if changed != 1:
                connection.rollback()
                raise ValueError("action confirmation raced with another request")
            self.repository.event_in_transaction(
                connection,
                row["case_id"],
                row["prepared_run_id"],
                "action.confirmed",
                {"action_id": action_id},
                iso(at),
            )
            self._audit(
                connection,
                requester_ref,
                "action.confirmed",
                action_id,
                "succeeded",
                {"case_id": row["case_id"], "action_type": row["action_type"]},
                at,
                request_id=confirmation_message_id,
            )
            connection.commit()

        if row["commit_tool_name"] == row["tool_name"]:
            arguments = json.loads(row["arguments_json"])
        else:
            arguments = {
                "action_token": row["server_token"],
                "confirmation": row["confirmation_phrase"],
            }
        arguments["_action_context"] = {"idempotency_key": row["idempotency_key"]}
        try:
            result = await registry.execute(
                row["commit_tool_name"],
                arguments,
                allow_action=True,
            )
            if result.state == EvidenceState.OBSERVED:
                status = "succeeded"
            elif result.state in {EvidenceState.ZERO_MATCHES, EvidenceState.INPUT_REJECTED}:
                status = "rejected"
            else:
                status = "outcome_unknown"
            public_summary = result.summary
        except Exception:
            status = "outcome_unknown"
            public_summary = "受控动作结果不可确认；系统不会自动重试。"
        self.mark_terminal(
            action_id,
            status,
            {"summary": public_summary},
            actor_ref=requester_ref,
            now=at,
        )
        return {"action_id": action_id, "status": status, "message": public_summary}

    def mark_terminal(
        self,
        action_id: str,
        status: str,
        result: dict[str, object],
        *,
        actor_ref: str = "system:action-service",
        now: datetime | None = None,
    ) -> None:
        if status not in {"succeeded", "rejected", "outcome_unknown", "duplicate", "failed"}:
            raise ValueError("invalid terminal action status")
        at = now or datetime.now(UTC)
        safe_result = {"summary": str(result.get("summary") or "")[:10_000]}
        with self.repository.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT case_id, prepared_run_id, action_type FROM actions WHERE id=?",
                (action_id,),
            ).fetchone()
            if not row:
                raise KeyError(action_id)
            changed = connection.execute(
                """UPDATE actions SET status=?, result_json=?, finished_at=?
                   WHERE id=? AND status='executing'""",
                (status, json.dumps(safe_result, ensure_ascii=False), iso(at), action_id),
            ).rowcount
            if changed == 1:
                self.repository.event_in_transaction(
                    connection,
                    row["case_id"],
                    row["prepared_run_id"],
                    "action.terminal",
                    {"action_id": action_id, "status": status},
                    iso(at),
                )
                self._audit(
                    connection,
                    actor_ref,
                    "action.terminal",
                    action_id,
                    status,
                    {"case_id": row["case_id"], "action_type": row["action_type"]},
                    at,
                )
            connection.commit()
        if changed != 1:
            raise ValueError("action cannot be committed or retried")

    def expire_pending(self, now: datetime | None = None) -> int:
        at = now or datetime.now(UTC)
        with self.repository.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            rows = connection.execute(
                """SELECT id, case_id, prepared_run_id, action_type FROM actions
                   WHERE status='awaiting_confirmation' AND expires_at<=?""",
                (iso(at),),
            ).fetchall()
            for row in rows:
                connection.execute(
                    "UPDATE actions SET status='expired', finished_at=? WHERE id=?",
                    (iso(at), row["id"]),
                )
                self.repository.event_in_transaction(
                    connection,
                    row["case_id"],
                    row["prepared_run_id"],
                    "action.expired",
                    {"action_id": row["id"]},
                    iso(at),
                )
                self._audit(
                    connection,
                    "system:action-expiry",
                    "action.expired",
                    row["id"],
                    "succeeded",
                    {"case_id": row["case_id"], "action_type": row["action_type"]},
                    at,
                )
            connection.commit()
        return len(rows)

    def _store_prepared(
        self,
        *,
        case_id: str,
        flow: ActionFlow,
        arguments: dict[str, Any],
        server_token: str,
        prepared_run_id: str | None,
        prepared_message_id: str | None,
        prepared_agent_version_id: str | None,
        requester_ref: str,
        prepare_summary: str,
        now: datetime | None,
    ) -> dict[str, str]:
        if not server_token or len(server_token) > 4096:
            raise ValueError("Provider action token is outside the allowed range")
        at = now or datetime.now(UTC)
        expires = at + timedelta(seconds=self.confirmation_ttl_seconds)
        action_id = new_id("action")
        idempotency_key = f"controlled:{case_id}:{flow.action_type}:{action_id}"
        with self.repository.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            case = connection.execute(
                """SELECT c.agent_id,
                          COALESCE(c.pinned_agent_version_id, a.active_version_id)
                            AS active_agent_version_id
                   FROM cases c JOIN agents a ON a.id=c.agent_id WHERE c.id=?""",
                (case_id,),
            ).fetchone()
            if not case:
                raise KeyError(case_id)
            self._validate_prepare_links(
                connection,
                case_id,
                requester_ref,
                prepared_run_id,
                prepared_message_id,
            )
            run_version = None
            if prepared_run_id:
                run_version = connection.execute(
                    "SELECT agent_version_id FROM runs WHERE id=?",
                    (prepared_run_id,),
                ).fetchone()["agent_version_id"]
            effective_agent_version_id = (
                prepared_agent_version_id or run_version or case["active_agent_version_id"]
            )
            if run_version and run_version != effective_agent_version_id:
                raise ValueError("prepared Run and Agent Version do not match")
            version = connection.execute(
                """SELECT id FROM agent_versions
                   WHERE id=? AND agent_id=? AND status='published'""",
                (effective_agent_version_id, case["agent_id"]),
            ).fetchone()
            if not version:
                raise ValueError("prepared Agent Version is unavailable")
            existing = connection.execute(
                """SELECT id FROM actions WHERE case_id=? AND requester_ref=?
                   AND action_type=? AND status='awaiting_confirmation' AND expires_at>?
                   LIMIT 1""",
                (case_id, requester_ref, flow.action_type, iso(at)),
            ).fetchone()
            if existing:
                connection.rollback()
                raise ValueError("an equivalent action is already awaiting confirmation")
            connection.execute(
                """INSERT INTO actions(
                   id, case_id, agent_id, tool_name, commit_tool_name, action_type,
                   arguments_json, status, server_token, idempotency_key,
                   prepared_run_id, prepared_message_id, prepared_agent_version_id,
                   requester_ref,
                   confirmation_phrase, prepare_result_json, prepared_at, expires_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'awaiting_confirmation', ?, ?, ?, ?, ?,
                          ?, ?, ?, ?, ?)""",
                (
                    action_id,
                    case_id,
                    case["agent_id"],
                    flow.prepare_tool_name,
                    flow.commit_tool_name,
                    flow.action_type,
                    json.dumps(arguments, ensure_ascii=False),
                    server_token,
                    idempotency_key,
                    prepared_run_id,
                    prepared_message_id,
                    effective_agent_version_id,
                    requester_ref,
                    flow.confirmation_phrase,
                    json.dumps({"summary": prepare_summary[:10_000]}, ensure_ascii=False),
                    iso(at),
                    iso(expires),
                ),
            )
            self.repository.event_in_transaction(
                connection,
                case_id,
                prepared_run_id,
                "action.prepared",
                {
                    "action_id": action_id,
                    "action_type": flow.action_type,
                    "tool_name": flow.prepare_tool_name,
                },
                iso(at),
            )
            self._audit(
                connection,
                requester_ref,
                "action.prepared",
                action_id,
                "succeeded",
                {
                    "case_id": case_id,
                    "action_type": flow.action_type,
                    "prepare_tool": flow.prepare_tool_name,
                    "commit_tool": flow.commit_tool_name,
                    "prepared_agent_version_id": effective_agent_version_id,
                    "expires_at": iso(expires),
                },
                at,
                request_id=prepared_message_id,
            )
            connection.commit()
        return {
            "action_id": action_id,
            "status": "awaiting_confirmation",
            "confirmation_phrase": flow.confirmation_phrase,
            "expires_at": iso(expires),
            "message": ("受控动作已准备，尚未执行；请在后续独立消息中发送精确确认短语。"),
        }

    def _flow(self, tool_name: str) -> ActionFlow:
        return ActionFlow(
            action_type=f"tool:{tool_name}",
            prepare_tool_name=tool_name,
            commit_tool_name=tool_name,
            confirmation_phrase="确认执行",
        )

    def _validate_current_message_intent(
        self,
        case_id: str,
        requester_ref: str,
        message_id: str | None,
        flow: ActionFlow,
    ) -> None:
        if not message_id:
            raise PolicyError("current user message is required for a model-prepared action")
        message = self.repository.get_message(message_id)
        if (
            message["case_id"] != case_id
            or message["role"] != "user"
            or message.get("actor_ref") != requester_ref
        ):
            raise PolicyError("action intent is not bound to the current user message")

    @staticmethod
    def _validate_prepare_links(
        connection: Any,
        case_id: str,
        requester_ref: str,
        run_id: str | None,
        message_id: str | None,
    ) -> None:
        if run_id:
            run = connection.execute(
                "SELECT case_id, trigger_message_id FROM runs WHERE id=?", (run_id,)
            ).fetchone()
            if not run or run["case_id"] != case_id:
                raise ValueError("prepared Run does not belong to the exact Case")
            if message_id and run["trigger_message_id"] != message_id:
                raise ValueError("prepared message is not the Run trigger")
        if message_id:
            message = connection.execute(
                "SELECT case_id, role, actor_ref FROM messages WHERE id=?", (message_id,)
            ).fetchone()
            if (
                not message
                or message["case_id"] != case_id
                or message["role"] != "user"
                or message["actor_ref"] != requester_ref
            ):
                raise ValueError("prepared message is not owned by the exact Case/requester")

    @staticmethod
    def _confirmation_rejection(
        connection: Any,
        row: Any,
        confirmation: str,
        requester_ref: str,
        case_id: str | None,
        message_id: str | None,
        now: datetime,
    ) -> str | None:
        if row["status"] != "awaiting_confirmation":
            return "not_pending"
        if row["expires_at"] <= iso(now):
            return "expired"
        if case_id is not None and row["case_id"] != case_id:
            return "wrong_case"
        if row["requester_ref"] != requester_ref:
            return "wrong_requester"
        if confirmation != row["confirmation_phrase"]:
            return "wrong_confirmation"
        if message_id:
            if message_id == row["prepared_message_id"]:
                return "same_message"
            message = connection.execute(
                "SELECT case_id, role, actor_ref, content FROM messages WHERE id=?",
                (message_id,),
            ).fetchone()
            if (
                not message
                or message["case_id"] != row["case_id"]
                or message["role"] != "user"
                or message["actor_ref"] != requester_ref
                or message["content"] != row["confirmation_phrase"]
            ):
                return "invalid_confirmation_message"
        return None

    @staticmethod
    def _rejection_message(reason: str) -> str:
        messages = {
            "not_pending": "action is not awaiting confirmation",
            "expired": "action confirmation has expired",
            "wrong_case": "confirmation must use the preparing Case",
            "wrong_requester": "confirmation must come from the preparing subject",
            "wrong_confirmation": "exact subsequent confirmation is required",
            "same_message": "prepare and confirmation require separate messages",
            "invalid_confirmation_message": "confirmation message is not bound to the action",
        }
        return messages[reason]

    @staticmethod
    def _prepared_envelope(
        action: dict[str, str],
        provider_summary: str | None = None,
    ) -> EvidenceEnvelope:
        return EvidenceEnvelope(
            state=EvidenceState.OBSERVED,
            summary=("受控动作仅已准备，尚未执行；必须等待同一案件、同一主体的后续精确确认。"),
            data={
                "action_id": action["action_id"],
                "status": action["status"],
                "expires_at": action["expires_at"],
                "prepare_summary": provider_summary or "参数已校验",
            },
            coverage_state="internal_state",
            source_ref=f"action:{action['action_id']}",
            source_role="internal_state",
            safe_statements=("动作只完成准备，尚未执行",),
        )

    @staticmethod
    def _audit(
        connection: Any,
        actor_ref: str,
        action: str,
        target_id: str,
        result: str,
        metadata: dict[str, Any],
        now: datetime,
        *,
        request_id: str | None = None,
    ) -> None:
        connection.execute(
            """INSERT INTO audit_events(
               actor_type, actor_ref, action, target_type, target_id,
               request_id, result, metadata_json, created_at
            ) VALUES ('user', ?, ?, 'controlled_action', ?, ?, ?, ?, ?)""",
            (
                actor_ref,
                action,
                target_id,
                request_id,
                result,
                json.dumps(metadata, ensure_ascii=False),
                iso(now),
            ),
        )
