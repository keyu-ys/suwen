"""Small public contract for first-party Suwen capability packages.

Capability packages may import this module only.  The Runtime deliberately
keeps database, Case, Channel, Secret, model, and private package-loader
objects out of this API.
"""

from __future__ import annotations

import re
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from typing import Any, Literal

from .types import CapabilityArtifactPayload, EvidenceEnvelope, EvidenceState, ToolRisk

CAPABILITY_API_VERSION = "1.5.0"
CAPABILITY_CONTRACT_VERSION = "suwen-capability.v1"
CapabilityKind = Literal["tools", "domain"]
CapabilityExternalState = Literal[
    "succeeded",
    "unavailable",
    "timed_out",
    "failed",
    "output_rejected",
]
CapabilityHandler = Callable[
    [dict[str, Any], "CapabilityContext"],
    EvidenceEnvelope | Awaitable[EvidenceEnvelope],
]
CapabilityExternalExecutor = Callable[
    ["CapabilityExternalRequest"],
    Any,
]

_DEPENDENCY_ID = re.compile(r"^[a-z][a-z0-9-]{1,63}$")


@dataclass(frozen=True)
class CapabilityExternalRequest:
    """A bounded logical request to one manifest-declared external dependency.

    A package can name only the dependency and its argument vector.  It never
    receives an executable path, working directory, environment, Secret, or
    host process handle.  The Runtime owns the eventual deployment binding.
    """

    dependency_id: str
    arguments: tuple[str, ...]
    timeout_seconds: float = 30.0
    max_output_bytes: int = 128 * 1024
    purpose: str = ""

    def __post_init__(self) -> None:
        if not _DEPENDENCY_ID.fullmatch(self.dependency_id):
            raise ValueError("external dependency id must be a stable identifier")
        if not self.arguments or len(self.arguments) > 64:
            raise ValueError("external request must contain 1 to 64 arguments")
        if any(not isinstance(item, str) or "\x00" in item or len(item) > 16_384 for item in self.arguments):
            raise ValueError("external request arguments must be bounded safe strings")
        if sum(len(item) for item in self.arguments) > 64 * 1024:
            raise ValueError("external request arguments exceed the configured bound")
        if not 0 < self.timeout_seconds <= 300:
            raise ValueError("external request timeout must be between 0 and 300 seconds")
        if not 1 <= self.max_output_bytes <= 2 * 1024 * 1024:
            raise ValueError("external request output bound must be between 1 byte and 2 MiB")
        if not isinstance(self.purpose, str) or "\x00" in self.purpose or len(self.purpose) > 512:
            raise ValueError("external request purpose must be a bounded safe string")


@dataclass(frozen=True)
class CapabilityExternalResult:
    """Sanitized result returned by a host-owned external dependency binding."""

    state: CapabilityExternalState
    stdout: str = ""
    stderr: str = ""
    exit_code: int | None = None
    failure_kind: str | None = None
    output_truncated: bool = False

    def __post_init__(self) -> None:
        if self.state not in {
            "succeeded",
            "unavailable",
            "timed_out",
            "failed",
            "output_rejected",
        }:
            raise ValueError("external result state is unsupported")
        if not isinstance(self.stdout, str) or "\x00" in self.stdout or len(self.stdout) > 2 * 1024 * 1024:
            raise ValueError("external result stdout must be a bounded safe string")
        if not isinstance(self.stderr, str) or "\x00" in self.stderr or len(self.stderr) > 2 * 1024 * 1024:
            raise ValueError("external result stderr must be a bounded safe string")
        if self.exit_code is not None and not isinstance(self.exit_code, int):
            raise ValueError("external result exit_code must be an integer or null")
        if self.failure_kind is not None and (
            not isinstance(self.failure_kind, str)
            or not re.fullmatch(r"[a-z0-9_.-]{1,96}", self.failure_kind)
        ):
            raise ValueError("external result failure_kind is invalid")
        if not isinstance(self.output_truncated, bool):
            raise ValueError("external result output_truncated must be boolean")


class CapabilityExternalAccess:
    """The sole external-execution surface exposed to a capability handler."""

    def __init__(
        self,
        declared_dependencies: Mapping[str, str],
        executor: CapabilityExternalExecutor,
    ) -> None:
        self._declared_dependencies = dict(declared_dependencies)
        self._executor = executor

    async def execute(self, request: CapabilityExternalRequest) -> CapabilityExternalResult:
        """Run one request only when its logical dependency is declared.

        Contract-version matching and executable binding are intentionally host
        responsibilities.  A package receives only a stable failure category.
        """

        if request.dependency_id not in self._declared_dependencies:
            return CapabilityExternalResult(
                state="unavailable",
                failure_kind="undeclared_dependency",
            )
        try:
            result = self._executor(request)
            if hasattr(result, "__await__"):
                result = await result
        except TimeoutError:
            return CapabilityExternalResult(state="timed_out", failure_kind="executor_timeout")
        except Exception:
            return CapabilityExternalResult(state="failed", failure_kind="executor_failed")
        if not isinstance(result, CapabilityExternalResult):
            return CapabilityExternalResult(state="failed", failure_kind="executor_contract_invalid")
        return result


async def unavailable_external_executor(
    _request: CapabilityExternalRequest,
) -> CapabilityExternalResult:
    """Safe default until a later lifecycle phase installs a real binding."""

    return CapabilityExternalResult(
        state="unavailable",
        failure_kind="external_dependency_unavailable",
    )


@dataclass(frozen=True)
class CapabilityManifest:
    """Portable manifest metadata after deterministic host validation."""

    id: str
    kind: CapabilityKind
    version: str
    name: str
    description: str
    capability_api: str
    entrypoint: str | None
    trusted_code: bool
    distribution: str | None = None
    python_namespace: str | None = None
    content_entrypoint: str | None = None
    external_dependencies: tuple[dict[str, str], ...] = ()
    provided_external_dependencies: tuple[dict[str, Any], ...] = ()
    schema: str = CAPABILITY_CONTRACT_VERSION


@dataclass(frozen=True)
class CapabilityContext:
    """Non-sensitive per-call metadata deliberately exposed to one package."""

    capability_id: str
    capability_version: str
    run_id: str | None = None
    case_id: str | None = None
    external: CapabilityExternalAccess | None = None


@dataclass(frozen=True)
class CapabilityTool:
    name: str
    description: str
    input_schema: dict[str, Any]
    handler: CapabilityHandler
    risk: ToolRisk = ToolRisk.READ_ONLY
    timeout_seconds: float = 30.0
    result_contract: str = "model-evidence.v2"
    provider_id: str | None = None
    resource_class: str = "standard"
    run_call_limit: int | None = None
    run_call_limit_range: tuple[int, int] | None = None
    equivalence_key: Callable[[dict[str, Any]], Any | None] | None = None


@dataclass(frozen=True)
class CapabilityPrompt:
    id: str
    content: str


@dataclass(frozen=True)
class CapabilityReference:
    """A bounded, immutable knowledge item delivered with one domain Skill.

    The Runtime exposes the content only through the host-owned reference
    reader.  Capability packages never receive a workspace path or a file
    handle after registration.
    """

    id: str
    title: str
    description: str
    content: str
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CapabilitySkill:
    id: str
    version: str
    name: str
    description: str
    instructions: str
    # ``fallback`` is the legacy text field used by the first fixture API.
    # New declarative packages use the explicit boolean ``is_fallback``.
    fallback: str = ""
    applicability: str = ""
    is_fallback: bool = False
    references: tuple[CapabilityReference, ...] = ()


@dataclass(frozen=True)
class CapabilityRegistration:
    tools: tuple[CapabilityTool, ...]
    prompts: tuple[CapabilityPrompt, ...]
    skills: tuple[CapabilitySkill, ...]


class CapabilityApi:
    """Registration surface passed to one trusted, installed capability package."""

    def __init__(self, manifest: CapabilityManifest) -> None:
        self.manifest = manifest
        self._tools: dict[str, CapabilityTool] = {}
        self._prompts: dict[str, CapabilityPrompt] = {}
        self._skills: dict[str, CapabilitySkill] = {}

    def register_tool(self, tool: CapabilityTool) -> None:
        if self.manifest.kind != "tools":
            raise ValueError("only a tools capability may register Tools")
        if tool.risk is not ToolRisk.READ_ONLY:
            raise ValueError("first-party capability tools must be read-only")
        if not tool.name or tool.name in self._tools:
            raise ValueError("capability Tool id must be unique and non-empty")
        if not callable(tool.handler):
            raise ValueError("capability Tool handler must be callable")
        if tool.run_call_limit is not None and (
            isinstance(tool.run_call_limit, bool) or not 1 <= tool.run_call_limit <= 120
        ):
            raise ValueError("capability Tool Run call limit must be between 1 and 120")
        if tool.run_call_limit_range is not None:
            minimum, maximum = tool.run_call_limit_range
            if (
                isinstance(minimum, bool)
                or isinstance(maximum, bool)
                or not 1 <= minimum <= maximum <= 120
                or tool.run_call_limit is None
                or not minimum <= tool.run_call_limit <= maximum
            ):
                raise ValueError("capability Tool Run call limit range is invalid")
        self._tools[tool.name] = tool

    def register_prompt(self, prompt: CapabilityPrompt) -> None:
        if self.manifest.kind != "domain":
            raise ValueError("only a domain capability may register Prompt content")
        if not prompt.id or not prompt.content.strip() or prompt.id in self._prompts:
            raise ValueError("capability Prompt id and content must be unique and non-empty")
        self._prompts[prompt.id] = prompt

    def register_skill(self, skill: CapabilitySkill) -> None:
        if self.manifest.kind != "domain":
            raise ValueError("only a domain capability may register Skills")
        references_are_valid = all(
            isinstance(item, CapabilityReference)
            and bool(item.id)
            and bool(item.title.strip())
            and bool(item.description.strip())
            and bool(item.content.strip())
            for item in skill.references
        )
        reference_ids = (
            {item.id for item in skill.references if isinstance(item, CapabilityReference)}
            if references_are_valid
            else set()
        )
        if (
            not skill.id
            or not skill.version
            or not skill.name.strip()
            or not skill.description.strip()
            or not skill.instructions.strip()
            or skill.id in self._skills
            or not isinstance(skill.fallback, str)
            or not isinstance(skill.is_fallback, bool)
            or not references_are_valid
            or len(reference_ids) != len(skill.references)
        ):
            raise ValueError("capability Skill fields must be unique and non-empty")
        self._skills[skill.id] = skill

    @property
    def registration(self) -> CapabilityRegistration:
        return CapabilityRegistration(
            tools=tuple(self._tools.values()),
            prompts=tuple(self._prompts.values()),
            skills=tuple(self._skills.values()),
        )


def project_capability_evidence(
    payload: Any,
    provider_id: str,
    tool_name: str,
) -> EvidenceEnvelope:
    """Project a portable evidence payload without exposing private host modules."""

    # The generic projector lives behind the public boundary so packages never
    # import the historical MCP or Plugin implementation directly.
    from .mcp_adapter import project_producer_evidence

    return project_producer_evidence(
        payload,
        provider_id,
        tool_name,
        source_namespace="capability",
        provider_label="能力包",
    )


__all__ = [
    "CAPABILITY_API_VERSION",
    "CAPABILITY_CONTRACT_VERSION",
    "CapabilityApi",
    "CapabilityArtifactPayload",
    "CapabilityContext",
    "CapabilityExternalAccess",
    "CapabilityExternalExecutor",
    "CapabilityExternalRequest",
    "CapabilityExternalResult",
    "CapabilityExternalState",
    "CapabilityKind",
    "CapabilityManifest",
    "CapabilityPrompt",
    "CapabilityReference",
    "CapabilityRegistration",
    "CapabilitySkill",
    "CapabilityTool",
    "EvidenceEnvelope",
    "EvidenceState",
    "ToolRisk",
    "project_capability_evidence",
    "unavailable_external_executor",
]
