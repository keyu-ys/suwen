"""Provider-neutral communication personas for Suwen conversations."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any

PERSONA_SNAPSHOT_SCHEMA = "suwen.persona-snapshot.v1"
DEFAULT_PERSONA_ID = "technical-peer"


@dataclass(frozen=True)
class PersonaPreset:
    id: str
    name: str
    description: str
    instruction: str
    detail: str = "adaptive"

    def public_view(self) -> dict[str, str]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "instruction": self.instruction,
            "detail": self.detail,
        }


PERSONA_PRESETS: tuple[PersonaPreset, ...] = (
    PersonaPreset(
        id=DEFAULT_PERSONA_ID,
        name="技术同事",
        description="直接、务实、自然地并肩排查，细节随问题复杂度调整。",
        instruction=(
            "像一位靠谱的技术同事与提问者并肩排查。\n"
            "先给结论，基于事实报告进展，语气直接、务实、自然。\n"
            "把复杂部分拆清楚，细节随问题复杂度调整。"
        ),
        detail="adaptive",
    ),
    PersonaPreset(
        id="concise-investigator",
        name="简洁调查员",
        description="使用最短充分表达，突出结论、事实、未知和下一步。",
        instruction=(
            "以简洁调查员的方式协作。\n"
            "先给最短充分结论，再列支撑事实、未知边界和一个必要下一步。\n"
            "进展报告只包含已经验证且会影响判断的信息。"
        ),
        detail="concise",
    ),
    PersonaPreset(
        id="patient-explainer",
        name="耐心解释者",
        description="用容易理解的语言解释关系、术语和判断依据。",
        instruction=(
            "以耐心解释者的方式协作。\n"
            "先给结论，再用容易理解的语言逐步解释对象关系、时间关系和判断依据。\n"
            "术语首次出现时顺手解释，并让每一步都便于提问者核对。"
        ),
        detail="explanatory",
    ),
)

_PERSONAS_BY_ID = {item.id: item for item in PERSONA_PRESETS}


def list_personas() -> list[dict[str, str]]:
    return [item.public_view() for item in PERSONA_PRESETS]


def get_persona(persona_id: str) -> PersonaPreset:
    try:
        return _PERSONAS_BY_ID[persona_id]
    except KeyError as exc:
        raise ValueError(f"unknown Persona: {persona_id}") from exc


def _snapshot_digest(payload: dict[str, Any]) -> str:
    stable = {
        "schema": payload["schema"],
        "id": payload["id"],
        "name": payload["name"],
        "instruction": payload["instruction"],
        "detail": payload["detail"],
    }
    return hashlib.sha256(
        json.dumps(
            stable,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()


def persona_snapshot(persona_id: str, binding_revision: int) -> dict[str, Any]:
    persona = get_persona(persona_id)
    snapshot: dict[str, Any] = {
        "schema": PERSONA_SNAPSHOT_SCHEMA,
        "id": persona.id,
        "name": persona.name,
        "instruction": persona.instruction,
        "detail": persona.detail,
        "binding_revision": int(binding_revision),
    }
    snapshot["digest"] = _snapshot_digest(snapshot)
    return snapshot


def normalize_persona_snapshot(value: str | dict[str, Any]) -> dict[str, Any]:
    try:
        snapshot = json.loads(value) if isinstance(value, str) else dict(value)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise ValueError("Persona snapshot is invalid") from exc
    required = {"schema", "id", "name", "instruction", "detail", "binding_revision", "digest"}
    if set(snapshot) != required:
        raise ValueError("Persona snapshot fields are invalid")
    if snapshot["schema"] != PERSONA_SNAPSHOT_SCHEMA:
        raise ValueError("Persona snapshot schema is unsupported")
    if any(not isinstance(snapshot[key], str) or not snapshot[key].strip() for key in (
        "id",
        "name",
        "instruction",
        "detail",
        "digest",
    )):
        raise ValueError("Persona snapshot text fields are invalid")
    if isinstance(snapshot["binding_revision"], bool) or not isinstance(
        snapshot["binding_revision"], int
    ) or snapshot["binding_revision"] < 1:
        raise ValueError("Persona snapshot binding revision is invalid")
    if snapshot["digest"] != _snapshot_digest(snapshot):
        raise ValueError("Persona snapshot digest does not match content")
    return snapshot


def render_persona_instruction(snapshot: dict[str, Any]) -> str:
    normalized = normalize_persona_snapshot(snapshot)
    return (
        f'<persona id="{normalized["id"]}">\n'
        "以下内容定义与提问者的协作和表达方式；调查、安全、证据与工具规则保持优先。\n"
        f'{normalized["instruction"].strip()}\n'
        "</persona>"
    )
