"""Deterministic first-party capability and Agent Profile release artifacts.

The artifact contract is deliberately filesystem-only.  Building and
verifying a release never opens the Runtime database and never writes a
managed workspace.  Installation is handled by ``capability_installations``.
"""

from __future__ import annotations

import base64
import csv
import hashlib
import io
import json
import re
import stat
import tomllib
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

from .agent_profiles import inspect_agent_profile_source
from .capability_packages import inspect_capability_package

RELEASE_SCHEMA = "suwen-release.v1"
BUILDER_CONTRACT = "suwen-release-builder.v1"
ARTIFACT_SUFFIX = ".suwenpkg"
_FIXED_ZIP_TIME = (1980, 1, 1, 0, 0, 0)
_MAX_ENTRIES = 2_000
_MAX_ENTRY_BYTES = 16 * 1024 * 1024
_MAX_TOTAL_BYTES = 64 * 1024 * 1024
_DIGEST = re.compile(r"^[0-9a-f]{64}$")
_RESOURCE_TYPES = frozenset({"capability", "agent-profile"})
_TOP_LEVEL = frozenset({"release.json", "inventory.json", "release-notes.md", "source", "payload"})


class ReleaseArtifactError(ValueError):
    """The release bytes or authoring source violate ``suwen-release.v1``."""


@dataclass(frozen=True)
class ReleaseArtifact:
    path: Path
    artifact_digest: str
    resource_type: str
    resource_id: str
    version: str
    source_content_digest: str
    payload_digest: str
    trusted_code: bool
    release: dict[str, Any]
    inventory: tuple[dict[str, Any], ...]

    def public_view(self) -> dict[str, Any]:
        return {
            "schema": RELEASE_SCHEMA,
            "resource_type": self.resource_type,
            "id": self.resource_id,
            "version": self.version,
            "source_content_digest": self.source_content_digest,
            "artifact_digest": self.artifact_digest,
            "payload_digest": self.payload_digest,
            "trusted_code": self.trusted_code,
            "entry_count": len(self.inventory),
            "path": str(self.path),
        }


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def file_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_release_artifact(
    source_root: Path,
    output_dir: Path,
    *,
    source_revision: str,
    release_notes: str | None = None,
    rollback_target: str | None = None,
) -> ReleaseArtifact:
    """Build byte-identical release bytes from an identical declared input."""

    source_root = source_root.resolve()
    output_dir = output_dir.resolve()
    if not source_root.is_dir():
        raise ReleaseArtifactError("release source must be a directory")
    if not source_revision.strip() or len(source_revision) > 200 or "\x00" in source_revision:
        raise ReleaseArtifactError("source revision must be non-empty safe text")

    source_entries = _source_entries(source_root)
    source_map = {f"source/{name}": payload for name, payload in source_entries}
    payload_map: dict[str, bytes] = {}

    if (source_root / "manifest.toml").is_file():
        manifest, source_digest = inspect_capability_package(source_root)
        resource_type = "capability"
        resource_id = manifest.id
        version = manifest.version
        resource_schema = manifest.schema
        trusted_code = manifest.trusted_code
        api_range = manifest.capability_api
        external_dependencies = list(manifest.external_dependencies)
        provided_external_dependencies = list(
            manifest.provided_external_dependencies
        )
        capability_kind: str | None = manifest.kind
        distribution: str | None = manifest.distribution
        python_namespace: str | None = manifest.python_namespace
        if manifest.kind == "tools":
            if not distribution or not python_namespace:
                raise ReleaseArtifactError("tools capability distribution identity is unavailable")
            wheel_name, wheel_bytes = _build_tools_wheel(
                source_root,
                distribution,
                python_namespace,
                manifest.version,
            )
            payload_map[f"payload/wheels/{wheel_name}"] = wheel_bytes
            payload_kind = "pure-python-wheel"
            payload_digest = sha256_bytes(wheel_bytes)
        else:
            payload_kind = "declarative-source"
            payload_digest = source_digest
    elif (source_root / "profile.toml").is_file():
        profile = inspect_agent_profile_source(source_root / "profile.toml")
        resource_type = "agent-profile"
        resource_id = profile.id
        version = profile.version
        resource_schema = profile.manifest()["schema"]
        trusted_code = False
        api_range = None
        external_dependencies = []
        provided_external_dependencies = []
        capability_kind = None
        distribution = None
        python_namespace = None
        source_digest = profile.digest
        payload_kind = "profile-source"
        payload_digest = source_digest
    else:
        raise ReleaseArtifactError("release source requires manifest.toml or profile.toml")

    notes = release_notes or f"# {resource_id} {version}\n\nRollback target: {rollback_target or 'none'}\n"
    if "\x00" in notes or not notes.strip():
        raise ReleaseArtifactError("release notes must be non-empty safe text")

    content_entries = {**source_map, **payload_map, "release-notes.md": notes.encode("utf-8")}
    inventory = [_inventory_item(name, payload) for name, payload in sorted(content_entries.items())]
    inventory_bytes = canonical_json_bytes({"schema": RELEASE_SCHEMA, "entries": inventory})
    release = {
        "schema": RELEASE_SCHEMA,
        "builder_contract": BUILDER_CONTRACT,
        "resource_type": resource_type,
        "id": resource_id,
        "version": version,
        "resource_schema": resource_schema,
        "capability_kind": capability_kind,
        "capability_api": api_range,
        "distribution": distribution,
        "trusted_code": trusted_code,
        "external_dependencies": external_dependencies,
        "provided_external_dependencies": provided_external_dependencies,
        "python_namespace": python_namespace,
        "source": {"revision": source_revision, "content_digest": source_digest},
        "payload": {"kind": payload_kind, "digest": payload_digest},
        "inventory_digest": sha256_bytes(inventory_bytes),
        "rollback_target": rollback_target,
    }
    final_entries = {
        **content_entries,
        "inventory.json": inventory_bytes,
        "release.json": canonical_json_bytes(release),
    }
    output_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    target = output_dir / f"{resource_id}-{version}{ARTIFACT_SUFFIX}"
    temporary = output_dir / f".{target.name}.tmp"
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_STORED, strict_timestamps=True) as archive:
        for name, payload in sorted(final_entries.items()):
            _write_zip_entry(archive, name, payload)
    temporary.replace(target)
    return verify_release_artifact(target)


def verify_release_artifact(path: Path, *, expected_digest: str | None = None) -> ReleaseArtifact:
    path = path.resolve()
    if not path.is_file() or path.suffix != ARTIFACT_SUFFIX:
        raise ReleaseArtifactError("release artifact must be an existing .suwenpkg file")
    artifact_digest = file_digest(path)
    if expected_digest is not None and (
        not _DIGEST.fullmatch(expected_digest) or expected_digest != artifact_digest
    ):
        raise ReleaseArtifactError("release artifact digest mismatch")

    entries = _read_safe_zip(path)
    required = {"release.json", "inventory.json", "release-notes.md"}
    if not required.issubset(entries):
        raise ReleaseArtifactError("release artifact is missing required metadata")
    top_level = {PurePosixPath(name).parts[0] for name in entries}
    unknown = top_level - _TOP_LEVEL
    if unknown:
        raise ReleaseArtifactError(
            f"release artifact contains unsupported top-level entry {sorted(unknown)[0]}"
        )

    release = _json_object(entries["release.json"], "release.json")
    inventory_doc = _json_object(entries["inventory.json"], "inventory.json")
    if release.get("schema") != RELEASE_SCHEMA or release.get("builder_contract") != BUILDER_CONTRACT:
        raise ReleaseArtifactError("unsupported release artifact contract")
    if inventory_doc.get("schema") != RELEASE_SCHEMA or not isinstance(inventory_doc.get("entries"), list):
        raise ReleaseArtifactError("release inventory is invalid")
    if sha256_bytes(entries["inventory.json"]) != release.get("inventory_digest"):
        raise ReleaseArtifactError("release inventory digest mismatch")

    inventory: list[dict[str, Any]] = []
    expected_names: set[str] = set()
    for raw in inventory_doc["entries"]:
        if not isinstance(raw, dict) or set(raw) != {"path", "sha256", "size", "mode", "role"}:
            raise ReleaseArtifactError("release inventory entry is invalid")
        name = raw.get("path")
        if not isinstance(name, str) or name in expected_names or name in {"release.json", "inventory.json"}:
            raise ReleaseArtifactError("release inventory path is invalid or duplicated")
        payload = entries.get(name)
        if payload is None:
            raise ReleaseArtifactError("release inventory references a missing entry")
        if raw.get("sha256") != sha256_bytes(payload) or raw.get("size") != len(payload):
            raise ReleaseArtifactError("release inventory content mismatch")
        if raw.get("mode") != "0644" or raw.get("role") != _entry_role(name):
            raise ReleaseArtifactError("release inventory metadata mismatch")
        expected_names.add(name)
        inventory.append(dict(raw))
    actual_content = set(entries) - {"release.json", "inventory.json"}
    if expected_names != actual_content:
        raise ReleaseArtifactError("release contains untracked content")

    resource_type = release.get("resource_type")
    resource_id = release.get("id")
    version = release.get("version")
    source = release.get("source")
    payload = release.get("payload")
    if (
        resource_type not in _RESOURCE_TYPES
        or not isinstance(resource_id, str)
        or not isinstance(version, str)
        or not isinstance(source, dict)
        or not isinstance(payload, dict)
        or not _DIGEST.fullmatch(str(source.get("content_digest", "")))
        or not _DIGEST.fullmatch(str(payload.get("digest", "")))
        or not isinstance(release.get("trusted_code"), bool)
    ):
        raise ReleaseArtifactError("release resource identity is invalid")

    source_root_digest = _source_digest_from_entries(entries, resource_type)
    if source_root_digest != source["content_digest"]:
        raise ReleaseArtifactError("release source content digest mismatch")
    if resource_type == "capability":
        _verify_capability_payload(release, entries)
    else:
        if release.get("trusted_code") is not False or release.get("capability_kind") is not None:
            raise ReleaseArtifactError("Agent Profile release cannot contain trusted code")
        if payload.get("kind") != "profile-source" or payload.get("digest") != source["content_digest"]:
            raise ReleaseArtifactError("Agent Profile payload is invalid")

    return ReleaseArtifact(
        path=path,
        artifact_digest=artifact_digest,
        resource_type=resource_type,
        resource_id=resource_id,
        version=version,
        source_content_digest=source["content_digest"],
        payload_digest=payload["digest"],
        trusted_code=release["trusted_code"],
        release=release,
        inventory=tuple(inventory),
    )


def extract_verified_release(artifact: ReleaseArtifact, target: Path) -> str:
    """Extract a verified release into an empty staging directory."""

    target = target.resolve()
    if target.exists() and any(target.iterdir()):
        raise ReleaseArtifactError("release staging target must be empty")
    target.mkdir(mode=0o700, parents=True, exist_ok=True)
    entries = _read_safe_zip(artifact.path)
    for name, payload in sorted(entries.items()):
        if name.startswith("payload/wheels/"):
            continue
        destination = target.joinpath(*PurePosixPath(name).parts)
        destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        destination.write_bytes(payload)
        destination.chmod(0o600)
    if artifact.release["payload"]["kind"] == "pure-python-wheel":
        wheel_names = [name for name in entries if name.startswith("payload/wheels/")]
        code_root = target / "code"
        code_root.mkdir(mode=0o700)
        _extract_wheel(entries[wheel_names[0]], code_root)
    return _tree_digest(target)


def _source_entries(root: Path) -> list[tuple[str, bytes]]:
    result: list[tuple[str, bytes]] = []
    seen_casefold: set[str] = set()
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix().encode("utf-8")):
        if path.is_dir():
            continue
        relative = path.relative_to(root)
        if "__pycache__" in relative.parts or path.suffix == ".pyc" or path.name == ".DS_Store":
            continue
        if path.is_symlink():
            raise ReleaseArtifactError("release source cannot contain symbolic links")
        name = relative.as_posix()
        _validate_archive_name(name)
        folded = name.casefold()
        if folded in seen_casefold:
            raise ReleaseArtifactError("release source contains case-conflicting paths")
        seen_casefold.add(folded)
        payload = path.read_bytes()
        if len(payload) > _MAX_ENTRY_BYTES:
            raise ReleaseArtifactError("release source entry exceeds size limit")
        result.append((name, payload))
    if not result:
        raise ReleaseArtifactError("release source is empty")
    return result


def _build_tools_wheel(
    root: Path,
    distribution: str,
    python_namespace: str,
    version: str,
) -> tuple[str, bytes]:
    pyproject = root / "pyproject.toml"
    if not pyproject.is_file():
        raise ReleaseArtifactError("tools capability requires pyproject.toml")
    with pyproject.open("rb") as handle:
        raw = tomllib.load(handle)
    project = raw.get("project")
    if not isinstance(project, dict):
        raise ReleaseArtifactError("tools pyproject requires [project]")
    if project.get("name") != distribution or project.get("version") != version:
        raise ReleaseArtifactError("tools distribution identity must match capability Manifest")
    if project.get("dependencies", []) != []:
        raise ReleaseArtifactError("release v1 tools wheel cannot declare dependencies")
    package_name = python_namespace
    package_root = root / "src" / package_name
    if not package_root.is_dir() or not (package_root / "__init__.py").is_file():
        raise ReleaseArtifactError("tools source package is unavailable")

    wheel_entries: dict[str, bytes] = {}
    for name, payload in _source_entries(package_root):
        if Path(name).suffix not in {".py", ".json", ".swift"}:
            raise ReleaseArtifactError(
                "release v1 tools wheel accepts Python and bounded package resources only"
            )
        wheel_entries[f"{package_name}/{name}"] = payload
    dist_info = f"{package_name}-{version}.dist-info"
    metadata = (
        "Metadata-Version: 2.3\n"
        f"Name: {distribution}\n"
        f"Version: {version}\n"
        f"Summary: {str(project.get('description', '')).strip()}\n"
        f"Requires-Python: {project.get('requires-python', '>=3.11')}\n\n"
    ).encode()
    wheel = (
        b"Wheel-Version: 1.0\nGenerator: suwen-release-builder.v1\nRoot-Is-Purelib: true\nTag: py3-none-any\n"
    )
    wheel_entries[f"{dist_info}/METADATA"] = metadata
    wheel_entries[f"{dist_info}/WHEEL"] = wheel
    record_name = f"{dist_info}/RECORD"
    rows = []
    for name, payload in sorted(wheel_entries.items()):
        encoded = base64.urlsafe_b64encode(hashlib.sha256(payload).digest()).rstrip(b"=").decode("ascii")
        rows.append((name, f"sha256={encoded}", str(len(payload))))
    rows.append((record_name, "", ""))
    stream = io.StringIO(newline="")
    writer = csv.writer(stream, lineterminator="\n")
    writer.writerows(rows)
    wheel_entries[record_name] = stream.getvalue().encode("utf-8")

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_STORED, strict_timestamps=True) as archive:
        for name, payload in sorted(wheel_entries.items()):
            _write_zip_entry(archive, name, payload)
    return f"{package_name}-{version}-py3-none-any.whl", buffer.getvalue()


def _verify_capability_payload(release: dict[str, Any], entries: dict[str, bytes]) -> None:
    payload = release["payload"]
    kind = release.get("capability_kind")
    manifest_bytes = entries.get("source/manifest.toml")
    if manifest_bytes is None:
        raise ReleaseArtifactError("capability release is missing source Manifest")
    try:
        manifest = tomllib.loads(manifest_bytes.decode("utf-8"))
    except (UnicodeDecodeError, tomllib.TOMLDecodeError) as exc:
        raise ReleaseArtifactError("capability source Manifest is invalid") from exc
    if manifest.get("id") != release["id"] or manifest.get("version") != release["version"]:
        raise ReleaseArtifactError("capability release identity differs from source Manifest")
    if manifest.get("kind") != kind or bool(manifest.get("trusted_code")) != release["trusted_code"]:
        raise ReleaseArtifactError("capability release contract differs from source Manifest")
    if manifest.get("provided_external_dependencies", []) != release.get(
        "provided_external_dependencies", []
    ):
        raise ReleaseArtifactError("capability provided dependency contract differs from release")
    expected_distribution = manifest.get("distribution", release["id"] if kind == "tools" else None)
    expected_namespace = manifest.get(
        "python_namespace",
        release["id"].replace("-", "_") if kind == "tools" else None,
    )
    if (
        release.get("distribution") != expected_distribution
        or release.get("python_namespace") != expected_namespace
    ):
        raise ReleaseArtifactError("capability Python identity differs from source Manifest")
    wheel_names = [name for name in entries if name.startswith("payload/wheels/")]
    if kind == "tools":
        if payload.get("kind") != "pure-python-wheel" or len(wheel_names) != 1:
            raise ReleaseArtifactError("tools release requires exactly one wheel")
        wheel_bytes = entries[wheel_names[0]]
        if sha256_bytes(wheel_bytes) != payload.get("digest"):
            raise ReleaseArtifactError("tools wheel digest mismatch")
        _verify_tools_wheel(
            wheel_bytes,
            str(expected_distribution),
            str(expected_namespace),
            release["version"],
        )
    elif kind == "domain":
        if wheel_names or payload.get("kind") != "declarative-source":
            raise ReleaseArtifactError("domain release cannot contain executable payload")
        if payload.get("digest") != release["source"]["content_digest"]:
            raise ReleaseArtifactError("domain payload digest mismatch")
    else:
        raise ReleaseArtifactError("capability release kind is invalid")


def _verify_tools_wheel(
    payload: bytes,
    distribution: str,
    python_namespace: str,
    version: str,
) -> None:
    entries = _read_safe_zip_bytes(payload, "tools wheel")
    metadata_names = [name for name in entries if name.endswith(".dist-info/METADATA")]
    wheel_names = [name for name in entries if name.endswith(".dist-info/WHEEL")]
    record_names = [name for name in entries if name.endswith(".dist-info/RECORD")]
    if len(metadata_names) != 1 or len(wheel_names) != 1 or len(record_names) != 1:
        raise ReleaseArtifactError("tools wheel metadata is incomplete")
    metadata = entries[metadata_names[0]].decode("utf-8")
    if f"Name: {distribution}\n" not in metadata or f"Version: {version}\n" not in metadata:
        raise ReleaseArtifactError("tools wheel identity mismatch")
    if "Requires-Dist:" in metadata:
        raise ReleaseArtifactError("release v1 tools wheel cannot require dependencies")
    wheel = entries[wheel_names[0]].decode("utf-8")
    if "Root-Is-Purelib: true" not in wheel or "Tag: py3-none-any" not in wheel:
        raise ReleaseArtifactError("release v1 tools wheel must be pure Python")
    package_root = python_namespace + "/"
    for name in entries:
        if name.endswith((".so", ".dylib", ".dll", ".pyd")):
            raise ReleaseArtifactError("release v1 tools wheel cannot contain native code")
        if not (name.startswith(package_root) or ".dist-info/" in name):
            raise ReleaseArtifactError("tools wheel contains an undeclared package")
    _verify_wheel_record(entries, record_names[0])


def _verify_wheel_record(entries: dict[str, bytes], record_name: str) -> None:
    rows = list(csv.reader(io.StringIO(entries[record_name].decode("utf-8"))))
    records = {row[0]: row[1:] for row in rows if len(row) == 3}
    if set(records) != set(entries):
        raise ReleaseArtifactError("tools wheel RECORD does not cover exact contents")
    for name, payload in entries.items():
        digest, size = records[name]
        if name == record_name:
            if digest or size:
                raise ReleaseArtifactError("tools wheel RECORD self-entry must be empty")
            continue
        encoded = base64.urlsafe_b64encode(hashlib.sha256(payload).digest()).rstrip(b"=").decode("ascii")
        if digest != f"sha256={encoded}" or size != str(len(payload)):
            raise ReleaseArtifactError("tools wheel RECORD content mismatch")


def _source_digest_from_entries(entries: dict[str, bytes], resource_type: str) -> str:
    source = {
        name.removeprefix("source/"): payload
        for name, payload in entries.items()
        if name.startswith("source/")
    }
    if not source:
        raise ReleaseArtifactError("release source snapshot is empty")
    if resource_type == "agent-profile":
        profile = source.get("profile.toml")
        if profile is None:
            raise ReleaseArtifactError("Agent Profile release is missing profile.toml")
        return _profile_digest_bytes(profile)
    digest = hashlib.sha256()
    for name, payload in sorted(source.items()):
        encoded = name.encode("utf-8")
        digest.update(len(encoded).to_bytes(4, "big"))
        digest.update(encoded)
        digest.update(len(payload).to_bytes(8, "big"))
        digest.update(payload)
    return digest.hexdigest()


def _profile_digest_bytes(payload: bytes) -> str:
    temporary = io.BytesIO(payload)
    try:
        raw = tomllib.load(temporary)
    except tomllib.TOMLDecodeError as exc:
        raise ReleaseArtifactError("Agent Profile source is invalid") from exc
    allowed = {
        "schema",
        "id",
        "version",
        "name",
        "description",
        "language",
        "max_tool_risk",
        "host_prompt",
        "packs",
        "capabilities",
        "connectors",
    }
    if not isinstance(raw, dict) or set(raw) - allowed:
        raise ReleaseArtifactError("Agent Profile source fields are invalid")
    return sha256_bytes(canonical_json_bytes(raw))


def _read_safe_zip(path: Path) -> dict[str, bytes]:
    try:
        with zipfile.ZipFile(path) as archive:
            return _validated_zip_entries(archive, "release artifact")
    except zipfile.BadZipFile as exc:
        raise ReleaseArtifactError("release artifact is not a valid ZIP") from exc


def _read_safe_zip_bytes(payload: bytes, label: str) -> dict[str, bytes]:
    try:
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            return _validated_zip_entries(archive, label)
    except zipfile.BadZipFile as exc:
        raise ReleaseArtifactError(f"{label} is not a valid ZIP") from exc


def _validated_zip_entries(archive: zipfile.ZipFile, label: str) -> dict[str, bytes]:
    infos = archive.infolist()
    if not infos or len(infos) > _MAX_ENTRIES:
        raise ReleaseArtifactError(f"{label} entry count is invalid")
    result: dict[str, bytes] = {}
    folded: set[str] = set()
    total = 0
    for info in infos:
        name = info.filename
        _validate_archive_name(name)
        if name in result or name.casefold() in folded:
            raise ReleaseArtifactError(f"{label} contains duplicate or case-conflicting paths")
        mode = info.external_attr >> 16
        if stat.S_IFMT(mode) not in {0, stat.S_IFREG} or info.is_dir():
            raise ReleaseArtifactError(f"{label} contains a non-regular entry")
        if info.file_size > _MAX_ENTRY_BYTES:
            raise ReleaseArtifactError(f"{label} entry exceeds size limit")
        total += info.file_size
        if total > _MAX_TOTAL_BYTES:
            raise ReleaseArtifactError(f"{label} exceeds total size limit")
        payload = archive.read(info)
        if len(payload) != info.file_size:
            raise ReleaseArtifactError(f"{label} entry size mismatch")
        result[name] = payload
        folded.add(name.casefold())
    return result


def _validate_archive_name(name: str) -> None:
    path = PurePosixPath(name)
    if (
        not name
        or name.startswith("/")
        or "\\" in name
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise ReleaseArtifactError("release contains an unsafe path")


def _write_zip_entry(archive: zipfile.ZipFile, name: str, payload: bytes) -> None:
    info = zipfile.ZipInfo(name, _FIXED_ZIP_TIME)
    info.compress_type = zipfile.ZIP_STORED
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | 0o644) << 16
    archive.writestr(info, payload)


def _inventory_item(name: str, payload: bytes) -> dict[str, Any]:
    return {
        "path": name,
        "sha256": sha256_bytes(payload),
        "size": len(payload),
        "mode": "0644",
        "role": _entry_role(name),
    }


def _entry_role(name: str) -> str:
    if name == "release-notes.md":
        return "release-notes"
    if name.startswith("source/"):
        return "source"
    if name.startswith("payload/"):
        return "payload"
    raise ReleaseArtifactError("release inventory path has no declared role")


def _json_object(payload: bytes, label: str) -> dict[str, Any]:
    try:
        value = json.loads(payload)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ReleaseArtifactError(f"{label} must be valid UTF-8 JSON") from exc
    if not isinstance(value, dict):
        raise ReleaseArtifactError(f"{label} must be a JSON object")
    return value


def _extract_wheel(payload: bytes, target: Path) -> None:
    entries = _read_safe_zip_bytes(payload, "tools wheel")
    for name, value in sorted(entries.items()):
        destination = target.joinpath(*PurePosixPath(name).parts)
        destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        destination.write_bytes(value)
        destination.chmod(0o600)


def _tree_digest(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(
        (item for item in root.rglob("*") if item.is_file()),
        key=lambda item: item.relative_to(root).as_posix(),
    ):
        name = path.relative_to(root).as_posix().encode("utf-8")
        payload = path.read_bytes()
        digest.update(len(name).to_bytes(4, "big"))
        digest.update(name)
        digest.update(len(payload).to_bytes(8, "big"))
        digest.update(payload)
    return digest.hexdigest()


__all__ = [
    "ARTIFACT_SUFFIX",
    "BUILDER_CONTRACT",
    "RELEASE_SCHEMA",
    "ReleaseArtifact",
    "ReleaseArtifactError",
    "build_release_artifact",
    "extract_verified_release",
    "file_digest",
    "verify_release_artifact",
]
