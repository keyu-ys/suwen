from __future__ import annotations

import asyncio
import html
import os
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .artifacts import ArtifactStore
from .tools import ToolRegistry
from .types import EvidenceEnvelope, EvidenceState, ToolDefinition, ToolRisk

_BROWSER_CANDIDATES = (
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/usr/bin/google-chrome",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
)
_PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
_PNG_END = b"\x00\x00\x00\x00IEND\xaeB`\x82"


@dataclass(frozen=True)
class _Node:
    id: str
    label: str
    description: str
    kind: str
    fields: tuple[str, ...]


@dataclass(frozen=True)
class _Edge:
    source: str
    target: str
    label: str


def diagram_tool_definition() -> ToolDefinition:
    """Return the generic, model-composed diagram contract.

    The Runtime owns only bounded rendering and Run-bound Artifact delivery. It
    never infers business nodes, relationships, routes, or conclusions.
    """

    node_schema = {
        "type": "object",
        "properties": {
            "id": {"type": "string", "minLength": 1, "maxLength": 40},
            "label": {"type": "string", "minLength": 1, "maxLength": 80},
            "description": {"type": "string", "maxLength": 240},
            "kind": {
                "type": "string",
                "enum": ["start", "process", "decision", "evidence", "unknown", "end", "entity"],
            },
            "fields": {
                "type": "array",
                "items": {"type": "string", "minLength": 1, "maxLength": 100},
                "maxItems": 10,
            },
        },
        "required": ["id", "label"],
        "additionalProperties": False,
    }
    edge_schema = {
        "type": "object",
        "properties": {
            "from": {"type": "string", "minLength": 1, "maxLength": 40},
            "to": {"type": "string", "minLength": 1, "maxLength": 40},
            "label": {"type": "string", "maxLength": 80},
        },
        "required": ["from", "to"],
        "additionalProperties": False,
    }
    return ToolDefinition(
        name="render_explanation_diagram",
        description=(
            "Render a bounded flowchart or entity-relationship diagram from nodes and relations "
            "you have already composed. Use only when a visual materially improves the final "
            "explanation. The result is a current-Run PNG Artifact and is presentation, not new "
            "source evidence; cite it in Markdown as ![description](artifact://ARTIFACT_ID)."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "diagram_type": {"type": "string", "enum": ["flowchart", "entity_relationship"]},
                "title": {"type": "string", "minLength": 1, "maxLength": 100},
                "direction": {"type": "string", "enum": ["top_down", "left_right"]},
                "nodes": {"type": "array", "items": node_schema, "minItems": 2, "maxItems": 12},
                "edges": {"type": "array", "items": edge_schema, "maxItems": 20},
                "caption": {"type": "string", "maxLength": 240},
            },
            "required": ["diagram_type", "title", "nodes", "edges"],
            "additionalProperties": False,
        },
        risk=ToolRisk.READ_ONLY,
        timeout_seconds=20.0,
        provider_id="runtime-core",
        resource_class="heavy_media",
        run_call_limit=2,
        run_call_limit_range=(1, 4),
    )


class DiagramRenderer:
    """Render model-composed structures in an isolated local browser."""

    def __init__(self, artifacts: ArtifactStore, data_dir: Path) -> None:
        self.artifacts = artifacts
        self.data_dir = data_dir.resolve()

    def register_tool(self, registry: ToolRegistry) -> None:
        async def render(arguments: dict[str, Any]) -> EvidenceEnvelope:
            context = arguments.get("_runtime_context")
            if not isinstance(context, dict):
                raise ValueError("trusted Run context is unavailable")
            case_id = context.get("case_id")
            run_id = context.get("run_id")
            if not isinstance(case_id, str) or not isinstance(run_id, str):
                raise ValueError("trusted Case and Run context are unavailable")
            return await self.render(arguments, case_id=case_id, run_id=run_id)

        registry.register(diagram_tool_definition(), render)

    async def render(
        self,
        arguments: dict[str, Any],
        *,
        case_id: str,
        run_id: str,
    ) -> EvidenceEnvelope:
        nodes, edges = _normalize_graph(arguments)
        diagram_type = str(arguments["diagram_type"])
        title = str(arguments["title"]).strip()
        direction = str(arguments.get("direction", "top_down"))
        caption = str(arguments.get("caption", "")).strip()
        width, height, page = _diagram_page(
            diagram_type=diagram_type,
            title=title,
            direction=direction,
            nodes=nodes,
            edges=edges,
            caption=caption,
        )
        browser = _browser_executable()
        if browser is None:
            return EvidenceEnvelope(
                state=EvidenceState.NOT_OBSERVABLE,
                summary="当前运行环境没有可用的本地网页渲染器，未生成图示。",
                coverage_state="not_observable",
                source_role="derived_presentation",
                limitations=("local_browser_renderer_unavailable",),
                safe_statements=("文字答复不受影响，可继续使用 Markdown 结构表达",),
            )

        temporary_root = self.data_dir / "tmp"
        temporary_root.mkdir(mode=0o700, parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="diagram-", dir=temporary_root) as directory:
            working = Path(directory)
            page_path = working / "diagram.html"
            image_path = working / "diagram.png"
            page_path.write_text(page, encoding="utf-8")
            process = await asyncio.create_subprocess_exec(
                str(browser),
                "--headless=new",
                "--disable-gpu",
                "--disable-extensions",
                "--disable-background-networking",
                "--disable-sync",
                "--hide-scrollbars",
                "--no-first-run",
                "--no-default-browser-check",
                f"--user-data-dir={working / 'browser-profile'}",
                f"--window-size={width},{height}",
                f"--screenshot={image_path}",
                page_path.as_uri(),
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                rendered = await _wait_for_complete_png(image_path, process, timeout=15.0)
            finally:
                if process.returncode is None:
                    process.terminate()
                    try:
                        await asyncio.wait_for(process.wait(), timeout=2.0)
                    except TimeoutError:
                        process.kill()
                        await process.wait()
            stderr = await process.stderr.read() if process.stderr is not None else b""
            if not rendered or not image_path.is_file():
                detail = stderr.decode("utf-8", errors="replace")[-600:].strip()
                raise RuntimeError(f"local diagram renderer failed: {detail or 'PNG was not produced'}")
            content = image_path.read_bytes()
            if not content.startswith(_PNG_SIGNATURE):
                raise RuntimeError("local diagram renderer returned an invalid PNG")

        descriptor = self.artifacts.write(
            content,
            case_id=case_id,
            run_id=run_id,
            suffix=".png",
            sensitive=True,
        )
        artifact_id = str(descriptor["id"])
        return EvidenceEnvelope(
            state=EvidenceState.OBSERVED,
            summary="已把本轮组织的节点与关系渲染为可嵌入答复的 PNG 图示。",
            data={
                "diagram_type": diagram_type,
                "title": title,
                "caption": caption,
                "node_count": len(nodes),
                "edge_count": len(edges),
                "artifact_id": artifact_id,
                "artifact_uri": f"artifact://{artifact_id}",
                "media_type": "image/png",
                "width": width,
                "height": height,
                "content_sha256": descriptor["sha256"],
            },
            coverage_state="proven_total",
            source_ref=f"artifact:{artifact_id}",
            source_role="derived_presentation",
            limitations=("diagram_is_model_composed_presentation_not_source_evidence",),
            safe_statements=("图中节点与关系只来自本次 Tool 调用的结构化输入",),
        )


def _browser_executable() -> Path | None:
    configured = os.getenv("SUWEN_DIAGRAM_BROWSER_PATH", "").strip()
    candidates = (configured, *_BROWSER_CANDIDATES) if configured else _BROWSER_CANDIDATES
    for candidate in candidates:
        path = Path(candidate).expanduser()
        if path.is_file() and os.access(path, os.X_OK):
            return path.resolve()
    for executable in ("google-chrome", "chromium", "chromium-browser"):
        resolved = shutil.which(executable)
        if resolved:
            return Path(resolved).resolve()
    return None


async def _wait_for_complete_png(
    image_path: Path,
    process: asyncio.subprocess.Process,
    *,
    timeout: float,
) -> bool:
    """Wait for Chrome's atomic-enough output, not for its macOS helper teardown.

    Some managed Chrome installations keep their parent process alive after
    `--screenshot` has successfully flushed the PNG. The current subprocess is
    owned by this Tool invocation, so the bounded renderer stops it once a full
    PNG end chunk is visible.
    """

    deadline = asyncio.get_running_loop().time() + timeout
    while asyncio.get_running_loop().time() < deadline:
        if image_path.is_file():
            content = image_path.read_bytes()
            if content.startswith(_PNG_SIGNATURE) and content.endswith(_PNG_END):
                return True
        if process.returncode is not None:
            return False
        await asyncio.sleep(0.1)
    return False


def _normalize_graph(arguments: dict[str, Any]) -> tuple[tuple[_Node, ...], tuple[_Edge, ...]]:
    raw_nodes = arguments.get("nodes")
    raw_edges = arguments.get("edges")
    if not isinstance(raw_nodes, list) or not isinstance(raw_edges, list):
        raise ValueError("diagram nodes and edges must be arrays")
    nodes: list[_Node] = []
    seen: set[str] = set()
    diagram_type = str(arguments.get("diagram_type"))
    for item in raw_nodes:
        if not isinstance(item, dict):
            raise ValueError("diagram node must be an object")
        node_id = str(item["id"]).strip()
        if node_id in seen:
            raise ValueError(f"diagram node id is duplicated: {node_id}")
        seen.add(node_id)
        fields = item.get("fields", [])
        if not isinstance(fields, list):
            raise ValueError("diagram node fields must be an array")
        nodes.append(
            _Node(
                id=node_id,
                label=str(item["label"]).strip(),
                description=str(item.get("description", "")).strip(),
                kind=str(item.get("kind", "entity" if diagram_type == "entity_relationship" else "process")),
                fields=tuple(str(value).strip() for value in fields if str(value).strip()),
            )
        )
    edges: list[_Edge] = []
    for item in raw_edges:
        if not isinstance(item, dict):
            raise ValueError("diagram edge must be an object")
        source = str(item["from"]).strip()
        target = str(item["to"]).strip()
        if source not in seen or target not in seen:
            raise ValueError("diagram edge references an unknown node")
        edges.append(_Edge(source=source, target=target, label=str(item.get("label", "")).strip()))
    return tuple(nodes), tuple(edges)


def _diagram_page(
    *,
    diagram_type: str,
    title: str,
    direction: str,
    nodes: tuple[_Node, ...],
    edges: tuple[_Edge, ...],
    caption: str,
) -> tuple[int, int, str]:
    card_width = 280 if diagram_type == "entity_relationship" else 260
    card_height = max(
        104,
        max((88 + len(node.fields) * 25 + (32 if node.description else 0) for node in nodes), default=104),
    )
    ranks = _graph_ranks(nodes, edges)
    rank_groups: dict[int, list[_Node]] = {}
    for node in nodes:
        rank_groups.setdefault(ranks[node.id], []).append(node)
    layers = [rank_groups[key] for key in sorted(rank_groups)]
    layer_gap = 115
    item_gap = 46
    margin_x = 90
    margin_top = 132
    caption_height = 64 if caption else 28
    max_layer = max(len(layer) for layer in layers)
    if direction == "left_right":
        width = margin_x * 2 + len(layers) * card_width + max(0, len(layers) - 1) * layer_gap
        height = margin_top + max_layer * card_height + max(0, max_layer - 1) * item_gap + caption_height
    else:
        width = margin_x * 2 + max_layer * card_width + max(0, max_layer - 1) * item_gap
        height = margin_top + len(layers) * card_height + max(0, len(layers) - 1) * layer_gap + caption_height
    width = min(max(width, 760), 1800)
    height = min(max(height, 520), 2200)

    positions: dict[str, tuple[float, float]] = {}
    for layer_index, layer in enumerate(layers):
        if direction == "left_right":
            x = margin_x + layer_index * (card_width + layer_gap)
            total = len(layer) * card_height + max(0, len(layer) - 1) * item_gap
            start_y = margin_top + max(0, (height - margin_top - caption_height - total) / 2)
            for item_index, node in enumerate(layer):
                positions[node.id] = (x, start_y + item_index * (card_height + item_gap))
        else:
            y = margin_top + layer_index * (card_height + layer_gap)
            total = len(layer) * card_width + max(0, len(layer) - 1) * item_gap
            start_x = max(margin_x, (width - total) / 2)
            for item_index, node in enumerate(layer):
                positions[node.id] = (start_x + item_index * (card_width + item_gap), y)

    lines: list[str] = []
    labels: list[str] = []
    for edge in edges:
        source_x, source_y = positions[edge.source]
        target_x, target_y = positions[edge.target]
        if direction == "left_right":
            x1, y1 = source_x + card_width, source_y + card_height / 2
            x2, y2 = target_x, target_y + card_height / 2
        else:
            x1, y1 = source_x + card_width / 2, source_y + card_height
            x2, y2 = target_x + card_width / 2, target_y
        bend = (y1 + y2) / 2 if direction != "left_right" else (x1 + x2) / 2
        path = (
            f"M {x1:.1f} {y1:.1f} C {x1:.1f} {bend:.1f}, {x2:.1f} {bend:.1f}, {x2:.1f} {y2:.1f}"
            if direction != "left_right"
            else f"M {x1:.1f} {y1:.1f} C {bend:.1f} {y1:.1f}, {bend:.1f} {y2:.1f}, {x2:.1f} {y2:.1f}"
        )
        lines.append(f'<path d="{path}" marker-end="url(#arrow)" />')
        if edge.label:
            label_x = (x1 + x2) / 2
            label_y = (y1 + y2) / 2 - 7
            labels.append(
                f'<text x="{label_x:.1f}" y="{label_y:.1f}" text-anchor="middle">'
                f"{html.escape(edge.label)}</text>"
            )

    node_markup: list[str] = []
    for node in nodes:
        x, y = positions[node.id]
        fields = "".join(f"<li>{html.escape(field)}</li>" for field in node.fields)
        node_markup.append(
            f'<section class="node kind-{html.escape(node.kind)}" '
            f'style="left:{x:.1f}px;top:{y:.1f}px;width:{card_width}px;min-height:{card_height}px">'
            f'<div class="node-kind">{html.escape(_kind_label(node.kind))}</div>'
            f'<h2>{html.escape(node.label)}</h2>'
            + (f'<p>{html.escape(node.description)}</p>' if node.description else "")
            + (f'<ul>{fields}</ul>' if fields else "")
            + "</section>"
        )

    escaped_caption = html.escape(caption)
    page = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
*{{box-sizing:border-box}}
html,body{{margin:0;width:100%;height:100%;overflow:hidden}}
body{{
  font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
  background:#f4f7f5;color:#20302a
}}
.canvas{{
  position:relative;width:{width}px;height:{height}px;
  background:radial-gradient(circle at top left,#eef8f2 0,transparent 38%),#f7f9f8
}}
.title{{position:absolute;left:54px;top:38px;margin:0;font-size:29px;line-height:1.25;color:#173d31;letter-spacing:.01em}}
.eyebrow{{position:absolute;right:54px;top:43px;color:#698078;font-size:14px;font-weight:650}}
.edges{{position:absolute;inset:0;width:100%;height:100%;overflow:visible}}
.edges path{{fill:none;stroke:#7c948b;stroke-width:2.1}}
.edges text{{
  font-size:13px;fill:#5d716a;paint-order:stroke;stroke:#f7f9f8;
  stroke-width:6px;stroke-linejoin:round
}}
.node{{
  position:absolute;padding:18px 20px;border:1px solid #d7e2dd;border-radius:17px;
  background:rgba(255,255,255,.97);box-shadow:0 8px 24px rgba(43,69,59,.08)
}}
.node-kind{{
  display:inline-flex;padding:3px 8px;border-radius:999px;background:#e7f3ec;
  color:#39705c;font-size:11px;font-weight:720;letter-spacing:.08em
}}
.node h2{{margin:9px 0 0;font-size:18px;line-height:1.34;color:#1e392f}}
.node p{{margin:8px 0 0;color:#5a6c65;font-size:13px;line-height:1.55}}
.node ul{{
  margin:10px 0 0;padding:9px 0 0 18px;border-top:1px solid #edf1ef;
  color:#4b5d56;font-size:12.5px;line-height:1.55
}}
.kind-start,.kind-end{{border-color:#b8d8c8;background:#f4fbf7}}.kind-decision{{border-color:#decfa8;background:#fffaf0}}
.kind-evidence{{border-color:#b9cfdf;background:#f5faff}}.kind-unknown{{border-style:dashed;border-color:#c7c8c8;background:#fbfbfb}}
.caption{{position:absolute;left:54px;right:54px;bottom:24px;margin:0;color:#667971;font-size:13px;line-height:1.45}}
</style>
</head>
<body><main class="canvas">
<h1 class="title">{html.escape(title)}</h1>
<div class="eyebrow">素问 · {"实体关系" if diagram_type == "entity_relationship" else "流程说明"}</div>
<svg class="edges" viewBox="0 0 {width} {height}" aria-hidden="true">
<defs>
  <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5"
          markerWidth="7" markerHeight="7" orient="auto-start-reverse">
    <path d="M 0 0 L 10 5 L 0 10 z" fill="#7c948b"/>
  </marker>
</defs>
{"".join(lines)}{"".join(labels)}
</svg>
{"".join(node_markup)}
{f'<p class="caption">{escaped_caption}</p>' if caption else ''}
</main></body></html>"""
    return width, height, page


def _graph_ranks(nodes: tuple[_Node, ...], edges: tuple[_Edge, ...]) -> dict[str, int]:
    ranks = {node.id: 0 for node in nodes}
    indegree = {node.id: 0 for node in nodes}
    outgoing: dict[str, list[str]] = {node.id: [] for node in nodes}
    for edge in edges:
        outgoing[edge.source].append(edge.target)
        indegree[edge.target] += 1
    queue = [node.id for node in nodes if indegree[node.id] == 0]
    visited: set[str] = set()
    while queue:
        current = queue.pop(0)
        visited.add(current)
        for target in outgoing[current]:
            ranks[target] = max(ranks[target], ranks[current] + 1)
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
    next_rank = max(ranks.values(), default=0) + 1
    for node in nodes:
        if node.id not in visited:
            ranks[node.id] = next_rank
            next_rank += 1
    return ranks


def _kind_label(kind: str) -> str:
    return {
        "start": "开始",
        "process": "步骤",
        "decision": "判断",
        "evidence": "证据",
        "unknown": "待确认",
        "end": "结果",
        "entity": "实体",
    }.get(kind, "节点")
