from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .access_tokens import (
    AccessTokenBundle,
    default_access_tokens_path,
    load_access_token_bundle,
)
from .process_manager import validate_process_manager

MODEL_REASONING_EFFORTS = frozenset({"none", "low", "medium", "high", "xhigh", "max"})
DEFAULT_MODEL_REASONING_EFFORT = "high"


@dataclass(frozen=True)
class ModelConfig:
    # Compatibility shape for direct Harness construction. Product execution
    # resolves its model from Model Registry + Agent Version instead of TOML.
    provider: str = "openai-compatible"
    model: str = "keyu-mtp"
    base_url: str = ""
    api_key_env: str = "SUWEN_LOCAL_MODEL_API_KEY"
    api_key_value: str = field(default="", repr=False)
    timeout_seconds: float = 300.0
    transport_max_retries: int = 3
    protocol_max_retries: int = 3
    transport_backoff_base_seconds: float = 1.0
    transport_backoff_cap_seconds: float = 10.0
    protocol_temperature_step: float = 0.2
    temperature: float = 0.2
    max_output_tokens: int = 4096
    # New Model Profile revisions default to an explicit high reasoning level.
    # None is retained only for legacy immutable revisions that historically
    # omitted the provider-neutral control.
    reasoning_effort: str | None = DEFAULT_MODEL_REASONING_EFFORT

    @property
    def api_key(self) -> str:
        return self.api_key_value or _environment_value(self.api_key_env)


@dataclass(frozen=True)
class HarnessConfig:
    max_tool_calls: int = 60
    max_tool_waves: int = 30
    context_message_limit: int = 80
    compact_after_messages: int = 50
    tool_result_recent_count: int = 2
    tool_result_old_max_chars: int = 3_000
    tool_result_recent_max_chars: int = 50_000
    context_safety_margin_ratio: float = 0.05
    context_safety_margin_min_tokens: int = 4_096
    context_checkpoint_ratio: float = 0.75
    context_reference_ratio: float = 0.85
    context_minimal_ratio: float = 0.90
    context_recent_protocol_pairs: int = 2
    context_recent_history_messages: int = 12
    context_evidence_card_max_chars: int = 2_400
    tool_timeout_seconds: float = 30.0
    run_timeout_seconds: float = 900.0
    max_concurrency: int = 3
    tool_call_limit_overrides: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True)
class LifecycleConfig:
    inactive_days: int = 7
    review_delay_seconds: int = 0


@dataclass(frozen=True)
class SchedulerConfig:
    poll_seconds: float = 2.0
    lease_seconds: int = 30


@dataclass(frozen=True)
class FeishuConfig:
    enabled: bool = False
    app_id_env: str = "SUWEN_FEISHU_APP_ID"
    app_secret_env: str = "SUWEN_FEISHU_APP_SECRET"
    verification_token_env: str = "SUWEN_FEISHU_VERIFICATION_TOKEN"
    encrypt_key_env: str = "SUWEN_FEISHU_ENCRYPT_KEY"
    bot_open_id_env: str = "SUWEN_FEISHU_BOT_OPEN_ID"
    allow_unverified_fixture_events: bool = False
    require_mention_in_group: bool = True
    sender: str = "capture"
    api_base_url: str = "https://open.feishu.cn/open-apis"
    allowed_actor_refs_env: str = "SUWEN_FEISHU_ALLOWED_ACTORS"
    allowed_chat_refs_env: str = "SUWEN_FEISHU_ALLOWED_CHATS"

    @property
    def app_id(self) -> str:
        return _environment_value(self.app_id_env)

    @property
    def app_secret(self) -> str:
        return _environment_value(self.app_secret_env)

    @property
    def verification_token(self) -> str:
        return _environment_value(self.verification_token_env)

    @property
    def encrypt_key(self) -> str:
        return _environment_value(self.encrypt_key_env)

    @property
    def bot_open_id(self) -> str:
        return _environment_value(self.bot_open_id_env)

    @property
    def allowed_actor_refs(self) -> set[str]:
        return _env_csv(self.allowed_actor_refs_env)

    @property
    def allowed_chat_refs(self) -> set[str]:
        return _env_csv(self.allowed_chat_refs_env)


@dataclass(frozen=True)
class ArtifactConfig:
    max_bytes: int = 10 * 1024 * 1024
    retention_hours: int = 24


@dataclass(frozen=True)
class ActionConfig:
    confirmation_ttl_seconds: int = 600


@dataclass(frozen=True)
class CandidateConfig:
    # Ten two-turn episodes can each require one Skill read plus the answer
    # turn.  Keep enough suite-level headroom for a small number of bounded
    # domain Tool calls without weakening the per-Run Tool/wave limits.
    max_model_turns: int = 60
    max_elapsed_seconds: int = 15 * 60

    def __post_init__(self) -> None:
        if self.max_model_turns < 1:
            raise ValueError("candidate.max_model_turns must be positive")
        if self.max_elapsed_seconds < 1:
            raise ValueError("candidate.max_elapsed_seconds must be positive")


@dataclass(frozen=True)
class Settings:
    name: str = "素问"
    runtime_mode: str = "test"
    data_dir: Path = Path(".data")
    database_path: Path = Path(".data/suwen.db")
    admin_token_env: str = "SUWEN_ADMIN_TOKEN"
    operator_token_env: str = "SUWEN_OPERATOR_TOKEN"
    reviewer_token_env: str = "SUWEN_REVIEWER_TOKEN"
    viewer_token_env: str = "SUWEN_VIEWER_TOKEN"
    api_token_env: str = "SUWEN_API_TOKEN"
    access_tokens_file: Path | None = None
    access_tokens: AccessTokenBundle | None = field(default=None, repr=False)
    model: ModelConfig = field(default_factory=ModelConfig)
    harness: HarnessConfig = field(default_factory=HarnessConfig)
    lifecycle: LifecycleConfig = field(default_factory=LifecycleConfig)
    scheduler: SchedulerConfig = field(default_factory=SchedulerConfig)
    feishu: FeishuConfig = field(default_factory=FeishuConfig)
    artifacts: ArtifactConfig = field(default_factory=ArtifactConfig)
    actions: ActionConfig = field(default_factory=ActionConfig)
    candidate: CandidateConfig = field(default_factory=CandidateConfig)
    packs_dir: Path = Path("packs")
    trusted_local_pack_refs: tuple[str, ...] = ("generic@0.3.0",)
    process_manager: str = "none"
    process_manager_label: str = ""
    # Test harnesses may opt in through direct construction. load_settings() never does.
    enable_test_fixture_agent: bool = False

    @property
    def admin_token(self) -> str:
        if self.access_tokens is not None:
            return self.access_tokens.admin_token
        return _environment_value(self.admin_token_env)

    @property
    def operator_token(self) -> str:
        return _environment_value(self.operator_token_env)

    @property
    def reviewer_token(self) -> str:
        return _environment_value(self.reviewer_token_env)

    @property
    def viewer_token(self) -> str:
        return _environment_value(self.viewer_token_env)

    @property
    def api_token(self) -> str:
        if self.access_tokens is not None:
            return self.access_tokens.api_token
        return _environment_value(self.api_token_env)

    def token_is_active(self, role: str, *, at: Any = None) -> bool:
        if role not in {"admin", "operator", "reviewer", "viewer", "api"}:
            raise ValueError("unsupported access token role")
        token = self.api_token if role == "api" else getattr(self, f"{role}_token")
        if not token:
            return False
        if self.access_tokens is not None and role in {"admin", "api"}:
            return not self.access_tokens.expired(at)
        return True


def _env_csv(name: str) -> set[str]:
    return {item.strip() for item in _environment_value(name).split(",") if item.strip()}


def _environment_value(name: str, default: str = "") -> str:
    return os.getenv(name, default)


def _section(data: dict[str, Any], name: str) -> dict[str, Any]:
    value = data.get(name, {})
    if not isinstance(value, dict):
        raise ValueError(f"configuration section {name!r} must be a table")
    return value


def _trusted_local_pack_refs(app: dict[str, Any]) -> tuple[str, ...]:
    configured: Any
    new_name = "SUWEN_TRUSTED_LOCAL_PACK_REFS"
    environment = _environment_value(new_name)
    if new_name in os.environ:
        configured = environment.split(",") if environment else []
    else:
        configured = app.get("trusted_local_pack_refs", ["generic@0.3.0"])
    if not isinstance(configured, list) or any(
        not isinstance(item, str) or not item.strip() for item in configured
    ):
        raise ValueError("app.trusted_local_pack_refs must be an array of exact id@version strings")
    normalized = tuple(item.strip() for item in configured)
    if len(normalized) != len(set(normalized)):
        raise ValueError("app.trusted_local_pack_refs must not contain duplicates")
    return normalized


def load_settings(path: str | Path | None = None) -> Settings:
    config_path = Path(path or _environment_value("SUWEN_CONFIG", "config/agent.toml"))
    data: dict[str, Any] = {}
    if config_path.exists():
        with config_path.open("rb") as handle:
            data = tomllib.load(handle)
    if "plugins" in data:
        raise ValueError("plugins configuration is unsupported; use native capability releases")

    app = _section(data, "app")
    fixture_keys = {"enable_test_fixture_agent", "enable_legacy_fixture_agent"} & set(app)
    if fixture_keys:
        raise ValueError("application configuration cannot enable synthetic test fixtures")
    model = _section(data, "model")
    harness = _section(data, "harness")
    lifecycle = _section(data, "lifecycle")
    scheduler = _section(data, "scheduler")
    feishu = _section(data, "feishu")
    artifacts = _section(data, "artifacts")
    actions = _section(data, "actions")
    candidate = _section(data, "candidate")
    data_dir = Path(_environment_value("SUWEN_DATA_DIR", str(app.get("data_dir", ".data"))))
    database_path = Path(
        _environment_value("SUWEN_DATABASE_PATH", str(app.get("database_path", data_dir / "suwen.db")))
    )
    process_manager, process_manager_label = validate_process_manager(
        _environment_value("SUWEN_PROCESS_MANAGER", str(app.get("process_manager", "none"))),
        _environment_value("SUWEN_PROCESS_MANAGER_LABEL", str(app.get("process_manager_label", ""))),
    )
    inferred_runtime_mode = (
        "production" if process_manager in {"launchd", "systemd"} else "development"
    )
    runtime_mode = _environment_value(
        "SUWEN_RUNTIME_MODE", str(app.get("runtime_mode", inferred_runtime_mode))
    )
    if runtime_mode not in {"development", "production"}:
        raise ValueError("app.runtime_mode must be development or production")
    configured_access_tokens_file = _environment_value(
        "SUWEN_ACCESS_TOKENS_FILE", str(app.get("access_tokens_file", ""))
    ).strip()
    if configured_access_tokens_file:
        access_tokens_file = Path(configured_access_tokens_file).expanduser()
    elif runtime_mode == "production":
        access_tokens_file = default_access_tokens_path(data_dir)
    else:
        access_tokens_file = None
    access_tokens = (
        load_access_token_bundle(access_tokens_file)
        if access_tokens_file is not None and access_tokens_file.is_file()
        else None
    )
    return Settings(
        name=app.get("name", "素问"),
        runtime_mode=runtime_mode,
        data_dir=data_dir,
        database_path=database_path,
        admin_token_env=app.get("admin_token_env", "SUWEN_ADMIN_TOKEN"),
        operator_token_env=app.get("operator_token_env", "SUWEN_OPERATOR_TOKEN"),
        reviewer_token_env=app.get("reviewer_token_env", "SUWEN_REVIEWER_TOKEN"),
        viewer_token_env=app.get("viewer_token_env", "SUWEN_VIEWER_TOKEN"),
        api_token_env=app.get("api_token_env", "SUWEN_API_TOKEN"),
        access_tokens_file=access_tokens_file,
        access_tokens=access_tokens,
        model=ModelConfig(**model),
        harness=HarnessConfig(**harness),
        lifecycle=LifecycleConfig(**lifecycle),
        scheduler=SchedulerConfig(**scheduler),
        feishu=FeishuConfig(**feishu),
        artifacts=ArtifactConfig(**artifacts),
        actions=ActionConfig(**actions),
        candidate=CandidateConfig(**candidate),
        packs_dir=Path(
            _environment_value("SUWEN_PACKS_DIR", str(app.get("packs_dir", data.get("packs_dir", "packs"))))
        ),
        trusted_local_pack_refs=_trusted_local_pack_refs(app),
        process_manager=process_manager,
        process_manager_label=process_manager_label,
    )
