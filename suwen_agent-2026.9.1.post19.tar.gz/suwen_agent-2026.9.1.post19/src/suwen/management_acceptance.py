from __future__ import annotations

import hashlib
import ipaddress
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

MANAGEMENT_E2E_SCHEMA_VERSION = "suwen-management-e2e.v1"
MANAGEMENT_E2E_REQUIRED_CHECKS = (
    "admin_model_configured",
    "admin_agent_created",
    "admin_pack_tools_selected",
    "admin_agent_validated",
    "admin_agent_published",
    "agent_model_isolation",
    "viewer_edit_denied",
    "reviewer_publish_denied",
    "admin_audit_visible",
    "secret_redaction",
    "refresh_recovery",
    "management_only_no_conversation",
)
_MANAGEMENT_WEB_FILES = ("index.html", "app.js", "style.css", "markdown-preview.js")
_ALLOWED_RUNNERS = {"manual_browser", "playwright"}


def management_web_asset_digest(web_root: Path, extra_assets: tuple[Path, ...] = ()) -> str:
    """Digest the exact management page assets used by one acceptance record."""

    digest = hashlib.sha256()
    for relative_name in _MANAGEMENT_WEB_FILES:
        path = web_root / relative_name
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"management web asset is missing: {relative_name}")
        digest.update(relative_name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    for path in extra_assets:
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"management reference asset is missing: {path.name}")
        digest.update(path.name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def management_e2e_template(
    agent_id: str,
    process_instance_id: str,
    process_started_at: str,
    asset_digest: str,
) -> dict[str, Any]:
    return {
        "schema_version": MANAGEMENT_E2E_SCHEMA_VERSION,
        "agent_id": agent_id,
        "runner": "manual_browser",
        "base_url": "http://127.0.0.1:8090",
        "process_instance_id": process_instance_id,
        "process_started_at": process_started_at,
        "management_asset_digest": asset_digest,
        "started_at": None,
        "finished_at": None,
        "checks": {check_id: "not_run" for check_id in MANAGEMENT_E2E_REQUIRED_CHECKS},
        "external_writes": 0,
        "secret_values_included": False,
        "constraints": {
            "loopback_only": True,
            "all_checks_required": True,
            "real_channel_allowed": False,
            "conversation_controls_allowed": False,
        },
    }


def validate_management_e2e_artifact(
    source: object,
    *,
    agent_id: str,
    process_instance_id: str,
    process_started_at: str,
    asset_digest: str,
) -> dict[str, Any]:
    if not isinstance(source, dict):
        raise ValueError("management E2E evidence must be one JSON object")
    allowed = {
        "schema_version",
        "agent_id",
        "runner",
        "base_url",
        "process_instance_id",
        "process_started_at",
        "management_asset_digest",
        "started_at",
        "finished_at",
        "checks",
        "external_writes",
        "secret_values_included",
    }
    if set(source) != allowed:
        raise ValueError("management E2E evidence fields do not match the required schema")
    if source.get("schema_version") != MANAGEMENT_E2E_SCHEMA_VERSION:
        raise ValueError("unsupported management E2E evidence schema")
    if source.get("agent_id") != agent_id:
        raise ValueError("management E2E evidence does not match the target Agent")
    if source.get("process_instance_id") != process_instance_id:
        raise ValueError("management E2E evidence does not match the live process instance")
    expected_process_start = _parse_observed_time(process_started_at, "process_started_at")
    observed_process_start = _parse_observed_time(
        source.get("process_started_at"),
        "process_started_at",
    )
    if observed_process_start != expected_process_start:
        raise ValueError("management E2E evidence does not match the live process start")
    if source.get("management_asset_digest") != asset_digest:
        raise ValueError("management E2E evidence does not match the loaded web assets")
    runner = source.get("runner")
    if runner not in _ALLOWED_RUNNERS:
        raise ValueError("management E2E evidence runner is unsupported")
    base_url = source.get("base_url")
    if not isinstance(base_url, str) or not _is_loopback_root(base_url):
        raise ValueError("management E2E evidence must target a loopback service root")
    started_at = _parse_observed_time(source.get("started_at"), "started_at")
    finished_at = _parse_observed_time(source.get("finished_at"), "finished_at")
    duration_seconds = (finished_at - started_at).total_seconds()
    if duration_seconds < 0:
        raise ValueError("management E2E evidence cannot finish before it starts")
    if duration_seconds > 14_400:
        raise ValueError("management E2E evidence duration must not exceed four hours")
    if started_at < expected_process_start:
        raise ValueError("management E2E evidence cannot predate the live process")
    if finished_at > datetime.now(UTC) + timedelta(seconds=30):
        raise ValueError("management E2E evidence cannot be recorded from the future")
    checks = source.get("checks")
    if not isinstance(checks, dict) or set(checks) != set(MANAGEMENT_E2E_REQUIRED_CHECKS):
        raise ValueError("management E2E evidence must contain every required check exactly once")
    if any(status != "passed" for status in checks.values()):
        raise ValueError("management E2E evidence cannot be recorded until every check passed")
    if source.get("external_writes") != 0:
        raise ValueError("management E2E evidence requires zero external writes")
    if source.get("secret_values_included") is not False:
        raise ValueError("management E2E evidence must not contain secret values")
    return {
        "schema_version": MANAGEMENT_E2E_SCHEMA_VERSION,
        "agent_id": agent_id,
        "runner": runner,
        "base_url": base_url,
        "process_instance_id": process_instance_id,
        "process_started_at": expected_process_start.isoformat(),
        "management_asset_digest": asset_digest,
        "started_at": started_at.isoformat(),
        "finished_at": finished_at.isoformat(),
        "duration_seconds": duration_seconds,
        "checks": {check_id: "passed" for check_id in MANAGEMENT_E2E_REQUIRED_CHECKS},
        "external_writes": 0,
        "secret_values_included": False,
    }


def _parse_observed_time(value: object, field: str) -> datetime:
    if not isinstance(value, str):
        raise ValueError(f"management E2E evidence requires {field}")
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"management E2E evidence {field} is invalid") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"management E2E evidence {field} must include a timezone")
    return parsed.astimezone(UTC)


def _is_loopback_root(value: str) -> bool:
    try:
        parsed = urlsplit(value)
        _ = parsed.port
    except ValueError:
        return False
    if (
        parsed.scheme not in {"http", "https"}
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
        or parsed.path not in {"", "/"}
    ):
        return False
    host = parsed.hostname.strip().strip("[]")
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return host.lower() == "localhost"
