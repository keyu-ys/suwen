from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import tomllib
from collections.abc import Collection, Mapping
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any

from .skills import Skill, SkillRegistry
from .tools import ToolRegistry


@dataclass(frozen=True)
class Pack:
    id: str
    version: str
    name: str
    description: str
    path: Path
    skills: tuple[Skill, ...]
    domain_config: Mapping[str, Any]
    trusted_code: bool
    trust_level: str
    publisher: str
    compatible_core_range: str
    source_revision: str
    baseline_attestation_digest: str
    tool_names: tuple[str, ...]
    tools: ToolRegistry
    digest: str


@dataclass(frozen=True)
class PackInspection:
    """Fully validated Pack metadata obtained without importing executable code."""

    id: str
    version: str
    name: str
    description: str
    path: Path
    skills: tuple[Skill, ...]
    domain_config: Mapping[str, Any]
    trusted_code: bool
    trust_level: str
    publisher: str
    compatible_core_range: str
    source_revision: str
    baseline_attestation_digest: str
    tool_names: tuple[str, ...]
    digest: str
    tool_module_path: Path | None
    baseline_attestation_path: Path | None

    @property
    def trust_ref(self) -> str:
        return f"{self.id}@{self.version}"


@dataclass(frozen=True)
class PackDiscovery:
    """Safe metadata for a Pack that is present but not loaded into the runtime."""

    id: str
    version: str
    name: str
    description: str
    publisher: str
    trust_level: str
    compatible_core_range: str
    digest: str
    trust_ref: str
    code_bearing: bool
    skill_count: int
    tool_count: int
    trusted_by_deployment: bool
    installed: bool
    code: str
    required_action: str


# These refs are part of this distribution, but callers still have to pass them
# explicitly. Keeping the loader default empty prevents a dropped Pack from
# granting trust to itself through pack.toml.
BUILTIN_TRUSTED_LOCAL_PACK_REFS = frozenset({"generic@0.3.0"})
_BUILTIN_DECLARED_CODE_TOOLS = {"generic@0.3.0": ("inspect_claim",)}


class PackRegistry:
    def __init__(
        self,
        packs: list[Pack],
        skills: SkillRegistry,
        discoveries: list[PackDiscovery] | None = None,
    ):
        self._packs = packs
        self.skills = skills
        self._discoveries = discoveries or []

    @classmethod
    def load(
        cls,
        root: Path,
        tools: ToolRegistry,
        *,
        trusted_local_pack_refs: Collection[str] = (),
        allowed_pack_refs: Collection[str] | None = None,
        expected_digests: Mapping[str, str] | None = None,
    ) -> PackRegistry:
        packs: list[Pack] = []
        all_skills: list[Skill] = []
        discoveries: list[PackDiscovery] = []
        trusted_refs = _validate_trusted_refs(trusted_local_pack_refs)
        allowed_refs = None if allowed_pack_refs is None else _validate_trusted_refs(allowed_pack_refs)
        expected = dict(expected_digests or {})
        for ref, digest in expected.items():
            _validate_trusted_refs((ref,))
            if not isinstance(digest, str) or len(digest) != 64:
                raise ValueError("expected Pack digest must be a sha256 hex string")

        for inspection in cls.inspect(root):
            trust_ref = inspection.trust_ref
            expected_digest = expected.get(trust_ref)
            if expected_digest is not None and expected_digest != inspection.digest:
                raise ValueError(f"Pack content digest mismatch before load: {trust_ref}")
            selected = allowed_refs is None or trust_ref in allowed_refs
            trusted = trust_ref in trusted_refs
            if not selected:
                needs_trust = inspection.trusted_code and not trusted
                discoveries.append(
                    _pack_discovery(
                        inspection,
                        trusted_by_deployment=trusted,
                        installed=False,
                        code=("trusted_local_approval_required" if needs_trust else "install_required"),
                        required_action=(
                            "deployment_trust_then_install_and_restart"
                            if needs_trust
                            else ("install_and_restart" if inspection.trusted_code else "install")
                        ),
                    )
                )
                continue
            if inspection.trusted_code and not trusted:
                discoveries.append(
                    _pack_discovery(
                        inspection,
                        trusted_by_deployment=False,
                        installed=allowed_refs is not None,
                        code="trusted_local_approval_required",
                        required_action="deployment_trust_and_restart",
                    )
                )
                continue
            pack_tools = ToolRegistry()
            if inspection.tool_module_path is not None:
                _load_tool_module(
                    inspection.tool_module_path,
                    (f"suwen_pack_{inspection.id.replace('-', '_')}_{inspection.version.replace('.', '_')}"),
                    pack_tools,
                )
            pack_tool_names = tuple(sorted(item.name for item in pack_tools.definitions()))
            if pack_tool_names != inspection.tool_names:
                raise ValueError(f"Domain Pack loaded Tool names differ from its safe manifest: {trust_ref}")
            if inspection.baseline_attestation_path is not None:
                _validate_attested_tool_interfaces(
                    inspection.baseline_attestation_path,
                    pack_tools,
                )
            # The process-level catalog exposes the latest loaded schema for management.
            # Runtime delivery below always resolves the exact Pack Version registry.
            tools.merge_from(pack_tools)
            pack = Pack(
                id=inspection.id,
                version=inspection.version,
                name=inspection.name,
                description=inspection.description,
                path=inspection.path,
                skills=inspection.skills,
                domain_config=inspection.domain_config,
                # A Python tool module executes with this process's full authority.
                # `trusted_code` records that deployment trust; it is not a sandbox claim.
                trusted_code=inspection.trusted_code,
                trust_level=inspection.trust_level,
                publisher=inspection.publisher,
                compatible_core_range=inspection.compatible_core_range,
                source_revision=inspection.source_revision,
                baseline_attestation_digest=inspection.baseline_attestation_digest,
                tool_names=pack_tool_names,
                tools=pack_tools,
                digest=inspection.digest,
            )
            packs.append(pack)
            all_skills.extend(inspection.skills)
        return cls(packs, SkillRegistry(all_skills), discoveries)

    @classmethod
    def inspect(cls, root: Path) -> list[PackInspection]:
        """Validate a controlled directory without importing any Python module."""
        root = _resolved_pack_root(root)
        if not root.exists():
            return []
        manifests: list[tuple[Path, dict[str, Any]]] = []
        identities: list[tuple[str, str]] = []
        for manifest_path in sorted(root.glob("*/pack.toml")):
            with manifest_path.open("rb") as handle:
                manifest = tomllib.load(handle)
            if not isinstance(manifest, dict):
                raise ValueError("Domain Pack manifest must be a table")
            pack_id = _required_manifest_string(manifest, "id")
            version = _required_manifest_string(manifest, "version")
            _required_manifest_string(manifest, "name")
            _required_manifest_string(manifest, "description")
            manifests.append((manifest_path, manifest))
            identities.append((pack_id, version))
        if len(set(identities)) != len(identities):
            raise ValueError("duplicate Domain Pack id and version")

        inspections: list[PackInspection] = []
        for manifest_path, manifest in manifests:
            pack_path = manifest_path.parent.resolve()
            source_revision = str(manifest.get("source_revision", ""))
            baseline_path: Path | None = None
            baseline_digest = ""
            if manifest.get("baseline_attestation_file"):
                baseline_path = _pack_path(
                    pack_path,
                    manifest["baseline_attestation_file"],
                    "baseline_attestation_file",
                )
                baseline_digest = _validate_baseline_attestation(
                    pack_path,
                    baseline_path,
                    source_revision,
                )
            tool_module = manifest.get("tool_module")
            trust_level = str(manifest.get("trust_level", "trusted_local" if tool_module else "guidance"))
            if trust_level not in {
                "guidance",
                "trusted_local",
                "composite",
            }:
                raise ValueError(f"unknown Domain Pack trust level: {trust_level}")
            retired_fields = sorted(
                set(manifest) & {"tools_file", "external_tool_dependencies"}
            )
            if retired_fields:
                raise ValueError(
                    "Domain Pack declarative Tool contracts are retired; use a Connector catalog"
                )
            if tool_module and (trust_level != "trusted_local" or manifest.get("trusted_code") is not True):
                raise ValueError("code-bearing Domain Pack requires trusted_local and trusted_code=true")
            if manifest.get("trusted_code") and not tool_module:
                raise ValueError("trusted_code=true requires a tool_module")
            compatible_core_range = str(manifest.get("compatible_core_range", ""))
            _validate_core_range(compatible_core_range)
            pack_digest = _pack_digest(pack_path)
            skills_dir = _pack_path(
                pack_path,
                manifest.get("skills_dir", "skills"),
                "skills_dir",
            )
            pack_skills = tuple(SkillRegistry.load(skills_dir).list())
            domain_config = manifest.get("domain_config", {})
            if not isinstance(domain_config, dict):
                raise ValueError("Domain Pack domain_config must be a table")
            _validate_agent_contract(domain_config.get("agent_validation"))

            tool_module_path: Path | None = None
            trust_ref = f"{manifest['id']}@{manifest['version']}"
            declared_names = _declared_tool_names(manifest.get("tool_names", []))
            if tool_module:
                tool_module_path = _pack_path(pack_path, tool_module, "tool_module")
                if not tool_module_path.is_file():
                    raise ValueError(f"missing Domain Pack tool module: {tool_module_path}")
                if not declared_names:
                    declared_names = _BUILTIN_DECLARED_CODE_TOOLS.get(trust_ref, ())
                if not declared_names:
                    raise ValueError("code-bearing Domain Pack must declare tool_names")
            if tool_module_path is None:
                if declared_names:
                    raise ValueError("Domain Pack tool_names require a trusted code module")
                if baseline_path is not None:
                    raise ValueError("Tool interface attestation requires a trusted code module")

            inspections.append(
                PackInspection(
                    id=str(manifest["id"]),
                    version=str(manifest["version"]),
                    name=str(manifest["name"]),
                    description=str(manifest["description"]),
                    path=pack_path,
                    skills=pack_skills,
                    domain_config=_freeze_mapping(domain_config),
                    trusted_code=bool(tool_module_path),
                    trust_level=trust_level,
                    publisher=str(manifest.get("publisher", "unknown")),
                    compatible_core_range=compatible_core_range,
                    source_revision=source_revision,
                    baseline_attestation_digest=baseline_digest,
                    tool_names=declared_names,
                    digest=pack_digest,
                    tool_module_path=tool_module_path,
                    baseline_attestation_path=baseline_path,
                )
            )
        return inspections

    @classmethod
    def catalog_discoveries(
        cls,
        root: Path,
        *,
        loaded_pack_refs: Collection[str],
        installed_pack_refs: Collection[str],
        trusted_local_pack_refs: Collection[str],
    ) -> list[dict[str, Any]]:
        loaded = _validate_trusted_refs(loaded_pack_refs)
        installed = _validate_trusted_refs(installed_pack_refs)
        trusted = _validate_trusted_refs(trusted_local_pack_refs)
        discoveries: list[PackDiscovery] = []
        for inspection in cls.inspect(root):
            ref = inspection.trust_ref
            if ref in loaded:
                continue
            if inspection.trusted_code and ref not in trusted:
                code = "trusted_local_approval_required"
                action = (
                    "deployment_trust_and_restart"
                    if ref in installed
                    else "deployment_trust_then_install_and_restart"
                )
            elif ref in installed:
                code = "restart_required"
                action = "restart"
            else:
                code = "install_required"
                action = "install_and_restart" if inspection.trusted_code else "install"
            discoveries.append(
                _pack_discovery(
                    inspection,
                    trusted_by_deployment=ref in trusted,
                    installed=ref in installed,
                    code=code,
                    required_action=action,
                )
            )
        return [pack_discovery_manifest(item) for item in discoveries]

    def list(self) -> list[Pack]:
        return list(self._packs)

    def discoveries(self) -> list[dict[str, Any]]:
        return [pack_discovery_manifest(item) for item in self._discoveries]

    def extend(self, packs: Collection[Pack]) -> None:
        additions = list(packs)
        self.validate_extension(additions)
        skills = [*self.skills.list(), *(skill for pack in additions for skill in pack.skills)]
        self._packs.extend(additions)
        self.skills = SkillRegistry(skills)

    def validate_extension(self, packs: Collection[Pack]) -> None:
        additions = list(packs)
        refs = {(item.id, item.version) for item in self._packs}
        if any((item.id, item.version) in refs for item in additions):
            raise ValueError("Pack version is already loaded")

    def domain_configs(self) -> Mapping[str, Mapping[str, Any]]:
        return MappingProxyType({pack.id: pack.domain_config for pack in self._packs})

    def tool_provider_types(self) -> Mapping[str, str]:
        """Return deployment-controlled Provider provenance for loaded Pack tools."""

        provider_types: dict[str, str] = {}
        for pack in self._packs:
            if not pack.tool_names:
                continue
            if pack.trust_level == "trusted_local":
                provider_type = "trusted_local"
            else:
                raise ValueError(
                    f"Tool-bearing Pack has no executable Provider provenance: {pack.id}@{pack.version}"
                )
            for definition in pack.tools.definitions():
                existing = provider_types.get(definition.provider_id)
                if existing is not None and existing != provider_type:
                    raise ValueError(
                        f"Tool Provider is declared with conflicting provenance: {definition.provider_id}"
                    )
                provider_types[definition.provider_id] = provider_type
        return MappingProxyType(provider_types)

    def skills_for(self, pack_refs: list[dict[str, Any]]) -> SkillRegistry:
        selected = self._select(pack_refs)
        skills = [skill for pack in selected for skill in pack.skills]
        if len({skill.id for skill in skills}) != len(skills):
            raise ValueError("selected Pack versions contain duplicate Skill IDs")
        return SkillRegistry(skills)

    def tools_for(self, pack_refs: list[dict[str, Any]], registry: ToolRegistry) -> ToolRegistry:
        selected = self._select(pack_refs)
        resolved = ToolRegistry()
        runtime_names = sorted(
            item.name for item in registry.definitions() if item.provider_id == "runtime-core"
        )
        resolved.merge_from(registry.subset(runtime_names))
        for pack in selected:
            runtime_tools = registry.subset(pack.tool_names)
            for name in pack.tool_names:
                if runtime_tools.get(name) != pack.tools.get(name):
                    raise ValueError(
                        f"loaded Tool definition drifted from Pack contract: {pack.id}@{pack.version}:{name}"
                    )
            resolved.merge_from(runtime_tools)
        return resolved

    def resolve_refs(self, pack_refs: list[dict[str, Any]]) -> list[Pack]:
        return self._select(pack_refs)

    def _select(self, pack_refs: list[dict[str, Any]]) -> list[Pack]:
        available = {(pack.id, pack.version): pack for pack in self._packs}
        selected: list[Pack] = []
        for item in pack_refs:
            key = (str(item["pack_id"]), str(item["version"]))
            if key not in available:
                raise ValueError(f"Pack version is not loaded: {key[0]}@{key[1]}")
            pack = available[key]
            declared_digest = item.get("digest")
            if declared_digest is not None and str(declared_digest) != pack.digest:
                raise ValueError(f"Pack content digest mismatch: {key[0]}@{key[1]}")
            selected.append(pack)
        return selected


def pack_catalog_manifest(pack: Pack | PackInspection) -> dict[str, Any]:
    """Return the immutable, JSON-safe catalog description for a validated Pack."""
    return {
        "id": pack.id,
        "version": pack.version,
        "name": pack.name,
        "description": pack.description,
        "publisher": pack.publisher,
        "trust_level": pack.trust_level,
        "trusted_code": pack.trusted_code,
        "process_authority": ("same_as_suwen_process" if pack.trusted_code else "not_applicable"),
        "compatible_core_range": pack.compatible_core_range,
        "source_revision": pack.source_revision,
        "baseline_attestation_digest": pack.baseline_attestation_digest,
        "skills": sorted(skill.id for skill in pack.skills),
        "fallback_skills": sorted(skill.id for skill in pack.skills if skill.fallback),
        "tools": sorted(pack.tool_names),
        "domain_config": _thaw_value(pack.domain_config),
    }


def pack_discovery_manifest(discovery: PackDiscovery) -> dict[str, Any]:
    """Return public metadata without exposing a deployment-local filesystem path."""
    return {
        "id": discovery.id,
        "version": discovery.version,
        "name": discovery.name,
        "description": discovery.description,
        "publisher": discovery.publisher,
        "trust_level": discovery.trust_level,
        "compatible_core_range": discovery.compatible_core_range,
        "content_digest": discovery.digest,
        "trust_ref": discovery.trust_ref,
        "code": discovery.code,
        "code_bearing": discovery.code_bearing,
        "skill_count": discovery.skill_count,
        "tool_count": discovery.tool_count,
        "trusted_by_deployment": discovery.trusted_by_deployment,
        "installed": discovery.installed,
        "loaded": False,
        "executed": False,
        "required_action": discovery.required_action,
        "process_authority": ("same_as_suwen_process" if discovery.code_bearing else "not_applicable"),
    }


def bundled_packs_root() -> Path:
    packaged = Path(__file__).resolve().parent / "_bundled" / "packs"
    if packaged.is_dir():
        return packaged
    source = Path(__file__).resolve().parents[2] / "packs"
    return source


def bundled_web_root() -> Path:
    packaged = Path(__file__).resolve().parent / "_bundled" / "web"
    if packaged.is_dir():
        return packaged
    source = Path(__file__).resolve().parents[2] / "web"
    return source


def bundled_investigation_glossary() -> Path:
    packaged = (
        Path(__file__).resolve().parent
        / "_bundled"
        / "docs"
        / "specs"
        / "04-investigation-concepts-and-glossary.md"
    )
    if packaged.is_file():
        return packaged
    return (
        Path(__file__).resolve().parents[2]
        / "docs"
        / "specs"
        / "04-investigation-concepts-and-glossary.md"
    )


def bundled_investigation_glossary_assets_root() -> Path:
    return bundled_investigation_glossary().parent / "assets" / "glossary"


def _resolved_pack_root(root: Path) -> Path:
    if not root.exists() and root == Path("packs"):
        return bundled_packs_root()
    return root


def _declared_tool_names(value: Any) -> tuple[str, ...]:
    if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
        raise ValueError("Domain Pack tool_names must be a unique string array")
    names = tuple(sorted(item.strip() for item in value))
    if len(names) != len(set(names)):
        raise ValueError("Domain Pack tool_names must be a unique string array")
    return names


def _pack_discovery(
    inspection: PackInspection,
    *,
    trusted_by_deployment: bool,
    installed: bool,
    code: str,
    required_action: str,
) -> PackDiscovery:
    return PackDiscovery(
        id=inspection.id,
        version=inspection.version,
        name=inspection.name,
        description=inspection.description,
        publisher=inspection.publisher,
        trust_level=inspection.trust_level,
        compatible_core_range=inspection.compatible_core_range,
        digest=inspection.digest,
        trust_ref=inspection.trust_ref,
        code_bearing=inspection.trusted_code,
        skill_count=len(inspection.skills),
        tool_count=len(inspection.tool_names),
        trusted_by_deployment=trusted_by_deployment,
        installed=installed,
        code=code,
        required_action=required_action,
    )


def _required_manifest_string(manifest: Mapping[str, Any], field: str) -> str:
    value = manifest.get(field)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"Domain Pack {field} must be a non-empty string")
    return value.strip()


def _validate_trusted_refs(values: Collection[str]) -> frozenset[str]:
    if isinstance(values, (str, bytes)):
        raise ValueError("trusted local Pack refs must be a collection of id@version values")
    trusted: set[str] = set()
    for value in values:
        if not isinstance(value, str) or value != value.strip():
            raise ValueError("trusted local Pack ref must be an exact id@version string")
        pack_id, separator, version = value.partition("@")
        if not separator or not pack_id or not version or "@" in version:
            raise ValueError("trusted local Pack ref must be an exact id@version string")
        trusted.add(value)
    return frozenset(trusted)


def _pack_path(root: Path, raw_path: Any, label: str) -> Path:
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError(f"Domain Pack {label} must be a non-empty relative path")
    relative = Path(raw_path)
    if relative.is_absolute():
        raise ValueError(f"Domain Pack {label} must be relative")
    resolved = (root / relative).resolve()
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"Domain Pack {label} escapes its directory") from exc
    return resolved


def _freeze_mapping(value: dict[str, Any]) -> Mapping[str, Any]:
    return MappingProxyType({str(key): _freeze_value(item) for key, item in value.items()})


def _freeze_value(value: Any) -> Any:
    if isinstance(value, dict):
        return _freeze_mapping(value)
    if isinstance(value, list):
        return tuple(_freeze_value(item) for item in value)
    return value


def _thaw_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _thaw_value(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_thaw_value(item) for item in value]
    return value


def _validate_agent_contract(value: Any) -> None:
    if value is None:
        return
    if not isinstance(value, dict):
        raise ValueError("Domain Pack agent_validation must be a table")
    allowed = {
        "required_model_capabilities",
        "required_trust_level",
        "required_fallback_skills",
        "required_tool_providers",
        "require_all_pack_tools",
        "prompt_source_revision",
        "runtime_policy",
    }
    unknown = sorted(set(value) - allowed)
    if unknown:
        raise ValueError(f"unknown Domain Pack agent_validation field: {unknown[0]}")

    for field in (
        "required_model_capabilities",
        "required_fallback_skills",
        "required_tool_providers",
    ):
        items = value.get(field, [])
        if (
            not isinstance(items, list)
            or any(not isinstance(item, str) or not item.strip() for item in items)
            or len(items) != len(set(items))
        ):
            raise ValueError(f"Domain Pack agent_validation.{field} must be a unique string array")

    trust_level = value.get("required_trust_level")
    if trust_level is not None and trust_level not in {
        "guidance",
        "trusted_local",
        "composite",
    }:
        raise ValueError("Domain Pack agent_validation.required_trust_level is invalid")
    require_all = value.get("require_all_pack_tools")
    if require_all is not None and not isinstance(require_all, bool):
        raise ValueError("Domain Pack agent_validation.require_all_pack_tools must be boolean")
    prompt_revision = value.get("prompt_source_revision")
    if prompt_revision is not None and (not isinstance(prompt_revision, str) or not prompt_revision.strip()):
        raise ValueError("Domain Pack agent_validation.prompt_source_revision must be a string")

    runtime = value.get("runtime_policy", {})
    if not isinstance(runtime, dict):
        raise ValueError("Domain Pack agent_validation.runtime_policy must be a table")
    limits = {
        "max_tool_calls": (1, 120),
        "max_tool_waves": (1, 60),
        "max_concurrency": (1, 6),
    }
    unknown_runtime = sorted(set(runtime) - set(limits))
    if unknown_runtime:
        raise ValueError(f"unknown Domain Pack agent_validation.runtime_policy field: {unknown_runtime[0]}")
    for field, (minimum, maximum) in limits.items():
        if field not in runtime:
            continue
        configured = runtime[field]
        if (
            not isinstance(configured, int)
            or isinstance(configured, bool)
            or not minimum <= configured <= maximum
        ):
            raise ValueError(f"Domain Pack agent_validation.runtime_policy.{field} is outside core limits")


def _load_tool_module(path: Path, module_name: str, tools: ToolRegistry) -> None:
    # This imports deployment-trusted Python in-process. Code-bearing Domain Packs
    # have full process authority and must never be described as security sandboxes.
    if not path.is_file():
        raise ValueError(f"missing Domain Pack tool module: {path}")
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"cannot load Domain Pack tool module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    register = getattr(module, "register_tools", None)
    if not callable(register):
        raise ValueError(f"Domain Pack tool module lacks register_tools(): {path}")
    register(tools)


def _validate_baseline_attestation(
    pack_root: Path,
    attestation_path: Path,
    source_revision: str,
) -> str:
    payload_bytes = attestation_path.read_bytes()
    try:
        payload = json.loads(payload_bytes)
    except json.JSONDecodeError as exc:
        raise ValueError("Domain Pack baseline attestation is invalid JSON") from exc
    if not isinstance(payload, dict):
        raise ValueError("Domain Pack baseline attestation metadata is invalid")
    files = payload.get("files")
    source_artifacts = payload.get("source_artifacts")
    if (
        payload.get("schema_version") != "suwen-capability-attestation.v1"
        or payload.get("source_revision") != source_revision
        or not isinstance(files, dict)
        or not files
        or len(files) > 200
        or not isinstance(source_artifacts, dict)
        or not source_artifacts
        or any(
            not isinstance(name, str) or not isinstance(digest, str) or len(digest) != 64
            for name, digest in source_artifacts.items()
        )
    ):
        raise ValueError("Domain Pack baseline attestation metadata is invalid")
    for relative_path, expected_digest in files.items():
        if (
            not isinstance(relative_path, str)
            or not isinstance(expected_digest, str)
            or len(expected_digest) != 64
        ):
            raise ValueError("Domain Pack baseline attestation entry is invalid")
        target = _pack_path(pack_root, relative_path, "baseline attestation entry")
        observed = hashlib.sha256(target.read_bytes()).hexdigest()
        if observed != expected_digest:
            raise ValueError(f"Domain Pack baseline attestation mismatch: {relative_path}")
    return hashlib.sha256(payload_bytes).hexdigest()


def _validate_attested_tool_interfaces(
    attestation_path: Path,
    tools: ToolRegistry,
) -> None:
    payload = json.loads(attestation_path.read_text(encoding="utf-8"))
    interfaces = payload.get("tool_interfaces")
    if interfaces is None:
        return
    if not isinstance(interfaces, dict):
        raise ValueError("Domain Pack baseline tool interfaces are invalid")

    observed: dict[str, dict[str, list[str]]] = {}
    for definition in tools.definitions():
        schema = definition.input_schema
        properties = schema.get("properties", {}) if isinstance(schema, Mapping) else {}
        required = schema.get("required", []) if isinstance(schema, Mapping) else []
        if not isinstance(properties, Mapping) or not isinstance(required, (list, tuple)):
            raise ValueError("Domain Pack Tool input schema is invalid")
        observed[definition.name] = {
            "properties": sorted(str(name) for name in properties),
            "required": sorted(str(name) for name in required),
        }

    expected: dict[str, dict[str, list[str]]] = {}
    for tool_name, contract in interfaces.items():
        if not isinstance(tool_name, str) or not isinstance(contract, dict):
            raise ValueError("Domain Pack baseline tool interface entry is invalid")
        properties = contract.get("properties")
        required = contract.get("required")
        if (
            not isinstance(properties, list)
            or not isinstance(required, list)
            or any(not isinstance(name, str) or not name for name in [*properties, *required])
            or len(properties) != len(set(properties))
            or len(required) != len(set(required))
            or not set(required).issubset(properties)
        ):
            raise ValueError("Domain Pack baseline tool interface entry is invalid")
        expected[tool_name] = {
            "properties": sorted(properties),
            "required": sorted(required),
        }

    if expected != observed:
        raise ValueError("Domain Pack Tool interfaces do not match the frozen baseline")


def _pack_digest(root: Path) -> str:
    digest = hashlib.sha256()
    total = 0
    all_paths = list(root.rglob("*"))
    symbolic_links = [path for path in all_paths if path.is_symlink()]
    if symbolic_links:
        raise ValueError(f"Pack contains a symbolic link: {symbolic_links[0]}")
    paths = sorted(
        path
        for path in all_paths
        if path.is_file()
        and "__pycache__" not in path.parts
        and path.suffix.lower() in {".toml", ".md", ".json", ".py"}
    )
    for path in paths:
        payload = path.read_bytes()
        total += len(payload)
        if len(payload) > 500_000 or total > 2_000_000:
            raise ValueError("Pack content exceeds the configured size limit")
        digest.update(path.relative_to(root).as_posix().encode())
        digest.update(b"\0")
        digest.update(payload)
        digest.update(b"\0")
    if not paths:
        raise ValueError("Pack contains no declarative content")
    return digest.hexdigest()


def _validate_core_range(value: str) -> None:
    if not value:
        return
    current = (0, 1, 0)
    for raw in value.split(","):
        clause = raw.strip()
        operator = next(
            (item for item in (">=", "<=", "==", ">", "<") if clause.startswith(item)),
            None,
        )
        if operator is None:
            raise ValueError("unsupported compatible_core_range")
        try:
            target = tuple(int(item) for item in clause[len(operator) :].split("."))
        except ValueError as exc:
            raise ValueError("invalid compatible_core_range") from exc
        target = (target + (0, 0, 0))[:3]
        checks = {
            ">=": current >= target,
            "<=": current <= target,
            "==": current == target,
            ">": current > target,
            "<": current < target,
        }
        if not checks[operator]:
            raise ValueError("Domain Pack is not compatible with this core version")
