from __future__ import annotations

import hashlib
import inspect
import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from .types import EvidenceEnvelope, ToolDefinition, ToolRisk

ToolHandler = Callable[[dict[str, Any]], EvidenceEnvelope | Awaitable[EvidenceEnvelope]]

MAX_NORMALIZED_ARGUMENT_STRING_BYTES = 65_536
MAX_NORMALIZED_ARGUMENT_DEPTH = 16
MAX_ARGUMENT_CORRECTIONS = 32


@dataclass(frozen=True)
class ToolArgumentCorrection:
    """One bounded, schema-proven container correction applied by the Runtime."""

    path: str
    source_type: str
    target_type: str
    reason_code: str = "schema_guided_json_container_decode"


@dataclass(frozen=True)
class ToolArgumentNormalization:
    """Effective Tool arguments plus value-free audit metadata.

    The model turn retains the Provider's original arguments.  The Tool call
    persists ``arguments`` below, so Trace readers can compare original and
    effective values without duplicating business content in the audit marker.
    """

    arguments: dict[str, Any]
    corrections: tuple[ToolArgumentCorrection, ...] = ()

    @property
    def applied(self) -> bool:
        return bool(self.corrections)

    def audit_projection(self) -> dict[str, Any] | None:
        if not self.corrections:
            return None
        return {
            "state": "applied",
            "reason_code": "schema_guided_json_container_decode",
            "corrections": [
                {
                    "path": item.path,
                    "source_type": item.source_type,
                    "target_type": item.target_type,
                    "reason_code": item.reason_code,
                }
                for item in self.corrections
            ],
        }

# Runtime mechanics are always available to the Agent. They are not optional
# business tools, so the management console should not offer them as choices.
SYSTEM_REQUIRED_TOOL_NAMES = frozenset(
    {
        "inspect_claim",
        "read_artifact_chunk",
        "find_artifact_text",
        "render_explanation_diagram",
        "recall_case_history",
        "read_skill",
        "list_skill_references",
        "search_skill_references",
        "read_skill_reference",
    }
)


def is_system_required_tool(name: str) -> bool:
    return name in SYSTEM_REQUIRED_TOOL_NAMES


class PolicyError(RuntimeError):
    pass


class ToolInputValidationError(PolicyError):
    """A model-visible Tool argument failed the published JSON schema."""

    def __init__(
        self,
        message: str,
        *,
        reason_code: str = "tool_schema_validation",
        minimum_correction: str = "按当前 Tool 的公开 schema 修正输入。",
    ) -> None:
        super().__init__(message)
        self.reason_code = reason_code
        self.minimum_correction = minimum_correction


class ToolRegistry:
    def __init__(self) -> None:
        self._definitions: dict[str, ToolDefinition] = {}
        self._handlers: dict[str, ToolHandler] = {}

    def register(self, definition: ToolDefinition, handler: ToolHandler) -> None:
        if definition.name in self._definitions:
            raise ValueError(f"duplicate tool: {definition.name}")
        _validate_schema_definition(definition.input_schema)
        if definition.run_call_limit is not None and (
            isinstance(definition.run_call_limit, bool)
            or not 1 <= definition.run_call_limit <= 120
        ):
            raise ValueError("Tool Run call limit must be between 1 and 120")
        if definition.run_call_limit_range is not None:
            minimum, maximum = definition.run_call_limit_range
            if (
                isinstance(minimum, bool)
                or isinstance(maximum, bool)
                or not 1 <= minimum <= maximum <= 120
                or definition.run_call_limit is None
                or not minimum <= definition.run_call_limit <= maximum
            ):
                raise ValueError("Tool Run call limit range is invalid")
        self._definitions[definition.name] = definition
        self._handlers[definition.name] = handler

    def definitions(self) -> list[ToolDefinition]:
        return list(self._definitions.values())

    def names(self) -> frozenset[str]:
        return frozenset(self._definitions)

    def get(self, name: str) -> ToolDefinition:
        try:
            return self._definitions[name]
        except KeyError as exc:
            raise PolicyError(f"unknown tool: {name}") from exc

    def subset(self, names: list[str] | tuple[str, ...] | set[str]) -> ToolRegistry:
        selected = ToolRegistry()
        for name in names:
            definition = self.get(name)
            selected.register(definition, self._handlers[name])
        return selected

    def merge_from(self, other: ToolRegistry, *, replace: bool = False) -> None:
        """Merge definitions and handlers while making name conflicts explicit."""
        for definition in other.definitions():
            existing = self._definitions.get(definition.name)
            if existing is not None:
                if existing != definition and not replace:
                    raise ValueError(f"incompatible duplicate Tool definition: {definition.name}")
                if replace:
                    self._definitions[definition.name] = definition
                    self._handlers[definition.name] = other._handlers[definition.name]
                continue
            self.register(definition, other._handlers[definition.name])

    def unregister(self, names: set[str] | frozenset[str] | tuple[str, ...]) -> None:
        """Remove exact runtime registrations owned by a deactivated extension.

        Lifecycle owners must retain their staged registry if rollback is needed.
        Core callers cannot remove unknown names silently because that would leave
        an unexplainable partial plugin state.
        """

        requested = set(names)
        missing = requested - set(self._definitions)
        if missing:
            raise ValueError(f"cannot unregister unknown Tool: {sorted(missing)[0]}")
        for name in sorted(requested):
            del self._definitions[name]
            del self._handlers[name]

    def bind_provider_handlers(
        self,
        provider_id: str,
        observed: ToolRegistry,
        *,
        expected_names: set[str] | None = None,
    ) -> tuple[str, ...]:
        """Atomically bind observed handlers after exact public-contract comparison."""
        expected = {
            name: definition
            for name, definition in self._definitions.items()
            if definition.provider_id == provider_id and (expected_names is None or name in expected_names)
        }
        actual = {
            definition.name: definition
            for definition in observed.definitions()
            if definition.provider_id == provider_id
        }
        if set(expected) != set(actual):
            raise ValueError("Tool Provider catalog does not match the frozen expected names")
        for name, definition in expected.items():
            candidate = actual[name]
            if (
                candidate.risk != definition.risk
                or candidate.result_contract != definition.result_contract
                or candidate.run_call_limit != definition.run_call_limit
                or candidate.run_call_limit_range != definition.run_call_limit_range
                or not input_schema_accepts_contract(
                    definition.input_schema,
                    candidate.input_schema,
                )
            ):
                raise ValueError(f"Tool Provider schema does not match the frozen contract: {name}")
        for name in sorted(expected):
            self._handlers[name] = observed._handlers[name]
        return tuple(sorted(expected))

    def restore_handlers_from(self, source: ToolRegistry, names: set[str]) -> None:
        """Restore an already validated local handler set without changing definitions."""
        for name in sorted(names):
            if name not in self._definitions or name not in source._handlers:
                raise ValueError(f"Tool handler cannot be restored: {name}")
        for name in sorted(names):
            self._handlers[name] = source._handlers[name]

    def replace_provider_catalog(
        self,
        provider_id: str,
        observed: ToolRegistry,
    ) -> tuple[tuple[str, ...], tuple[str, ...]]:
        """Atomically replace one dynamically observed Provider catalog.

        Names owned by another Provider are hard conflicts.  The caller keeps any
        previous client alive for already-resolved Runs; this registry only changes
        the surface available to future resolutions.
        """

        candidates = {item.name: item for item in observed.definitions()}
        if not candidates or any(item.provider_id != provider_id for item in candidates.values()):
            raise ValueError("observed Tool catalog must have one non-empty Provider owner")
        conflicts = sorted(
            name
            for name in candidates
            if name in self._definitions and self._definitions[name].provider_id != provider_id
        )
        if conflicts:
            raise ValueError(f"Tool Provider name conflicts with another Provider: {conflicts[0]}")
        previous = tuple(
            sorted(name for name, item in self._definitions.items() if item.provider_id == provider_id)
        )
        for name in previous:
            del self._definitions[name]
            del self._handlers[name]
        for definition in observed.definitions():
            self.register(definition, observed._handlers[definition.name])
        return previous, tuple(sorted(candidates))

    async def execute(
        self, name: str, arguments: dict[str, Any], *, allow_action: bool = False
    ) -> EvidenceEnvelope:
        definition = self.get(name)
        if definition.risk in {ToolRisk.UNCLASSIFIED, ToolRisk.EXTERNAL_WRITE}:
            raise PolicyError(f"tool risk is not allowed: {definition.risk}")
        if definition.risk == ToolRisk.CONTROLLED_ACTION and not allow_action:
            raise PolicyError("controlled action requires the action state machine")
        validation_arguments = arguments
        if "_runtime_context" in arguments or (allow_action and "_action_context" in arguments):
            validation_arguments = dict(arguments)
            validation_arguments.pop("_action_context", None)
            validation_arguments.pop("_runtime_context", None)
        self.validate_arguments(name, validation_arguments)
        result = self._handlers[name](arguments)
        if inspect.isawaitable(result):
            result = await result
        if not isinstance(result, EvidenceEnvelope):
            raise TypeError("tool handler must return EvidenceEnvelope")
        return result

    def validate_arguments(self, name: str, arguments: dict[str, Any]) -> None:
        definition = self.get(name)
        if not isinstance(arguments, dict):
            raise ToolInputValidationError("tool arguments must be object")
        _validate_value(arguments, definition.input_schema, "tool arguments")

    def normalize_arguments(
        self,
        name: str,
        arguments: dict[str, Any],
    ) -> ToolArgumentNormalization:
        """Decode JSON-string containers only when the public schema proves it safe.

        Best-effort OpenAI-compatible Providers can occasionally serialize a
        nested object or array twice.  This boundary corrects that single wire
        representation defect without coercing scalars, guessing fields, or
        weakening normal JSON Schema validation.  Ambiguous schemas and invalid
        JSON remain unchanged and therefore follow the existing rejection path.
        """

        definition = self.get(name)
        if not isinstance(arguments, dict):
            return ToolArgumentNormalization(arguments=arguments)
        normalized, corrections = _normalize_schema_containers(
            arguments,
            definition.input_schema,
            path="tool arguments",
            depth=0,
            correction_budget=MAX_ARGUMENT_CORRECTIONS,
        )
        if not isinstance(normalized, dict):
            return ToolArgumentNormalization(arguments=arguments)
        return ToolArgumentNormalization(
            arguments=normalized,
            corrections=tuple(corrections),
        )

    def call_fingerprint(self, name: str, arguments: dict[str, Any]) -> str:
        """Return one bounded key for exact or capability-declared equivalent calls.

        The default remains Tool name plus public arguments. A trusted first-party
        capability may additionally declare a pure canonicalizer so a shortcut and
        its base data-plane form share one same-Run dedupe boundary. Invalid or
        oversized provider keys safely fall back to exact-call semantics.
        """

        definition = self.get(name)
        equivalent: Any | None = None
        if definition.equivalence_key is not None:
            try:
                equivalent = definition.equivalence_key(dict(arguments))
                encoded = json.dumps(
                    equivalent,
                    ensure_ascii=False,
                    allow_nan=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                if equivalent is None or len(encoded.encode("utf-8")) > 8_192:
                    equivalent = None
            except (TypeError, ValueError, KeyError):
                equivalent = None
        payload = (
            {
                "provider_id": definition.provider_id,
                "equivalent_call": equivalent,
            }
            if equivalent is not None
            else {"name": name, "arguments": arguments}
        )
        return json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        )


def tool_schema_projection(registry: ToolRegistry) -> list[dict[str, Any]]:
    return [
        {
            "name": item.name,
            "description": item.description,
            "input_schema": item.input_schema,
            "risk": str(item.risk),
            "timeout_seconds": item.timeout_seconds,
            "result_contract": item.result_contract,
            "provider_id": item.provider_id,
            "resource_class": item.resource_class,
            "run_call_limit": item.run_call_limit,
            "run_call_limit_range": list(item.run_call_limit_range)
            if item.run_call_limit_range is not None
            else None,
        }
        for item in registry.definitions()
    ]


def tool_schema_digest(registry: ToolRegistry) -> str:
    encoded = json.dumps(
        tool_schema_projection(registry),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode()
    return hashlib.sha256(encoded).hexdigest()


def _validate_schema_definition(schema: Any) -> None:
    if not isinstance(schema, dict):
        raise ValueError("tool input schema must be an object")
    schema_type = schema.get("type", "object")
    allowed_types = {"array", "boolean", "integer", "null", "number", "object", "string"}
    declared_types = schema_type if isinstance(schema_type, list) else [schema_type]
    if not declared_types or any(item not in allowed_types for item in declared_types):
        raise ValueError("tool input schema contains an unsupported type")
    if "object" not in declared_types:
        raise ValueError("tool input schema root type must include object")
    _validate_schema_node(schema, "tool input schema")


def input_schema_accepts_contract(
    frozen: dict[str, Any],
    provider: dict[str, Any],
) -> bool:
    """Return whether every input accepted by ``frozen`` is accepted by ``provider``.

    A new Run may expose a Provider's current compatible schema.  This
    comparison proves that the current Provider still accepts every call the
    published baseline accepted; annotations such as descriptions, defaults,
    and timeouts do not narrow that callable set.
    """

    frozen_alternatives = _schema_alternatives(frozen)
    provider_alternatives = _schema_alternatives(provider)
    return all(
        any(_single_schema_is_subset(item, candidate) for candidate in provider_alternatives)
        for item in frozen_alternatives
    )


def _schema_alternatives(schema: dict[str, Any]) -> list[dict[str, Any]]:
    common = {
        key: value for key, value in schema.items() if key not in {"anyOf", "default", "description", "title"}
    }
    any_of = schema.get("anyOf")
    if isinstance(any_of, list) and any_of:
        return [{**common, **alternative} for alternative in any_of if isinstance(alternative, dict)]
    declared = common.get("type")
    if isinstance(declared, list):
        return [{**common, "type": item} for item in declared]
    return [common]


def _single_schema_is_subset(frozen: dict[str, Any], provider: dict[str, Any]) -> bool:
    # JSON Schema composition can narrow a provider contract without changing
    # its top-level properties. Proving arbitrary schema containment is outside
    # the v1 host, so provider-side composition constraints must either be
    # absent (the provider is broader) or exactly frozen into the Agent schema.
    for keyword in ("oneOf", "allOf", "not", "if", "then", "else"):
        if keyword in provider and provider[keyword] != frozen.get(keyword):
            return False
    if "const" in provider and provider["const"] != frozen.get("const", object()):
        return False

    frozen_type = frozen.get("type")
    provider_type = provider.get("type")
    if provider_type is not None and frozen_type != provider_type:
        return False

    frozen_enum = frozen.get("enum")
    provider_enum = provider.get("enum")
    if provider_enum is not None and (
        frozen_enum is None or any(item not in provider_enum for item in frozen_enum)
    ):
        return False

    minimum_key = {
        "integer": "minimum",
        "number": "minimum",
        "string": "minLength",
        "array": "minItems",
        "object": "minProperties",
    }.get(frozen_type)
    maximum_key = {
        "integer": "maximum",
        "number": "maximum",
        "string": "maxLength",
        "array": "maxItems",
        "object": "maxProperties",
    }.get(frozen_type)
    minimum_keys = (minimum_key,) if minimum_key else ()
    maximum_keys = (maximum_key,) if maximum_key else ()
    for minimum_key in minimum_keys:
        provider_minimum = provider.get(minimum_key)
        frozen_minimum = frozen.get(minimum_key)
        if provider_minimum is not None and (frozen_minimum is None or frozen_minimum < provider_minimum):
            return False
    for maximum_key in maximum_keys:
        provider_maximum = provider.get(maximum_key)
        frozen_maximum = frozen.get(maximum_key)
        if provider_maximum is not None and (frozen_maximum is None or frozen_maximum > provider_maximum):
            return False
    if provider.get("uniqueItems") is True and frozen.get("uniqueItems") is not True:
        return False

    if frozen_type == "object" or "properties" in frozen or "properties" in provider:
        frozen_properties = frozen.get("properties", {})
        provider_properties = provider.get("properties", {})
        if not isinstance(frozen_properties, dict) or not isinstance(provider_properties, dict):
            return False
        if not set(provider.get("required", [])).issubset(set(frozen.get("required", []))):
            return False
        provider_additional = provider.get("additionalProperties", True)
        for name, child in frozen_properties.items():
            candidate = provider_properties.get(name)
            if candidate is None:
                if provider_additional is False:
                    return False
                candidate = provider_additional if isinstance(provider_additional, dict) else {}
            if not input_schema_accepts_contract(child, candidate):
                return False
        frozen_additional = frozen.get("additionalProperties", True)
        if frozen_additional is not False:
            if provider_additional is False:
                return False
            if isinstance(provider_additional, dict):
                source = frozen_additional if isinstance(frozen_additional, dict) else {}
                if not input_schema_accepts_contract(source, provider_additional):
                    return False

    frozen_items = frozen.get("items")
    provider_items = provider.get("items")
    if provider_items is not None:
        if frozen_items is None or not input_schema_accepts_contract(
            frozen_items,
            provider_items,
        ):
            return False
    return True


def _validate_schema_node(schema: Any, path: str) -> None:
    if not isinstance(schema, dict):
        raise ValueError(f"{path} must be an object")
    schema_type = schema.get("type")
    declared_types = schema_type if isinstance(schema_type, list) else [schema_type]
    if schema_type is not None:
        allowed_types = {"array", "boolean", "integer", "null", "number", "object", "string"}
        if not declared_types or any(item not in allowed_types for item in declared_types):
            raise ValueError(f"{path} contains an unsupported type")
    for keyword in ("anyOf", "oneOf", "allOf"):
        alternatives = schema.get(keyword)
        if alternatives is None:
            continue
        if not isinstance(alternatives, list) or not alternatives:
            raise ValueError(f"{path}.{keyword} must be a non-empty array")
        for index, alternative in enumerate(alternatives):
            _validate_schema_node(alternative, f"{path}.{keyword}[{index}]")
    for keyword in ("not", "if", "then", "else"):
        child = schema.get(keyword)
        if child is not None:
            _validate_schema_node(child, f"{path}.{keyword}")
    properties = schema.get("properties", {})
    if not isinstance(properties, dict):
        raise ValueError(f"{path}.properties must be an object")
    for name, child in properties.items():
        if not isinstance(name, str):
            raise ValueError(f"{path}.properties keys must be strings")
        _validate_schema_node(child, f"{path}.properties.{name}")
    required = schema.get("required", [])
    if not isinstance(required, list) or any(not isinstance(item, str) for item in required):
        raise ValueError(f"{path}.required must be an array of strings")
    if schema.get("additionalProperties", True) is False and any(item not in properties for item in required):
        raise ValueError(f"{path}.required contains a property without a schema")
    additional = schema.get("additionalProperties", True)
    if not isinstance(additional, (bool, dict)):
        raise ValueError(f"{path}.additionalProperties must be boolean or an object")
    if isinstance(additional, dict):
        _validate_schema_node(additional, f"{path}.additionalProperties")
    items = schema.get("items")
    if items is not None:
        _validate_schema_node(items, f"{path}.items")
    enum = schema.get("enum")
    if enum is not None and (not isinstance(enum, list) or not enum):
        raise ValueError(f"{path}.enum must be a non-empty array")
    for keyword in (
        "minItems",
        "maxItems",
        "minLength",
        "maxLength",
        "minProperties",
        "maxProperties",
    ):
        boundary = schema.get(keyword)
        if boundary is not None and (
            not isinstance(boundary, int) or isinstance(boundary, bool) or boundary < 0
        ):
            raise ValueError(f"{path}.{keyword} must be a non-negative integer")
    if (
        isinstance(schema.get("minItems"), int)
        and isinstance(schema.get("maxItems"), int)
        and schema["minItems"] > schema["maxItems"]
    ):
        raise ValueError(f"{path}.minItems cannot exceed maxItems")
    if (
        isinstance(schema.get("minLength"), int)
        and isinstance(schema.get("maxLength"), int)
        and schema["minLength"] > schema["maxLength"]
    ):
        raise ValueError(f"{path}.minLength cannot exceed maxLength")
    if (
        isinstance(schema.get("minProperties"), int)
        and isinstance(schema.get("maxProperties"), int)
        and schema["minProperties"] > schema["maxProperties"]
    ):
        raise ValueError(f"{path}.minProperties cannot exceed maxProperties")
    for keyword in ("minimum", "maximum"):
        boundary = schema.get(keyword)
        if boundary is not None and (not isinstance(boundary, (int, float)) or isinstance(boundary, bool)):
            raise ValueError(f"{path}.{keyword} must be a number")
    if (
        isinstance(schema.get("minimum"), (int, float))
        and isinstance(schema.get("maximum"), (int, float))
        and schema["minimum"] > schema["maximum"]
    ):
        raise ValueError(f"{path}.minimum cannot exceed maximum")
    if "uniqueItems" in schema and not isinstance(schema["uniqueItems"], bool):
        raise ValueError(f"{path}.uniqueItems must be boolean")


def _normalize_schema_containers(
    value: Any,
    schema: dict[str, Any],
    *,
    path: str,
    depth: int,
    correction_budget: int,
) -> tuple[Any, list[ToolArgumentCorrection]]:
    if depth > MAX_NORMALIZED_ARGUMENT_DEPTH or correction_budget <= 0:
        return value, []

    corrections: list[ToolArgumentCorrection] = []
    active_schema = schema
    if isinstance(value, str):
        decoded = _decode_schema_container(value, schema, path)
        if decoded is not None:
            value, active_schema = decoded
            corrections.append(
                ToolArgumentCorrection(
                    path=path,
                    source_type="string",
                    target_type="object" if isinstance(value, dict) else "array",
                )
            )

    selected = _unique_matching_alternative(value, active_schema, path)
    if selected is not None:
        active_schema = selected

    if isinstance(value, dict):
        properties = active_schema.get("properties", {})
        additional = active_schema.get("additionalProperties")
        normalized: dict[str, Any] = {}
        for name, child in value.items():
            if len(corrections) >= correction_budget:
                normalized[name] = child
                continue
            child_schema = properties.get(name) if isinstance(properties, dict) else None
            if child_schema is None and isinstance(additional, dict):
                child_schema = additional
            if not isinstance(child_schema, dict):
                normalized[name] = child
                continue
            normalized_child, child_corrections = _normalize_schema_containers(
                child,
                child_schema,
                path=f"{path}.{name}",
                depth=depth + 1,
                correction_budget=correction_budget - len(corrections),
            )
            normalized[name] = normalized_child
            corrections.extend(child_corrections)
        return normalized, corrections

    if isinstance(value, list) and isinstance(active_schema.get("items"), dict):
        normalized_items: list[Any] = []
        for index, child in enumerate(value):
            if len(corrections) >= correction_budget:
                normalized_items.append(child)
                continue
            normalized_child, child_corrections = _normalize_schema_containers(
                child,
                active_schema["items"],
                path=f"{path}[{index}]",
                depth=depth + 1,
                correction_budget=correction_budget - len(corrections),
            )
            normalized_items.append(normalized_child)
            corrections.extend(child_corrections)
        return normalized_items, corrections

    return value, corrections


def _decode_schema_container(
    value: str,
    schema: dict[str, Any],
    path: str,
) -> tuple[dict[str, Any] | list[Any], dict[str, Any]] | None:
    if len(value.encode("utf-8")) > MAX_NORMALIZED_ARGUMENT_STRING_BYTES:
        return None
    if _schema_matches_value(value, schema, path):
        return None
    try:
        decoded = json.loads(value, parse_constant=_reject_non_finite_json_constant)
    except (json.JSONDecodeError, UnicodeError, ValueError):
        return None
    if not isinstance(decoded, (dict, list)):
        return None
    target_type = "object" if isinstance(decoded, dict) else "array"
    branches = _declared_container_branches(schema, target_type)
    matches = [branch for branch in branches if _schema_matches_value(decoded, branch, path)]
    if len(matches) != 1 or not _schema_matches_value(decoded, schema, path):
        return None
    return decoded, matches[0]


def _reject_non_finite_json_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON constant is not allowed: {value}")


def _declared_container_branches(
    schema: dict[str, Any],
    target_type: str,
) -> list[dict[str, Any]]:
    alternatives = schema.get("oneOf") or schema.get("anyOf")
    candidates = alternatives if isinstance(alternatives, list) else [schema]
    return [
        candidate
        for candidate in candidates
        if isinstance(candidate, dict) and _schema_declares_container(candidate, target_type)
    ]


def _schema_declares_container(schema: dict[str, Any], target_type: str) -> bool:
    declared = schema.get("type")
    declared_types = set(declared if isinstance(declared, list) else ([declared] if declared else []))
    if target_type in declared_types:
        return "string" not in declared_types
    children = schema.get("allOf")
    if not isinstance(children, list):
        return False
    matching_children = [
        child
        for child in children
        if isinstance(child, dict) and _schema_declares_container(child, target_type)
    ]
    return len(matching_children) == 1


def _unique_matching_alternative(
    value: Any,
    schema: dict[str, Any],
    path: str,
) -> dict[str, Any] | None:
    alternatives = schema.get("oneOf") or schema.get("anyOf")
    if not isinstance(alternatives, list):
        return None
    matches = [
        child
        for child in alternatives
        if isinstance(child, dict) and _schema_matches_value(value, child, path)
    ]
    return matches[0] if len(matches) == 1 else None


def _validate_value(value: Any, schema: dict[str, Any], path: str) -> None:
    for child in schema.get("allOf", []):
        _validate_value(value, child, path)
    if "anyOf" in schema and not any(_schema_matches_value(value, child, path) for child in schema["anyOf"]):
        raise ToolInputValidationError(f"{path} does not match any allowed schema")
    if "oneOf" in schema:
        selected = _select_discriminated_alternative(value, schema["oneOf"])
        if selected is not None:
            _validate_value(value, selected, path)
        else:
            discriminator_error = _one_of_discriminator_error(value, schema["oneOf"])
            if discriminator_error is not None:
                raise discriminator_error
            matches = sum(_schema_matches_value(value, child, path) for child in schema["oneOf"])
            if matches != 1:
                raise ToolInputValidationError(f"{path} must match exactly one allowed schema")
    if "not" in schema and _schema_matches_value(value, schema["not"], path):
        raise ToolInputValidationError(f"{path} matches a forbidden schema")
    if "if" in schema:
        branch = "then" if _schema_matches_value(value, schema["if"], path) else "else"
        if branch in schema:
            _validate_value(value, schema[branch], path)
    if "const" in schema and value != schema["const"]:
        raise ToolInputValidationError(f"{path} does not match the required constant")
    declared = schema.get("type")
    declared_types = declared if isinstance(declared, list) else ([declared] if declared else [])
    if declared_types and not any(_matches_type(value, item) for item in declared_types):
        expected = " or ".join(str(item) for item in declared_types)
        actual = (
            "null"
            if value is None
            else "boolean"
            if isinstance(value, bool)
            else "integer"
            if isinstance(value, int)
            else "number"
            if isinstance(value, float)
            else "string"
            if isinstance(value, str)
            else "array"
            if isinstance(value, list)
            else "object"
            if isinstance(value, dict)
            else type(value).__name__
        )
        raise ToolInputValidationError(
            f"{path} must be {expected}",
            reason_code="invalid_json_type",
            minimum_correction=(
                f"将 {path} 的 JSON 类型从 {actual} 改为 {expected}；"
                "不要原样重复当前结构。"
            ),
        )
    if "enum" in schema and value not in schema["enum"]:
        raise ToolInputValidationError(f"{path} is not an allowed value")
    if isinstance(value, str):
        if len(value) < schema.get("minLength", 0):
            raise ToolInputValidationError(f"{path} is shorter than the allowed minimum")
        if "maxLength" in schema and len(value) > schema["maxLength"]:
            raise ToolInputValidationError(f"{path} exceeds the allowed maximum length")
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            raise ToolInputValidationError(f"{path} is below the allowed minimum")
        if "maximum" in schema and value > schema["maximum"]:
            raise ToolInputValidationError(f"{path} exceeds the allowed maximum")

    if isinstance(value, dict):
        if len(value) < schema.get("minProperties", 0):
            field = path.rsplit(".", 1)[-1]
            raise ToolInputValidationError(
                f"{path} has fewer properties than allowed",
                reason_code=("missing_filter" if field == "filter" else f"invalid_{field}"),
                minimum_correction=(
                    "提供一个非空 filter；基础 Mongo 读取不允许无条件扫描。"
                    if field == "filter"
                    else f"为 {field} 提供至少一个明确字段。"
                ),
            )
        if "maxProperties" in schema and len(value) > schema["maxProperties"]:
            field = path.rsplit(".", 1)[-1]
            raise ToolInputValidationError(
                f"{path} has more properties than allowed",
                reason_code=f"invalid_{field}",
                minimum_correction=f"把 {field} 缩小到公开 schema 的字段数量上限。",
            )
        if any(not isinstance(name, str) for name in value):
            raise ToolInputValidationError(f"{path} property names must be strings")
        properties = schema.get("properties", {})
        required = schema.get("required", [])
        missing = [name for name in required if name not in value]
        if missing:
            raise ToolInputValidationError(
                f"{path} is missing required properties: {', '.join(sorted(missing))}",
                reason_code=(
                    f"missing_{missing[0]}" if len(missing) == 1 else "missing_required_fields"
                ),
                minimum_correction=f"提供必需字段：{', '.join(sorted(missing))}。",
            )
        additional = schema.get("additionalProperties", True)
        unknown = [name for name in value if name not in properties]
        if additional is False and unknown:
            raise ToolInputValidationError(
                f"{path} contains unexpected properties: {', '.join(sorted(unknown))}",
                reason_code="unsupported_input_field",
                minimum_correction=f"移除不受支持字段：{', '.join(sorted(unknown))}。",
            )
        for name, child_value in value.items():
            child_schema = properties.get(name)
            if child_schema is None and isinstance(additional, dict):
                child_schema = additional
            if child_schema is not None:
                _validate_value(child_value, child_schema, f"{path}.{name}")
    elif isinstance(value, list):
        if len(value) < schema.get("minItems", 0):
            raise ToolInputValidationError(f"{path} has fewer items than allowed")
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            raise ToolInputValidationError(f"{path} has more items than allowed")
        if schema.get("uniqueItems") and len({repr(item) for item in value}) != len(value):
            raise ToolInputValidationError(f"{path} must contain unique items")
        if "items" in schema:
            for index, item in enumerate(value):
                _validate_value(item, schema["items"], f"{path}[{index}]")


def _schema_matches_value(value: Any, schema: dict[str, Any], path: str) -> bool:
    try:
        _validate_value(value, schema, path)
    except PolicyError:
        return False
    return True


def _select_discriminated_alternative(
    value: Any,
    alternatives: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Select a oneOf branch with an explicit scalar property discriminator.

    Besides producing a clearer error, this preserves the branch's structured
    correction metadata instead of collapsing every missing operation field
    into a generic oneOf mismatch.
    """

    if not isinstance(value, dict):
        return None
    for discriminator in ("operation", "subcommand", "type", "kind"):
        current = value.get(discriminator)
        candidates = []
        for alternative in alternatives:
            properties = alternative.get("properties")
            if not isinstance(properties, dict):
                continue
            field_schema = properties.get(discriminator)
            if isinstance(field_schema, dict) and field_schema.get("const") == current:
                candidates.append(alternative)
        if len(candidates) == 1:
            return candidates[0]
    return None


def _one_of_discriminator_error(
    value: Any,
    alternatives: list[dict[str, Any]],
) -> ToolInputValidationError | None:
    if not isinstance(value, dict):
        return None
    for discriminator in ("operation", "subcommand", "type", "kind"):
        allowed: list[Any] = []
        required_everywhere = True
        for alternative in alternatives:
            properties = alternative.get("properties")
            required = alternative.get("required", [])
            field_schema = properties.get(discriminator) if isinstance(properties, dict) else None
            if not isinstance(field_schema, dict) or "const" not in field_schema:
                allowed = []
                break
            allowed.append(field_schema["const"])
            required_everywhere = required_everywhere and discriminator in required
        if not allowed:
            continue
        if discriminator not in value and required_everywhere:
            return ToolInputValidationError(
                f"tool arguments is missing required property: {discriminator}",
                reason_code=f"missing_{discriminator}",
                minimum_correction=f"提供必需字段：{discriminator}。",
            )
        if discriminator in value and value[discriminator] not in allowed:
            return ToolInputValidationError(
                f"{discriminator} is not an allowed value",
                reason_code=f"unsupported_{discriminator}",
                minimum_correction=(
                    f"{discriminator} 只能是："
                    + "、".join(str(item) for item in allowed)
                    + "。"
                ),
            )
    return None


def _matches_type(value: Any, expected: str) -> bool:
    if expected == "null":
        return value is None
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "string":
        return isinstance(value, str)
    if expected == "array":
        return isinstance(value, list)
    if expected == "object":
        return isinstance(value, dict)
    return False
