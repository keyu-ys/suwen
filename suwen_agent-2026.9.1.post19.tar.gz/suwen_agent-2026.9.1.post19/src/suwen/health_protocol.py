from __future__ import annotations

from typing import Any

HEALTH_SERVICE_ID = "suwen"
HEALTH_CONTRACT_VERSION = "suwen-health.v1"


def has_suwen_health_identity(payload: object) -> bool:
    if not isinstance(payload, dict):
        return False
    return (
        payload.get("service_id") == HEALTH_SERVICE_ID
        and payload.get("contract_version") == HEALTH_CONTRACT_VERSION
    )


def health_identity() -> dict[str, Any]:
    return {
        "service_id": HEALTH_SERVICE_ID,
        "contract_version": HEALTH_CONTRACT_VERSION,
    }
