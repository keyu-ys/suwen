from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from .audit_context import authorization_source, current_request_id, failure_class
from .personas import DEFAULT_PERSONA_ID, persona_snapshot
from .skills import CORE_SYSTEM_PROMPT, SKILL_RUNTIME_TOOL_NAMES

CURRENT_SCHEMA_VERSION = 25
DATABASE_BASELINE_ID = "suwen-mcp-v1"
REVIEW_ENGINE_PROFILE_ID = "deterministic-review"
REVIEW_ENGINE_VERSION_ID = "reviewengine-deterministic-v1"
TEST_FIXTURE_AGENT_ID = "test-fixture-agent"
TEST_FIXTURE_AGENT_VERSION_ID = "agentver-test-fixture-agent-v1"
TEST_FIXTURE_PROVIDER_ID = "test-fixture-stub"
TEST_FIXTURE_PROVIDER_VERSION_ID = "providerver-test-fixture-stub-v1"
TEST_FIXTURE_MODEL_PROFILE_ID = "test-fixture-stub"
TEST_FIXTURE_MODEL_PROFILE_VERSION_ID = "modelver-test-fixture-stub-v1"
TEST_FIXTURE_PROMPT_BUNDLE_ID = "test-fixture-prompt"
TEST_FIXTURE_PROMPT_BUNDLE_VERSION_ID = "promptver-test-fixture-prompt-v1"
GENERIC_PACK_VERSION_ID = "packver-generic-v0.3.0"
LOCAL_ENDPOINT_SECRET_REF_ID = "secret-local-model-endpoint"
LOCAL_API_KEY_SECRET_REF_ID = "secret-local-model-api-key"
LOCAL_PROVIDER_ID = "local"
LOCAL_PROVIDER_VERSION_ID = "providerver-local-v1"
KEYU_MTP_PROFILE_ID = "keyu-mtp"
KEYU_MTP_PROFILE_VERSION_ID = "modelver-keyu-mtp-v2"
SUWEN_AGENT_ID = "suwen"
SUWEN_DRAFT_VERSION_ID = "agentver-suwen-v1"
SUWEN_CORE_PROMPT_BUNDLE_ID = "suwen-core"
SUWEN_CORE_PROMPT_BUNDLE_VERSION = 5
SUWEN_CORE_PROMPT_BUNDLE_VERSION_ID = "promptver-suwen-core-v5"
SCHEMA_BASELINE = """
PRAGMA foreign_keys = ON;

CREATE TABLE actions (
    id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL REFERENCES cases(id),
    tool_name TEXT NOT NULL,
    arguments_json TEXT NOT NULL DEFAULT '{}',
    status TEXT NOT NULL,
    server_token TEXT NOT NULL UNIQUE,
    idempotency_key TEXT NOT NULL UNIQUE,
    prepared_run_id TEXT REFERENCES runs(id),
    requester_ref TEXT NOT NULL,
    prepared_at TEXT NOT NULL,
    confirmed_at TEXT,
    finished_at TEXT,
    result_json TEXT
, agent_id TEXT REFERENCES agents(id), action_type TEXT NOT NULL DEFAULT 'generic_controlled', commit_tool_name TEXT, confirmation_phrase TEXT NOT NULL DEFAULT '确认执行', expires_at TEXT, prepared_message_id TEXT REFERENCES messages(id), confirmed_message_id TEXT REFERENCES messages(id), prepare_result_json TEXT NOT NULL DEFAULT '{}', prepared_agent_version_id TEXT REFERENCES agent_versions(id));

CREATE TABLE agent_channel_bindings (
    id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL REFERENCES agents(id),
    channel_instance_id TEXT NOT NULL REFERENCES channel_instances(id),
    policy_json TEXT NOT NULL DEFAULT '{}',
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(agent_id, channel_instance_id)
);

CREATE TABLE agent_model_bindings (
    agent_id TEXT PRIMARY KEY REFERENCES agents(id),
    model_profile_id TEXT NOT NULL REFERENCES model_profiles(id),
    revision INTEGER NOT NULL DEFAULT 1,
    updated_by TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE agent_persona_bindings (
    agent_id TEXT PRIMARY KEY REFERENCES agents(id),
    persona_id TEXT NOT NULL,
    revision INTEGER NOT NULL DEFAULT 1,
    updated_by TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE agent_profile_releases (
    id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL,
    version TEXT NOT NULL,
    source_content_digest TEXT NOT NULL,
    artifact_id TEXT NOT NULL REFERENCES native_release_artifacts(id),
    installation_id TEXT NOT NULL REFERENCES native_workspace_installations(id),
    composition_lock_digest TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('installed', 'disabled')),
    installed_at TEXT NOT NULL,
    UNIQUE(profile_id, version)
);

CREATE TABLE agent_version_capabilities (
    agent_version_id TEXT NOT NULL REFERENCES agent_versions(id),
    capability_version_id TEXT NOT NULL REFERENCES capability_package_versions(id),
    role TEXT NOT NULL CHECK(role IN ('tools', 'domain')),
    position INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0, 1)), installation_id TEXT
REFERENCES native_workspace_installations(id), artifact_digest TEXT,
    PRIMARY KEY(agent_version_id, capability_version_id)
);

CREATE TABLE agent_version_packs (
    agent_version_id TEXT NOT NULL REFERENCES agent_versions(id),
    pack_version_id TEXT NOT NULL REFERENCES capability_pack_versions(id),
    position INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY(agent_version_id, pack_version_id)
);

CREATE TABLE agent_versions (
    id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL REFERENCES agents(id),
    version INTEGER NOT NULL,
    status TEXT NOT NULL,
    prompt_bundle_version_id TEXT REFERENCES prompt_bundle_versions(id),
    runtime_policy_json TEXT NOT NULL DEFAULT '{}',
    context_policy_json TEXT NOT NULL DEFAULT '{}',
    channel_policy_json TEXT NOT NULL DEFAULT '{}',
    review_policy_json TEXT NOT NULL DEFAULT '{}',
    presentation_policy_json TEXT NOT NULL DEFAULT '{}',
    config_json TEXT NOT NULL DEFAULT '{}',
    tool_schema_digest TEXT,
    digest TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    published_at TEXT,
    superseded_at TEXT,
    UNIQUE(agent_id, version)
);

CREATE TABLE agents (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    language TEXT NOT NULL DEFAULT 'zh-CN',
    status TEXT NOT NULL DEFAULT 'draft',
    active_version_id TEXT REFERENCES agent_versions(id),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    archived_at TEXT
);

CREATE TABLE artifacts (
    id TEXT PRIMARY KEY,
    case_id TEXT REFERENCES cases(id),
    run_id TEXT REFERENCES runs(id),
    relative_path TEXT NOT NULL UNIQUE,
    sha256 TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    sensitive INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
, agent_id TEXT REFERENCES agents(id));

CREATE TABLE audit_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_type TEXT NOT NULL,
    actor_ref TEXT NOT NULL,
    action TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    target_version TEXT,
    request_id TEXT,
    before_digest TEXT,
    after_digest TEXT,
    result TEXT NOT NULL,
    metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
, authorization_source TEXT NOT NULL DEFAULT 'system_internal', failure_class TEXT);

CREATE TABLE candidate_attempts (
    id TEXT PRIMARY KEY,
    candidate_key TEXT NOT NULL UNIQUE,
    suite_digest TEXT NOT NULL,
    agent_id TEXT NOT NULL REFERENCES agents(id),
    agent_version_id TEXT NOT NULL REFERENCES agent_versions(id),
    model_profile_version_id TEXT NOT NULL REFERENCES model_profile_versions(id),
    provider_version_id TEXT NOT NULL REFERENCES model_provider_versions(id),
    prompt_bundle_digest TEXT NOT NULL,
    pack_digests_json TEXT NOT NULL,
    tool_schema_digest TEXT NOT NULL,
    code_revision TEXT NOT NULL,
    configuration_fingerprint TEXT NOT NULL,
    workspace_ref TEXT NOT NULL,
    status TEXT NOT NULL,
    manifest_json TEXT NOT NULL,
    scorecard_json TEXT,
    failure_class TEXT,
    model_calls INTEGER NOT NULL DEFAULT 0,
    source_calls INTEGER NOT NULL DEFAULT 0,
    external_writes INTEGER NOT NULL DEFAULT 0,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    started_at TEXT,
    finished_at TEXT
);

CREATE TABLE candidate_human_reviews (
    id TEXT PRIMARY KEY,
    candidate_attempt_id TEXT NOT NULL UNIQUE REFERENCES candidate_attempts(id),
    reviewer_ref TEXT NOT NULL,
    dimensions_json TEXT NOT NULL,
    decision TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE capability_candidates (
    id TEXT PRIMARY KEY,
    research_digest_id TEXT NOT NULL REFERENCES research_digests(id),
    kind TEXT NOT NULL,
    summary TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'discovered',
    supporting_review_count INTEGER NOT NULL,
    counterexample_count INTEGER NOT NULL,
    support_refs_json TEXT NOT NULL,
    counter_refs_json TEXT NOT NULL,
    existing_capability_map_json TEXT NOT NULL,
    change_slice_json TEXT NOT NULL,
    risk_json TEXT NOT NULL,
    validation_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(research_digest_id, kind)
);

CREATE TABLE capability_pack_versions (
    id TEXT PRIMARY KEY,
    pack_id TEXT NOT NULL REFERENCES capability_packs(id),
    version TEXT NOT NULL,
    manifest_json TEXT NOT NULL,
    digest TEXT NOT NULL,
    source_ref TEXT,
    compatible_core_range TEXT NOT NULL DEFAULT '',
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(pack_id, version)
);

CREATE TABLE capability_package_versions (
    id TEXT PRIMARY KEY,
    capability_id TEXT NOT NULL REFERENCES capability_packages(id),
    version TEXT NOT NULL,
    manifest_json TEXT NOT NULL,
    content_digest TEXT NOT NULL,
    capability_api_range TEXT NOT NULL,
    lifecycle_state TEXT NOT NULL CHECK(lifecycle_state IN (
        'source-present', 'artifact-built', 'workspace-installed'
    )),
    artifact_digest TEXT,
    artifact_path TEXT,
    workspace_path TEXT,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    artifact_built_at TEXT,
    installed_at TEXT,
    UNIQUE(capability_id, version)
);

CREATE TABLE capability_packages (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL CHECK(kind IN ('tools', 'domain')),
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'available' CHECK(status IN ('available', 'disabled', 'retired')),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE capability_packs (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    trust_level TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'installed',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    retired_at TEXT
, retirement_reason TEXT, replacement_pack_version_id TEXT);

CREATE TABLE capability_process_loads (
    process_instance_id TEXT NOT NULL,
    capability_version_id TEXT NOT NULL REFERENCES capability_package_versions(id),
    installation_id TEXT REFERENCES native_workspace_installations(id),
    artifact_digest TEXT,
    state TEXT NOT NULL CHECK(state IN ('process-loaded', 'load-failed')),
    loaded_at TEXT NOT NULL,
    last_used_at TEXT NOT NULL,
    error_code TEXT,
    PRIMARY KEY(process_instance_id, capability_version_id)
);

CREATE TABLE "cases" (
    id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL REFERENCES agents(id),
    pinned_agent_version_id TEXT REFERENCES agent_versions(id),
    title TEXT NOT NULL,
    lifecycle TEXT NOT NULL DEFAULT 'open',
    disposition TEXT NOT NULL DEFAULT 'unknown',
    close_reason TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    last_external_at TEXT,
    closed_at TEXT,
    reopened_count INTEGER NOT NULL DEFAULT 0,
    persona_snapshot_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE "channel_bindings" (
    id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL REFERENCES agents(id),
    channel TEXT NOT NULL,
    channel_instance TEXT NOT NULL,
    scope_kind TEXT NOT NULL,
    scope_ref TEXT NOT NULL,
    actor_ref TEXT NOT NULL DEFAULT '',
    case_id TEXT NOT NULL REFERENCES cases(id),
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE channel_ingress_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_instance_id TEXT REFERENCES channel_instances(id),
    event_ref_hash TEXT,
    outcome TEXT NOT NULL,
    failure_class TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE channel_instance_versions (
    id TEXT PRIMARY KEY,
    channel_instance_id TEXT NOT NULL REFERENCES channel_instances(id),
    version INTEGER NOT NULL,
    config_json TEXT NOT NULL,
    digest TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(channel_instance_id, version)
);

CREATE TABLE channel_instances (
    id TEXT PRIMARY KEY,
    channel_type TEXT NOT NULL,
    name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    config_json TEXT NOT NULL DEFAULT '{}',
    secret_ref_id TEXT REFERENCES secret_refs(id),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    archived_at TEXT
, revision INTEGER NOT NULL DEFAULT 1, health_state TEXT NOT NULL DEFAULT 'unknown', validated_at TEXT, last_error_class TEXT);

CREATE TABLE channel_secret_bindings (
    channel_instance_id TEXT NOT NULL REFERENCES channel_instances(id),
    purpose TEXT NOT NULL,
    secret_ref_id TEXT NOT NULL REFERENCES secret_refs(id),
    created_at TEXT NOT NULL,
    PRIMARY KEY(channel_instance_id, purpose)
);

CREATE TABLE config_validation_runs (
    id TEXT PRIMARY KEY,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    target_digest TEXT NOT NULL,
    status TEXT NOT NULL,
    findings_json TEXT NOT NULL DEFAULT '[]',
    actor_ref TEXT NOT NULL,
    created_at TEXT NOT NULL,
    finished_at TEXT
);

CREATE TABLE events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id TEXT REFERENCES cases(id),
    run_id TEXT REFERENCES runs(id),
    kind TEXT NOT NULL,
    payload_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
, agent_id TEXT REFERENCES agents(id));

CREATE TABLE evidence (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES runs(id),
    tool_call_id TEXT REFERENCES tool_calls(id),
    state TEXT NOT NULL,
    coverage_state TEXT NOT NULL,
    summary TEXT NOT NULL,
    data_json TEXT NOT NULL DEFAULT '{}',
    source_ref TEXT,
    created_at TEXT NOT NULL
, contract_version TEXT NOT NULL DEFAULT 'model-evidence.v2', truncation_state TEXT NOT NULL DEFAULT 'unknown', source_role TEXT NOT NULL DEFAULT 'current_observation', limitations_json TEXT NOT NULL DEFAULT '[]', safe_statements_json TEXT NOT NULL DEFAULT '[]', continuation_json TEXT, observed_at TEXT, observation_id TEXT REFERENCES evidence_observations(id), content_digest TEXT NOT NULL DEFAULT '', unchanged_from_evidence_id TEXT REFERENCES evidence(id));

CREATE TABLE evidence_observations (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES runs(id),
    tool_call_id TEXT REFERENCES tool_calls(id),
    contract_version TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    sensitivity TEXT NOT NULL DEFAULT 'restricted_redacted',
    created_at TEXT NOT NULL
);

CREATE TABLE external_dependency_bindings (
    id TEXT PRIMARY KEY,
    dependency_id TEXT NOT NULL,
    contract TEXT NOT NULL,
    command TEXT NOT NULL,
    resolved_executable TEXT NOT NULL,
    version TEXT,
    generation INTEGER NOT NULL,
    allowed_subcommands_json TEXT NOT NULL,
    timeout_seconds REAL NOT NULL,
    max_output_bytes INTEGER NOT NULL,
    policy_digest TEXT NOT NULL,
    active INTEGER NOT NULL CHECK(active IN (0, 1)),
    configured_by TEXT NOT NULL,
    configured_at TEXT NOT NULL,
    disabled_at TEXT,
    UNIQUE(dependency_id, contract, generation)
);

CREATE TABLE external_messages (
    channel TEXT NOT NULL,
    channel_instance TEXT NOT NULL,
    message_ref TEXT NOT NULL,
    case_id TEXT NOT NULL REFERENCES cases(id),
    event_id TEXT REFERENCES inbound_events(event_id), direction TEXT NOT NULL DEFAULT 'legacy', message_kind TEXT NOT NULL DEFAULT 'text', internal_message_id TEXT REFERENCES messages(id), run_id TEXT REFERENCES runs(id), created_outbox_id TEXT REFERENCES outbox(id), last_outbox_id TEXT REFERENCES outbox(id), card_id TEXT, parent_message_ref TEXT, root_message_ref TEXT, thread_ref TEXT, lifecycle_state TEXT NOT NULL DEFAULT 'linked', channel_revision INTEGER, linked_at TEXT, updated_at TEXT,
    PRIMARY KEY(channel, channel_instance, message_ref)
);

CREATE TABLE feedback (
    id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL REFERENCES cases(id),
    actor_ref TEXT NOT NULL,
    kind TEXT NOT NULL,
    value TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '',
    source TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE inbound_events (
    event_id TEXT PRIMARY KEY,
    channel TEXT NOT NULL,
    case_id TEXT REFERENCES cases(id),
    received_at TEXT NOT NULL,
    state TEXT NOT NULL
, agent_id TEXT REFERENCES agents(id));

CREATE TABLE jobs (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    case_id TEXT REFERENCES cases(id),
    unique_key TEXT NOT NULL UNIQUE,
    payload_json TEXT NOT NULL,
    due_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    lease_until TEXT,
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    created_at TEXT NOT NULL,
    finished_at TEXT
, agent_id TEXT REFERENCES agents(id));

CREATE TABLE messages (
    id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL REFERENCES cases(id),
    seq INTEGER NOT NULL,
    role TEXT NOT NULL,
    actor_ref TEXT,
    content TEXT NOT NULL,
    external_event_id TEXT,
    created_at TEXT NOT NULL,
    metadata_json TEXT NOT NULL DEFAULT '{}',
    UNIQUE(case_id, seq),
    UNIQUE(external_event_id)
);

CREATE TABLE model_profile_versions (
    id TEXT PRIMARY KEY,
    model_profile_id TEXT NOT NULL REFERENCES model_profiles(id),
    version INTEGER NOT NULL,
    provider_version_id TEXT NOT NULL REFERENCES model_provider_versions(id),
    model_id TEXT NOT NULL,
    max_input_length INTEGER NOT NULL,
    max_output_tokens INTEGER NOT NULL,
    temperature REAL NOT NULL,
    reasoning_effort TEXT,
    timeout_seconds REAL NOT NULL,
    capabilities_json TEXT NOT NULL DEFAULT '{}',
    routing_json TEXT NOT NULL DEFAULT '{}',
    digest TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(model_profile_id, version)
);

CREATE TABLE model_profiles (
    id TEXT PRIMARY KEY,
    provider_id TEXT NOT NULL REFERENCES model_providers(id),
    name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    archived_at TEXT
);

CREATE TABLE model_provider_versions (
    id TEXT PRIMARY KEY,
    provider_id TEXT NOT NULL REFERENCES model_providers(id),
    version INTEGER NOT NULL,
    endpoint_ref TEXT NOT NULL DEFAULT '',
    secret_ref_id TEXT REFERENCES secret_refs(id),
    config_json TEXT NOT NULL DEFAULT '{}',
    digest TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(provider_id, version)
);

CREATE TABLE model_providers (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    protocol TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    archived_at TEXT
);

CREATE TABLE model_turns (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES runs(id),
    turn_index INTEGER NOT NULL,
    status TEXT NOT NULL,
    finish_reason TEXT,
    tool_request_count INTEGER NOT NULL DEFAULT 0,
    request_chars INTEGER NOT NULL DEFAULT 0,
    response_chars INTEGER NOT NULL DEFAULT 0,
    latency_ms INTEGER NOT NULL DEFAULT 0,
    usage_state TEXT NOT NULL DEFAULT 'not_observable',
    usage_json TEXT,
    failure_class TEXT,
    started_at TEXT NOT NULL,
    finished_at TEXT NOT NULL, request_json TEXT, response_json TEXT,
    context_generation_id TEXT REFERENCES context_generations(id),
    UNIQUE(run_id, turn_index)
);

CREATE TABLE native_install_transactions (
    id TEXT PRIMARY KEY,
    operation TEXT NOT NULL CHECK(operation IN ('import', 'install', 'disable', 'prepare-rollback')),
    artifact_digest TEXT,
    resource_type TEXT,
    resource_id TEXT,
    version TEXT,
    state TEXT NOT NULL CHECK(state IN ('started', 'succeeded', 'failed')),
    input_json TEXT NOT NULL DEFAULT '{}',
    result_json TEXT,
    error_code TEXT,
    actor TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT
);

CREATE TABLE native_release_artifacts (
    id TEXT PRIMARY KEY,
    artifact_digest TEXT NOT NULL UNIQUE,
    resource_type TEXT NOT NULL CHECK(resource_type IN ('capability', 'agent-profile')),
    resource_id TEXT NOT NULL,
    version TEXT NOT NULL,
    source_content_digest TEXT NOT NULL,
    payload_digest TEXT NOT NULL,
    trusted_code INTEGER NOT NULL CHECK(trusted_code IN (0, 1)),
    release_json TEXT NOT NULL,
    inventory_json TEXT NOT NULL,
    artifact_path TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL CHECK(status IN ('verified', 'quarantined')),
    trust_confirmed INTEGER NOT NULL DEFAULT 0 CHECK(trust_confirmed IN (0, 1)),
    imported_by TEXT NOT NULL,
    imported_at TEXT NOT NULL,
    UNIQUE(resource_type, resource_id, version)
);

CREATE TABLE native_workspace_installations (
    id TEXT PRIMARY KEY,
    artifact_id TEXT NOT NULL REFERENCES native_release_artifacts(id),
    capability_version_id TEXT REFERENCES capability_package_versions(id),
    install_digest TEXT NOT NULL,
    workspace_path TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL CHECK(status IN ('installed', 'disabled')),
    transaction_id TEXT NOT NULL REFERENCES native_install_transactions(id),
    installed_by TEXT NOT NULL,
    installed_at TEXT NOT NULL,
    disabled_at TEXT,
    UNIQUE(artifact_id)
);

CREATE TABLE outbox (
    id TEXT PRIMARY KEY,
    case_id TEXT REFERENCES cases(id),
    channel TEXT NOT NULL,
    address_json TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL DEFAULT 'pending',
    attempts INTEGER NOT NULL DEFAULT 0,
    available_at TEXT NOT NULL,
    lease_until TEXT,
    lease_owner TEXT,
    created_at TEXT NOT NULL,
    sent_at TEXT,
    last_error TEXT
, agent_id TEXT REFERENCES agents(id), outcome_state TEXT, receipt_json TEXT, external_message_ref TEXT, finished_at TEXT);

CREATE TABLE prompt_bundle_versions (
    id TEXT PRIMARY KEY,
    prompt_bundle_id TEXT NOT NULL REFERENCES prompt_bundles(id),
    version INTEGER NOT NULL,
    content_json TEXT NOT NULL,
    digest TEXT NOT NULL,
    source_ref TEXT,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(prompt_bundle_id, version)
);

CREATE TABLE prompt_bundles (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    archived_at TEXT
);

CREATE TABLE publish_events (
    id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL REFERENCES agents(id),
    from_version_id TEXT REFERENCES agent_versions(id),
    to_version_id TEXT NOT NULL REFERENCES agent_versions(id),
    kind TEXT NOT NULL,
    actor_ref TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE research_digest_reviews (
    research_digest_id TEXT NOT NULL REFERENCES research_digests(id),
    review_id TEXT NOT NULL REFERENCES reviews(id),
    role TEXT NOT NULL,
    PRIMARY KEY(research_digest_id, review_id)
);

CREATE TABLE research_digests (
    id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL REFERENCES agents(id),
    input_snapshot_hash TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    summary TEXT NOT NULL,
    existing_capability_map_json TEXT NOT NULL,
    risk_json TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    reviewer_ref TEXT,
    reviewer_note TEXT,
    decided_at TEXT,
    UNIQUE(agent_id, input_snapshot_hash)
);

CREATE TABLE review_engine_profiles (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    status TEXT NOT NULL,
    active_version_id TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE review_engine_versions (
    id TEXT PRIMARY KEY,
    review_engine_profile_id TEXT NOT NULL REFERENCES review_engine_profiles(id),
    version INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    engine_kind TEXT NOT NULL,
    algorithm_version TEXT NOT NULL,
    model_profile_version_id TEXT NOT NULL REFERENCES model_profile_versions(id),
    prompt_bundle_version_id TEXT NOT NULL REFERENCES prompt_bundle_versions(id),
    config_json TEXT NOT NULL,
    digest TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(review_engine_profile_id, version)
);

CREATE TABLE reviews (
    id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL REFERENCES cases(id),
    snapshot_version TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    summary TEXT NOT NULL,
    conclusion_json TEXT NOT NULL,
    findings_json TEXT NOT NULL,
    safety_findings_json TEXT NOT NULL,
    capability_gaps_json TEXT NOT NULL,
    evidence_refs_json TEXT NOT NULL,
    feedback_refs_json TEXT NOT NULL,
    confidence TEXT NOT NULL,
    reviewer_ref TEXT,
    reviewer_note TEXT,
    created_at TEXT NOT NULL,
    decided_at TEXT, agent_id TEXT REFERENCES agents(id), agent_version_scope_json TEXT NOT NULL DEFAULT '[]', input_snapshot_hash TEXT, review_engine_version_id TEXT
    REFERENCES review_engine_versions(id), model_profile_scope_json TEXT NOT NULL DEFAULT '[]', pack_digest_scope_json TEXT NOT NULL DEFAULT '[]', run_refs_json TEXT NOT NULL DEFAULT '[]', reply_refs_json TEXT NOT NULL DEFAULT '[]', limitations_json TEXT NOT NULL DEFAULT '[]',
    UNIQUE(case_id, snapshot_version)
);

CREATE TABLE run_capabilities (
    run_id TEXT NOT NULL REFERENCES runs(id),
    capability_version_id TEXT NOT NULL REFERENCES capability_package_versions(id),
    role TEXT NOT NULL CHECK(role IN ('tools', 'domain')),
    content_digest TEXT NOT NULL,
    load_state TEXT NOT NULL CHECK(load_state IN ('process-loaded', 'real-called')),
    tool_call_count INTEGER NOT NULL DEFAULT 0,
    evidence_count INTEGER NOT NULL DEFAULT 0,
    loaded_at TEXT NOT NULL,
    first_called_at TEXT, installation_id TEXT
REFERENCES native_workspace_installations(id), artifact_digest TEXT,
    PRIMARY KEY(run_id, capability_version_id)
);

CREATE TABLE run_external_dependencies (
    run_id TEXT NOT NULL REFERENCES runs(id),
    dependency_id TEXT NOT NULL,
    contract TEXT NOT NULL,
    binding_id TEXT REFERENCES external_dependency_bindings(id),
    binding_generation INTEGER,
    command TEXT,
    resolved_executable TEXT,
    version TEXT,
    policy_digest TEXT,
    state TEXT NOT NULL CHECK(state IN ('unavailable', 'bound', 'called', 'failed', 'timed-out')),
    call_count INTEGER NOT NULL DEFAULT 0,
    frozen_at TEXT NOT NULL,
    first_called_at TEXT,
    PRIMARY KEY(run_id, dependency_id)
);

CREATE TABLE "runs" (
    id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL REFERENCES cases(id),
    agent_version_id TEXT NOT NULL REFERENCES agent_versions(id),
    model_profile_version_id TEXT NOT NULL REFERENCES model_profile_versions(id),
    provider_version_id TEXT NOT NULL REFERENCES model_provider_versions(id),
    trigger_message_id TEXT REFERENCES messages(id),
    status TEXT NOT NULL,
    stop_reason TEXT,
    model_profile_json TEXT NOT NULL,
    context_json TEXT NOT NULL DEFAULT '{}',
    prompt_bundle_digest TEXT,
    pack_digests_json TEXT NOT NULL DEFAULT '[]',
    tool_schema_digest TEXT,
    started_at TEXT NOT NULL,
    finished_at TEXT
, context_layers_json TEXT NOT NULL DEFAULT '[]', context_chars INTEGER NOT NULL DEFAULT 0, context_token_estimate INTEGER NOT NULL DEFAULT 0, usage_state TEXT NOT NULL DEFAULT 'not_observable', usage_json TEXT);

CREATE TABLE schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE secret_refs (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    resolver TEXT NOT NULL,
    locator TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'unverified',
    version INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    last_verified_at TEXT
);

CREATE TABLE snapshots (
    id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL REFERENCES cases(id),
    through_seq INTEGER NOT NULL,
    summary TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(case_id, through_seq)
);

CREATE TABLE system_settings (
    key TEXT PRIMARY KEY,
    value_json TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    updated_by TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE tool_calls (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES runs(id),
    provider_call_id TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    risk TEXT NOT NULL,
    arguments_json TEXT NOT NULL,
    status TEXT NOT NULL,
    result_json TEXT,
    created_at TEXT NOT NULL,
    finished_at TEXT,
    call_fingerprint TEXT,
    result_kind TEXT NOT NULL DEFAULT 'observation',
    duplicate_of_tool_call_id TEXT REFERENCES tool_calls(id),
    reused_evidence_id TEXT REFERENCES evidence(id),
    UNIQUE(run_id, provider_call_id)
);

CREATE TABLE diagnostic_checkpoints (
    id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL REFERENCES cases(id),
    through_message_seq INTEGER NOT NULL,
    content_json TEXT NOT NULL,
    content_digest TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(case_id, through_message_seq, content_digest)
);

CREATE TABLE case_context_heads (
    case_id TEXT PRIMARY KEY REFERENCES cases(id),
    checkpoint_id TEXT NOT NULL REFERENCES diagnostic_checkpoints(id),
    version INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL
);

CREATE TABLE context_generations (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES runs(id),
    turn_index INTEGER NOT NULL,
    checkpoint_id TEXT REFERENCES diagnostic_checkpoints(id),
    strategy TEXT NOT NULL,
    pressure_tier TEXT NOT NULL,
    budget_json TEXT NOT NULL,
    source_message_count INTEGER NOT NULL,
    projected_message_count INTEGER NOT NULL,
    omitted_protocol_groups INTEGER NOT NULL DEFAULT 0,
    omitted_history_messages INTEGER NOT NULL DEFAULT 0,
    evidence_refs_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    UNIQUE(run_id, turn_index)
);

CREATE TABLE context_generation_evidence (
    context_generation_id TEXT NOT NULL REFERENCES context_generations(id),
    evidence_id TEXT NOT NULL REFERENCES evidence(id),
    projection TEXT NOT NULL DEFAULT 'evidence-card',
    PRIMARY KEY(context_generation_id, evidence_id)
);

CREATE TABLE tool_providers (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    provider_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    connection_ref TEXT NOT NULL DEFAULT '',
    secret_ref_id TEXT REFERENCES secret_refs(id),
    binding_generation INTEGER NOT NULL DEFAULT 0,
    runtime_metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    archived_at TEXT
);

CREATE TABLE tool_schema_versions (
    id TEXT PRIMARY KEY,
    tool_provider_id TEXT NOT NULL REFERENCES tool_providers(id),
    version INTEGER NOT NULL,
    schema_json TEXT NOT NULL,
    digest TEXT NOT NULL,
    observed_at TEXT,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(tool_provider_id, version)
);

CREATE INDEX idx_actions_pending_expiry
ON actions(status, expires_at, case_id);

CREATE INDEX idx_actions_prepared_agent_version
ON actions(prepared_agent_version_id, status);

CREATE INDEX idx_agent_channel_bindings_instance
ON agent_channel_bindings(channel_instance_id, active, agent_id);

CREATE INDEX idx_agent_version_capabilities_version
ON agent_version_capabilities(agent_version_id, position);

CREATE INDEX idx_agent_versions_agent ON agent_versions(agent_id, version);

CREATE INDEX idx_agents_status ON agents(status, updated_at);

CREATE INDEX idx_artifacts_expiry ON artifacts(expires_at);

CREATE INDEX idx_audit_events_created ON audit_events(created_at, id);

CREATE INDEX idx_audit_events_target
ON audit_events(target_type, target_id, created_at);

CREATE INDEX idx_candidate_attempts_status
ON candidate_attempts(status, created_at);

CREATE INDEX idx_capability_candidates_status
ON capability_candidates(status, created_at);

CREATE INDEX idx_capability_package_versions_capability
ON capability_package_versions(capability_id, created_at);

CREATE INDEX idx_capability_process_loads_version
ON capability_process_loads(capability_version_id, last_used_at);

CREATE INDEX idx_cases_agent_updated ON cases(agent_id, updated_at);

CREATE INDEX idx_cases_lifecycle_activity ON cases(lifecycle, last_external_at);

CREATE UNIQUE INDEX idx_channel_bindings_active_scope
ON channel_bindings(agent_id, channel, channel_instance, scope_kind, scope_ref, actor_ref)
WHERE active = 1;

CREATE INDEX idx_channel_ingress_instance
ON channel_ingress_events(channel_instance_id, created_at);

CREATE INDEX idx_channel_instances_status
ON channel_instances(channel_type, status, updated_at);

CREATE INDEX idx_events_case_id ON events(case_id, id);

CREATE UNIQUE INDEX idx_evidence_observation ON evidence(observation_id)
WHERE observation_id IS NOT NULL;

CREATE INDEX idx_evidence_observations_run ON evidence_observations(run_id, created_at);

CREATE UNIQUE INDEX idx_external_dependency_active_binding
ON external_dependency_bindings(dependency_id, contract) WHERE active=1;

CREATE INDEX idx_external_messages_card
ON external_messages(channel, channel_instance, card_id);

CREATE INDEX idx_external_messages_internal
ON external_messages(internal_message_id);

CREATE INDEX idx_external_messages_run
ON external_messages(run_id);

CREATE INDEX idx_feedback_case ON feedback(case_id, created_at);

CREATE INDEX idx_jobs_due ON jobs(status, due_at);

CREATE INDEX idx_messages_case_seq ON messages(case_id, seq);

CREATE INDEX idx_model_profiles_provider ON model_profiles(provider_id, status);

CREATE INDEX idx_model_turns_run ON model_turns(run_id, turn_index);

CREATE INDEX idx_context_generations_run
ON context_generations(run_id, turn_index);

CREATE INDEX idx_diagnostic_checkpoints_case
ON diagnostic_checkpoints(case_id, through_message_seq);

CREATE INDEX idx_tool_calls_fingerprint
ON tool_calls(run_id, call_fingerprint);

CREATE INDEX idx_native_installation_capability
ON native_workspace_installations(capability_version_id, status);

CREATE INDEX idx_native_release_resource
ON native_release_artifacts(resource_type, resource_id, version);

CREATE INDEX idx_outbox_channel_status ON outbox(channel, status, created_at);

CREATE INDEX idx_research_digests_status ON research_digests(status, created_at);

CREATE INDEX idx_reviews_agent_status ON reviews(agent_id, status, created_at);

CREATE INDEX idx_reviews_status ON reviews(status, created_at);

CREATE INDEX idx_run_capabilities_version
ON run_capabilities(capability_version_id, loaded_at);

CREATE INDEX idx_runs_agent_version ON runs(agent_version_id, started_at);

CREATE TRIGGER audit_events_fill_context
AFTER INSERT ON audit_events
WHEN NEW.request_id IS NULL
  OR NEW.authorization_source='system_internal'
  OR (NEW.failure_class IS NULL AND NEW.result<>'succeeded')
BEGIN
    UPDATE audit_events
    SET request_id=COALESCE(NEW.request_id, trace_request_id()),
        authorization_source=CASE
            WHEN NEW.authorization_source='system_internal'
            THEN trace_authorization_source(NEW.actor_type, NEW.actor_ref)
            ELSE NEW.authorization_source
        END,
        failure_class=CASE
            WHEN NEW.failure_class IS NOT NULL THEN NEW.failure_class
            ELSE trace_failure_class(NEW.result, NEW.metadata_json)
        END
    WHERE id=NEW.id;
END;
"""


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _digest(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _suwen_core_prompt_content() -> dict[str, Any]:
    """The neutral, Runtime-owned host Prompt for new Agent Drafts.

    Keep this deliberately free of a business domain, retired capability component,
    Tool name, Channel, model, or external deployment detail.  Domain content is
    appended only by an explicit native capability binding during composition.
    """

    return {
        "system_prompt": CORE_SYSTEM_PROMPT,
        "source_revision": "suwen-runtime-core-v4-persona-neutral",
    }


def _bundled_pack_records() -> dict[tuple[str, str], tuple[Any, dict[str, Any]]]:
    """Inspect built-in catalog records without importing executable Pack modules."""
    from .packs import PackRegistry, bundled_packs_root, pack_catalog_manifest

    loaded = PackRegistry.inspect(bundled_packs_root())
    return {(pack.id, pack.version): (pack, pack_catalog_manifest(pack)) for pack in loaded}


class Database:
    def __init__(
        self,
        path: str | Path,
        *,
        enable_test_fixture_agent: bool = False,
    ):
        self.path = Path(path)
        self.enable_test_fixture_agent = enable_test_fixture_agent

    def initialize(self) -> dict[str, Any]:
        self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        try:
            self.path.parent.chmod(0o700)
        except OSError:
            pass

        existing_version = self._existing_schema_version()
        if existing_version not in {None, 22, 23, 24, CURRENT_SCHEMA_VERSION}:
            raise RuntimeError("fresh_database_required: existing Demo databases are unsupported")

        created = existing_version is None
        upgraded = existing_version in {22, 23, 24}
        connection = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        self._configure_connection(connection)
        try:
            connection.execute("PRAGMA journal_mode=WAL")
            if created:
                connection.executescript(SCHEMA_BASELINE)
                connection.execute(
                    "INSERT INTO schema_meta(key, value) VALUES('version', ?)",
                    (str(CURRENT_SCHEMA_VERSION),),
                )
                connection.execute(
                    "INSERT INTO schema_meta(key, value) VALUES('baseline', ?)",
                    (DATABASE_BASELINE_ID,),
                )
                self._seed_configuration_foundation(connection)
            elif upgraded:
                if existing_version == 22:
                    self._upgrade_schema_22_to_23(connection)
                if existing_version in {22, 23}:
                    self._upgrade_schema_23_to_24(connection)
                self._upgrade_schema_24_to_25(connection)
            baseline = connection.execute("SELECT value FROM schema_meta WHERE key='baseline'").fetchone()
            if not baseline or baseline[0] != DATABASE_BASELINE_ID:
                raise RuntimeError("fresh_database_required: existing Demo databases are unsupported")
            self._ensure_current_suwen_prompt(connection)
            connection.execute("PRAGMA foreign_keys=ON")
            violations = connection.execute("PRAGMA foreign_key_check").fetchall()
            if violations:
                raise RuntimeError(f"database foreign key check failed: {len(violations)} violation(s)")
        finally:
            connection.close()
        try:
            self.path.chmod(0o600)
        except OSError:
            pass
        return {
            "status": "initialized" if created else "upgraded" if upgraded else "current",
            "created": created,
            "upgraded": upgraded,
            "from_schema_version": existing_version,
            "schema_version": CURRENT_SCHEMA_VERSION,
        }

    @staticmethod
    def _upgrade_schema_22_to_23(connection: sqlite3.Connection) -> None:
        baseline = connection.execute(
            "SELECT value FROM schema_meta WHERE key='baseline'"
        ).fetchone()
        if not baseline or baseline[0] != DATABASE_BASELINE_ID:
            raise RuntimeError("fresh_database_required: unsupported schema 22 baseline")

        connection.execute("BEGIN IMMEDIATE")
        try:
            additions = {
                "model_turns": (("context_generation_id", "TEXT"),),
                "tool_calls": (
                    ("call_fingerprint", "TEXT"),
                    ("result_kind", "TEXT NOT NULL DEFAULT 'observation'"),
                    ("duplicate_of_tool_call_id", "TEXT"),
                    ("reused_evidence_id", "TEXT"),
                ),
                "evidence": (
                    ("content_digest", "TEXT NOT NULL DEFAULT ''"),
                    ("unchanged_from_evidence_id", "TEXT"),
                ),
            }
            for table, columns in additions.items():
                existing = {
                    row[1] for row in connection.execute(f"PRAGMA table_info({table})").fetchall()
                }
                for name, declaration in columns:
                    if name not in existing:
                        connection.execute(f"ALTER TABLE {table} ADD COLUMN {name} {declaration}")
            schema_statements = (
                """CREATE TABLE IF NOT EXISTS diagnostic_checkpoints (
                    id TEXT PRIMARY KEY,
                    case_id TEXT NOT NULL REFERENCES cases(id),
                    through_message_seq INTEGER NOT NULL,
                    content_json TEXT NOT NULL,
                    content_digest TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(case_id, through_message_seq, content_digest)
                )""",
                """CREATE TABLE IF NOT EXISTS case_context_heads (
                    case_id TEXT PRIMARY KEY REFERENCES cases(id),
                    checkpoint_id TEXT NOT NULL REFERENCES diagnostic_checkpoints(id),
                    version INTEGER NOT NULL DEFAULT 1,
                    updated_at TEXT NOT NULL
                )""",
                """CREATE TABLE IF NOT EXISTS context_generations (
                    id TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL REFERENCES runs(id),
                    turn_index INTEGER NOT NULL,
                    checkpoint_id TEXT REFERENCES diagnostic_checkpoints(id),
                    strategy TEXT NOT NULL,
                    pressure_tier TEXT NOT NULL,
                    budget_json TEXT NOT NULL,
                    source_message_count INTEGER NOT NULL,
                    projected_message_count INTEGER NOT NULL,
                    omitted_protocol_groups INTEGER NOT NULL DEFAULT 0,
                    omitted_history_messages INTEGER NOT NULL DEFAULT 0,
                    evidence_refs_json TEXT NOT NULL DEFAULT '[]',
                    created_at TEXT NOT NULL,
                    UNIQUE(run_id, turn_index)
                )""",
                """CREATE TABLE IF NOT EXISTS context_generation_evidence (
                    context_generation_id TEXT NOT NULL REFERENCES context_generations(id),
                    evidence_id TEXT NOT NULL REFERENCES evidence(id),
                    projection TEXT NOT NULL DEFAULT 'evidence-card',
                    PRIMARY KEY(context_generation_id, evidence_id)
                )""",
                """CREATE INDEX IF NOT EXISTS idx_context_generations_run
                    ON context_generations(run_id, turn_index)""",
                """CREATE INDEX IF NOT EXISTS idx_diagnostic_checkpoints_case
                    ON diagnostic_checkpoints(case_id, through_message_seq)""",
                """CREATE INDEX IF NOT EXISTS idx_tool_calls_fingerprint
                    ON tool_calls(run_id, call_fingerprint)""",
            )
            for statement in schema_statements:
                connection.execute(statement)
            connection.execute(
                "UPDATE schema_meta SET value=? WHERE key='version'",
                ("23",),
            )
            connection.execute(
                """INSERT INTO audit_events(
                   actor_type, actor_ref, action, target_type, target_id,
                   target_version, result, metadata_json, created_at
                ) VALUES ('system', 'database', 'database.upgraded', 'database',
                          'primary', ?, 'succeeded', ?, ?)""",
                (
                    "23",
                    json.dumps(
                        {
                            "from_schema_version": 22,
                            "to_schema_version": 23,
                            "change": "diagnostic_context_management",
                        },
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                    _now(),
                ),
            )
            violations = connection.execute("PRAGMA foreign_key_check").fetchall()
            if violations:
                raise RuntimeError(
                    "database foreign key check failed during schema 23 upgrade: "
                    f"{len(violations)} violation(s)"
                )
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise

    @staticmethod
    def _upgrade_schema_23_to_24(connection: sqlite3.Connection) -> None:
        baseline = connection.execute(
            "SELECT value FROM schema_meta WHERE key='baseline'"
        ).fetchone()
        if not baseline or baseline[0] != DATABASE_BASELINE_ID:
            raise RuntimeError("fresh_database_required: unsupported schema 23 baseline")

        connection.execute("BEGIN IMMEDIATE")
        try:
            columns = {
                row[1]
                for row in connection.execute(
                    "PRAGMA table_info(model_profile_versions)"
                ).fetchall()
            }
            if "reasoning_effort" not in columns:
                # Existing immutable versions remain NULL: they historically
                # omitted the control. New revisions always write an explicit
                # validated level, defaulting to high.
                connection.execute(
                    "ALTER TABLE model_profile_versions ADD COLUMN reasoning_effort TEXT"
                )
            connection.execute(
                "UPDATE schema_meta SET value=? WHERE key='version'",
                ("24",),
            )
            connection.execute(
                """INSERT INTO audit_events(
                   actor_type, actor_ref, action, target_type, target_id,
                   target_version, result, metadata_json, created_at
                ) VALUES ('system', 'database', 'database.upgraded', 'database',
                          'primary', ?, 'succeeded', ?, ?)""",
                (
                    "24",
                    json.dumps(
                        {
                            "from_schema_version": 23,
                            "to_schema_version": 24,
                            "change": "model_profile_reasoning_effort",
                        },
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                    _now(),
                ),
            )
            violations = connection.execute("PRAGMA foreign_key_check").fetchall()
            if violations:
                raise RuntimeError(
                    "database foreign key check failed during schema 24 upgrade: "
                    f"{len(violations)} violation(s)"
                )
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise

    @staticmethod
    def _upgrade_schema_24_to_25(connection: sqlite3.Connection) -> None:
        baseline = connection.execute(
            "SELECT value FROM schema_meta WHERE key='baseline'"
        ).fetchone()
        if not baseline or baseline[0] != DATABASE_BASELINE_ID:
            raise RuntimeError("fresh_database_required: unsupported schema 24 baseline")

        default_snapshot_json = json.dumps(
            persona_snapshot(DEFAULT_PERSONA_ID, 1),
            ensure_ascii=False,
            sort_keys=True,
        )
        connection.execute("BEGIN IMMEDIATE")
        try:
            connection.execute(
                """CREATE TABLE IF NOT EXISTS agent_persona_bindings (
                    agent_id TEXT PRIMARY KEY REFERENCES agents(id),
                    persona_id TEXT NOT NULL,
                    revision INTEGER NOT NULL DEFAULT 1,
                    updated_by TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )"""
            )
            connection.execute(
                """INSERT OR IGNORE INTO agent_persona_bindings(
                   agent_id, persona_id, revision, updated_by, updated_at
                ) SELECT id, ?, 1, 'system:migration', updated_at FROM agents""",
                (DEFAULT_PERSONA_ID,),
            )
            case_columns = {
                row[1] for row in connection.execute("PRAGMA table_info(cases)").fetchall()
            }
            if "persona_snapshot_json" not in case_columns:
                connection.execute(
                    "ALTER TABLE cases ADD COLUMN persona_snapshot_json TEXT NOT NULL DEFAULT '{}'"
                )
            connection.execute(
                """UPDATE cases SET persona_snapshot_json=?
                   WHERE persona_snapshot_json IS NULL OR persona_snapshot_json='{}'""",
                (default_snapshot_json,),
            )
            connection.execute(
                "UPDATE schema_meta SET value=? WHERE key='version'",
                (str(CURRENT_SCHEMA_VERSION),),
            )
            connection.execute(
                """INSERT INTO audit_events(
                   actor_type, actor_ref, action, target_type, target_id,
                   target_version, result, metadata_json, created_at
                ) VALUES ('system', 'database', 'database.upgraded', 'database',
                          'primary', ?, 'succeeded', ?, ?)""",
                (
                    str(CURRENT_SCHEMA_VERSION),
                    json.dumps(
                        {
                            "from_schema_version": 24,
                            "to_schema_version": CURRENT_SCHEMA_VERSION,
                            "change": "agent_persona_case_snapshot",
                        },
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                    _now(),
                ),
            )
            violations = connection.execute("PRAGMA foreign_key_check").fetchall()
            if violations:
                raise RuntimeError(
                    "database foreign key check failed during schema 25 upgrade: "
                    f"{len(violations)} violation(s)"
                )
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise

    def _existing_schema_version(self) -> int | None:
        if not self.path.exists() or self.path.stat().st_size == 0:
            return None
        uri = f"file:{self.path.resolve()}?mode=ro"
        connection = sqlite3.connect(uri, uri=True, timeout=10)
        try:
            row = connection.execute("SELECT value FROM schema_meta WHERE key='version'").fetchone()
        except sqlite3.DatabaseError as exc:
            raise RuntimeError("fresh_database_required: existing Demo databases are unsupported") from exc
        finally:
            connection.close()
        if not row:
            raise RuntimeError("fresh_database_required: existing Demo databases are unsupported")
        try:
            return int(row[0])
        except (TypeError, ValueError) as exc:
            raise RuntimeError("fresh_database_required: existing Demo databases are unsupported") from exc

    def installed_pack_digests(self) -> dict[str, str]:
        """Return exact catalog refs that may be loaded by this installation."""
        with self.connect() as connection:
            rows = connection.execute(
                """SELECT cpv.pack_id, cpv.version, cpv.digest
                   FROM capability_pack_versions cpv
                   JOIN capability_packs cp ON cp.id=cpv.pack_id
                   WHERE cp.status IN ('installed', 'disabled', 'retired')
                   ORDER BY cpv.pack_id, cpv.version"""
            ).fetchall()
        return {f"{row['pack_id']}@{row['version']}": str(row["digest"]) for row in rows}

    @staticmethod
    def _table_exists(connection: sqlite3.Connection, name: str) -> bool:
        return bool(
            connection.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)
            ).fetchone()
        )

    @staticmethod
    def _schema_version(connection: sqlite3.Connection) -> int:
        row = connection.execute("SELECT value FROM schema_meta WHERE key='version'").fetchone()
        if not row:
            raise RuntimeError("database schema version is missing")
        try:
            return int(row["value"])
        except (TypeError, ValueError) as exc:
            raise RuntimeError("database schema version is invalid") from exc

    def _seed_configuration_foundation(self, connection: sqlite3.Connection) -> None:
        at = _now()
        pack_records = _bundled_pack_records()
        try:
            generic_pack, pack_manifest = pack_records[("generic", "0.3.0")]
        except KeyError as exc:
            raise RuntimeError("required built-in generic Pack version is missing") from exc
        local_provider_config = {
            "protocol": "openai-compatible",
            "endpoint_ref": LOCAL_ENDPOINT_SECRET_REF_ID,
            "secret_ref": LOCAL_API_KEY_SECRET_REF_ID,
        }
        keyu_mtp_config = {
            "model_id": "keyu-mtp",
            "max_input_length": 130000,
            "max_output_tokens": 8192,
            "temperature": 0.2,
            "reasoning_effort": "high",
            "timeout_seconds": 300.0,
            "capabilities": {
                "tool_calling": True,
                "vision": False,
                "structured_output": False,
                "local": True,
            },
            "routing": {"fallback": False},
        }
        suwen_agent_config = {
            "tags": ["通用调查"],
            "max_tool_risk": "read_only",
            "schema": "suwen.agent-config.v1",
            "tool_allowlist": sorted(
                {
                    "find_artifact_text",
                    "inspect_claim",
                    "read_artifact_chunk",
                    "render_explanation_diagram",
                    "recall_case_history",
                    *SKILL_RUNTIME_TOOL_NAMES,
                }
            ),
        }
        suwen_core_prompt_content = _suwen_core_prompt_content()
        connection.execute(
            """INSERT OR IGNORE INTO capability_packs(
               id, name, description, trust_level, status, created_at, updated_at
            ) VALUES ('generic', '通用诊断包', '宿主无关的通用诊断能力包',
                      'trusted_local', 'installed', ?, ?)""",
            (at, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO capability_pack_versions(
               id, pack_id, version, manifest_json, digest, source_ref,
               compatible_core_range, created_by, created_at
            ) VALUES (?, 'generic', ?, ?, ?, ?, ?, 'system:bootstrap', ?)""",
            (
                GENERIC_PACK_VERSION_ID,
                generic_pack.version,
                json.dumps(pack_manifest, ensure_ascii=False),
                generic_pack.digest,
                f"catalog:{generic_pack.publisher}",
                generic_pack.compatible_core_range,
                at,
            ),
        )
        connection.execute(
            """INSERT OR IGNORE INTO prompt_bundles(
               id, name, description, status, created_at, updated_at
            ) VALUES (?, 'Suwen Core',
                      '领域无关的 Suwen Runtime 宿主提示词',
                      'active', ?, ?)""",
            (SUWEN_CORE_PROMPT_BUNDLE_ID, at, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO prompt_bundle_versions(
               id, prompt_bundle_id, version, content_json, digest, source_ref,
               created_by, created_at
            ) VALUES (?, ?, ?, ?, ?, 'runtime:suwen-core@4-persona-neutral',
                      'system:bootstrap', ?)""",
            (
                SUWEN_CORE_PROMPT_BUNDLE_VERSION_ID,
                SUWEN_CORE_PROMPT_BUNDLE_ID,
                SUWEN_CORE_PROMPT_BUNDLE_VERSION,
                json.dumps(suwen_core_prompt_content, ensure_ascii=False),
                _digest(suwen_core_prompt_content),
                at,
            ),
        )
        connection.execute(
            """INSERT OR REPLACE INTO system_settings(
               key, value_json, version, updated_by, updated_at
            ) VALUES ('default_agent_id', ?, 1, 'system:bootstrap', ?)""",
            (
                json.dumps(TEST_FIXTURE_AGENT_ID if self.enable_test_fixture_agent else SUWEN_AGENT_ID),
                at,
            ),
        )

        connection.execute(
            """INSERT OR IGNORE INTO secret_refs(
               id, name, resolver, locator, status, created_at, updated_at
            ) VALUES (?, 'Local model endpoint', 'env',
                      'SUWEN_LOCAL_MODEL_BASE_URL', 'unverified', ?, ?)""",
            (LOCAL_ENDPOINT_SECRET_REF_ID, at, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO secret_refs(
               id, name, resolver, locator, status, created_at, updated_at
            ) VALUES (?, 'Local model API key', 'env',
                      'SUWEN_LOCAL_MODEL_API_KEY', 'unverified', ?, ?)""",
            (LOCAL_API_KEY_SECRET_REF_ID, at, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO model_providers(
               id, name, protocol, status, created_at, updated_at
            ) VALUES (?, '本地模型服务', 'openai-compatible',
                      'active', ?, ?)""",
            (LOCAL_PROVIDER_ID, at, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO model_provider_versions(
               id, provider_id, version, endpoint_ref, secret_ref_id,
               config_json, digest, created_by, created_at
            ) VALUES (?, ?, 1, ?, ?, ?, ?, 'system:bootstrap', ?)""",
            (
                LOCAL_PROVIDER_VERSION_ID,
                LOCAL_PROVIDER_ID,
                LOCAL_ENDPOINT_SECRET_REF_ID,
                LOCAL_API_KEY_SECRET_REF_ID,
                json.dumps(local_provider_config),
                _digest(local_provider_config),
                at,
            ),
        )
        connection.execute(
            """INSERT OR IGNORE INTO model_profiles(
               id, provider_id, name, status, created_at, updated_at
            ) VALUES (?, ?, 'keyu-mtp (130K)', 'active', ?, ?)""",
            (KEYU_MTP_PROFILE_ID, LOCAL_PROVIDER_ID, at, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO model_profile_versions(
               id, model_profile_id, version, provider_version_id, model_id,
               max_input_length, max_output_tokens, temperature, reasoning_effort,
               timeout_seconds,
               capabilities_json, routing_json, digest, created_by, created_at
            ) VALUES (?, ?, 2, ?, 'keyu-mtp', 130000, 8192, 0.2, 'high', 300.0,
                      ?, ?, ?, 'system:bootstrap', ?)""",
            (
                KEYU_MTP_PROFILE_VERSION_ID,
                KEYU_MTP_PROFILE_ID,
                LOCAL_PROVIDER_VERSION_ID,
                json.dumps(keyu_mtp_config["capabilities"]),
                json.dumps(keyu_mtp_config["routing"]),
                _digest(keyu_mtp_config),
                at,
            ),
        )
        connection.execute(
            """INSERT OR IGNORE INTO agents(
               id, name, description, language, status, created_at, updated_at
            ) VALUES (?, '素问', '素问：证据驱动的故障调查智能体',
                      'zh-CN', 'draft', ?, ?)""",
            (SUWEN_AGENT_ID, at, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO agent_versions(
               id, agent_id, version, status, prompt_bundle_version_id,
               runtime_policy_json, context_policy_json,
               channel_policy_json, review_policy_json, presentation_policy_json,
               config_json, digest, created_by, created_at
            ) VALUES (?, ?, 1, 'draft', ?, ?, '{}', '{}', '{}', '{}',
                      ?, ?, 'system:bootstrap', ?)""",
            (
                SUWEN_DRAFT_VERSION_ID,
                SUWEN_AGENT_ID,
                SUWEN_CORE_PROMPT_BUNDLE_VERSION_ID,
                json.dumps(
                    {
                        "max_tool_calls": 60,
                        "max_tool_waves": 30,
                        "max_concurrency": 6,
                        "run_timeout_seconds": 900,
                    }
                ),
                json.dumps(suwen_agent_config),
                _digest(suwen_agent_config),
                at,
            ),
        )
        connection.execute(
            """INSERT OR IGNORE INTO agent_model_bindings(
               agent_id, model_profile_id, revision, updated_by, updated_at
            ) VALUES (?, ?, 1, 'system:bootstrap', ?)""",
            (SUWEN_AGENT_ID, KEYU_MTP_PROFILE_ID, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO agent_persona_bindings(
               agent_id, persona_id, revision, updated_by, updated_at
            ) VALUES (?, ?, 1, 'system:bootstrap', ?)""",
            (SUWEN_AGENT_ID, DEFAULT_PERSONA_ID, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO agent_version_packs(
               agent_version_id, pack_version_id, position, enabled
            ) VALUES (?, ?, 0, 1)""",
            (SUWEN_DRAFT_VERSION_ID, GENERIC_PACK_VERSION_ID),
        )
        if self.enable_test_fixture_agent:
            self._seed_test_fixture_configuration(connection, at)
        self._seed_runtime_control_plane(connection, at)

    @staticmethod
    def _ensure_current_suwen_prompt(connection: sqlite3.Connection) -> None:
        """Install this release's immutable Markdown Prompt beside historical versions."""

        content = _suwen_core_prompt_content()
        digest = _digest(content)
        by_id = connection.execute(
            """SELECT prompt_bundle_id, version, digest FROM prompt_bundle_versions
               WHERE id=?""",
            (SUWEN_CORE_PROMPT_BUNDLE_VERSION_ID,),
        ).fetchone()
        if by_id:
            if (
                by_id["prompt_bundle_id"] != SUWEN_CORE_PROMPT_BUNDLE_ID
                or int(by_id["version"]) != SUWEN_CORE_PROMPT_BUNDLE_VERSION
                or by_id["digest"] != digest
            ):
                raise RuntimeError("bundled Suwen core Prompt identity conflicts with stored content")
            return
        version_conflict = connection.execute(
            """SELECT id, digest FROM prompt_bundle_versions
               WHERE prompt_bundle_id=? AND version=?""",
            (SUWEN_CORE_PROMPT_BUNDLE_ID, SUWEN_CORE_PROMPT_BUNDLE_VERSION),
        ).fetchone()
        if version_conflict:
            raise RuntimeError("bundled Suwen core Prompt version conflicts with stored content")

        at = _now()
        connection.execute("BEGIN IMMEDIATE")
        try:
            connection.execute(
                """INSERT OR IGNORE INTO prompt_bundles(
                   id, name, description, status, created_at, updated_at
                ) VALUES (?, 'Suwen Core', '领域无关的 Suwen Runtime 宿主提示词',
                          'active', ?, ?)""",
                (SUWEN_CORE_PROMPT_BUNDLE_ID, at, at),
            )
            connection.execute(
                """INSERT INTO prompt_bundle_versions(
                   id, prompt_bundle_id, version, content_json, digest, source_ref,
                   created_by, created_at
                ) VALUES (?, ?, ?, ?, ?, 'runtime:suwen-core@5-model-autonomy',
                          'system:release-resource', ?)""",
                (
                    SUWEN_CORE_PROMPT_BUNDLE_VERSION_ID,
                    SUWEN_CORE_PROMPT_BUNDLE_ID,
                    SUWEN_CORE_PROMPT_BUNDLE_VERSION,
                    json.dumps(content, ensure_ascii=False),
                    digest,
                    at,
                ),
            )
            connection.execute(
                "UPDATE prompt_bundles SET updated_at=? WHERE id=?",
                (at, SUWEN_CORE_PROMPT_BUNDLE_ID),
            )
            connection.execute(
                """INSERT INTO audit_events(
                   actor_type, actor_ref, action, target_type, target_id,
                   target_version, after_digest, result, metadata_json, created_at
                ) VALUES ('system', 'release-resource', 'prompt_bundle.version_installed',
                          'capability', ?, ?, ?, 'succeeded', '{}', ?)""",
                (
                    SUWEN_CORE_PROMPT_BUNDLE_ID,
                    str(SUWEN_CORE_PROMPT_BUNDLE_VERSION),
                    digest,
                    at,
                ),
            )
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise

    def _seed_runtime_control_plane(
        self,
        connection: sqlite3.Connection,
        at: str,
    ) -> None:
        """Seed domain-neutral Channel and Review control-plane records."""

        channels = [
            (
                "api-local",
                "api",
                "Local API",
                {"mode": "authenticated_or_loopback", "sender": "none"},
            ),
            (
                "console-capture",
                "console",
                "Isolated Console Capture",
                {"mode": "fixture", "sender": "capture", "formal_metrics": False},
            ),
        ]
        if self.enable_test_fixture_agent:
            channels.append((
                "app-fixture",
                "feishu",
                "Feishu Fixture Capture",
                {"mode": "fixture", "sender": "capture", "external_writes": 0},
            ))
        for instance_id, channel_type, name, config in channels:
            status = "active"
            health_state = "fixture_ready"
            config_json = json.dumps(config, ensure_ascii=False, sort_keys=True)
            connection.execute(
                """INSERT INTO channel_instances(
                   id, channel_type, name, status, config_json, revision,
                   health_state, validated_at, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, ?)""",
                (
                    instance_id,
                    channel_type,
                    name,
                    status,
                    config_json,
                    health_state,
                    at if status == "active" else None,
                    at,
                    at,
                ),
            )
            connection.execute(
                """INSERT INTO channel_instance_versions(
                   id, channel_instance_id, version, config_json, digest,
                   created_by, created_at
                ) VALUES (?, ?, 1, ?, ?, 'system:bootstrap', ?)""",
                (
                    f"channelver-{instance_id}-v1",
                    instance_id,
                    config_json,
                    _digest(config),
                    at,
                ),
            )
            if self.enable_test_fixture_agent:
                connection.execute(
                    """INSERT INTO agent_channel_bindings(
                       id, agent_id, channel_instance_id, policy_json,
                       active, created_at, updated_at
                    ) VALUES (?, ?, ?, '{}', 1, ?, ?)""",
                    (
                        f"agentchannel-{TEST_FIXTURE_AGENT_ID}-{instance_id}",
                        TEST_FIXTURE_AGENT_ID,
                        instance_id,
                        at,
                        at,
                    ),
                )

        review_config = {
            "input": "immutable case trace identifiers and structured states",
            "output": "bounded-review.v1",
            "uses_raw_message_content": True,
            "persists_raw_message_content": False,
            "model_calls": 0,
            "automatic_agent_mutation": False,
        }
        review_model_version = (
            TEST_FIXTURE_MODEL_PROFILE_VERSION_ID
            if self.enable_test_fixture_agent
            else KEYU_MTP_PROFILE_VERSION_ID
        )
        review_prompt_version = (
            TEST_FIXTURE_PROMPT_BUNDLE_VERSION_ID
            if self.enable_test_fixture_agent
            else SUWEN_CORE_PROMPT_BUNDLE_VERSION_ID
        )
        connection.execute(
            """INSERT INTO review_engine_profiles(
               id, name, status, active_version_id, created_at, updated_at
            ) VALUES (?, 'Deterministic bounded Review', 'active', ?, ?, ?)""",
            (REVIEW_ENGINE_PROFILE_ID, REVIEW_ENGINE_VERSION_ID, at, at),
        )
        connection.execute(
            """INSERT INTO review_engine_versions(
               id, review_engine_profile_id, version, status, engine_kind,
               algorithm_version, model_profile_version_id,
               prompt_bundle_version_id, config_json, digest, created_by, created_at
            ) VALUES (?, ?, 1, 'active', 'deterministic', 'bounded-review.v1',
                      ?, ?, ?, ?, 'system:bootstrap', ?)""",
            (
                REVIEW_ENGINE_VERSION_ID,
                REVIEW_ENGINE_PROFILE_ID,
                review_model_version,
                review_prompt_version,
                json.dumps(review_config, ensure_ascii=False, sort_keys=True),
                _digest(review_config),
                at,
            ),
        )
        connection.execute(
            """INSERT INTO audit_events(
               actor_type, actor_ref, action, target_type, target_id,
               target_version, result, metadata_json, created_at
            ) VALUES ('system', 'database', 'database.initialized', 'database',
                      'primary', ?, 'succeeded', ?, ?)""",
            (
                str(CURRENT_SCHEMA_VERSION),
                json.dumps({"baseline": DATABASE_BASELINE_ID}),
                at,
            ),
        )

    @staticmethod
    def _seed_test_fixture_configuration(
        connection: sqlite3.Connection,
        at: str,
    ) -> None:
        """Create one synthetic deterministic Agent only for isolated tests."""

        provider_config = {"protocol": "stub", "endpoint_ref": ""}
        model_config = {
            "model_id": "deterministic-diagnostician",
            "max_input_length": 80000,
            "max_output_tokens": 2000,
            "temperature": 0.2,
            "reasoning_effort": "high",
            "timeout_seconds": 60,
            "capabilities": {"tool_calling": True, "local": True},
            "routing": {"enabled": False},
        }
        prompt_content = {"kind": "test-fixture-default", "source": "runtime"}
        agent_config = {
            "schema": "suwen.agent-config.v1",
            "tags": ["测试夹具"],
            "max_tool_risk": "controlled_action",
            "tool_allowlist": ["find_artifact_text", "inspect_claim", "read_artifact_chunk"],
        }
        connection.execute(
            """INSERT OR IGNORE INTO model_providers(
               id, name, protocol, status, created_at, updated_at
            ) VALUES (?, 'Isolated deterministic test provider', 'stub', 'active', ?, ?)""",
            (TEST_FIXTURE_PROVIDER_ID, at, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO model_provider_versions(
               id, provider_id, version, endpoint_ref, config_json, digest,
               created_by, created_at
            ) VALUES (?, ?, 1, '', ?, ?, 'system:test-fixture', ?)""",
            (
                TEST_FIXTURE_PROVIDER_VERSION_ID,
                TEST_FIXTURE_PROVIDER_ID,
                json.dumps(provider_config),
                _digest(provider_config),
                at,
            ),
        )
        connection.execute(
            """INSERT OR IGNORE INTO model_profiles(
               id, provider_id, name, status, created_at, updated_at
            ) VALUES (?, ?, 'Isolated deterministic test model', 'active', ?, ?)""",
            (TEST_FIXTURE_MODEL_PROFILE_ID, TEST_FIXTURE_PROVIDER_ID, at, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO model_profile_versions(
               id, model_profile_id, version, provider_version_id, model_id,
               max_input_length, max_output_tokens, temperature, reasoning_effort,
               timeout_seconds,
               capabilities_json, routing_json, digest, created_by, created_at
            ) VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'system:test-fixture', ?)""",
            (
                TEST_FIXTURE_MODEL_PROFILE_VERSION_ID,
                TEST_FIXTURE_MODEL_PROFILE_ID,
                TEST_FIXTURE_PROVIDER_VERSION_ID,
                model_config["model_id"],
                model_config["max_input_length"],
                model_config["max_output_tokens"],
                model_config["temperature"],
                model_config["reasoning_effort"],
                model_config["timeout_seconds"],
                json.dumps(model_config["capabilities"]),
                json.dumps(model_config["routing"]),
                _digest(model_config),
                at,
            ),
        )
        connection.execute(
            """INSERT OR IGNORE INTO prompt_bundles(
               id, name, description, status, created_at, updated_at
            ) VALUES (?, 'Isolated test prompt', 'Test-only deterministic runtime prompt',
                      'active', ?, ?)""",
            (TEST_FIXTURE_PROMPT_BUNDLE_ID, at, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO prompt_bundle_versions(
               id, prompt_bundle_id, version, content_json, digest, source_ref,
               created_by, created_at
            ) VALUES (?, ?, 1, ?, ?, 'code:test-fixture-default',
                      'system:test-fixture', ?)""",
            (
                TEST_FIXTURE_PROMPT_BUNDLE_VERSION_ID,
                TEST_FIXTURE_PROMPT_BUNDLE_ID,
                json.dumps(prompt_content),
                _digest(prompt_content),
                at,
            ),
        )
        connection.execute(
            """INSERT OR IGNORE INTO agents(
               id, name, description, language, status, created_at, updated_at
            ) VALUES (?, 'Isolated Fixture Agent', 'Test-only deterministic Agent',
                      'zh-CN', 'published', ?, ?)""",
            (TEST_FIXTURE_AGENT_ID, at, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO agent_versions(
               id, agent_id, version, status, prompt_bundle_version_id,
               runtime_policy_json, context_policy_json,
               channel_policy_json, review_policy_json, presentation_policy_json,
               config_json, digest, created_by, created_at, published_at
            ) VALUES (?, ?, 1, 'published', ?, ?, '{}', '{}', '{}', '{}',
                      ?, ?, 'system:test-fixture', ?, ?)""",
            (
                TEST_FIXTURE_AGENT_VERSION_ID,
                TEST_FIXTURE_AGENT_ID,
                TEST_FIXTURE_PROMPT_BUNDLE_VERSION_ID,
                json.dumps(
                    {
                        "max_tool_calls": 12,
                        "max_tool_waves": 8,
                        "max_concurrency": 3,
                    }
                ),
                json.dumps(agent_config),
                _digest(agent_config),
                at,
                at,
            ),
        )
        connection.execute(
            """INSERT OR IGNORE INTO agent_version_packs(
               agent_version_id, pack_version_id, position, enabled
            ) VALUES (?, ?, 0, 1)""",
            (TEST_FIXTURE_AGENT_VERSION_ID, GENERIC_PACK_VERSION_ID),
        )
        connection.execute(
            "UPDATE agents SET active_version_id=? WHERE id=?",
            (TEST_FIXTURE_AGENT_VERSION_ID, TEST_FIXTURE_AGENT_ID),
        )
        connection.execute(
            """INSERT OR IGNORE INTO agent_model_bindings(
               agent_id, model_profile_id, revision, updated_by, updated_at
            ) VALUES (?, ?, 1, 'system:test-fixture', ?)""",
            (TEST_FIXTURE_AGENT_ID, TEST_FIXTURE_MODEL_PROFILE_ID, at),
        )
        connection.execute(
            """INSERT OR IGNORE INTO agent_persona_bindings(
               agent_id, persona_id, revision, updated_by, updated_at
            ) VALUES (?, ?, 1, 'system:test-fixture', ?)""",
            (TEST_FIXTURE_AGENT_ID, DEFAULT_PERSONA_ID, at),
        )
        connection.execute(
            """INSERT OR REPLACE INTO system_settings(
               key, value_json, version, updated_by, updated_at
            ) VALUES ('test_fixture_agent_id', ?, 1, 'system:test-fixture', ?)""",
            (json.dumps(TEST_FIXTURE_AGENT_ID), at),
        )

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        self._configure_connection(connection)
        try:
            yield connection
        finally:
            connection.close()

    @staticmethod
    def _configure_connection(connection: sqlite3.Connection) -> None:
        internal_request_id = f"op_{uuid.uuid4().hex}"
        connection.row_factory = sqlite3.Row
        connection.create_function(
            "trace_request_id",
            0,
            lambda: current_request_id() or internal_request_id,
        )
        connection.create_function("trace_authorization_source", 2, authorization_source)
        connection.create_function("trace_failure_class", 2, failure_class)
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=10000")

    def ready(self) -> bool:
        try:
            with self.connect() as connection:
                row = connection.execute("SELECT value FROM schema_meta WHERE key='version'").fetchone()
            return bool(row and int(row["value"]) == CURRENT_SCHEMA_VERSION)
        except (sqlite3.Error, TypeError, ValueError):
            return False

    def check(self) -> dict[str, Any]:
        if not self.path.exists():
            return {
                "schema_version": None,
                "expected_schema_version": CURRENT_SCHEMA_VERSION,
                "quick_check": "not_run",
                "foreign_key_violations": None,
                "counts": {},
                "ready": False,
                "error": "database does not exist",
            }
        with self.connect() as connection:
            try:
                version = self._schema_version(connection)
            except (RuntimeError, sqlite3.Error) as exc:
                return {
                    "schema_version": None,
                    "expected_schema_version": CURRENT_SCHEMA_VERSION,
                    "quick_check": "not_run",
                    "foreign_key_violations": None,
                    "counts": {},
                    "ready": False,
                    "error": str(exc),
                }
            quick_check = connection.execute("PRAGMA quick_check").fetchone()[0]
            foreign_key_rows = connection.execute("PRAGMA foreign_key_check").fetchall()
            counts: dict[str, int] = {}
            for table in ("agents", "agent_versions", "model_profiles", "cases", "runs", "audit_events"):
                if self._table_exists(connection, table):
                    counts[table] = connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        return {
            "schema_version": version,
            "expected_schema_version": CURRENT_SCHEMA_VERSION,
            "quick_check": quick_check,
            "foreign_key_violations": len(foreign_key_rows),
            "counts": counts,
            "ready": (version == CURRENT_SCHEMA_VERSION and quick_check == "ok" and not foreign_key_rows),
        }

    def backup(self, destination: str | Path) -> Path:
        target = Path(destination)
        if not self.path.is_file():
            raise FileNotFoundError(self.path)
        if target.exists():
            raise FileExistsError(target)
        if target.resolve() == self.path.resolve():
            raise ValueError("backup destination must differ from database path")
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        try:
            target.parent.chmod(0o700)
        except OSError:
            pass
        partial = target.with_name(f".{target.name}.partial-{os.getpid()}")
        if partial.exists():
            raise FileExistsError(partial)
        try:
            with self.connect() as source:
                checkpoint = source.execute("PRAGMA wal_checkpoint(PASSIVE)").fetchone()
                if checkpoint and int(checkpoint[0]) != 0:
                    raise RuntimeError("database WAL checkpoint could not complete before backup")
                destination_connection = sqlite3.connect(partial)
                try:
                    source.backup(destination_connection)
                finally:
                    destination_connection.close()
            partial.chmod(0o600)
            partial.replace(target)
            target.chmod(0o600)
        except BaseException:
            partial.unlink(missing_ok=True)
            raise
        return target
