from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import ipaddress
import json
import os
import sqlite3
import time
import uuid
from collections import deque
from collections.abc import Callable
from contextlib import asynccontextmanager
from dataclasses import replace
from datetime import UTC, datetime, timedelta
from typing import Any, Literal
from urllib.parse import urlsplit

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import AwareDatetime, BaseModel, ConfigDict, Field

from .acceptance import DeliveryPreflight
from .actions import ActionService
from .agent_profiles import AgentProfileRegistry
from .agent_registry import AgentRegistry, AgentValidationError
from .artifacts import ArtifactStore
from .audit_context import bind_audit_context, current_request_id, request_id_from_header
from .candidate import CandidateRegistry, CandidateRunner
from .capability_installations import NativeReleaseManager
from .capability_packages import CapabilityPackageRegistry
from .capability_registry import CapabilityRegistry
from .case_history import register_case_recall_tool
from .cases import CaseService, InboundEventInProgress, InboundNotAdmitted
from .channel_configuration import FeishuChannelConfigurator, FeishuConfigurationError
from .channel_registry import ChannelRegistry, ChannelResolutionError
from .channels import ChannelDrop, FeishuAdapter, FeishuMediaDownloader
from .config import Settings, load_settings
from .db import SUWEN_AGENT_ID, Database
from .deployment import (
    ACTIVATION_SCHEMA_VERSION,
    ReleaseManager,
    RuntimeLayout,
    loaded_release_name,
)
from .diagram import DiagramRenderer
from .external_dependencies import ExternalDependencyError, ExternalDependencyManager
from .feishu_long_connection import FeishuCredentialProbe, FeishuLongConnectionSupervisor
from .health_protocol import health_identity
from .image_text import ImageTextExtractor
from .management_acceptance import management_e2e_template, management_web_asset_digest
from .model_registry import ModelCatalogDiscoveryError, ModelRegistry
from .operations import OperationsView
from .outbox import ChannelSenderRouter, OutboxDispatcher, build_sender
from .packs import (
    PackInspection,
    PackRegistry,
    bundled_investigation_glossary,
    bundled_investigation_glossary_assets_root,
    bundled_web_root,
)
from .personas import DEFAULT_PERSONA_ID, list_personas
from .process_manager import observe_process_manager
from .release import SUWEN_RELEASE_VERSION, __version__
from .repository import Repository, iso
from .research import ResearchService, ReviewEngineRegistry
from .review import LifecycleService, ReviewEngine
from .runtime import RuntimeHarness, RuntimeResolver
from .scheduler import Scheduler
from .service import DiagnosticService
from .tool_provider_registry import ToolProviderRegistry
from .tools import PolicyError, ToolRegistry, is_system_required_tool
from .types import EvidenceState, InboundAttachment, InboundContext, InboundEvent

MANAGEMENT_SESSION_COOKIE = "suwen_management_session"
MANAGEMENT_SESSION_TTL_SECONDS = 30 * 24 * 60 * 60
INBOUND_ENVELOPE_SCHEMA = "suwen.inbound-envelope.v1"
INBOUND_PREPARATION_LEASE_SECONDS = 20 * 60
INBOUND_PREPARATION_MAX_ATTEMPTS = 3
_PERSISTED_REPLY_ADDRESS_KEYS = frozenset(
    {
        "chat_id",
        "channel_instance",
        "thread_id",
        "reply_to",
        "parent_id",
        "root_id",
        "mentioned_bot",
        "require_mention_in_group",
        "parent_refs",
        "channel_revision",
        "channel_transport_identity",
    }
)


def _management_session_value(role: str, token: str, expires_at: int) -> str:
    payload = f"v1.{role}.{expires_at}"
    signature = hmac.new(token.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).digest()
    encoded_signature = base64.urlsafe_b64encode(signature).decode("ascii").rstrip("=")
    return f"{payload}.{encoded_signature}"


def _management_session_matches(
    value: str,
    role: str,
    token: str,
    *,
    observed_at: int,
) -> bool:
    if not value or len(value) > 512:
        return False
    parts = value.split(".")
    if len(parts) != 4 or parts[0] != "v1" or parts[1] != role:
        return False
    try:
        expires_at = int(parts[2])
    except ValueError:
        return False
    if expires_at <= observed_at:
        return False
    expected = _management_session_value(role, token, expires_at)
    return hmac.compare_digest(value, expected)


class StrictRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")


class RuntimeActivationInput(StrictRequest):
    activation_id: str = Field(min_length=12, max_length=100)
    target_release: str = Field(min_length=1, max_length=200)


class MessageInput(StrictRequest):
    content: str = Field(min_length=1, max_length=50_000)
    image_artifact_ids: tuple[str, ...] = Field(default=(), max_length=4)


class CaseCreate(StrictRequest):
    content: str | None = Field(default=None, min_length=1, max_length=50_000)
    agent_id: str | None = None
    occurred_at: AwareDatetime | None = None


class ReviewDecision(StrictRequest):
    decision: str
    note: str = Field(default="", max_length=5000)


class ReviewEngineVersionCreate(StrictRequest):
    config: dict[str, Any] = Field(default_factory=dict)


class ResearchGenerate(StrictRequest):
    agent_id: str


class ResearchDecision(StrictRequest):
    decision: str
    note: str = Field(default="", max_length=5000)


class CandidateDecision(StrictRequest):
    decision: str


class CandidateHumanReview(StrictRequest):
    decision: str
    scorecard_digest: str = Field(min_length=64, max_length=64, pattern=r"^[0-9a-f]{64}$")
    episode_dimensions: dict[str, dict[str, str]]
    skill_influence_observed: dict[str, bool]
    tool_influence_observed: dict[str, bool | None]
    influence_notes: dict[str, str]
    note: str = Field(default="", max_length=5000)


class ActionPrepare(StrictRequest):
    tool_name: str
    arguments: dict[str, Any] = Field(default_factory=dict)


class ActionConfirm(StrictRequest):
    confirmation: str


class FeedbackInput(StrictRequest):
    value: str
    note: str = Field(default="", max_length=5000)


class ManagementE2EObservationInput(StrictRequest):
    schema_version: str
    agent_id: str
    runner: str
    base_url: str = Field(min_length=1, max_length=500)
    process_instance_id: str = Field(min_length=1, max_length=200)
    process_started_at: str = Field(min_length=1, max_length=100)
    management_asset_digest: str = Field(
        min_length=64,
        max_length=64,
        pattern=r"^[0-9a-f]{64}$",
    )
    started_at: str = Field(min_length=1, max_length=100)
    finished_at: str = Field(min_length=1, max_length=100)
    checks: dict[str, str]
    external_writes: int
    secret_values_included: bool


class SecretRefCreate(StrictRequest):
    id: str
    name: str = Field(min_length=1, max_length=200)
    env_name: str


class ProviderCreate(StrictRequest):
    id: str
    name: str = Field(min_length=1, max_length=200)
    protocol: str
    endpoint: str = Field(min_length=1, max_length=2000)
    api_key: str | None = Field(default=None, max_length=65536)
    status: str = "draft"


class ProviderVersionCreate(StrictRequest):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    protocol: str | None = None
    endpoint: str = Field(min_length=1, max_length=2000)
    api_key: str | None = Field(default=None, max_length=65536)


class ModelCapabilitiesInput(StrictRequest):
    tool_calling: bool
    vision: bool
    structured_output: bool
    local: bool


class ProfileCreate(StrictRequest):
    id: str
    provider_id: str
    name: str = Field(min_length=1, max_length=200)
    model_id: str = Field(min_length=1, max_length=200)
    max_input_length: int
    max_output_tokens: int
    temperature: float
    reasoning_effort: Literal["none", "low", "medium", "high", "xhigh", "max"] = "high"
    timeout_seconds: float
    capabilities: ModelCapabilitiesInput
    routing: dict[str, Any] = Field(default_factory=lambda: {"fallback": False})
    provider_version_id: str | None = None


class ProfileVersionCreate(StrictRequest):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    model_id: str = Field(min_length=1, max_length=200)
    max_input_length: int
    max_output_tokens: int
    temperature: float
    reasoning_effort: Literal["none", "low", "medium", "high", "xhigh", "max"] = "high"
    timeout_seconds: float
    capabilities: ModelCapabilitiesInput
    routing: dict[str, Any] = Field(default_factory=lambda: {"fallback": False})
    provider_id: str | None = None
    provider_version_id: str | None = None


class AgentProfileRef(StrictRequest):
    id: str = Field(min_length=2, max_length=64, pattern=r"^[a-z][a-z0-9-]{1,63}$")
    version: str = Field(min_length=5, max_length=100)
    digest: str = Field(min_length=64, max_length=64, pattern=r"^[0-9a-f]{64}$")


class CapabilityBindingInput(StrictRequest):
    capability_version_id: str = Field(min_length=1, max_length=200)
    role: Literal["tools", "domain"]
    position: int = Field(default=0, ge=0)


class AgentProfileApplyInput(StrictRequest):
    profile: AgentProfileRef
    expected_draft_digest: str | None = Field(
        default=None,
        min_length=64,
        max_length=64,
        pattern=r"^[0-9a-f]{64}$",
    )


class NativeReleaseInstallInput(StrictRequest):
    artifact_digest: str = Field(min_length=64, max_length=64, pattern=r"^[0-9a-f]{64}$")
    trust_code: bool = False


class MarkdownDomainSkillReferenceUpsert(StrictRequest):
    id: str = Field(min_length=2, max_length=64, pattern=r"^[a-z][a-z0-9-]{1,63}$")
    title: str = Field(min_length=1, max_length=240)
    description: str = Field(min_length=1, max_length=1000)
    content: str = Field(min_length=1, max_length=100_000)
    source_url: str = Field(min_length=1, max_length=2000)
    source_revision: str = Field(min_length=1, max_length=500)
    source_updated: str = Field(min_length=1, max_length=100)


class MarkdownDomainSkillUpsert(StrictRequest):
    version: str = Field(pattern=r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?$")
    capability_name: str = Field(min_length=1, max_length=200)
    skill_id: str = Field(min_length=2, max_length=64, pattern=r"^[a-z][a-z0-9-]{1,63}$")
    skill_name: str = Field(min_length=1, max_length=200)
    description: str = Field(min_length=1, max_length=5000)
    applicability: str = Field(min_length=1, max_length=5000)
    instructions: str = Field(min_length=1, max_length=30_000)
    source_url: str = Field(min_length=1, max_length=2000)
    source_revision: str = Field(min_length=1, max_length=500)
    source_updated: str = Field(min_length=1, max_length=100)
    references: list[MarkdownDomainSkillReferenceUpsert] = Field(
        default_factory=list,
        max_length=8,
    )
    agent_id: str | None = Field(default=None, min_length=1, max_length=200)
    publish_agent: bool = False
    probe_model_if_needed: bool = False
    note: str = Field(default="", max_length=1000)


class ExternalCliPreviewInput(StrictRequest):
    dependency_id: str = Field(min_length=2, max_length=64)
    contract: str = Field(min_length=1, max_length=100)
    command: str = Field(min_length=1, max_length=2000)
    version_arguments: list[str] = Field(default_factory=lambda: ["--version"], max_length=16)


class ExternalCliConfigureInput(ExternalCliPreviewInput):
    allowed_subcommands: list[str] = Field(min_length=1, max_length=64)
    timeout_seconds: float = Field(default=30.0, gt=0, le=300)
    max_output_bytes: int = Field(default=128 * 1024, ge=1, le=2 * 1024 * 1024)


class ExternalCliDisableInput(StrictRequest):
    dependency_id: str = Field(min_length=2, max_length=64)
    contract: str = Field(min_length=1, max_length=100)


class AgentCreate(StrictRequest):
    id: str
    name: str = Field(min_length=1, max_length=200)
    agent_profile: AgentProfileRef | None = None
    description: str = Field(default="", max_length=5000)
    language: str = Field(default="zh-CN", max_length=32)
    model_profile_id: str
    persona_id: str = DEFAULT_PERSONA_ID
    prompt_bundle_version_id: str | None = None
    runtime_policy: dict[str, Any] | None = None
    context_policy: dict[str, Any] | None = None
    channel_policy: dict[str, Any] | None = None
    review_policy: dict[str, Any] | None = None
    presentation_policy: dict[str, Any] | None = None
    config: dict[str, Any] | None = None
    pack_version_ids: list[str] | None = None
    capability_bindings: list[CapabilityBindingInput] | None = None


class AgentDraftUpdate(StrictRequest):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    description: str | None = Field(default=None, max_length=5000)
    language: str | None = Field(default=None, max_length=32)
    prompt_bundle_version_id: str | None = None
    runtime_policy: dict[str, Any] | None = None
    context_policy: dict[str, Any] | None = None
    channel_policy: dict[str, Any] | None = None
    review_policy: dict[str, Any] | None = None
    presentation_policy: dict[str, Any] | None = None
    config: dict[str, Any] | None = None
    pack_version_ids: list[str] | None = None
    capability_bindings: list[CapabilityBindingInput] | None = None


class AgentCurrentModelUpdate(StrictRequest):
    model_profile_id: str


class AgentCurrentPersonaUpdate(StrictRequest):
    persona_id: str


class PublishInput(StrictRequest):
    note: str = Field(default="", max_length=1000)


class RollbackInput(StrictRequest):
    target_version_id: str
    note: str = Field(default="", max_length=1000)


class CloneInput(StrictRequest):
    id: str
    name: str = Field(min_length=1, max_length=200)


class AgentStatusInput(StrictRequest):
    status: str


class ModelStatusInput(StrictRequest):
    status: str


class DefaultAgentInput(StrictRequest):
    agent_id: str


class CaseVersionPinInput(StrictRequest):
    agent_version_id: str | None = None


class PackStatusInput(StrictRequest):
    status: str
    reason: str = Field(default="", max_length=2000)
    replacement_pack_version_id: str | None = None


class PackSelectionInput(StrictRequest):
    id: str = Field(min_length=2, max_length=64)
    version: str = Field(min_length=1, max_length=100)
    content_digest: str = Field(min_length=64, max_length=64, pattern=r"^[0-9a-f]{64}$")


class PromptBundleCreate(StrictRequest):
    id: str
    name: str = Field(min_length=1, max_length=200)
    description: str = Field(default="", max_length=5000)
    content: dict[str, Any]
    source_ref: str = Field(default="admin", max_length=1000)


class PromptVersionCreate(StrictRequest):
    content: dict[str, Any]
    source_ref: str = Field(default="admin", max_length=1000)


class PromptStatusInput(StrictRequest):
    status: str


class ToolProviderCreate(StrictRequest):
    id: str
    name: str = Field(min_length=1, max_length=200)
    provider_type: str
    connection_ref: str = Field(default="", max_length=2000)
    secret_ref_id: str | None = None


class ToolSchemaCreate(StrictRequest):
    schema_definition: list[dict[str, Any]]


class ToolProviderStatusInput(StrictRequest):
    status: str


class ToolProviderStdioConfigInput(StrictRequest):
    command: list[str]
    cwd: str
    environment: dict[str, str] = Field(default_factory=dict)
    secret_env: str | None = None
    secret_ref_id: str | None = None
    timeout_seconds: float = 30.0


class ToolProviderHTTPConfigInput(StrictRequest):
    endpoint: str = Field(min_length=1, max_length=2000)
    timeout_seconds: float = 30.0
    max_response_bytes: int = 2 * 1024 * 1024


class ToolProviderConnectInput(StrictRequest):
    pass


class ChannelInstanceCreate(StrictRequest):
    id: str
    channel_type: str
    name: str = Field(min_length=1, max_length=200)
    config: dict[str, Any] = Field(default_factory=dict)
    secret_bindings: dict[str, str] = Field(default_factory=dict)


class ChannelInstanceVersionCreate(StrictRequest):
    config: dict[str, Any] = Field(default_factory=dict)
    secret_bindings: dict[str, str] = Field(default_factory=dict)


class ChannelInstanceRename(StrictRequest):
    name: str


class ChannelStatusChange(StrictRequest):
    status: str


class ChannelAgentBindingCreate(StrictRequest):
    agent_id: str
    policy: dict[str, Any] = Field(default_factory=dict)


class FeishuConfigurationPut(StrictRequest):
    name: str = Field(min_length=1, max_length=80)
    agent_id: str | None = None
    enabled: bool
    domain: str = Field(pattern=r"^(feishu|lark)$")
    app_id: str = Field(min_length=1, max_length=500)
    app_secret: str | None = Field(default=None, max_length=64 * 1024)
    verification_token: str | None = Field(default=None, max_length=64 * 1024)
    encrypt_key: str | None = Field(default=None, max_length=64 * 1024)
    require_mention_in_group: bool = True
    allowed_actor_refs: str = Field(default="", max_length=10_000)
    allowed_chat_refs: str = Field(default="", max_length=10_000)


class AppState:
    def __init__(self, settings: Settings):
        self.settings = settings
        configured_home = os.getenv("SUWEN_HOME")
        self.runtime_layout = RuntimeLayout.resolve(configured_home) if configured_home else None
        self.loaded_release = (
            loaded_release_name(self.runtime_layout) if self.runtime_layout is not None else None
        )
        self.shutdown_callback: Callable[[], None] | None = None
        self.activation_handoff_task: asyncio.Task[None] | None = None
        self.activation_handoff_error: str | None = None
        self._inbound_preparation_tasks: set[asyncio.Task[bool]] = set()
        glossary_assets = bundled_investigation_glossary_assets_root()
        self.management_asset_digest = management_web_asset_digest(
            bundled_web_root(),
            (
                bundled_investigation_glossary(),
                glossary_assets / "suwen-overall-concept.png",
                glossary_assets / "suwen-entity-relationships.png",
            ),
        )
        self.process_instance_id = f"instance-{uuid.uuid4().hex}"
        self.process_started_at = iso()
        self.process_manager = observe_process_manager(
            settings.process_manager,
            settings.process_manager_label,
        )
        management_tokens = {
            "admin": settings.admin_token,
            "operator": settings.operator_token,
            "reviewer": settings.reviewer_token,
            "viewer": settings.viewer_token,
        }
        configured_management_tokens = {role: value for role, value in management_tokens.items() if value}
        if configured_management_tokens and not settings.admin_token:
            raise ValueError("配置管理角色令牌时必须同时配置管理员令牌")
        all_tokens = [
            value for value in [settings.api_token, *configured_management_tokens.values()] if value
        ]
        if len(all_tokens) != len(set(all_tokens)):
            raise ValueError("运行接口与管理角色必须使用互不相同的访问令牌")
        if settings.feishu.enabled and not (
            settings.feishu.verification_token
            or settings.feishu.encrypt_key
            or settings.feishu.allow_unverified_fixture_events
        ):
            raise ValueError("enabled Feishu adapter requires verification configuration")
        if settings.runtime_mode == "development" and settings.feishu.enabled:
            raise ValueError("development runtime cannot enable the Feishu adapter")
        self.database = Database(
            settings.database_path,
            enable_test_fixture_agent=settings.enable_test_fixture_agent,
        )
        self.database.initialize()
        self.repository = Repository(self.database)
        self.model_registry = ModelRegistry(self.database)
        self.candidates = CandidateRegistry(self.database)
        self.candidate_runner = CandidateRunner(
            settings,
            database=self.database,
            initialize_database=False,
        )
        self.operations = OperationsView(self.database, settings.data_dir)
        self.channel_registry = ChannelRegistry(
            self.database,
            self.model_registry.secrets,
            allow_fixture_ingress=settings.feishu.allow_unverified_fixture_events,
            runtime_mode=settings.runtime_mode,
        )
        self.artifacts = ArtifactStore(
            self.repository,
            settings.data_dir,
            settings.artifacts.max_bytes,
            settings.artifacts.retention_hours,
        )
        self.image_text = ImageTextExtractor()
        self.tools = ToolRegistry()
        self.artifacts.register_continuation_tool(self.tools)
        self.diagram_renderer = DiagramRenderer(self.artifacts, settings.data_dir)
        self.diagram_renderer.register_tool(self.tools)
        register_case_recall_tool(self.repository, self.tools)
        installed_pack_digests = self.database.installed_pack_digests()
        self.packs = PackRegistry.load(
            settings.packs_dir,
            self.tools,
            trusted_local_pack_refs=settings.trusted_local_pack_refs,
            allowed_pack_refs=installed_pack_digests,
            expected_digests=installed_pack_digests,
        )
        self.skills = self.packs.skills
        self.skills.register_reference_tools(self.tools)
        self.capability_packages = CapabilityPackageRegistry(
            self.database,
            settings.data_dir / "capability-packages",
        )
        self.external_dependencies = ExternalDependencyManager(self.database)
        self.capability_packages.set_external_dependency_manager(self.external_dependencies)
        self.native_releases = NativeReleaseManager(
            self.database,
            settings.data_dir / "native-releases",
            self.capability_packages,
        )
        self.agent_profiles = AgentProfileRegistry(
            self.database,
            self.packs,
            self.tools,
            self.capability_packages,
            installed_root=self.native_releases.installation_root / "agent-profile",
        )
        self.capabilities = CapabilityRegistry(self.database, self.packs, self.tools)
        self.capabilities.sync_loaded_catalog()
        self.tool_providers = ToolProviderRegistry(
            self.database,
            self.tools,
            self.model_registry.secrets,
        )
        self.tool_providers.sync_loaded_catalog(self.packs.tool_provider_types())
        self.agent_registry = AgentRegistry(
            self.database,
            self.model_registry,
            self.packs,
            self.tools,
            self.capability_packages,
            self.agent_profiles,
        )
        self.repository.recover_interrupted_runs()
        self.repository.recover_interrupted_actions()
        self.repository.recover_running_jobs("prepare_inbound")
        self.repository.recover_incomplete_inbound_events()
        self.repository.recover_running_jobs("process_inbound")
        self.actions = ActionService(
            self.repository,
            self.tools,
            settings.actions.confirmation_ttl_seconds,
        )
        self.actions.expire_pending()
        self.runtime_resolver = RuntimeResolver(
            self.database,
            self.model_registry,
            settings.harness,
            self.packs,
            self.tools,
            self.capability_packages,
        )
        self.harness = RuntimeHarness(
            self.repository,
            self.runtime_resolver,
            self.actions,
            self.artifacts,
            connector_catalogs=self.tool_providers,
        )
        self.cases = CaseService(self.repository, self.artifacts)
        self.service = DiagnosticService(
            self.repository,
            self.cases,
            self.harness,
            settings.lifecycle.review_delay_seconds,
            self.artifacts,
        )
        self.reviews = ReviewEngine(self.repository)
        self.review_engines = ReviewEngineRegistry(self.database)
        self.research = ResearchService(self.database)
        self.lifecycle = LifecycleService(self.repository, settings.lifecycle.inactive_days)
        self.service.set_action_service(self.actions)
        self.feishu = FeishuAdapter(settings.feishu)
        artifact_reader = self.artifacts.read_content
        self.sender = ChannelSenderRouter(
            self.channel_registry,
            build_sender(settings.feishu, artifact_reader=artifact_reader),
            artifact_reader=artifact_reader,
        )
        self.outbox = OutboxDispatcher(self.repository, self.sender)
        self.service.set_outbox_dispatcher(self.outbox)
        self.scheduler = Scheduler(
            self.repository,
            self.reviews,
            self.lifecycle,
            self.cleanup_private_data,
            self.outbox,
            settings.scheduler.poll_seconds,
            settings.scheduler.lease_seconds,
            process_inbound=self.service.process_inbound_job,
            prepare_inbound=self.prepare_inbound_job,
        )
        self.feishu_probe = FeishuCredentialProbe()
        self.feishu_long_connections = FeishuLongConnectionSupervisor(
            self.channel_registry,
            self.handle_long_connection_event,
        )
        self.feishu_channel_configurator = FeishuChannelConfigurator(
            self.channel_registry,
            self.model_registry,
            self.feishu_probe,
            self.feishu_long_connections,
        )
        self.delivery_preflight = DeliveryPreflight(
            self.database,
            self.model_registry,
            self.capabilities,
            self.capability_packages,
            self.candidate_runner,
            self.operations,
            settings,
            self.management_asset_digest,
        )

    async def add_feishu_lifecycle_reaction(self, event: Any, emoji_type: str) -> bool:
        """Apply deterministic channel feedback without involving the model."""

        address = event.reply_address
        message_id = str(address.get("reply_to") or "")
        if not message_id:
            return False
        return await self.sender.add_reaction(
            "feishu",
            address,
            message_id,
            emoji_type,
        )

    @staticmethod
    def _inbound_event_key(event: InboundEvent) -> str:
        return f"{event.channel}:{event.channel_instance}:{event.event_id}"

    @staticmethod
    def _serialize_inbound_envelope(event: InboundEvent) -> dict[str, Any]:
        if event.contexts or any(item.content is not None for item in event.attachments):
            raise ValueError("durable inbound envelope must precede resource materialization")
        reply_address = {
            key: value for key, value in event.reply_address.items() if key in _PERSISTED_REPLY_ADDRESS_KEYS
        }
        # Round-trip once so unsupported or accidental secret-bearing objects
        # cannot cross the transport acknowledgement boundary.
        reply_address = json.loads(json.dumps(reply_address, ensure_ascii=False))
        return {
            "schema": INBOUND_ENVELOPE_SCHEMA,
            "event": {
                "event_id": event.event_id,
                "channel": event.channel,
                "channel_instance": event.channel_instance,
                "scope_kind": event.scope_kind,
                "scope_ref": event.scope_ref,
                "actor_ref": event.actor_ref,
                "content": event.content,
                "occurred_at": event.occurred_at,
                "agent_id": event.agent_id,
                "parent_event_ref": event.parent_event_ref,
                "reply_address": reply_address,
                "command": event.command,
                "attachments": [
                    {
                        "kind": item.kind,
                        "external_ref": item.external_ref,
                        "media_type": item.media_type,
                    }
                    for item in event.attachments
                ],
            },
        }

    @staticmethod
    def _deserialize_inbound_envelope(payload: dict[str, Any]) -> InboundEvent:
        if payload.get("schema") != INBOUND_ENVELOPE_SCHEMA:
            raise ValueError("unsupported durable inbound envelope")
        item = payload.get("event")
        if not isinstance(item, dict):
            raise ValueError("durable inbound envelope lacks its event")
        reply_address = item.get("reply_address")
        if not isinstance(reply_address, dict):
            raise ValueError("durable inbound envelope has an invalid reply address")
        raw_attachments = item.get("attachments") or []
        if not isinstance(raw_attachments, list):
            raise ValueError("durable inbound envelope has invalid attachments")
        attachments = tuple(
            InboundAttachment(
                kind=str(attachment["kind"]),
                external_ref=str(attachment["external_ref"]),
                media_type=(
                    str(attachment["media_type"]) if attachment.get("media_type") is not None else None
                ),
            )
            for attachment in raw_attachments
            if isinstance(attachment, dict)
        )
        return InboundEvent(
            event_id=str(item["event_id"]),
            channel=str(item["channel"]),
            channel_instance=str(item["channel_instance"]),
            scope_kind=str(item["scope_kind"]),
            scope_ref=str(item["scope_ref"]),
            actor_ref=str(item["actor_ref"]),
            content=str(item["content"]),
            occurred_at=str(item["occurred_at"]),
            agent_id=str(item["agent_id"]),
            parent_event_ref=(str(item["parent_event_ref"]) if item.get("parent_event_ref") else None),
            reply_address=reply_address,
            command=str(item["command"]) if item.get("command") else None,
            attachments=attachments,
        )

    def _start_inbound_preparation(self, job: dict[str, Any]) -> None:
        payload = json.loads(str(job["payload_json"]))
        task = asyncio.create_task(
            self.prepare_inbound_job(job, payload),
            name=f"suwen-prepare-inbound-{job['id']}",
        )
        self._inbound_preparation_tasks.add(task)

        def consume(completed: asyncio.Task[bool]) -> None:
            self._inbound_preparation_tasks.discard(completed)
            if not completed.cancelled():
                completed.exception()

        task.add_done_callback(consume)

    async def wait_for_inbound_preparations(self) -> None:
        while self._inbound_preparation_tasks:
            await asyncio.gather(
                *tuple(self._inbound_preparation_tasks),
                return_exceptions=True,
            )

    async def prepare_inbound_job(
        self,
        job: dict[str, Any],
        payload: dict[str, Any],
    ) -> bool:
        """Materialize one already durable Channel envelope and enter the Case core."""

        stored = self.repository.job_for_unique_key(str(job["unique_key"]))
        if stored is None or stored["status"] == "completed":
            return True
        job = stored
        event = self._deserialize_inbound_envelope(payload)
        event_key = self._inbound_event_key(event)
        if self.service.availability_state["draining"]:
            self.repository.defer_job(
                str(job["id"]),
                due_at=datetime.now(UTC) + timedelta(seconds=2),
                reason="runtime_draining",
            )
            return False
        self.repository.extend_job_lease(
            str(job["id"]),
            datetime.now(UTC) + timedelta(seconds=INBOUND_PREPARATION_LEASE_SECONDS),
        )
        self.repository.mark_inbound_materializing(event_key)
        try:
            runtime_config = self.channel_registry.resolve_feishu_runtime(event.channel_instance)
            if runtime_config.mode != "long_connection":
                raise ChannelDrop("channel_transport_mismatch")
            frozen_transport = str(event.reply_address.get("channel_transport_identity") or "")
            if frozen_transport and frozen_transport != runtime_config.transport_identity:
                raise ChannelDrop("channel_transport_identity_changed")
            event = await self.materialize_feishu_resources(event, runtime_config)
            await self.service.handle_inbound(
                event,
                on_admitted=lambda admitted: self.add_feishu_lifecycle_reaction(
                    admitted,
                    "Typing",
                ),
                preclaimed=True,
            )
        except asyncio.CancelledError:
            self.repository.defer_job(
                str(job["id"]),
                due_at=datetime.now(UTC) + timedelta(seconds=2),
                reason="process_shutdown",
            )
            raise
        except Exception as exc:
            reason = f"{type(exc).__name__}: {exc}"[:1000]
            attempts = int(job.get("attempts") or 0)
            if attempts < INBOUND_PREPARATION_MAX_ATTEMPTS:
                self.repository.defer_job(
                    str(job["id"]),
                    due_at=datetime.now(UTC) + timedelta(seconds=min(30, 2**attempts)),
                    reason=reason,
                )
                return False
            self.repository.terminalize_inbound_preparation(
                str(job["id"]),
                event_key,
                reason,
            )
            self.channel_registry.record_ingress(
                event.channel_instance,
                event.event_id,
                "failed",
                type(exc).__name__,
            )
            return True
        self.repository.complete_inbound_preparation(str(job["id"]), event_key)
        return True

    async def materialize_feishu_resources(
        self,
        event: Any,
        runtime_config: Any,
    ) -> Any:
        parent_ref = self._unseen_feishu_parent_ref(event)
        if not event.attachments and not parent_ref:
            return event
        message_id = str(event.reply_address.get("reply_to") or "")
        items: list[InboundAttachment] = []
        contexts = list(event.contexts)
        try:
            downloader = FeishuMediaDownloader(runtime_config)
        except Exception as exc:
            if event.attachments:
                raise ChannelDrop("image_download_failed") from exc
            contexts.append(
                InboundContext(
                    kind="replied_message",
                    external_ref=str(parent_ref),
                    content="",
                    state=EvidenceState.NOT_OBSERVABLE,
                    limitations=("replied_message_read_failed",),
                )
            )
            return replace(event, contexts=tuple(contexts))
        try:
            for attachment in event.attachments:
                try:
                    items.append(
                        await downloader.download_image(
                            message_id,
                            attachment.external_ref,
                            max_bytes=self.settings.artifacts.max_bytes,
                        )
                    )
                except Exception as exc:
                    raise ChannelDrop("image_download_failed") from exc
            if parent_ref:
                try:
                    context = await downloader.read_message_context(parent_ref)
                except Exception:
                    contexts.append(
                        InboundContext(
                            kind="replied_message",
                            external_ref=parent_ref,
                            content="",
                            state=EvidenceState.NOT_OBSERVABLE,
                            limitations=("replied_message_read_failed",),
                        )
                    )
                else:
                    context_images: list[InboundAttachment] = []
                    limitations = list(context.limitations)
                    for attachment in context.attachments:
                        try:
                            context_images.append(
                                await downloader.download_image(
                                    parent_ref,
                                    attachment.external_ref,
                                    max_bytes=self.settings.artifacts.max_bytes,
                                )
                            )
                        except Exception:
                            limitations.append("replied_message_image_download_failed")
                    state = context.state
                    if context.attachments and not context_images and not context.content.strip():
                        state = EvidenceState.NOT_OBSERVABLE
                    contexts.append(
                        replace(
                            context,
                            state=state,
                            limitations=tuple(dict.fromkeys(limitations)),
                            attachments=tuple(context_images),
                        )
                    )
        finally:
            await downloader.close()

        if not self._agent_model_vision_ready(event.agent_id):
            items = list(await asyncio.gather(*(self._ocr_attachment(item) for item in items)))
            contexts = [
                replace(
                    context,
                    attachments=tuple(
                        await asyncio.gather(*(self._ocr_attachment(item) for item in context.attachments))
                    ),
                )
                if context.attachments
                else context
                for context in contexts
            ]
        return replace(event, attachments=tuple(items), contexts=tuple(contexts))

    def _unseen_feishu_parent_ref(self, event: Any) -> str | None:
        if event.command is not None:
            return None
        current_ref = str(event.reply_address.get("reply_to") or "")
        parent_ref = str(event.reply_address.get("parent_id") or "")
        if not parent_ref:
            root_ref = str(event.reply_address.get("root_id") or "")
            if root_ref and root_ref != current_ref:
                parent_ref = root_ref
        if not parent_ref or parent_ref == current_ref:
            return None
        if self.repository.case_for_external_message(
            event.channel,
            event.channel_instance,
            parent_ref,
        ):
            return None
        return parent_ref

    def _agent_model_vision_ready(self, agent_id: str) -> bool:
        current_model = self.agent_registry.get_agent(agent_id).get("current_model") or {}
        profile_version_id = str(current_model.get("model_profile_version_id") or "")
        readiness = (
            self.model_registry.probe_readiness(profile_version_id)
            if profile_version_id
            else {"status": "blocked"}
        )
        return bool(current_model.get("capabilities", {}).get("vision") and readiness["status"] == "ready")

    async def _ocr_attachment(self, attachment: InboundAttachment) -> InboundAttachment:
        if not isinstance(attachment.content, bytes):
            return attachment
        try:
            extraction = await asyncio.wait_for(
                asyncio.to_thread(self.image_text.extract, attachment.content),
                timeout=30,
            )
        except TimeoutError:
            extraction = {
                "state": "query_failed",
                "engine": "rapidocr",
                "text": "",
                "line_count": 0,
                "truncation_state": "complete",
                "limitations": ["ocr_timeout"],
            }
        return replace(attachment, text_extraction=extraction)

    async def handle_long_connection_event(
        self,
        instance_id: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Durably acknowledge one SDK-authenticated event, then process it async."""

        header = payload.get("header", {})
        event_ref = str(header.get("event_id") or "") or None
        try:
            runtime_config = self.channel_registry.resolve_feishu_runtime(instance_id)
            if runtime_config.mode != "long_connection":
                raise ChannelDrop("channel_transport_mismatch")
            adapter = FeishuAdapter(runtime_config)
            event = adapter.normalize(payload)
            expected_instances = {
                value for value in (runtime_config.external_instance_ref, runtime_config.app_id) if value
            }
            if (
                expected_instances
                and event.channel_instance != "default"
                and event.channel_instance not in expected_instances
            ):
                raise ChannelDrop("channel_instance_mismatch")
            resolved_agent = self.channel_registry.resolve_agent(instance_id, "feishu")
            event = replace(
                event,
                channel_instance=instance_id,
                agent_id=resolved_agent,
                reply_address={
                    **event.reply_address,
                    "channel_instance": instance_id,
                    "channel_revision": runtime_config.revision,
                    "channel_transport_identity": runtime_config.transport_identity,
                },
            )
            self.cases.assert_admitted(event)
            event_key = self._inbound_event_key(event)
            receipt = self.repository.accept_inbound_envelope(
                event_key,
                event.channel,
                event.agent_id,
                self._serialize_inbound_envelope(event),
            )
        except ChannelDrop as exc:
            self.channel_registry.record_ingress(instance_id, event_ref, "rejected", exc.reason)
            return {"accepted": False, "reason": exc.reason}
        except ChannelResolutionError as exc:
            reason = str(exc)
            self.channel_registry.record_ingress(instance_id, event_ref, "rejected", reason)
            return {"accepted": False, "reason": reason}
        except InboundNotAdmitted as exc:
            reason = str(exc)
            self.channel_registry.record_ingress(instance_id, event_ref, "rejected", reason)
            return {"accepted": False, "reason": reason}

        now = datetime.now(UTC)
        claimed = self.repository.claim_job(
            f"inbound-prepare:{event_key}",
            now,
            now + timedelta(seconds=INBOUND_PREPARATION_LEASE_SECONDS),
        )
        if claimed is not None:
            self._start_inbound_preparation(claimed)
        duplicate = not bool(receipt["created"])
        self.channel_registry.record_ingress(
            instance_id,
            event.event_id,
            "duplicate" if duplicate else "accepted",
        )
        return {
            "accepted": True,
            "duplicate": duplicate,
            "state": str(receipt["event"]["state"]),
            "queued": receipt["job"]["status"] != "completed",
        }

    def _pack_inspection(
        self,
        pack_id: str,
        version: str,
        content_digest: str,
    ) -> PackInspection:
        inspection = next(
            (
                item
                for item in PackRegistry.inspect(self.settings.packs_dir)
                if item.id == pack_id and item.version == version
            ),
            None,
        )
        if inspection is None:
            raise KeyError(f"{pack_id}@{version}")
        if inspection.digest != content_digest:
            raise ValueError("能力包内容摘要已变化，请重新预览后再安装")
        return inspection

    def pack_discoveries(self) -> list[dict[str, Any]]:
        return PackRegistry.catalog_discoveries(
            self.settings.packs_dir,
            loaded_pack_refs={f"{item.id}@{item.version}" for item in self.packs.list()},
            installed_pack_refs=self.database.installed_pack_digests(),
            trusted_local_pack_refs=self.settings.trusted_local_pack_refs,
        )

    def preview_pack_install(
        self,
        pack_id: str,
        version: str,
        content_digest: str,
    ) -> dict[str, Any]:
        inspection = self._pack_inspection(pack_id, version, content_digest)
        installed = self.database.installed_pack_digests().get(inspection.trust_ref)
        loaded = any(
            item.id == inspection.id and item.version == inspection.version for item in self.packs.list()
        )
        trusted = inspection.trust_ref in self.settings.trusted_local_pack_refs
        findings: list[dict[str, str]] = []
        if installed:
            if installed != inspection.digest:
                findings.append(
                    {
                        "code": "installed_digest_mismatch",
                        "severity": "error",
                        "message": "已安装版本与受控目录内容摘要不一致。",
                    }
                )
            else:
                findings.append(
                    {
                        "code": "already_installed",
                        "severity": "info",
                        "message": "该精确版本已经安装。",
                    }
                )
        if inspection.trusted_code and not trusted:
            findings.append(
                {
                    "code": "deployment_trust_required",
                    "severity": "warning",
                    "message": "代码包尚未获得部署级精确版本信任；安装不会执行代码。",
                }
            )
        return {
            "id": inspection.id,
            "version": inspection.version,
            "name": inspection.name,
            "description": inspection.description,
            "publisher": inspection.publisher,
            "trust_level": inspection.trust_level,
            "content_digest": inspection.digest,
            "code_bearing": inspection.trusted_code,
            "trusted_by_deployment": trusted,
            "skill_count": len(inspection.skills),
            "tool_count": len(inspection.tool_names),
            "installed": bool(installed),
            "loaded": loaded,
            "can_install": not installed,
            "installation_executes_code": False,
            "activation": "restart_required" if inspection.trusted_code else "immediate",
            "findings": findings,
        }

    def install_pack(
        self,
        pack_id: str,
        version: str,
        content_digest: str,
        actor: str,
    ) -> dict[str, Any]:
        inspection = self._pack_inspection(pack_id, version, content_digest)
        already_loaded = any(
            item.id == inspection.id and item.version == inspection.version for item in self.packs.list()
        )
        staged_registry: PackRegistry | None = None
        staged_tools: ToolRegistry | None = None
        if not inspection.trusted_code and not already_loaded:
            staged_tools = ToolRegistry()
            staged_registry = PackRegistry.load(
                self.settings.packs_dir,
                staged_tools,
                trusted_local_pack_refs=(),
                allowed_pack_refs={inspection.trust_ref},
                expected_digests={inspection.trust_ref: inspection.digest},
            )
            if len(staged_registry.list()) != 1:
                raise ValueError("能力包未能形成唯一的待安装运行版本")
            self.packs.validate_extension(staged_registry.list())
            combined_tools = ToolRegistry()
            combined_tools.merge_from(self.tools)
            combined_tools.merge_from(staged_tools)

        installed = self.capabilities.install_inspection(inspection, actor)
        if staged_registry is not None and staged_tools is not None:
            self.packs.extend(staged_registry.list())
            self.tools.merge_from(staged_tools)
            self.skills = self.packs.skills
            reference_tools = ToolRegistry()
            self.skills.register_reference_tools(reference_tools)
            self.tools.merge_from(reference_tools, replace=True)
            self.tool_providers.sync_loaded_catalog(self.packs.tool_provider_types())
            loaded = True
        else:
            loaded = already_loaded
        return {
            **installed,
            "loaded": loaded,
            "executed_code": False,
            "restart_required": inspection.trusted_code and not loaded,
            "trusted_by_deployment": (inspection.trust_ref in self.settings.trusted_local_pack_refs),
        }

    def cleanup_private_data(self, now: Any = None) -> int:
        return self.artifacts.cleanup(now) + self.actions.expire_pending(now)

    @property
    def message_availability(self) -> dict[str, Any]:
        state = dict(self.service.availability_state)
        preparation = self.repository.job_status_counts("prepare_inbound")
        state.update(
            {
                "active_preparations": len(self._inbound_preparation_tasks),
                "queued_preparations": preparation.get("pending", 0),
                "leased_preparations": preparation.get("running", 0),
                "pending_transport_callbacks": self.feishu_long_connections.pending_callback_count,
            }
        )
        return state

    def begin_activation_handoff(self, activation_id: str, target_release: str) -> None:
        if self.activation_handoff_task and not self.activation_handoff_task.done():
            return
        self.activation_handoff_task = asyncio.create_task(
            self._drain_and_handoff(activation_id, target_release),
            name=f"suwen-activation-handoff-{activation_id}",
        )

    def _activation_is_current(self, activation_id: str, target_release: str) -> bool:
        if self.runtime_layout is None:
            return False
        try:
            activation = ReleaseManager(self.runtime_layout).activation_status()
        except ValueError:
            return False
        return bool(
            activation
            and activation.get("activation_id") == activation_id
            and activation.get("target_release") == target_release
            and activation.get("status") == "worker_exit_requested"
        )

    async def _drain_and_handoff(self, activation_id: str, target_release: str) -> None:
        """Keep ingress alive while Runs drain, then make one short exec handoff."""

        self.service.begin_drain()
        feishu_stopped = False
        handed_off = False
        self.activation_handoff_error = None
        try:
            while True:
                if not self._activation_is_current(activation_id, target_release):
                    return
                try:
                    await asyncio.wait_for(self.service.wait_for_active_executions(), timeout=1)
                    break
                except TimeoutError:
                    continue

            feishu_stopped = True
            await self.feishu_long_connections.stop()
            await self.service.wait_for_inbound_idle()
            if not self._activation_is_current(activation_id, target_release):
                return
            if self.shutdown_callback is None:
                return
            self.shutdown_callback()
            handed_off = True
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.activation_handoff_error = f"{type(exc).__name__}: {exc}"[:1000]
        finally:
            if not handed_off:
                self.service.cancel_drain()
                if feishu_stopped:
                    self.feishu_long_connections.start()


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    state = AppState(settings)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        runtime = app.state.runtime
        await runtime.tool_providers.connect_configured()
        runtime.scheduler.start()
        runtime.feishu_long_connections.start()
        try:
            yield
        finally:
            await runtime.feishu_long_connections.stop()
            await runtime.scheduler.stop()
            await runtime.tool_providers.close()
            close_sender = getattr(runtime.sender, "close", None)
            if close_sender:
                await close_sender()

    app = FastAPI(title=settings.name, version="0.2.0", lifespan=lifespan)
    app.state.runtime = state
    rate_windows: dict[tuple[str, str], deque[float]] = {}

    def configured_management_tokens() -> list[tuple[str, str]]:
        return [
            (role, token)
            for role, token in (
                ("admin", state.settings.admin_token),
                ("operator", state.settings.operator_token),
                ("reviewer", state.settings.reviewer_token),
                ("viewer", state.settings.viewer_token),
            )
            if token
        ]

    def management_session_role(value: str | None) -> str | None:
        if not value:
            return None
        observed_at = int(time.time())
        for role, token in configured_management_tokens():
            if not state.settings.token_is_active(role):
                continue
            if _management_session_matches(value, role, token, observed_at=observed_at):
                return role
        return None

    def issue_management_session(response: Response, request: Request, role: str) -> None:
        tokens = dict(configured_management_tokens())
        token = tokens.get(role)
        if not token or not state.settings.token_is_active(role):
            return
        expires_at = int(time.time()) + MANAGEMENT_SESSION_TTL_SECONDS
        response.set_cookie(
            MANAGEMENT_SESSION_COOKIE,
            _management_session_value(role, token, expires_at),
            max_age=MANAGEMENT_SESSION_TTL_SECONDS,
            httponly=True,
            secure=request.url.scheme == "https",
            samesite="strict",
            path="/api/v1",
        )

    def secure_response(request: Request, response: Any) -> Any:
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; base-uri 'none'; frame-ancestors 'none'; "
            "form-action 'self'; object-src 'none'"
        )
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        request_id = current_request_id()
        if request_id:
            response.headers["X-Request-ID"] = request_id
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    def is_channel_ingress_path(path: str) -> bool:
        return path == "/api/v1/feishu/events" or (
            path.startswith("/api/v1/channels/") and path.endswith("/feishu/events")
        )

    def is_case_attachment_upload_path(path: str) -> bool:
        parts = path.split("/")
        return (
            len(parts) == 6
            and parts[:4] == ["", "api", "v1", "cases"]
            and bool(parts[4])
            and parts[5] == "attachments"
        )

    def request_authorization_source(request: Request) -> str:
        authorization = request.headers.get("authorization", "")
        supplied = authorization.removeprefix("Bearer ") if authorization else ""
        for role, token in configured_management_tokens():
            if token and state.settings.token_is_active(role) and supplied == token:
                return f"management_role_token:{role}"
        session_role = management_session_role(request.cookies.get(MANAGEMENT_SESSION_COOKIE))
        if not authorization and session_role:
            return f"management_browser_session:{session_role}"
        if (
            state.settings.api_token
            and state.settings.token_is_active("api")
            and supplied == state.settings.api_token
        ):
            return "runtime_api_token"
        if is_channel_ingress_path(request.url.path):
            return "channel_ingress_verification"
        if not configured_management_tokens():
            return "local_management_without_token"
        return "unauthenticated_request"

    def request_rate_limit(request: Request) -> tuple[bool, int]:
        if request.url.path.startswith("/assets/") or request.url.path == "/health":
            scope, limit = "public-read", 600
        elif request.method in {"GET", "HEAD", "OPTIONS"}:
            scope, limit = "control-read", 600
        elif is_channel_ingress_path(request.url.path):
            scope, limit = "channel-ingress", 300
        elif request.url.path.startswith("/api/v1/admin/"):
            scope, limit = "control-write", 240
        else:
            scope, limit = "runtime-write", 120
        client_ref = request.client.host if request.client else "unknown"
        key = (client_ref, scope)
        now = time.monotonic()
        window = rate_windows.setdefault(key, deque())
        while window and now - window[0] >= 60:
            window.popleft()
        if len(window) >= limit:
            retry_after = max(1, int(60 - (now - window[0])))
            return False, retry_after
        window.append(now)
        if len(rate_windows) > 4096:
            for stale_key, values in list(rate_windows.items()):
                if not values or now - values[-1] >= 60:
                    rate_windows.pop(stale_key, None)
        return True, 0

    @app.middleware("http")
    async def management_security_headers(request: Request, call_next: Any) -> Any:
        request_id = request_id_from_header(request.headers.get("x-request-id"))
        with bind_audit_context(request_id, request_authorization_source(request)):
            allowed, retry_after = request_rate_limit(request)
            if not allowed:
                return secure_response(
                    request,
                    JSONResponse(
                        {"detail": "请求过于频繁，请稍后再试"},
                        status_code=429,
                        headers={"Retry-After": str(retry_after)},
                    ),
                )
            attachment_upload = is_case_attachment_upload_path(request.url.path)
            body_limit = state.settings.artifacts.max_bytes if attachment_upload else 1_048_576
            content_length = request.headers.get("content-length")
            if content_length:
                try:
                    too_large = int(content_length) > body_limit
                except ValueError:
                    return secure_response(
                        request,
                        JSONResponse({"detail": "Content-Length 无效"}, status_code=400),
                    )
                if too_large:
                    return secure_response(
                        request,
                        JSONResponse({"detail": "请求正文超过接口大小上限"}, status_code=413),
                    )
            if request.method not in {"GET", "HEAD", "OPTIONS"} and request.url.path.startswith("/api/"):
                body = await request.body()
                if len(body) > body_limit:
                    return secure_response(
                        request,
                        JSONResponse({"detail": "请求正文超过接口大小上限"}, status_code=413),
                    )
                media_type = request.headers.get("content-type", "").split(";", 1)[0].strip().lower()
                accepted_media = (
                    {"image/png", "image/jpeg", "image/webp"} if attachment_upload else {"application/json"}
                )
                if body and media_type not in accepted_media:
                    return secure_response(
                        request,
                        JSONResponse({"detail": "接口写请求的 Content-Type 不受支持"}, status_code=415),
                    )
            if request.method not in {"GET", "HEAD", "OPTIONS"}:
                origin = request.headers.get("origin")
                host = request.headers.get("host", "")
                if origin and urlsplit(origin).netloc != host:
                    return secure_response(
                        request,
                        JSONResponse({"detail": "跨来源管理请求已拒绝"}, status_code=403),
                    )
            response = await call_next(request)
            session_role = getattr(request.state, "management_session_role", None)
            if session_role and response.status_code < 400:
                issue_management_session(response, request, session_role)
            return secure_response(request, response)

    def runtime_actor(authorization: str | None = Header(default=None)) -> str:
        expected = state.settings.api_token
        if expected:
            if not state.settings.token_is_active("api"):
                raise HTTPException(status_code=401, detail="运行接口访问令牌已过期")
            supplied = authorization.removeprefix("Bearer ") if authorization else ""
            if supplied != expected:
                raise HTTPException(status_code=401, detail="运行接口需要有效访问令牌")
            return "api:configured"
        return "api:local"

    def management_principal(
        request: Request,
        authorization: str | None = Header(default=None),
    ) -> dict[str, str]:
        configured = configured_management_tokens()
        if not configured:
            principal = {"role": "admin", "actor": "admin:local"}
            request.state.management_session_role = principal["role"]
            return principal
        supplied = authorization.removeprefix("Bearer ") if authorization else ""
        if authorization:
            for role, token in configured:
                if state.settings.token_is_active(role) and supplied == token:
                    principal = {"role": role, "actor": f"{role}:configured"}
                    request.state.management_session_role = role
                    return principal
            if all(not state.settings.token_is_active(role) for role, _token in configured):
                raise HTTPException(status_code=401, detail="管理端访问令牌已过期")
            raise HTTPException(status_code=401, detail="管理端需要有效访问令牌")
        session_value = request.cookies.get(MANAGEMENT_SESSION_COOKIE)
        session_role = management_session_role(session_value)
        if session_role:
            request.state.management_session_role = session_role
            return {"role": session_role, "actor": f"{session_role}:browser-session"}
        if all(not state.settings.token_is_active(role) for role, _token in configured):
            raise HTTPException(status_code=401, detail="管理端访问令牌已过期")
        if session_value:
            raise HTTPException(status_code=401, detail="管理会话已失效，请重新登录")
        raise HTTPException(status_code=401, detail="管理端需要有效访问令牌")

    def _require_role(principal: dict[str, str], allowed: set[str]) -> str:
        if principal["role"] not in allowed:
            raise HTTPException(status_code=403, detail="当前管理角色没有此操作权限")
        return principal["actor"]

    def require_viewer(
        principal: dict[str, str] = Depends(management_principal),  # noqa: B008
    ) -> str:
        return _require_role(principal, {"viewer", "operator", "reviewer", "admin"})

    def require_operator(
        principal: dict[str, str] = Depends(management_principal),  # noqa: B008
    ) -> str:
        return _require_role(principal, {"operator", "admin"})

    def require_reviewer(
        principal: dict[str, str] = Depends(management_principal),  # noqa: B008
    ) -> str:
        return _require_role(principal, {"reviewer", "admin"})

    def require_admin(
        principal: dict[str, str] = Depends(management_principal),  # noqa: B008
    ) -> str:
        return _require_role(principal, {"admin"})

    def case_reader(request: Request, authorization: str | None = Header(default=None)) -> str:
        supplied = authorization.removeprefix("Bearer ") if authorization else ""
        if (
            state.settings.api_token
            and state.settings.token_is_active("api")
            and supplied == state.settings.api_token
        ):
            return "api:configured"
        management_configured = any(
            (
                state.settings.admin_token,
                state.settings.operator_token,
                state.settings.reviewer_token,
                state.settings.viewer_token,
            )
        )
        if state.settings.api_token and not management_configured:
            raise HTTPException(status_code=401, detail="案件读取需要有效访问令牌")
        principal = management_principal(request, authorization)
        return require_viewer(principal)

    @app.get("/health")
    async def health() -> dict[str, Any]:
        database_ready = state.database.ready()
        default_model: dict[str, Any] | None = None
        default_agent: dict[str, Any] | None = None
        managed_channels: list[dict[str, Any]] = []
        configuration_channels: list[dict[str, Any]] = []
        if database_ready:
            for item in state.channel_registry.list_instances():
                bindings: list[dict[str, Any]] = []
                for binding in item.get("agent_bindings", []):
                    runtime_revision_digest = None
                    if binding.get("agent_status") == "published":
                        try:
                            runtime_revision_digest = state.operations.runtime_target(binding["agent_id"])[
                                "runtime_revision_digest"
                            ]
                        except (KeyError, RuntimeError, ValueError):
                            pass
                    bindings.append(
                        {
                            "agent_id": binding["agent_id"],
                            "active": bool(binding["active"]),
                            "policy": binding.get("policy", {}),
                            "runtime_revision_digest": runtime_revision_digest,
                        }
                    )
                binding_digest = hashlib.sha256(
                    json.dumps(bindings, ensure_ascii=False, sort_keys=True).encode()
                ).hexdigest()
                configuration_channels.append(
                    {
                        "id": item["id"],
                        "channel_type": item["channel_type"],
                        "mode": item.get("config", {}).get("mode"),
                        "revision": item["revision"],
                        "status": item["status"],
                        "binding_digest": binding_digest,
                    }
                )
                if item["channel_type"] != "feishu":
                    continue
                managed_channels.append(
                    {
                        "id": item["id"],
                        "channel_type": item["channel_type"],
                        "mode": item.get("config", {}).get("mode"),
                        "revision": item["revision"],
                        "status": item["status"],
                        "health_state": item["health_state"],
                        "reply_ready": bool(item.get("readiness", {}).get("reply_ready")),
                        "binding_digest": binding_digest,
                    }
                )
            try:
                default_agent = state.operations.default_runtime_target()
            except (KeyError, RuntimeError, ValueError):
                default_agent = None
            try:
                agent_model_version_id = default_agent["model_profile_version_id"]
                default_version = state.model_registry.get_profile_version(agent_model_version_id)
            except (KeyError, RuntimeError, TypeError):
                default_model = {
                    "profile_version_id": None,
                    "profile_id": None,
                    "model_id": None,
                    "configured": False,
                    "profile_status": "missing",
                    "provider_status": "missing",
                    "last_probe_status": "not_run",
                    "probe_stale": False,
                    "probe_readiness": "blocked",
                    "tool_calling_observed": False,
                    "structured_output_observed": False,
                    "vision_observed": False,
                }
            else:
                readiness = state.model_registry.probe_readiness(agent_model_version_id)
                probe_observed = next(
                    (
                        item.get("observed", {})
                        for item in (default_version["last_probe"] or {}).get("findings", [])
                        if item.get("code") == "probe_observed"
                    ),
                    {},
                )
                default_model = {
                    "profile_version_id": agent_model_version_id,
                    "profile_id": default_version["profile_id"],
                    "model_id": default_version["model_id"],
                    "configured": default_version["configuration"]["status"] == "valid",
                    "profile_status": default_version["profile_status"],
                    "provider_status": default_version["provider_status"],
                    "last_probe_status": (
                        default_version["last_probe"]["status"]
                        if default_version["last_probe"]
                        else "not_run"
                    ),
                    "probe_stale": bool(
                        default_version["last_probe"] and default_version["last_probe"]["stale"]
                    ),
                    "probe_readiness": readiness["status"],
                    "tool_calling_observed": bool(probe_observed.get("tool_calling_observed")),
                    "structured_output_observed": bool(probe_observed.get("structured_output_observed")),
                    "vision_observed": bool(probe_observed.get("vision_observed")),
                }
        message_availability = state.message_availability
        managed_channels_ready = all(
            item["status"] != "active"
            or item["mode"] != "long_connection"
            or (item["health_state"] == "connected" and item["reply_ready"])
            for item in managed_channels
        )
        runtime_readiness = {
            "ready": bool(
                database_ready
                and state.scheduler.running
                and not message_availability["draining"]
                and state.activation_handoff_error is None
                and managed_channels_ready
            ),
            "database_ready": database_ready,
            "scheduler_running": state.scheduler.running,
            "accepting_ingress": not message_availability["draining"],
            "activation_handoff_healthy": state.activation_handoff_error is None,
            "managed_channels_ready": managed_channels_ready,
        }
        configuration_snapshot = {
            "default_agent_runtime_revision": (
                default_agent.get("runtime_revision_digest") if default_agent else None
            ),
            "managed_channels": [
                item for item in sorted(configuration_channels, key=lambda value: value["id"])
            ],
        }
        runtime_configuration_digest = hashlib.sha256(
            json.dumps(configuration_snapshot, ensure_ascii=False, sort_keys=True).encode()
        ).hexdigest()
        return {
            **health_identity(),
            "release_version": SUWEN_RELEASE_VERSION,
            "package_version": __version__,
            "runtime_activation_contract": ACTIVATION_SCHEMA_VERSION,
            "loaded_release": state.loaded_release,
            "packs": [
                {"id": item.id, "version": item.version, "description": item.description}
                for item in state.packs.list()
            ],
            "status": "ready" if runtime_readiness["ready"] else "degraded",
            "database": "ready" if database_ready else "not_ready",
            "scheduler": "running" if state.scheduler.running else "stopped",
            "scheduler_last_success": state.scheduler.last_success,
            "scheduler_last_error": state.scheduler.last_error,
            "message_availability": message_availability,
            "runtime_readiness": runtime_readiness,
            "runtime_configuration_digest": runtime_configuration_digest,
            "activation_handoff_error": state.activation_handoff_error,
            "sender": state.settings.feishu.sender,
            "fallback_sender": state.settings.feishu.sender,
            "managed_channels": managed_channels,
            "process_instance_id": state.process_instance_id,
            "process_started_at": state.process_started_at,
            "process_manager": state.process_manager,
            "default_agent": default_agent,
            "default_model": default_model,
        }

    @app.post("/api/v1/admin/runtime/activate-release", status_code=202)
    async def activate_runtime_release(
        body: RuntimeActivationInput,
        request: Request,
        _: str = Depends(require_admin),
    ) -> dict[str, Any]:
        client_host = request.client.host if request.client else ""
        try:
            loopback = ipaddress.ip_address(client_host).is_loopback
        except ValueError:
            loopback = client_host.lower() == "localhost" or (
                state.settings.runtime_mode == "test" and client_host == "testclient"
            )
        if not loopback:
            raise HTTPException(status_code=403, detail="runtime activation is loopback-only")
        if state.runtime_layout is None or state.loaded_release is None:
            raise HTTPException(status_code=409, detail="managed runtime activation is unavailable")
        if state.shutdown_callback is None:
            raise HTTPException(status_code=409, detail="managed runtime shutdown is unavailable")
        try:
            activation = ReleaseManager(state.runtime_layout).request_worker_exit(
                body.activation_id,
                body.target_release,
                state.loaded_release,
            )
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        state.begin_activation_handoff(
            str(activation["activation_id"]),
            str(activation["target_release"]),
        )
        return {
            "activation_id": activation["activation_id"],
            "from_release": activation["from_release"],
            "target_release": activation["target_release"],
            "status": activation["status"],
        }

    @app.get("/api/v1/capabilities")
    async def capabilities() -> dict[str, Any]:
        return {
            "skills": [
                {"id": item.id, "version": item.version, "description": item.description}
                for item in state.skills.list()
            ],
            "tools": [
                {"name": item.name, "risk": item.risk, "description": item.description}
                for item in state.tools.definitions()
            ],
            "runtime_model_resolution": "per-run-agent-current-model-resource",
            "model_resolution": "instance-resource-selected-per-agent",
            "packs": [
                {
                    "id": item.id,
                    "version": item.version,
                    "description": item.description,
                    "trusted_code": item.trusted_code,
                    "trust_level": item.trust_level,
                    "source_revision": item.source_revision,
                    "content_digest": item.digest,
                    "domain_config": json.loads(json.dumps(item.domain_config, default=list)),
                }
                for item in state.packs.list()
            ],
        }

    @app.get("/api/v1/agents")
    async def available_agents(_: str = Depends(case_reader)) -> dict[str, Any]:
        with state.database.connect() as connection:
            rows = connection.execute(
                """SELECT a.id, a.name, a.description, a.language,
                          a.active_version_id, mpv.model_id,
                          mpv.model_profile_id, av.version
                   FROM agents a
                   JOIN agent_versions av ON av.id=a.active_version_id
                   JOIN agent_model_bindings binding ON binding.agent_id=a.id
                   JOIN model_profile_versions mpv
                     ON mpv.id=(
                          SELECT current_model.id
                            FROM model_profile_versions current_model
                           WHERE current_model.model_profile_id=binding.model_profile_id
                           ORDER BY current_model.version DESC LIMIT 1
                        )
                   WHERE a.status='published' ORDER BY a.name, a.id"""
            ).fetchall()
            default = connection.execute(
                "SELECT value_json FROM system_settings WHERE key='default_agent_id'"
            ).fetchone()
        default_agent_id = json.loads(default["value_json"]) if default else None
        return {"items": [{**dict(row), "is_default": row["id"] == default_agent_id} for row in rows]}

    @app.get("/api/v1/admin/secret-refs")
    async def list_secret_refs(_: str = Depends(require_viewer)) -> dict[str, Any]:
        with state.database.connect() as connection:
            rows = connection.execute("SELECT id FROM secret_refs ORDER BY id").fetchall()
            usage_rows = connection.execute(
                """SELECT endpoint_ref AS secret_ref_id, 'model' AS scope,
                          'provider_endpoint' AS purpose, provider_id AS owner_id
                     FROM model_provider_versions WHERE endpoint_ref <> ''
                   UNION ALL
                   SELECT secret_ref_id, 'model', 'provider_api_key', provider_id
                     FROM model_provider_versions WHERE secret_ref_id IS NOT NULL
                   UNION ALL
                   SELECT secret_ref_id, 'tool', 'provider_secret', id
                     FROM tool_providers WHERE secret_ref_id IS NOT NULL
                   UNION ALL
                   SELECT secret_ref_id, 'channel', purpose, channel_instance_id
                     FROM channel_secret_bindings
                   UNION ALL
                   SELECT secret_ref_id, 'channel', 'legacy_channel_secret', id
                     FROM channel_instances WHERE secret_ref_id IS NOT NULL"""
            ).fetchall()
        usages: dict[str, list[dict[str, str]]] = {}
        seen: set[tuple[str, str, str, str]] = set()
        for row in usage_rows:
            key = (row["secret_ref_id"], row["scope"], row["purpose"], row["owner_id"])
            if key in seen:
                continue
            seen.add(key)
            usages.setdefault(row["secret_ref_id"], []).append(
                {
                    "scope": row["scope"],
                    "purpose": row["purpose"],
                    "owner_id": row["owner_id"],
                }
            )
        items = []
        for row in rows:
            item = state.model_registry.secrets.metadata(row["id"])
            item["usages"] = usages.get(row["id"], [])
            items.append(item)
        return {"items": items}

    @app.post("/api/v1/admin/secret-refs", status_code=201)
    async def create_secret_ref(body: SecretRefCreate, admin: str = Depends(require_admin)) -> dict[str, Any]:
        try:
            return state.model_registry.create_secret_ref(body.id, body.name, body.env_name, admin)
        except (ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.put("/api/v1/admin/secret-refs/{ref_id}/private-value")
    async def store_secret_private_value(
        ref_id: str,
        request: Request,
        rotate: bool = False,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        raw = await request.body()
        if not raw or len(raw) > 70 * 1024:
            raise HTTPException(status_code=422, detail="private value payload is invalid")
        try:
            payload = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise HTTPException(status_code=422, detail="private value payload is invalid") from exc
        if (
            not isinstance(payload, dict)
            or set(payload) != {"value"}
            or not isinstance(payload["value"], str)
            or not payload["value"]
            or len(payload["value"].encode("utf-8")) > 64 * 1024
        ):
            raise HTTPException(status_code=422, detail="private value payload is invalid")
        try:
            return state.model_registry.secrets.store_private_values(
                {ref_id: payload["value"]},
                admin,
                replace=rotate,
            )[ref_id]
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Secret Ref not found") from exc
        except (FileExistsError, ValueError, RuntimeError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/model-providers")
    async def list_model_providers(
        limit: int = 50,
        offset: int = 0,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return state.model_registry.list_providers_page(limit, offset)

    @app.get("/api/v1/admin/channel-instances")
    async def list_channel_instances(
        agent_id: str | None = None,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return {"items": state.channel_registry.list_instances(agent_id=agent_id)}

    @app.post("/api/v1/admin/channel-instances", status_code=201)
    async def create_channel_instance(
        body: ChannelInstanceCreate,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.channel_registry.create_instance(
                body.id,
                body.channel_type,
                body.name,
                body.config,
                body.secret_bindings,
                admin,
            )
        except (KeyError, ValueError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.put("/api/v1/admin/channel-instances/{instance_id}/feishu-configuration")
    async def configure_feishu_channel(
        instance_id: str,
        body: FeishuConfigurationPut,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return await state.feishu_channel_configurator.configure(
                instance_id=instance_id,
                name=body.name,
                agent_id=body.agent_id,
                enabled=body.enabled,
                domain=body.domain,
                app_id=body.app_id,
                app_secret=body.app_secret,
                verification_token=body.verification_token,
                encrypt_key=body.encrypt_key,
                require_mention_in_group=body.require_mention_in_group,
                allowed_actor_refs=body.allowed_actor_refs,
                allowed_chat_refs=body.allowed_chat_refs,
                actor=admin,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Channel dependency not found") from exc
        except FeishuConfigurationError as exc:
            raise HTTPException(
                status_code=409,
                detail={"message": str(exc), "failure_class": exc.failure_class},
            ) from exc
        except (ValueError, RuntimeError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/channel-instances/{instance_id}")
    async def get_channel_instance(
        instance_id: str,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        try:
            return state.channel_registry.get_instance(instance_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Channel Instance not found") from exc

    @app.patch("/api/v1/admin/channel-instances/{instance_id}")
    async def rename_channel_instance(
        instance_id: str,
        body: ChannelInstanceRename,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.channel_registry.rename_instance(instance_id, body.name, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Channel Instance not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/channel-instances/{instance_id}/versions", status_code=201)
    async def create_channel_instance_version(
        instance_id: str,
        body: ChannelInstanceVersionCreate,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            result = state.channel_registry.create_version(
                instance_id,
                body.config,
                body.secret_bindings,
                admin,
            )
            await state.feishu_long_connections.reconcile()
            return result
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Channel dependency not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/channel-instances/{instance_id}/validate")
    async def validate_channel_instance(
        instance_id: str,
        admin: str = Depends(require_operator),
    ) -> dict[str, Any]:
        try:
            return state.channel_registry.validate(instance_id, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Channel Instance not found") from exc

    @app.post("/api/v1/admin/channel-instances/{instance_id}/probe")
    async def probe_channel_instance(
        instance_id: str,
        operator: str = Depends(require_operator),
    ) -> dict[str, Any]:
        try:
            runtime_config = state.channel_registry.resolve_feishu_probe_config(instance_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Channel Instance not found") from exc
        except ChannelResolutionError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        result = await state.feishu_probe.probe(runtime_config)
        state.channel_registry.record_credential_probe(
            instance_id,
            result.status == "passed",
            operator,
            result.failure_class,
        )
        return {
            "status": result.status,
            "failure_class": result.failure_class,
            "bot_open_id": result.bot_open_id,
            "message_accessed": False,
            "message_sent": False,
        }

    @app.post("/api/v1/admin/channel-instances/{instance_id}/status")
    async def set_channel_instance_status(
        instance_id: str,
        body: ChannelStatusChange,
        admin: str = Depends(require_operator),
    ) -> dict[str, Any]:
        try:
            result = state.channel_registry.set_status(instance_id, body.status, admin)
            await state.feishu_long_connections.reconcile()
            return result
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Channel Instance not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/channel-instances/{instance_id}/agent-bindings")
    async def bind_channel_agent(
        instance_id: str,
        body: ChannelAgentBindingCreate,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.channel_registry.bind_agent(
                instance_id,
                body.agent_id,
                body.policy,
                admin,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Channel or Agent not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.delete("/api/v1/admin/channel-instances/{instance_id}/agent-bindings/{agent_id}")
    async def unbind_channel_agent(
        instance_id: str,
        agent_id: str,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.channel_registry.unbind_agent(instance_id, agent_id, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Channel binding not found") from exc

    @app.get("/api/v1/admin/outbox")
    async def list_outbox(
        limit: int = 100,
        offset: int = 0,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return state.channel_registry.list_outbox(limit, offset)

    @app.get("/api/v1/admin/overview")
    async def admin_overview(_: str = Depends(require_viewer)) -> dict[str, Any]:
        result = state.operations.overview()
        stability = state.operations.stability_observation(
            SUWEN_AGENT_ID,
            state.process_instance_id,
        )
        result["process"] = {
            "status": "ready",
            "persistent_manager": state.process_manager["status"],
            "manager_evidence": state.process_manager,
            "instance_id": state.process_instance_id,
            "started_at": state.process_started_at,
            "stability": stability,
        }
        result["scheduler"] = {
            "running": state.scheduler.running,
            "last_success": state.scheduler.last_success,
            "last_error_class": (
                state.scheduler.last_error.split(":", 1)[0] if state.scheduler.last_error else None
            ),
        }
        result["database"] = state.database.check()
        return result

    @app.get("/api/v1/admin/delivery-preflight")
    async def delivery_preflight(
        agent_id: str = SUWEN_AGENT_ID,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        try:
            return state.delivery_preflight.inspect(
                agent_id,
                scheduler_running=state.scheduler.running,
                process_instance_id=state.process_instance_id,
                persistent_manager=state.process_manager,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc

    @app.get("/api/v1/admin/runs")
    async def list_admin_runs(
        agent_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
        offset: int = 0,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return state.operations.list_runs(
            agent_id=agent_id,
            status=status,
            limit=limit,
            offset=offset,
        )

    @app.get("/api/v1/admin/cases")
    async def list_admin_cases(
        limit: int = 100,
        offset: int = 0,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return state.operations.list_cases(limit, offset)

    @app.get("/api/v1/admin/cases/{case_id}")
    async def get_admin_case(
        case_id: str,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        try:
            return state.operations.get_case(case_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Case not found") from exc

    @app.get("/api/v1/admin/runs/{run_id}")
    async def get_admin_run(
        run_id: str,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        try:
            return state.operations.get_run(run_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Run not found") from exc

    @app.get("/api/v1/admin/jobs")
    async def list_admin_jobs(
        status: str | None = None,
        limit: int = 100,
        offset: int = 0,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return state.operations.list_jobs(status=status, limit=limit, offset=offset)

    @app.get("/api/v1/admin/audit")
    async def list_admin_audit(
        action: str | None = None,
        target_type: str | None = None,
        actor_ref: str | None = None,
        result: str | None = None,
        created_from: str | None = None,
        created_to: str | None = None,
        limit: int = 100,
        offset: int = 0,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        for value, label in (
            (created_from, "created_from"),
            (created_to, "created_to"),
        ):
            if value:
                try:
                    parsed = datetime.fromisoformat(value)
                except ValueError as exc:
                    raise HTTPException(
                        status_code=422,
                        detail=f"{label} 必须是带时区的 ISO 时间",
                    ) from exc
                if parsed.tzinfo is None:
                    raise HTTPException(
                        status_code=422,
                        detail=f"{label} 必须包含时区",
                    )
        return state.operations.list_audit(
            action=action,
            target_type=target_type,
            actor_ref=actor_ref,
            result=result,
            created_from=created_from,
            created_to=created_to,
            limit=limit,
            offset=offset,
        )

    @app.get("/api/v1/admin/system")
    async def admin_system(_: str = Depends(require_viewer)) -> dict[str, Any]:
        result = state.operations.system()
        result["scheduler"] = {
            "running": state.scheduler.running,
            "last_success": state.scheduler.last_success,
            "last_error_class": (
                state.scheduler.last_error.split(":", 1)[0] if state.scheduler.last_error else None
            ),
            "poll_seconds": state.settings.scheduler.poll_seconds,
            "lease_seconds": state.settings.scheduler.lease_seconds,
        }
        result["process_manager"] = state.process_manager
        result["runtime_mode"] = state.settings.runtime_mode
        result["management_web"] = {
            "asset_digest": state.management_asset_digest,
            "e2e": state.operations.management_e2e_observation(
                SUWEN_AGENT_ID,
                state.management_asset_digest,
            ),
        }
        channel_instances = state.channel_registry.list_instances()
        result["sender_mode"] = "managed_instances"
        result["feishu_enabled"] = any(
            item["channel_type"] == "feishu" and item["status"] == "active" for item in channel_instances
        )
        result["global_feishu_adapter_enabled"] = state.settings.feishu.enabled
        result["managed_channel_runtime"] = True
        result["storage"] = {
            "database_file": state.settings.database_path.name,
            "database_bytes": (
                state.settings.database_path.stat().st_size if state.settings.database_path.is_file() else 0
            ),
            "database_mode": (
                oct(state.settings.database_path.stat().st_mode & 0o777)
                if state.settings.database_path.is_file()
                else None
            ),
            "managed_backup_directory": "data/backups",
        }
        result["retention"] = {
            "artifact_hours": state.settings.artifacts.retention_hours,
            "action_confirmation_seconds": state.settings.actions.confirmation_ttl_seconds,
        }
        return result

    @app.get("/api/v1/admin/delivery/management-e2e-template")
    async def management_e2e_evidence_template(
        agent_id: str = SUWEN_AGENT_ID,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        try:
            state.operations.runtime_target(agent_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="智能体不存在") from exc
        return management_e2e_template(
            agent_id,
            state.process_instance_id,
            state.process_started_at,
            state.management_asset_digest,
        )

    @app.post(
        "/api/v1/admin/delivery/management-e2e-observations",
        status_code=201,
    )
    async def record_management_e2e_evidence(
        body: ManagementE2EObservationInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.operations.record_management_e2e_observation(
                admin,
                body.agent_id,
                state.process_instance_id,
                state.process_started_at,
                state.management_asset_digest,
                body.model_dump(),
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="智能体不存在") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/backups", status_code=201)
    async def create_managed_backup(admin: str = Depends(require_admin)) -> dict[str, Any]:
        try:
            return state.operations.create_backup(admin)
        except (OSError, sqlite3.Error, ValueError) as exc:
            raise HTTPException(status_code=409, detail="本地备份创建失败") from exc

    @app.get("/api/v1/admin/session")
    @app.post("/api/v1/admin/session")
    async def admin_session(
        principal: dict[str, str] = Depends(management_principal),  # noqa: B008
    ) -> dict[str, Any]:
        role = principal["role"]
        return {
            "role": role,
            "permissions": {
                "view": True,
                "operate": role in {"operator", "admin"},
                "review": role in {"reviewer", "admin"},
                "administer": role == "admin",
            },
        }

    @app.delete("/api/v1/admin/session", status_code=204)
    async def delete_admin_session() -> Response:
        response = Response(status_code=204)
        response.delete_cookie(MANAGEMENT_SESSION_COOKIE, path="/api/v1")
        return response

    @app.get("/api/v1/admin/model-providers/{provider_id}")
    async def get_model_provider(provider_id: str, _: str = Depends(require_viewer)) -> dict[str, Any]:
        try:
            return state.model_registry.get_provider(provider_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="model provider not found") from exc

    @app.post("/api/v1/admin/model-providers", status_code=201)
    async def create_model_provider(
        body: ProviderCreate, admin: str = Depends(require_admin)
    ) -> dict[str, Any]:
        try:
            return state.model_registry.create_provider_from_values(
                body.id,
                body.name,
                body.protocol,
                body.endpoint,
                body.api_key,
                admin,
                status=body.status,
            )
        except (ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.put("/api/v1/admin/model-providers/{provider_id}")
    async def update_model_provider(
        provider_id: str,
        body: ProviderVersionCreate,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.model_registry.create_provider_version_from_values(
                provider_id,
                name=body.name,
                protocol=body.protocol,
                endpoint=body.endpoint,
                api_key=body.api_key,
                actor=admin,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="model provider not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/model-providers/{provider_id}/model-catalog")
    async def discover_model_provider_catalog(
        provider_id: str,
        operator: str = Depends(require_operator),
    ) -> dict[str, Any]:
        try:
            return await state.model_registry.discover_provider_models(provider_id, operator)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="model provider not found") from exc
        except ModelCatalogDiscoveryError as exc:
            raise HTTPException(
                status_code=409,
                detail={"category": exc.category, "message": str(exc)},
            ) from exc

    @app.post("/api/v1/admin/model-providers/{provider_id}/status")
    async def set_model_provider_status(
        provider_id: str,
        body: ModelStatusInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.model_registry.set_provider_status(provider_id, body.status, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="model provider not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.delete("/api/v1/admin/model-providers/{provider_id}")
    async def delete_model_provider(
        provider_id: str,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.model_registry.delete_provider(provider_id, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="model provider not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/model-profiles")
    async def list_model_profiles(
        limit: int = 50,
        offset: int = 0,
        provider_id: str | None = None,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return state.model_registry.list_profiles_page(
            limit,
            offset,
            provider_id=provider_id,
        )

    @app.get("/api/v1/admin/model-options")
    async def list_model_options(_: str = Depends(require_viewer)) -> dict[str, Any]:
        return state.model_registry.selection_options()

    @app.get("/api/v1/admin/model-profiles/{profile_id}")
    async def get_model_profile(profile_id: str, _: str = Depends(require_viewer)) -> dict[str, Any]:
        try:
            return state.model_registry.get_profile(profile_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="model profile not found") from exc

    @app.post("/api/v1/admin/model-profiles", status_code=201)
    async def create_model_profile(
        body: ProfileCreate, admin: str = Depends(require_admin)
    ) -> dict[str, Any]:
        try:
            return state.model_registry.create_profile(
                body.id,
                body.provider_id,
                body.name,
                body.model_id,
                admin,
                max_input_length=body.max_input_length,
                max_output_tokens=body.max_output_tokens,
                temperature=body.temperature,
                reasoning_effort=body.reasoning_effort,
                timeout_seconds=body.timeout_seconds,
                capabilities=body.capabilities.model_dump(),
                routing=body.routing,
                provider_version_id=body.provider_version_id,
                status="active",
            )
        except (ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.put("/api/v1/admin/model-profiles/{profile_id}")
    async def update_model_profile(
        profile_id: str,
        body: ProfileVersionCreate,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.model_registry.create_profile_version(
                profile_id,
                admin,
                name=body.name,
                model_id=body.model_id,
                max_input_length=body.max_input_length,
                max_output_tokens=body.max_output_tokens,
                temperature=body.temperature,
                reasoning_effort=body.reasoning_effort,
                timeout_seconds=body.timeout_seconds,
                capabilities=body.capabilities.model_dump(),
                routing=body.routing,
                provider_id=body.provider_id,
                provider_version_id=body.provider_version_id,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="model profile not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.delete("/api/v1/admin/model-profiles/{profile_id}")
    async def delete_model_profile(profile_id: str, admin: str = Depends(require_admin)) -> dict[str, Any]:
        try:
            return state.model_registry.delete_profile(profile_id, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="model profile not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/model-profile-versions/{profile_version_id}/probe")
    async def probe_model_profile(
        profile_version_id: str, admin: str = Depends(require_operator)
    ) -> dict[str, Any]:
        try:
            return await state.model_registry.probe(profile_version_id, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="model profile version not found") from exc

    @app.get("/api/v1/admin/agents")
    async def list_agents(
        include_archived: bool = False,
        limit: int = 50,
        offset: int = 0,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return state.agent_registry.list_agents_page(
            limit,
            offset,
            include_archived=include_archived,
        )

    @app.get("/api/v1/admin/personas")
    async def list_agent_personas(_: str = Depends(require_viewer)) -> dict[str, Any]:
        return {"items": list_personas(), "default_id": DEFAULT_PERSONA_ID}

    @app.get("/api/v1/admin/agent-options")
    async def list_agent_options(_: str = Depends(require_viewer)) -> dict[str, Any]:
        return {"items": state.agent_registry.selection_options()}

    @app.get("/api/v1/admin/agent-profiles")
    async def list_agent_profiles(_: str = Depends(require_viewer)) -> dict[str, Any]:
        return {"items": state.agent_profiles.list()}

    @app.get("/api/v1/admin/native-releases")
    async def list_native_releases(_: str = Depends(require_viewer)) -> dict[str, Any]:
        return {
            "contract": "suwen-release.v1",
            "artifacts": state.native_releases.list_artifacts(),
            "installations": state.native_releases.list_installations(),
            "external_bindings": state.external_dependencies.list_bindings(),
        }

    @app.get("/api/v1/admin/domain-experts")
    async def list_domain_experts(_: str = Depends(require_viewer)) -> dict[str, Any]:
        return {"items": state.capability_packages.list_domain_experts()}

    @app.get(
        "/api/v1/admin/domain-experts/{capability_id}/versions/{capability_version_id}"
        "/skills/{skill_id}/references/{reference_id}"
    )
    async def get_domain_expert_reference(
        capability_id: str,
        capability_version_id: str,
        skill_id: str,
        reference_id: str,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        try:
            return state.capability_packages.get_domain_reference(
                capability_id,
                capability_version_id,
                skill_id,
                reference_id,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="领域引用文件不存在") from exc
        except (OSError, RuntimeError, ValueError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.put("/api/v1/admin/domain-experts/{capability_id}/skill")
    async def upsert_markdown_domain_skill(
        capability_id: str,
        body: MarkdownDomainSkillUpsert,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            installed = state.native_releases.install_markdown_domain(
                capability_id=capability_id,
                version=body.version,
                capability_name=body.capability_name,
                skill_id=body.skill_id,
                skill_name=body.skill_name,
                description=body.description,
                applicability=body.applicability,
                instructions=body.instructions,
                source_url=body.source_url,
                source_revision=body.source_revision,
                source_updated=body.source_updated,
                references=[item.model_dump() for item in body.references],
                actor=admin,
            )
            activation: dict[str, Any] | None = None
            if body.agent_id:
                before = state.agent_registry.get_agent(body.agent_id)
                source_version_id = before.get("draft_version_id") or before.get("active_version_id")
                source_version = next(item for item in before["versions"] if item["id"] == source_version_id)
                prompt_bundle_version_id = source_version.get("prompt_bundle_version_id")
                updated = state.agent_registry.update_draft(
                    body.agent_id,
                    admin,
                    capability_bindings=[
                        {
                            "capability_version_id": installed["capability_version_id"],
                            "role": "domain",
                            "position": 0,
                        }
                    ],
                )
                draft = next(
                    item for item in updated["versions"] if item["id"] == updated["draft_version_id"]
                )
                if draft.get("prompt_bundle_version_id") != prompt_bundle_version_id:
                    raise RuntimeError("Markdown Skill update changed the Agent prompt binding")
                validation = state.agent_registry.validate_draft(body.agent_id, admin)
                if (
                    body.probe_model_if_needed
                    and validation["status"] != "passed"
                    and {item.get("code") for item in validation["findings"]} == {"model_probe_not_passed"}
                ):
                    model_version_id = updated["current_model"]["model_profile_version_id"]
                    await state.model_registry.probe(model_version_id, admin)
                    validation = state.agent_registry.validate_draft(body.agent_id, admin)
                activation = {
                    "agent_id": body.agent_id,
                    "draft_version_id": updated["draft_version_id"],
                    "draft_digest": draft["digest"],
                    "prompt_bundle_version_id": prompt_bundle_version_id,
                    "validation": validation,
                    "published": False,
                }
                if body.publish_agent:
                    if validation["status"] != "passed":
                        raise AgentValidationError(validation["findings"])
                    published = state.agent_registry.publish(body.agent_id, admin, body.note)
                    active = next(
                        item for item in published["versions"] if item["id"] == published["active_version_id"]
                    )
                    activation.update(
                        {
                            "active_version_id": published["active_version_id"],
                            "active_version": active["version"],
                            "active_digest": active["digest"],
                            "published": True,
                        }
                    )
            return {"skill": installed, "activation": activation}
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent or dependency not found") from exc
        except AgentValidationError as exc:
            raise HTTPException(
                status_code=409,
                detail={"message": str(exc), "findings": exc.findings},
            ) from exc
        except (OSError, RuntimeError, ValueError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.delete("/api/v1/admin/domain-experts/{capability_id}")
    async def delete_domain_expert(
        capability_id: str,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.capability_packages.delete_package(capability_id, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="领域能力不存在") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/external-cli-bindings")
    async def list_external_cli_bindings(_: str = Depends(require_viewer)) -> dict[str, Any]:
        return {"items": state.external_dependencies.list_bindings()}

    @app.post("/api/v1/admin/external-cli-bindings/preview")
    async def preview_external_cli_binding(
        body: ExternalCliPreviewInput,
        _: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.external_dependencies.preview(
                body.dependency_id,
                body.contract,
                body.command,
                version_arguments=tuple(body.version_arguments),
            )
        except ExternalDependencyError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/external-cli-bindings/configure")
    async def configure_external_cli_binding(
        body: ExternalCliConfigureInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.external_dependencies.configure(
                body.dependency_id,
                body.contract,
                body.command,
                admin,
                allowed_subcommands=tuple(body.allowed_subcommands),
                timeout_seconds=body.timeout_seconds,
                max_output_bytes=body.max_output_bytes,
                version_arguments=tuple(body.version_arguments),
            )
        except ExternalDependencyError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/external-cli-bindings/disable")
    async def disable_external_cli_binding(
        body: ExternalCliDisableInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.external_dependencies.disable(body.dependency_id, body.contract, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="active CLI binding not found") from exc

    @app.post("/api/v1/admin/native-releases/install")
    async def install_native_release(
        body: NativeReleaseInstallInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.native_releases.install_artifact(
                body.artifact_digest,
                admin,
                trust_code=body.trust_code,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Native release artifact not found") from exc
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        except (OSError, RuntimeError, ValueError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/agent-profiles/{profile_id}/versions/{profile_version}")
    async def get_agent_profile(
        profile_id: str,
        profile_version: str,
        digest: str,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        try:
            return state.agent_profiles.get(profile_id, profile_version, digest).public_view(
                include_composition=True
            )
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.get("/api/v1/admin/capability-packs")
    async def list_capability_packs(_: str = Depends(require_viewer)) -> dict[str, Any]:
        try:
            discoveries = state.pack_discoveries()
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return {"items": state.capabilities.list_packs(), "discoveries": discoveries}

    @app.post("/api/v1/admin/capability-packs/preview")
    async def preview_capability_pack_install(
        body: PackSelectionInput,
        _: str = Depends(require_operator),
    ) -> dict[str, Any]:
        try:
            return state.preview_pack_install(body.id, body.version, body.content_digest)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="受控目录中没有该能力包版本") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/capability-packs/install")
    async def install_capability_pack(
        body: PackSelectionInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.install_pack(
                body.id,
                body.version,
                body.content_digest,
                admin,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="受控目录中没有该能力包版本") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/capability-packs/{pack_id}")
    async def get_capability_pack(pack_id: str, _: str = Depends(require_viewer)) -> dict[str, Any]:
        try:
            return state.capabilities.get_pack(pack_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Capability Pack not found") from exc

    @app.post("/api/v1/admin/capability-pack-versions/{pack_version_id}/validate")
    async def validate_capability_pack(
        pack_version_id: str, admin: str = Depends(require_operator)
    ) -> dict[str, Any]:
        try:
            return state.capabilities.validate_pack_version(pack_version_id, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Capability Pack version not found") from exc

    @app.post("/api/v1/admin/capability-packs/sync-loaded")
    async def sync_loaded_capability_packs(
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.capabilities.sync_loaded_catalog(admin)
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/capability-packs/{pack_id}/status")
    async def set_capability_pack_status(
        pack_id: str,
        body: PackStatusInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.capabilities.set_pack_status(
                pack_id,
                body.status,
                admin,
                reason=body.reason,
                replacement_pack_version_id=body.replacement_pack_version_id,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Capability Pack not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/prompt-bundles")
    async def list_prompt_bundles(_: str = Depends(require_viewer)) -> dict[str, Any]:
        return {"items": state.capabilities.list_prompt_bundles()}

    @app.post("/api/v1/admin/prompt-bundles", status_code=201)
    async def create_prompt_bundle(
        body: PromptBundleCreate, admin: str = Depends(require_admin)
    ) -> dict[str, Any]:
        try:
            return state.capabilities.create_prompt_bundle(
                body.id,
                body.name,
                body.description,
                body.content,
                body.source_ref,
                admin,
            )
        except (ValueError, KeyError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/prompt-bundles/{bundle_id}/versions", status_code=201)
    async def create_prompt_bundle_version(
        bundle_id: str,
        body: PromptVersionCreate,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.capabilities.create_prompt_version(bundle_id, body.content, body.source_ref, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Prompt Bundle not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/prompt-bundles/{bundle_id}/status")
    async def set_prompt_bundle_status(
        bundle_id: str,
        body: PromptStatusInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.capabilities.set_prompt_status(bundle_id, body.status, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Prompt Bundle not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/tool-providers")
    async def list_tool_providers(_: str = Depends(require_viewer)) -> dict[str, Any]:
        return {"items": state.tool_providers.list_providers()}

    @app.get("/api/v1/admin/tool-providers/{provider_id}")
    async def get_tool_provider(provider_id: str, _: str = Depends(require_viewer)) -> dict[str, Any]:
        try:
            return state.tool_providers.get_provider(provider_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Tool Provider not found") from exc

    @app.post("/api/v1/admin/tool-providers", status_code=201)
    async def create_tool_provider(
        body: ToolProviderCreate, admin: str = Depends(require_admin)
    ) -> dict[str, Any]:
        try:
            return state.tool_providers.create_provider(
                body.id,
                body.name,
                body.provider_type,
                body.connection_ref,
                body.secret_ref_id,
                admin,
            )
        except (KeyError, ValueError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/tool-providers/{provider_id}/schema-versions", status_code=201)
    async def create_tool_schema_version(
        provider_id: str,
        body: ToolSchemaCreate,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.tool_providers.create_schema_version(provider_id, body.schema_definition, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Tool Provider not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/tool-providers/{provider_id}/probe")
    async def probe_tool_provider(provider_id: str, admin: str = Depends(require_operator)) -> dict[str, Any]:
        try:
            return await state.tool_providers.probe(provider_id, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Tool Provider not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.put("/api/v1/admin/tool-providers/{provider_id}/stdio-config")
    async def configure_tool_provider_stdio(
        provider_id: str,
        body: ToolProviderStdioConfigInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.tool_providers.configure_stdio(
                provider_id,
                {
                    "transport": "stdio",
                    "command": body.command,
                    "cwd": body.cwd,
                    "environment": body.environment,
                    "secret_env": body.secret_env,
                    "timeout_seconds": body.timeout_seconds,
                },
                body.secret_ref_id,
                admin,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Tool Provider 或 Secret Ref 不存在") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.put("/api/v1/admin/tool-providers/{provider_id}/http-config")
    async def configure_tool_provider_http(
        provider_id: str,
        body: ToolProviderHTTPConfigInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            state.tool_providers.configure_http(
                provider_id,
                {
                    "transport": "streamable_http",
                    "endpoint": body.endpoint,
                    "timeout_seconds": body.timeout_seconds,
                    "max_response_bytes": body.max_response_bytes,
                },
                admin,
            )
            # Saving a Connector is an activation action: discover its current
            # catalog immediately instead of requiring a hidden restart/probe.
            return await state.tool_providers.connect(provider_id, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Tool Provider 不存在") from exc
        except (ValueError, OSError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail="MCP 连接或协议校验失败") from exc

    @app.post("/api/v1/admin/tool-providers/{provider_id}/connect")
    async def connect_tool_provider(
        provider_id: str,
        _: ToolProviderConnectInput,
        admin: str = Depends(require_operator),
    ) -> dict[str, Any]:
        try:
            return await state.tool_providers.connect(provider_id, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Tool Provider 不存在") from exc
        except (ValueError, OSError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail="MCP 连接或协议校验失败") from exc

    @app.post("/api/v1/admin/tool-providers/{provider_id}/status")
    async def set_tool_provider_status(
        provider_id: str,
        body: ToolProviderStatusInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.tool_providers.set_status(provider_id, body.status, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Tool Provider not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/tools")
    async def list_tools(_: str = Depends(require_viewer)) -> dict[str, Any]:
        items = state.tool_providers.list_tools()
        for item in items:
            system_required = is_system_required_tool(str(item.get("name", "")))
            item["selection_mode"] = "system_required" if system_required else "optional"
            item["user_selectable"] = not system_required
        return {"items": items}

    @app.get("/api/v1/admin/agents/{agent_id}/usage")
    async def get_agent_usage(
        agent_id: str,
        days: int = 30,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        if not 1 <= days <= 90:
            raise HTTPException(status_code=422, detail="days 必须在 1 到 90 之间")
        try:
            return state.operations.agent_usage_summary(agent_id, days=days)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc

    @app.get("/api/v1/admin/agents/{agent_id}")
    async def get_agent(agent_id: str, _: str = Depends(require_viewer)) -> dict[str, Any]:
        try:
            return state.agent_registry.get_agent(agent_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc

    @app.post("/api/v1/admin/agents", status_code=201)
    async def create_agent(body: AgentCreate, admin: str = Depends(require_admin)) -> dict[str, Any]:
        if body.agent_profile:
            controlled_fields = {
                "prompt_bundle_version_id",
                "runtime_policy",
                "context_policy",
                "channel_policy",
                "review_policy",
                "presentation_policy",
                "config",
                "pack_version_ids",
                "capability_bindings",
            }
            conflicting = sorted(controlled_fields & body.model_fields_set)
            if conflicting:
                raise HTTPException(
                    status_code=409,
                    detail=f"原生 Agent Profile 不能同时覆盖这些字段：{', '.join(conflicting)}",
                )
            try:
                return state.agent_registry.create_from_profile(
                    body.agent_profile.id,
                    body.agent_profile.version,
                    body.agent_profile.digest,
                    body.id,
                    body.name,
                    admin,
                    description=body.description,
                    language=body.language,
                    model_profile_id=body.model_profile_id,
                    persona_id=body.persona_id,
                )
            except (KeyError, ValueError, RuntimeError) as exc:
                raise HTTPException(status_code=409, detail=str(exc)) from exc
        values = body.model_dump(exclude_none=True)
        agent_id = values.pop("id")
        name = values.pop("name")
        values.pop("agent_profile", None)
        try:
            return state.agent_registry.create_agent(agent_id, name, admin, **values)
        except (KeyError, ValueError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.patch("/api/v1/admin/agents/{agent_id}/draft")
    async def update_agent_draft(
        agent_id: str, body: AgentDraftUpdate, admin: str = Depends(require_admin)
    ) -> dict[str, Any]:
        try:
            return state.agent_registry.update_draft(agent_id, admin, **body.model_dump(exclude_unset=True))
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent or dependency not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.put("/api/v1/admin/agents/{agent_id}/current-model")
    async def update_agent_current_model(
        agent_id: str,
        body: AgentCurrentModelUpdate,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.agent_registry.set_current_model(
                agent_id,
                body.model_profile_id,
                admin,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent or model resource not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.put("/api/v1/admin/agents/{agent_id}/current-persona")
    async def update_agent_current_persona(
        agent_id: str,
        body: AgentCurrentPersonaUpdate,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.agent_registry.set_current_persona(
                agent_id,
                body.persona_id,
                admin,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/agents/{agent_id}/draft/profile-preview")
    async def preview_agent_profile(
        agent_id: str,
        body: AgentProfileApplyInput,
        _: str = Depends(require_operator),
    ) -> dict[str, Any]:
        try:
            return state.agent_registry.preview_profile(
                agent_id,
                body.profile.id,
                body.profile.version,
                body.profile.digest,
                expected_draft_digest=body.expected_draft_digest,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent or Agent Profile not found") from exc
        except (ValueError, RuntimeError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/agents/{agent_id}/draft/apply-profile")
    async def apply_agent_profile(
        agent_id: str,
        body: AgentProfileApplyInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.agent_registry.apply_profile(
                agent_id,
                body.profile.id,
                body.profile.version,
                body.profile.digest,
                admin,
                expected_draft_digest=body.expected_draft_digest,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent or Agent Profile not found") from exc
        except (ValueError, RuntimeError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/agents/{agent_id}/validate")
    async def validate_agent_draft(agent_id: str, admin: str = Depends(require_operator)) -> dict[str, Any]:
        try:
            return state.agent_registry.validate_draft(agent_id, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/agents/{agent_id}/publish")
    async def publish_agent(
        agent_id: str, body: PublishInput, admin: str = Depends(require_admin)
    ) -> dict[str, Any]:
        try:
            return state.agent_registry.publish(agent_id, admin, body.note)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc
        except AgentValidationError as exc:
            raise HTTPException(
                status_code=409,
                detail={"message": str(exc), "findings": exc.findings},
            ) from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/agents/{agent_id}/rollback")
    async def rollback_agent(
        agent_id: str, body: RollbackInput, admin: str = Depends(require_admin)
    ) -> dict[str, Any]:
        try:
            return state.agent_registry.rollback(agent_id, body.target_version_id, admin, body.note)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc
        except AgentValidationError as exc:
            raise HTTPException(
                status_code=409,
                detail={"message": str(exc), "findings": exc.findings},
            ) from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/agents/{agent_id}/clone", status_code=201)
    async def clone_agent(
        agent_id: str, body: CloneInput, admin: str = Depends(require_admin)
    ) -> dict[str, Any]:
        try:
            return state.agent_registry.clone(agent_id, body.id, body.name, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/agents/{agent_id}/status")
    async def set_agent_status(
        agent_id: str, body: AgentStatusInput, admin: str = Depends(require_admin)
    ) -> dict[str, Any]:
        try:
            return state.agent_registry.set_status(agent_id, body.status, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/default-agent")
    async def set_default_agent(
        body: DefaultAgentInput, admin: str = Depends(require_admin)
    ) -> dict[str, Any]:
        try:
            state.agent_registry.set_default_agent(body.agent_id, admin)
            return {"agent_id": body.agent_id}
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/cases/{case_id}/agent-version-pin")
    async def pin_case_agent_version(
        case_id: str,
        body: CaseVersionPinInput,
        admin: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.agent_registry.pin_case_version(case_id, body.agent_version_id, admin)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Case not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/agents/{agent_id}/diff")
    async def diff_agent_versions(
        agent_id: str,
        from_version_id: str,
        to_version_id: str,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        try:
            return state.agent_registry.diff_versions(agent_id, from_version_id, to_version_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent version not found") from exc

    @app.post("/api/v1/cases", status_code=201)
    async def create_case(body: CaseCreate, actor: str = Depends(runtime_actor)) -> dict[str, Any]:
        try:
            if body.content is None:
                return {
                    "case": state.service.create_empty_case(body.agent_id),
                    "run": None,
                }
            case, run = await state.service.create_case_and_message(
                body.content,
                actor,
                body.agent_id,
                body.occurred_at,
            )
            return {"case": case, "run": run.__dict__}
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/cases")
    async def list_cases(_: str = Depends(case_reader)) -> dict[str, Any]:
        return {"items": state.repository.list_cases()}

    @app.get("/api/v1/cases/{case_id}")
    async def get_case(case_id: str, _: str = Depends(case_reader)) -> dict[str, Any]:
        try:
            case = state.repository.get_case(case_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="case not found") from exc
        return {
            "case": case,
            "messages": state.repository.list_messages(case_id),
            "runs": state.repository.list_runs(case_id),
            "tool_calls": state.repository.list_tool_calls(case_id),
            "evidence": state.repository.list_evidence(case_id),
            "snapshots": state.repository.list_snapshots(case_id),
            "artifacts": state.artifacts.list_for_case(case_id),
            "feedback": state.repository.list_feedback(case_id),
            "actions": state.repository.list_actions(case_id=case_id),
            "events": state.repository.list_events(case_id),
        }

    @app.get("/api/v1/cases/{case_id}/artifacts/{artifact_id}")
    async def get_case_artifact(
        case_id: str,
        artifact_id: str,
        _: str = Depends(case_reader),
    ) -> Response:
        try:
            item = state.artifacts.read_content(artifact_id, case_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="artifact not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=410, detail=str(exc)) from exc
        return Response(
            content=item["content"],
            media_type=str(item["media_type"]),
            headers={
                "ETag": f'"{item["sha256"]}"',
                "Content-Disposition": f'inline; filename="{artifact_id}"',
            },
        )

    @app.post("/api/v1/cases/{case_id}/attachments", status_code=201)
    async def upload_case_attachment(
        case_id: str,
        request: Request,
        _: str = Depends(runtime_actor),
    ) -> dict[str, Any]:
        try:
            state.repository.get_case(case_id)
            resolved = state.runtime_resolver.resolve(case_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="case not found") from exc
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        if not resolved.snapshot.get("model", {}).get("capability_observed", {}).get("vision"):
            raise HTTPException(status_code=409, detail="case model has not enabled vision")
        media_type = request.headers.get("content-type", "").split(";", 1)[0].strip().lower()
        try:
            descriptor = state.artifacts.write_image(
                await request.body(),
                case_id=case_id,
                declared_media_type=media_type,
            )
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        return {"attachment": descriptor}

    @app.post("/api/v1/cases/{case_id}/messages")
    async def add_message(
        case_id: str, body: MessageInput, actor: str = Depends(runtime_actor)
    ) -> dict[str, Any]:
        try:
            if body.image_artifact_ids:
                resolved = state.runtime_resolver.resolve(case_id)
                if not resolved.snapshot.get("model", {}).get("capability_observed", {}).get("vision"):
                    raise ValueError("case model has not enabled vision")
            result = await state.service.append_message(
                case_id,
                body.content,
                actor,
                body.image_artifact_ids,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="case not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return {"run": result.__dict__}

    @app.post("/api/v1/cases/{case_id}/new", status_code=201)
    async def new_case(case_id: str, actor: str = Depends(runtime_actor)) -> dict[str, Any]:
        try:
            case = state.service.new_case_for_api(case_id, actor)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="case not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return {"case": case}

    @app.get("/api/v1/cases/{case_id}/events")
    async def list_events(case_id: str, after: int = 0, _: str = Depends(case_reader)) -> dict[str, Any]:
        return {"items": state.repository.list_events(case_id, after)}

    @app.post("/api/v1/cases/{case_id}/feedback", status_code=201)
    async def add_feedback(
        case_id: str, body: FeedbackInput, actor: str = Depends(runtime_actor)
    ) -> dict[str, Any]:
        try:
            feedback = state.repository.add_feedback(
                case_id, actor, "resolution", body.value, body.note, "api"
            )
            state.service._schedule_review(case_id, feedback["id"])
            return feedback
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="case not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/reviews")
    async def list_reviews(
        status: str | None = None,
        agent_id: str | None = None,
        model_profile_version_id: str | None = None,
        capability_gap: str | None = None,
        created_from: str | None = None,
        created_to: str | None = None,
        limit: int = 50,
        offset: int = 0,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return state.repository.list_reviews_page(
            status,
            agent_id=agent_id,
            model_profile_version_id=model_profile_version_id,
            capability_gap=capability_gap,
            created_from=created_from,
            created_to=created_to,
            limit=limit,
            offset=offset,
        )

    @app.get("/api/v1/reviews/{review_id}")
    async def get_review(review_id: str, _: str = Depends(require_viewer)) -> dict[str, Any]:
        try:
            return state.repository.get_review(review_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="review not found") from exc

    @app.post("/api/v1/reviews/{review_id}/decision")
    async def decide_review(
        review_id: str, body: ReviewDecision, reviewer: str = Depends(require_reviewer)
    ) -> dict[str, Any]:
        try:
            return state.repository.decide_review(review_id, body.decision, reviewer, body.note)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="review not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/review-engine-profiles")
    async def list_review_engine_profiles(
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return {"items": state.review_engines.list_profiles()}

    @app.post(
        "/api/v1/admin/review-engine-profiles/{profile_id}/versions",
        status_code=201,
    )
    async def create_review_engine_version(
        profile_id: str,
        body: ReviewEngineVersionCreate,
        actor: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.review_engines.create_version(
                profile_id,
                actor,
                config=body.config or None,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Review Engine profile not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/admin/review-engine-profiles/{profile_id}/versions/{version_id}/activate")
    async def activate_review_engine_version(
        profile_id: str,
        version_id: str,
        actor: str = Depends(require_admin),
    ) -> dict[str, Any]:
        try:
            return state.review_engines.activate_version(profile_id, version_id, actor)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Review Engine version not found") from exc

    @app.get("/api/v1/research/digests")
    async def list_research_digests(
        agent_id: str | None = None,
        status: str | None = None,
        limit: int = 20,
        offset: int = 0,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return state.research.list_digests_page(
            agent_id=agent_id,
            status=status,
            limit=limit,
            offset=offset,
        )

    @app.post("/api/v1/research/digests", status_code=201)
    async def create_research_digest(
        body: ResearchGenerate,
        actor: str = Depends(require_reviewer),
    ) -> dict[str, Any]:
        try:
            return state.research.generate(body.agent_id, actor)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/research/digests/{digest_id}")
    async def get_research_digest(
        digest_id: str,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        try:
            return state.research.get_digest(digest_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Research Digest not found") from exc

    @app.post("/api/v1/research/digests/{digest_id}/decision")
    async def decide_research_digest(
        digest_id: str,
        body: ResearchDecision,
        actor: str = Depends(require_reviewer),
    ) -> dict[str, Any]:
        try:
            return state.research.decide_digest(
                digest_id,
                body.decision,
                actor,
                body.note,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Research Digest not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/research/candidates/{candidate_id}/decision")
    async def decide_research_candidate(
        candidate_id: str,
        body: CandidateDecision,
        actor: str = Depends(require_reviewer),
    ) -> dict[str, Any]:
        try:
            return state.research.decide_candidate(candidate_id, body.decision, actor)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Research candidate not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/admin/candidate-attempts")
    async def list_candidate_attempts(
        status: str | None = None,
        limit: int = 20,
        offset: int = 0,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return state.candidates.list_attempts_page(status, limit=limit, offset=offset)

    @app.get("/api/v1/admin/candidate-preflight")
    async def candidate_preflight(
        agent_id: str = SUWEN_AGENT_ID,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        try:
            return state.candidate_runner.preflight(agent_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Agent not found") from exc

    @app.get("/api/v1/admin/candidate-attempts/{attempt_id}")
    async def get_candidate_attempt(
        attempt_id: str,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        try:
            return state.candidates.get_attempt(attempt_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Candidate attempt not found") from exc

    @app.post("/api/v1/admin/candidate-attempts/{attempt_id}/human-review")
    async def review_candidate_attempt(
        attempt_id: str,
        body: CandidateHumanReview,
        reviewer: str = Depends(require_reviewer),
    ) -> dict[str, Any]:
        try:
            return state.candidates.human_review(
                attempt_id,
                reviewer,
                body.decision,
                body.scorecard_digest,
                body.episode_dimensions,
                body.skill_influence_observed,
                body.tool_influence_observed,
                body.influence_notes,
                body.note,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Candidate attempt not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/cases/{case_id}/actions/prepare", status_code=201)
    async def prepare_action(
        case_id: str, body: ActionPrepare, actor: str = Depends(runtime_actor)
    ) -> dict[str, str]:
        try:
            state.repository.get_case(case_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="case not found") from exc
        try:
            resolved = state.runtime_resolver.resolve(case_id)
            prepared, evidence = await state.actions.prepare_for_request(
                case_id,
                body.tool_name,
                body.arguments,
                requester_ref=actor,
                prepared_agent_version_id=resolved.snapshot["agent_version_id"],
                tools=resolved.tools,
            )
            if prepared is None:
                raise ValueError(evidence.summary)
            return prepared
        except (PolicyError, RuntimeError, ValueError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/actions/{action_id}/confirm")
    async def confirm_action(
        action_id: str, body: ActionConfirm, actor: str = Depends(runtime_actor)
    ) -> dict[str, str]:
        try:
            action = state.repository.get_action(action_id)
            resolved = state.runtime_resolver.resolve(action["case_id"], action["prepared_agent_version_id"])
            return await state.actions.confirm_and_commit(
                action_id,
                body.confirmation,
                requester_ref=actor,
                agent_version_id=resolved.snapshot["agent_version_id"],
                tools=resolved.tools,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="action not found") from exc
        except (RuntimeError, ValueError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.post("/api/v1/cases/{case_id}/actions/{action_id}/confirm")
    async def confirm_case_action(
        case_id: str,
        action_id: str,
        body: ActionConfirm,
        actor: str = Depends(runtime_actor),
    ) -> dict[str, str]:
        try:
            action = state.repository.get_action(action_id)
            resolved = state.runtime_resolver.resolve(action["case_id"], action["prepared_agent_version_id"])
            return await state.actions.confirm_and_commit(
                action_id,
                body.confirmation,
                requester_ref=actor,
                case_id=case_id,
                agent_version_id=resolved.snapshot["agent_version_id"],
                tools=resolved.tools,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="action not found") from exc
        except (RuntimeError, ValueError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/v1/actions")
    async def list_actions(
        case_id: str | None = None,
        status: str | None = None,
        _: str = Depends(require_viewer),
    ) -> dict[str, Any]:
        return {"items": state.repository.list_actions(case_id, status)}

    @app.get("/api/v1/actions/{action_id}")
    async def get_action(action_id: str, _: str = Depends(require_viewer)) -> dict[str, Any]:
        try:
            return state.repository.get_action(action_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="action not found") from exc

    async def handle_feishu_event(
        request: Request,
        managed_instance_id: str | None = None,
    ) -> JSONResponse:
        if managed_instance_id is None and not state.settings.feishu.enabled:
            return JSONResponse({"accepted": False, "reason": "channel_disabled"})
        raw = await request.body()
        instance_hint: str | None = managed_instance_id
        event_hint: str | None = None
        try:
            payload = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise HTTPException(status_code=400, detail="invalid JSON") from exc
        try:
            if not isinstance(payload, dict):
                raise ChannelDrop("invalid_payload")
            header = payload.get("header", {}) if isinstance(payload, dict) else {}
            observed_instance = (
                str(
                    header.get("app_id") or (payload.get("app_id") if isinstance(payload, dict) else "") or ""
                )
                or None
            )
            instance_hint = instance_hint or observed_instance
            event_hint = str(header.get("event_id") or payload.get("event_id") or "") or None
            runtime_config = (
                state.channel_registry.resolve_feishu_runtime(managed_instance_id)
                if managed_instance_id is not None
                else None
            )
            adapter = FeishuAdapter(runtime_config) if runtime_config else state.feishu
            payload = adapter.decode(dict(request.headers), raw, payload)
            decoded_header = payload.get("header", {})
            observed_instance = (
                str(decoded_header.get("app_id") or payload.get("app_id") or "") or observed_instance
            )
            instance_hint = instance_hint or observed_instance
            event_hint = str(decoded_header.get("event_id") or payload.get("event_id") or "") or event_hint
            if payload.get("type") == "url_verification":
                return JSONResponse({"challenge": payload.get("challenge", "")})
            event = adapter.normalize(payload)
            route_ref = str(payload.get("header", {}).get("route_ref") or "") or None
            if managed_instance_id is not None:
                assert runtime_config is not None
                expected_instances = {
                    value for value in (runtime_config.external_instance_ref, runtime_config.app_id) if value
                }
                if (
                    expected_instances
                    and event.channel_instance != "default"
                    and event.channel_instance not in expected_instances
                ):
                    raise ChannelDrop("channel_instance_mismatch")
                resolved_instance = managed_instance_id
                resolved_agent = state.channel_registry.resolve_agent(
                    managed_instance_id,
                    "feishu",
                    route_ref,
                )
            else:
                resolved_instance, resolved_agent = state.channel_registry.resolve_external_agent(
                    "feishu",
                    event.channel_instance,
                    route_ref,
                )
                runtime_config = state.channel_registry.resolve_feishu_runtime(resolved_instance)
            assert runtime_config is not None
            event = replace(
                event,
                channel_instance=resolved_instance,
                agent_id=resolved_agent,
                reply_address={
                    **event.reply_address,
                    "channel_instance": resolved_instance,
                    "channel_revision": runtime_config.revision,
                    "channel_transport_identity": runtime_config.transport_identity,
                },
            )
            event = await state.materialize_feishu_resources(event, runtime_config)
            result = await state.service.handle_inbound(
                event,
                on_admitted=lambda admitted: state.add_feishu_lifecycle_reaction(
                    admitted,
                    "Typing",
                ),
            )
        except ChannelDrop as exc:
            state.channel_registry.record_ingress(
                instance_hint,
                event_hint,
                "rejected",
                exc.reason,
            )
            return JSONResponse({"accepted": False, "reason": exc.reason})
        except ChannelResolutionError as exc:
            state.channel_registry.record_ingress(
                instance_hint,
                event_hint,
                "rejected",
                str(exc),
            )
            return JSONResponse({"accepted": False, "reason": str(exc)})
        except InboundEventInProgress:
            return JSONResponse({"accepted": True, "duplicate": True, "state": "processing"})
        except InboundNotAdmitted as exc:
            state.channel_registry.record_ingress(
                instance_hint,
                event_hint,
                "rejected",
                str(exc),
            )
            return JSONResponse({"accepted": False, "reason": str(exc)})
        except ValueError:
            return JSONResponse(
                {"accepted": False, "reason": "controlled_action_confirmation_rejected"},
                status_code=409,
            )
        if result["run"] is not None:
            result["run"] = result["run"].__dict__
        state.channel_registry.record_ingress(
            event.channel_instance,
            event.event_id,
            "duplicate" if result.get("duplicate") else "accepted",
        )
        return JSONResponse({"accepted": True, **result})

    @app.post("/api/v1/feishu/events")
    async def feishu_events(request: Request) -> JSONResponse:
        """Compatibility ingress; managed instances should use their exact ingress path."""

        return await handle_feishu_event(request)

    @app.post("/api/v1/channels/{instance_id}/feishu/events")
    async def managed_feishu_events(instance_id: str, request: Request) -> JSONResponse:
        return await handle_feishu_event(request, instance_id)

    @app.post("/api/v1/internal/tick")
    async def tick(_: str = Depends(require_operator)) -> dict[str, Any]:
        captured_before = len(getattr(state.sender, "deliveries", []))
        jobs = await state.scheduler.run_once()
        captured_after = len(getattr(state.sender, "deliveries", []))
        closed = state.lifecycle.close_inactive()
        return {
            "jobs": jobs,
            "captured_deliveries": captured_after - captured_before,
            "closed_cases": closed,
        }

    web_dir = bundled_web_root()

    @app.get("/assets/investigation-concepts-and-glossary.md")
    async def investigation_glossary() -> Response:
        return Response(
            bundled_investigation_glossary().read_text(encoding="utf-8"),
            media_type="text/markdown",
        )

    glossary_assets = bundled_investigation_glossary_assets_root()
    if glossary_assets.exists():
        app.mount("/assets/glossary", StaticFiles(directory=glossary_assets), name="glossary-assets")

    if web_dir.exists():
        app.mount("/assets", StaticFiles(directory=web_dir), name="assets")

    @app.get("/", response_class=HTMLResponse)
    async def index() -> str:
        return (web_dir / "index.html").read_text(encoding="utf-8")

    return app
