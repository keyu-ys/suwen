from __future__ import annotations

import fcntl
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import uuid
import zipfile
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from email.parser import BytesParser
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import urljoin, urlsplit

import httpx

from .release import product_release_label

SCHEMA_VERSION = "suwen-install.v1"
ACTIVATION_SCHEMA_VERSION = "suwen-runtime-activation.v1"
RELEASE_CHANNEL_SCHEMA_VERSION = "suwen-release-channel.v1"
RELEASE_RETENTION_SCHEMA_VERSION = "suwen-release-retention.v1"
RELEASE_RETENTION_GENERATIONS = 3
_MAX_RELEASE_CHANNEL_MANIFEST_BYTES = 64 * 1024
_MAX_RELEASE_WHEEL_BYTES = 1024 * 1024 * 1024
InstallRunner = Callable[[Path, Path], None]


@dataclass(frozen=True)
class RuntimeLayout:
    """Filesystem contract for one user-local Suwen installation."""

    home: Path

    @classmethod
    def resolve(cls, value: str | Path | None = None) -> RuntimeLayout:
        configured = value or os.getenv("SUWEN_HOME") or (Path.home() / ".suwen")
        raw = Path(configured).expanduser().absolute()
        if raw == Path(raw.anchor) or raw == Path.home().absolute():
            raise ValueError("Suwen home must be a dedicated directory, not a filesystem or user root")
        if raw.exists() and raw.is_symlink():
            raise ValueError("Suwen home cannot be a symbolic link")
        return cls(raw.resolve())

    @property
    def releases(self) -> Path:
        return self.home / "releases"

    @property
    def staging(self) -> Path:
        return self.home / ".staging"

    @property
    def workspace(self) -> Path:
        return self.home / "workspace"

    @property
    def config(self) -> Path:
        return self.workspace / "config" / "agent.toml"

    @property
    def data(self) -> Path:
        return self.workspace / ".data"

    @property
    def current(self) -> Path:
        return self.home / "current"

    @property
    def previous(self) -> Path:
        return self.home / "previous"

    @property
    def state_file(self) -> Path:
        return self.home / "install.json"

    @property
    def launcher(self) -> Path:
        return self.home / "bin" / "suwen"

    @property
    def lock_file(self) -> Path:
        return self.home / ".update.lock"

    @property
    def activation_file(self) -> Path:
        return self.data / "runtime" / "activation.json"

    def create_base(self) -> None:
        for path in (
            self.home,
            self.releases,
            self.staging,
            self.workspace,
            self.config.parent,
            self.data,
            self.data / "runtime",
            self.launcher.parent,
        ):
            path.mkdir(mode=0o700, parents=True, exist_ok=True)
            path.chmod(0o700)


class UpdateLock:
    def __init__(self, path: Path):
        self.path = path
        self._descriptor: int | None = None

    def __enter__(self) -> UpdateLock:
        descriptor = os.open(self.path, os.O_RDWR | os.O_CREAT, 0o600)
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            os.close(descriptor)
            raise RuntimeError("another Suwen install or update is already running") from exc
        self._descriptor = descriptor
        return self

    def __exit__(self, *_args: object) -> None:
        if self._descriptor is not None:
            fcntl.flock(self._descriptor, fcntl.LOCK_UN)
            os.close(self._descriptor)
            self._descriptor = None


class ReleaseManager:
    def __init__(
        self,
        layout: RuntimeLayout,
        *,
        install_runner: InstallRunner | None = None,
    ):
        self.layout = layout
        self.install_runner = install_runner or install_wheel

    def install(self, source: str | Path) -> dict[str, Any]:
        self.layout.create_base()
        with UpdateLock(self.layout.lock_file):
            if self._release_name(self.layout.current) is not None:
                raise ValueError("Suwen is already installed; use `suwen update`")
            return self._publish(source, operation="install")

    def update(self, source: str | Path | None = None) -> dict[str, Any]:
        self.layout.create_base()
        with UpdateLock(self.layout.lock_file):
            if self._release_name(self.layout.current) is None:
                raise ValueError("Suwen is not installed; run `suwen install --source ...`")
            selected = source if source is not None else self._configured_source()
            return self._publish(selected, operation="update")

    def rollback(self, release: str | None = None) -> dict[str, Any]:
        self.layout.create_base()
        with UpdateLock(self.layout.lock_file):
            current = self._release_name(self.layout.current)
            if current is None:
                raise ValueError("Suwen is not installed")
            target = release or self._release_name(self.layout.previous)
            if target is None:
                raise ValueError("no previous Suwen release is available")
            self._validate_release_name(target)
            target_path = self.layout.releases / target
            if not (target_path / "manifest.json").is_file():
                raise ValueError("requested Suwen release is unavailable")
            self._activate(target, previous=current)
            state = self._read_state()
            state.update(
                {
                    "current_release": target,
                    "previous_release": current,
                    "updated_at": _now(),
                }
            )
            _atomic_json(self.layout.state_file, state)
            activation = self._record_activation(current, target, operation="rollback")
            return self._result(
                "rollback",
                target,
                current,
                changed=True,
                activation=activation,
            )

    def status(self) -> dict[str, Any]:
        current = self._release_name(self.layout.current)
        previous = self._release_name(self.layout.previous)
        state = self._read_state(required=False)
        manifest: dict[str, Any] | None = None
        if current is not None:
            manifest = _read_json(self.layout.releases / current / "manifest.json")
        return {
            "schema_version": SCHEMA_VERSION,
            "installed": current is not None,
            "home": str(self.layout.home),
            "workspace": str(self.layout.workspace),
            "config": str(self.layout.config),
            "launcher": str(self.layout.launcher),
            "current_release": current,
            "previous_release": previous,
            "version": manifest.get("release_version") if manifest else None,
            "package_version": manifest.get("version") if manifest else None,
            "wheel_sha256": manifest.get("wheel_sha256") if manifest else None,
            "source": state.get("source"),
            "activation": self.activation_status(),
        }

    def activation_status(self) -> dict[str, Any] | None:
        if not self.layout.activation_file.is_file():
            return None
        payload = _read_json(self.layout.activation_file)
        if payload.get("schema_version") != ACTIVATION_SCHEMA_VERSION:
            raise ValueError("unsupported Suwen runtime activation metadata")
        return payload

    def request_worker_exit(
        self,
        activation_id: str,
        target_release: str,
        loaded_release: str | None,
    ) -> dict[str, Any]:
        activation = self.activation_status()
        if not activation or activation.get("activation_id") != activation_id:
            raise ValueError("runtime activation request is unavailable")
        if activation.get("target_release") != target_release:
            raise ValueError("runtime activation target does not match")
        if activation.get("from_release") != loaded_release:
            raise ValueError("runtime activation source does not match the loaded worker")
        if self._release_name(self.layout.current) != target_release:
            raise ValueError("runtime activation target is not current")
        if activation.get("status") not in {"awaiting_worker_exit", "worker_exit_requested"}:
            raise ValueError("runtime activation is not awaiting worker exit")
        activation.update({"status": "worker_exit_requested", "worker_exit_requested_at": _now()})
        _atomic_json(self.layout.activation_file, activation)
        return activation

    def complete_activation(
        self,
        activation_id: str,
        *,
        process_instance_id: str,
    ) -> dict[str, Any]:
        activation = self.activation_status()
        if not activation or activation.get("activation_id") != activation_id:
            raise ValueError("runtime activation request is unavailable")
        if self._release_name(self.layout.current) != activation.get("target_release"):
            raise ValueError("runtime activation target is not current")
        activation.update(
            {
                "status": "completed",
                "process_instance_id": process_instance_id,
                "completed_at": _now(),
            }
        )
        _atomic_json(self.layout.activation_file, activation)
        return activation

    def prune_superseded_releases(
        self,
        *,
        retain_generations: int = RELEASE_RETENTION_GENERATIONS,
    ) -> dict[str, Any]:
        """Keep the loaded release and two rollback generations after activation."""
        if (
            isinstance(retain_generations, bool)
            or not isinstance(retain_generations, int)
            or retain_generations < 3
        ):
            raise ValueError("Suwen release retention must keep at least three generations")
        self.layout.create_base()
        with UpdateLock(self.layout.lock_file):
            activation = self.activation_status()
            if activation and activation.get("status") != "completed":
                raise ValueError("Suwen releases cannot be pruned before activation completes")
            current = self._release_name(self.layout.current)
            if current is None:
                raise ValueError("Suwen is not installed")
            previous = self._release_name(self.layout.previous)
            entries: list[tuple[float, str, Path, dict[str, Any]]] = []
            skipped: list[str] = []
            for path in sorted(self.layout.releases.iterdir(), key=lambda item: item.name):
                if path.is_symlink() or not path.is_dir():
                    skipped.append(path.name)
                    continue
                try:
                    self._validate_release_name(path.name)
                    manifest = _read_json(path / "manifest.json")
                    created_at = manifest.get("created_at")
                    created = datetime.fromisoformat(created_at) if isinstance(created_at, str) else None
                    if (
                        manifest.get("schema_version") != "suwen-release.v1"
                        or manifest.get("release") != path.name
                        or created is None
                        or created.tzinfo is None
                    ):
                        raise ValueError("invalid release manifest")
                except (OSError, ValueError):
                    skipped.append(path.name)
                    continue
                entries.append((created.timestamp(), path.name, path, manifest))

            retained = {current}
            if previous is not None:
                retained.add(previous)
            for _created, name, _path, _manifest in sorted(entries, reverse=True):
                if len(retained) >= retain_generations:
                    break
                retained.add(name)

            retained_sources = {
                source
                for _created, name, _path, manifest in entries
                if name in retained
                for source in [self._managed_release_wheel(manifest)]
                if source is not None
            }
            state_source = self._managed_release_wheel(self._read_state(required=False))
            if state_source is not None:
                retained_sources.add(state_source)

            removed_releases: list[str] = []
            stale_sources: set[Path] = set()
            for _created, name, path, manifest in sorted(entries):
                if name in retained:
                    continue
                source = self._managed_release_wheel(manifest)
                if source is not None:
                    stale_sources.add(source)
                shutil.rmtree(path)
                removed_releases.append(name)

            removed_artifacts: list[str] = []
            for source in sorted(stale_sources - retained_sources):
                if source.is_file():
                    source.unlink()
                    removed_artifacts.append(str(source))

            return {
                "schema_version": RELEASE_RETENTION_SCHEMA_VERSION,
                "retain_generations": retain_generations,
                "retained_releases": sorted(retained),
                "removed_releases": removed_releases,
                "removed_artifacts": removed_artifacts,
                "skipped_unmanaged": sorted(set(skipped)),
            }

    def worker_handoff_command(
        self,
        loaded_release: str,
        arguments: Sequence[str],
    ) -> tuple[Path, list[str]]:
        activation = self.activation_status()
        if not activation or activation.get("status") != "worker_exit_requested":
            raise ValueError("runtime activation is not ready for worker handoff")
        if activation.get("from_release") != loaded_release:
            raise ValueError("runtime activation source does not match the loaded worker")
        target_release = activation.get("target_release")
        if not isinstance(target_release, str):
            raise ValueError("runtime activation target is invalid")
        if self._release_name(self.layout.current) != target_release:
            raise ValueError("runtime activation target is not current")
        executable = self.layout.releases / target_release / "venv" / "bin" / "suwen"
        if not executable.is_file() or not os.access(executable, os.X_OK):
            raise ValueError("runtime activation target executable is unavailable")
        return executable, [str(executable), *arguments]

    def _record_activation(
        self,
        from_release: str | None,
        target_release: str,
        *,
        operation: str,
    ) -> dict[str, Any]:
        activation = {
            "schema_version": ACTIVATION_SCHEMA_VERSION,
            "activation_id": f"activation-{uuid.uuid4().hex}",
            "operation": operation,
            "from_release": from_release,
            "target_release": target_release,
            "status": "awaiting_worker_exit" if from_release else "completed",
            "created_at": _now(),
        }
        _atomic_json(self.layout.activation_file, activation)
        return activation

    def _publish(self, source: str | Path, *, operation: str) -> dict[str, Any]:
        previous = self._release_name(self.layout.current)
        stage = self.layout.staging / f"update-{uuid.uuid4().hex}"
        stage.mkdir(mode=0o700)
        try:
            wheel, source_record, workspace_source = self._prepare_wheel(
                source,
                stage / "artifact",
            )
            package_name, version = inspect_wheel(wheel)
            if package_name.replace("_", "-").lower() != "suwen-agent":
                raise ValueError("Suwen release wheel must contain the suwen-agent package")
            digest = _sha256(wheel)
            release_version = product_release_label(version)
            release_name = f"{_safe_release_component(release_version)}-{digest[:12]}"
            release_path = self.layout.releases / release_name
            changed = release_name != previous
            if not release_path.exists():
                # Virtualenv entry points contain absolute interpreter paths, so the
                # environment must be created at its final location. It stays
                # unreachable from `current` until every check and manifest write passes.
                release_path.mkdir(mode=0o700)
                try:
                    self.install_runner(wheel, release_path)
                    executable = release_path / "venv" / "bin" / "suwen"
                    if not executable.is_file() or not os.access(executable, os.X_OK):
                        raise RuntimeError("installed Suwen release did not provide an executable")
                    _atomic_json(
                        release_path / "manifest.json",
                        {
                            "schema_version": "suwen-release.v1",
                            "release": release_name,
                            "package": package_name,
                            "version": version,
                            "release_version": release_version,
                            "wheel_sha256": digest,
                            "source": source_record,
                            "created_at": _now(),
                            "python": sys.version.split()[0],
                        },
                    )
                except BaseException:
                    shutil.rmtree(release_path, ignore_errors=True)
                    raise
            else:
                manifest = _read_json(release_path / "manifest.json")
                if manifest.get("wheel_sha256") != digest:
                    raise RuntimeError("existing Suwen release has conflicting content")

            self._initialize_workspace(workspace_source)
            self._install_launcher()
            if changed:
                self._activate(release_name, previous=previous)
            reported_previous = previous if changed else self._release_name(self.layout.previous)
            state = {
                "schema_version": SCHEMA_VERSION,
                "source": source_record,
                "current_release": release_name,
                "previous_release": reported_previous,
                "updated_at": _now(),
            }
            _atomic_json(self.layout.state_file, state)
            activation = None
            if changed and previous is not None:
                activation = self._record_activation(previous, release_name, operation=operation)
            elif not changed:
                pending = self.activation_status()
                if (
                    pending
                    and pending.get("target_release") == release_name
                    and pending.get("status") in {"awaiting_worker_exit", "worker_exit_requested"}
                ):
                    activation = pending
            return self._result(
                operation,
                release_name,
                reported_previous,
                changed=changed,
                activation=activation,
            )
        finally:
            shutil.rmtree(stage, ignore_errors=True)

    def _prepare_wheel(
        self,
        source: str | Path,
        artifact_dir: Path,
    ) -> tuple[Path, dict[str, Any], Path | None]:
        artifact_dir.mkdir(mode=0o700)
        source_text = str(source)
        if _is_http_url(source_text):
            wheel, source_identity = _download_release_channel(source_text, artifact_dir)
            return (
                wheel,
                {
                    "kind": "release-channel",
                    "url": source_text,
                    "source_identity": source_identity,
                },
                None,
            )
        source_path = Path(source).expanduser().absolute().resolve()
        if not source_path.exists():
            raise ValueError(f"Suwen update source does not exist: {source_path}")
        if source_path.is_file():
            if source_path.suffix != ".whl":
                raise ValueError("Suwen update source file must be a wheel")
            target = artifact_dir / source_path.name
            shutil.copy2(source_path, target)
            return target, _source_record(source_path), source_path
        if not (source_path / "pyproject.toml").is_file():
            raise ValueError("Suwen source checkout must contain pyproject.toml")
        uv = shutil.which("uv")
        if uv is None:
            raise RuntimeError("uv is required to build a Suwen source release")
        subprocess.run(
            [uv, "build", "--wheel", "--out-dir", str(artifact_dir), str(source_path)],
            check=True,
        )
        wheels = sorted(artifact_dir.glob("*.whl"))
        if len(wheels) != 1:
            raise RuntimeError("Suwen source build must produce exactly one wheel")
        return wheels[0], _source_record(source_path), source_path

    def _initialize_workspace(self, source: Path | None) -> None:
        if self.layout.config.exists():
            return
        template = (
            source / "config" / "runtime.example.toml"
            if source is not None and source.is_dir()
            else bundled_config_template()
        )
        if not template.is_file():
            raise RuntimeError("Suwen runtime configuration template is unavailable")
        descriptor = os.open(self.layout.config, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(descriptor, "wb") as target:
                target.write(template.read_bytes())
                target.flush()
                os.fsync(target.fileno())
                os.fchmod(target.fileno(), 0o600)
        except BaseException:
            self.layout.config.unlink(missing_ok=True)
            raise

    def _install_launcher(self) -> None:
        executable = self.layout.current / "venv" / "bin" / "suwen"
        payload = (f'#!/bin/sh\nset -eu\nexec {shlex.quote(str(executable))} "$@"\n').encode()
        if self.layout.launcher.exists():
            if self.layout.launcher.read_bytes() != payload:
                raise ValueError(f"refusing to overwrite unmanaged launcher: {self.layout.launcher}")
            return
        descriptor = os.open(self.layout.launcher, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o700)
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
                os.fchmod(handle.fileno(), 0o700)
        except BaseException:
            self.layout.launcher.unlink(missing_ok=True)
            raise

    def _activate(self, release: str, *, previous: str | None) -> None:
        self._validate_release_name(release)
        if previous is not None:
            self._replace_release_link(self.layout.previous, previous)
        self._replace_release_link(self.layout.current, release)

    def _replace_release_link(self, link: Path, release: str) -> None:
        self._validate_release_name(release)
        temporary = self.layout.home / f".{link.name}.{uuid.uuid4().hex}"
        temporary.symlink_to(Path("releases") / release)
        os.replace(temporary, link)

    def _release_name(self, link: Path) -> str | None:
        if not link.is_symlink():
            if link.exists():
                raise ValueError(f"managed Suwen path is not a symbolic link: {link}")
            return None
        target = os.readlink(link)
        relative = Path(target)
        if relative.parent != Path("releases"):
            raise ValueError(f"managed Suwen link escapes the releases directory: {link}")
        self._validate_release_name(relative.name)
        if not (self.layout.releases / relative.name).is_dir():
            raise ValueError(f"managed Suwen link targets a missing release: {link}")
        return relative.name

    @staticmethod
    def _validate_release_name(value: str) -> None:
        if not value or Path(value).name != value or value in {".", ".."}:
            raise ValueError("invalid Suwen release name")

    def _configured_source(self) -> str | Path:
        state = self._read_state()
        source = state.get("source")
        if not isinstance(source, dict):
            raise ValueError("installed Suwen source is missing; pass --source")
        if source.get("kind") == "release-channel" and isinstance(source.get("url"), str):
            return source["url"]
        if isinstance(source.get("path"), str):
            return Path(source["path"])
        raise ValueError("installed Suwen source is missing; pass --source")

    def _managed_release_wheel(self, payload: dict[str, Any]) -> Path | None:
        source = payload.get("source")
        if not isinstance(source, dict) or source.get("kind") != "wheel":
            return None
        value = source.get("path")
        if not isinstance(value, str) or not value:
            return None
        candidate = Path(value).expanduser().absolute().resolve()
        artifact_root = (self.layout.home / "artifacts").resolve()
        try:
            candidate.relative_to(artifact_root)
        except ValueError:
            return None
        return candidate if candidate.suffix == ".whl" else None

    def _read_state(self, *, required: bool = True) -> dict[str, Any]:
        if not self.layout.state_file.is_file():
            if required:
                raise ValueError("Suwen install metadata is unavailable")
            return {}
        state = _read_json(self.layout.state_file)
        if state.get("schema_version") != SCHEMA_VERSION:
            raise ValueError("unsupported Suwen install metadata")
        return state

    def _result(
        self,
        operation: str,
        release: str,
        previous: str | None,
        *,
        changed: bool,
        activation: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "operation": operation,
            "status": "activated" if changed else "already_current",
            "home": str(self.layout.home),
            "workspace": str(self.layout.workspace),
            "current_release": release,
            "previous_release": previous,
            "launcher": str(self.layout.launcher),
            "service_action": "not_performed",
            "service_restart_required": changed and operation != "install",
            "activation": activation,
        }


def loaded_release_name(layout: RuntimeLayout, executable: str | Path | None = None) -> str | None:
    candidate = Path(executable) if executable is not None else Path(__file__)
    candidate = candidate.absolute()
    try:
        relative = candidate.relative_to(layout.releases)
    except ValueError:
        return None
    if not relative.parts:
        return None
    release = relative.parts[0]
    ReleaseManager._validate_release_name(release)
    return release


def install_wheel(wheel: Path, release: Path) -> None:
    venv = release / "venv"
    subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    python = venv / "bin" / "python"
    subprocess.run(
        [
            str(python),
            "-m",
            "pip",
            "install",
            "--disable-pip-version-check",
            str(wheel),
        ],
        check=True,
    )
    executable = venv / "bin" / "suwen"
    subprocess.run(
        [str(executable), "--help"],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def inspect_wheel(path: Path) -> tuple[str, str]:
    try:
        with zipfile.ZipFile(path) as archive:
            metadata_files = [name for name in archive.namelist() if name.endswith(".dist-info/METADATA")]
            if len(metadata_files) != 1:
                raise ValueError("release wheel must contain exactly one METADATA file")
            metadata = BytesParser().parsebytes(archive.read(metadata_files[0]))
    except (OSError, zipfile.BadZipFile, KeyError) as exc:
        raise ValueError("Suwen release wheel is invalid") from exc
    name = metadata.get("Name")
    version = metadata.get("Version")
    if not name or not version:
        raise ValueError("Suwen release wheel metadata is incomplete")
    return name, version


def _is_http_url(value: str) -> bool:
    return value.startswith("http://") or value.startswith("https://")


def _download_release_channel(
    source_url: str,
    artifact_dir: Path,
) -> tuple[Path, dict[str, str]]:
    """Resolve one immutable wheel from a small LAN release-channel manifest."""

    manifest_url = _validated_release_channel_url(source_url)
    timeout = httpx.Timeout(connect=10.0, read=300.0, write=30.0, pool=10.0)
    try:
        with httpx.Client(timeout=timeout, follow_redirects=False, trust_env=False) as client:
            response = client.get(manifest_url)
            response.raise_for_status()
            if len(response.content) > _MAX_RELEASE_CHANNEL_MANIFEST_BYTES:
                raise ValueError("Suwen release-channel manifest is too large")
            try:
                manifest = response.json()
            except json.JSONDecodeError as exc:
                raise ValueError("Suwen release-channel manifest is invalid JSON") from exc
            artifact, source_identity = _validate_release_channel_manifest(manifest)
            artifact_url = urljoin(manifest_url, artifact["path"])
            _assert_same_release_channel_origin(manifest_url, artifact_url)
            target = artifact_dir / PurePosixPath(artifact["path"]).name
            digest = hashlib.sha256()
            size = 0
            with client.stream("GET", artifact_url) as wheel_response:
                wheel_response.raise_for_status()
                declared_length = wheel_response.headers.get("content-length")
                if declared_length is not None and int(declared_length) != artifact["size_bytes"]:
                    raise ValueError("Suwen release wheel size differs from channel manifest")
                with target.open("xb") as handle:
                    os.fchmod(handle.fileno(), 0o600)
                    for chunk in wheel_response.iter_bytes(1024 * 1024):
                        size += len(chunk)
                        if size > _MAX_RELEASE_WHEEL_BYTES or size > artifact["size_bytes"]:
                            raise ValueError("Suwen release wheel exceeds its declared size")
                        digest.update(chunk)
                        handle.write(chunk)
                    handle.flush()
                    os.fsync(handle.fileno())
    except httpx.HTTPError as exc:
        raise RuntimeError(f"Suwen release channel is unavailable: {type(exc).__name__}") from exc
    if size != artifact["size_bytes"]:
        target.unlink(missing_ok=True)
        raise ValueError("Suwen release wheel size differs from channel manifest")
    if digest.hexdigest() != artifact["sha256"]:
        target.unlink(missing_ok=True)
        raise ValueError("Suwen release wheel digest differs from channel manifest")
    return target, source_identity


def _validated_release_channel_url(value: str) -> str:
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError as exc:
        raise ValueError("Suwen release-channel URL is invalid") from exc
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Suwen release-channel URL must use HTTP or HTTPS")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Suwen release-channel URL cannot contain credentials, query, or fragment")
    if not parsed.path or parsed.path.endswith("/"):
        raise ValueError("Suwen release-channel URL must identify a manifest file")
    if port is not None and not 1 <= port <= 65535:
        raise ValueError("Suwen release-channel URL port is invalid")
    return value


def _validate_release_channel_manifest(
    payload: object,
) -> tuple[dict[str, Any], dict[str, str]]:
    if not isinstance(payload, dict) or payload.get("schema_version") != RELEASE_CHANNEL_SCHEMA_VERSION:
        raise ValueError("unsupported Suwen release-channel manifest")
    if payload.get("product") != "suwen-agent":
        raise ValueError("release channel does not publish suwen-agent")
    source_identity = payload.get("source_identity")
    required_identity = {"git_commit", "git_tree", "candidate_id", "acceptance_sha256"}
    if not isinstance(source_identity, dict) or set(source_identity) != required_identity:
        raise ValueError("Suwen release-channel source identity is missing")
    git_object = re.compile(r"(?:[0-9a-f]{40}|[0-9a-f]{64})\Z")
    candidate_id = re.compile(r"rc-[0-9a-f]{20}\Z")
    sha256 = re.compile(r"[0-9a-f]{64}\Z")
    if (
        not isinstance(source_identity.get("git_commit"), str)
        or git_object.fullmatch(source_identity["git_commit"]) is None
        or not isinstance(source_identity.get("git_tree"), str)
        or git_object.fullmatch(source_identity["git_tree"]) is None
        or not isinstance(source_identity.get("candidate_id"), str)
        or candidate_id.fullmatch(source_identity["candidate_id"]) is None
        or not isinstance(source_identity.get("acceptance_sha256"), str)
        or sha256.fullmatch(source_identity["acceptance_sha256"]) is None
    ):
        raise ValueError("Suwen release-channel source identity is invalid")
    artifact = payload.get("artifact")
    if not isinstance(artifact, dict):
        raise ValueError("Suwen release-channel artifact is missing")
    path = artifact.get("path")
    digest = artifact.get("sha256")
    size = artifact.get("size_bytes")
    relative = PurePosixPath(path) if isinstance(path, str) else None
    if (
        relative is None
        or relative.is_absolute()
        or len(relative.parts) != 2
        or relative.parts[0] != "artifacts"
        or relative.name in {"", ".", ".."}
        or relative.suffix != ".whl"
        or any(part in {"", ".", ".."} for part in relative.parts)
    ):
        raise ValueError("Suwen release-channel artifact path is invalid")
    if not isinstance(digest, str) or len(digest) != 64 or any(
        character not in "0123456789abcdef" for character in digest
    ):
        raise ValueError("Suwen release-channel artifact digest is invalid")
    if (
        not isinstance(size, int)
        or isinstance(size, bool)
        or size <= 0
        or size > _MAX_RELEASE_WHEEL_BYTES
    ):
        raise ValueError("Suwen release-channel artifact size is invalid")
    return (
        {"path": str(relative), "sha256": digest, "size_bytes": size},
        {key: str(source_identity[key]) for key in sorted(required_identity)},
    )


def _assert_same_release_channel_origin(manifest_url: str, artifact_url: str) -> None:
    manifest = urlsplit(manifest_url)
    artifact = urlsplit(artifact_url)
    if (manifest.scheme, manifest.hostname, manifest.port) != (
        artifact.scheme,
        artifact.hostname,
        artifact.port,
    ):
        raise ValueError("Suwen release wheel must use the manifest origin")


def bundled_config_template() -> Path:
    packaged = Path(__file__).resolve().parent / "_bundled" / "config" / "runtime.example.toml"
    if packaged.is_file():
        return packaged
    return Path(__file__).resolve().parents[2] / "config" / "runtime.example.toml"


def configure_product_runtime(layout: RuntimeLayout) -> None:
    if not layout.config.is_file():
        raise ValueError("Suwen runtime workspace is not installed")
    os.environ.setdefault("SUWEN_CONFIG", str(layout.config))
    os.chdir(layout.workspace)


def _source_record(source: Path) -> dict[str, str]:
    return {"kind": "checkout" if source.is_dir() else "wheel", "path": str(source)}


def _safe_release_component(value: str) -> str:
    normalized = "".join(
        character if character.isalnum() or character in ".-_" else "-" for character in value
    )
    if not normalized or normalized in {".", ".."}:
        raise ValueError("Suwen package version cannot form a release name")
    return normalized


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid Suwen metadata: {path.name}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"invalid Suwen metadata: {path.name}")
    return payload


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    encoded = (json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())
            os.fchmod(handle.fileno(), 0o600)
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise


def _now() -> str:
    return datetime.now(UTC).isoformat()
