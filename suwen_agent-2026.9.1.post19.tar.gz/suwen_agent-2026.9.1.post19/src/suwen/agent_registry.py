from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any
from zoneinfo import ZoneInfo

from .agent_composition import AgentCompositionError, compose_agent_surface
from .agent_profiles import AgentProfileRegistry, AgentProfileResolution
from .capability_packages import CapabilityBinding, CapabilityPackageRegistry
from .case_history import CASE_RECALL_TOOL_NAME
from .connectors import (
    effective_connector_allowlist,
    published_tool_baseline_digest,
    resolve_connector_bindings,
)
from .db import (
    GENERIC_PACK_VERSION_ID,
    SUWEN_CORE_PROMPT_BUNDLE_VERSION_ID,
    Database,
)
from .model_registry import ModelRegistry, model_capabilities
from .packs import PackRegistry
from .personas import DEFAULT_PERSONA_ID, get_persona
from .repository import iso, new_id
from .skills import SKILL_RUNTIME_TOOL_NAMES
from .tools import ToolRegistry
from .types import ToolRisk

_STABLE_ID = re.compile(r"^[a-z][a-z0-9-]{1,63}$")
_VERSION_JSON_FIELDS = (
    "runtime_policy_json",
    "context_policy_json",
    "channel_policy_json",
    "review_policy_json",
    "presentation_policy_json",
    "config_json",
)

_MAX_AGENT_TAGS = 20
_MAX_AGENT_TAG_LENGTH = 50
_MAX_REPLY_FOOTER_LENGTH = 500
_MAX_REVIEW_DELAY_SECONDS = 7 * 24 * 60 * 60
_POLICY_ALLOWED_KEYS = {
    "runtime_policy": frozenset(
        {
            "max_tool_calls",
            "max_tool_waves",
            "tool_timeout_seconds",
            "run_timeout_seconds",
            "max_concurrency",
        }
    ),
    "context_policy": frozenset(
        {
            "message_limit",
            "compact_after_messages",
            "tool_result_recent_count",
            "tool_result_old_max_chars",
            "tool_result_recent_max_chars",
            "safety_margin_ratio",
            "safety_margin_min_tokens",
            "checkpoint_ratio",
            "reference_ratio",
            "minimal_ratio",
            "recent_protocol_pairs",
            "recent_history_messages",
            "evidence_card_max_chars",
        }
    ),
    "channel_policy": frozenset({"channel_instance_ids", "reply_enabled"}),
    "review_policy": frozenset({"enabled", "delay_seconds"}),
    "presentation_policy": frozenset({"reply_footer"}),
    "config": frozenset(
        {
            "tags",
            "max_tool_risk",
            "tool_allowlist",
            "cloned_from",
            "agent_profile_id",
            "agent_profile_version",
            "agent_profile_digest",
            "agent_profile_artifact_digest",
            "agent_profile_installation_id",
            "agent_profile_install_digest",
            "agent_profile_composition_lock_digest",
            "schema",
            "tool_call_limit_overrides",
            "connector_bindings",
        }
    ),
}
_TOOL_RISK_RANK = {
    ToolRisk.READ_ONLY: 0,
    ToolRisk.CONTROLLED_ACTION: 1,
    ToolRisk.EXTERNAL_WRITE: 2,
    ToolRisk.UNCLASSIFIED: 3,
}
_RELEASE_TIMEZONE = ZoneInfo("Asia/Shanghai")


def _digest(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _loads(value: str | None, fallback: Any) -> Any:
    return json.loads(value) if value else fallback


def _contains_sensitive_key(value: Any) -> bool:
    if isinstance(value, dict):
        for key, item in value.items():
            normalized = str(key).lower().replace("-", "_")
            if normalized in {"api_key", "password", "secret", "token", "access_token"} or (
                normalized.endswith(("_api_key", "_password", "_secret", "_token"))
                and not normalized.endswith("_ref")
            ):
                return True
            if _contains_sensitive_key(item):
                return True
    if isinstance(value, list):
        return any(_contains_sensitive_key(item) for item in value)
    return False


def _release_datetime(value: str) -> datetime:
    created_at = datetime.fromisoformat(value)
    if created_at.tzinfo is None:
        created_at = created_at.replace(tzinfo=UTC)
    return created_at.astimezone(_RELEASE_TIMEZONE)


def _release_date(value: str) -> str:
    return _release_datetime(value).strftime("%Y.%m.%d")


def _annotate_release_versions(versions: list[dict[str, Any]]) -> None:
    """Add the product-facing daily release label without changing internal revisions."""
    post_by_date: dict[str, int] = {}

    def release_at(version: dict[str, Any]) -> str:
        return version.get("published_at") or version["created_at"]

    for item in sorted(
        versions,
        key=lambda version: (
            _release_datetime(release_at(version)),
            int(version["version"]),
            str(version["id"]),
        ),
    ):
        release_date = _release_date(release_at(item))
        post_number = post_by_date.get(release_date, 0) + 1
        post_by_date[release_date] = post_number
        item["revision"] = item["version"]
        item["release_date"] = release_date
        item["post_number"] = post_number
        item["release_version"] = f"v{release_date} post{post_number}"


class AgentValidationError(ValueError):
    def __init__(self, findings: list[dict[str, str]]):
        self.findings = findings
        super().__init__("Agent Draft validation failed")


class AgentRegistry:
    def __init__(
        self,
        database: Database,
        models: ModelRegistry | None = None,
        packs: PackRegistry | None = None,
        tools: ToolRegistry | None = None,
        capability_packages: CapabilityPackageRegistry | None = None,
        agent_profiles: AgentProfileRegistry | None = None,
    ):
        self.database = database
        self.models = models or ModelRegistry(database)
        self.packs = packs
        self.tools = tools
        self.capability_packages = capability_packages
        self.agent_profiles = agent_profiles

    @staticmethod
    def _stable_id(value: str) -> str:
        value = value.strip()
        if not _STABLE_ID.fullmatch(value):
            raise ValueError("id must use 2-64 lowercase letters, digits, or hyphens")
        return value

    @staticmethod
    def _coerce_capability_bindings(
        values: list[dict[str, Any] | CapabilityBinding] | None,
    ) -> list[CapabilityBinding]:
        if values is None:
            return []
        bindings: list[CapabilityBinding] = []
        for position, value in enumerate(values):
            if isinstance(value, CapabilityBinding):
                version_id = value.capability_version_id
                role = value.role
            elif isinstance(value, dict):
                version_id = value.get("capability_version_id")
                role = value.get("role")
            else:
                raise ValueError("capability binding must be an object")
            if not isinstance(version_id, str) or not version_id:
                raise ValueError("capability binding version is required")
            if role not in {"tools", "domain"}:
                raise ValueError("capability binding role must be tools or domain")
            bindings.append(CapabilityBinding(version_id, str(role), position))
        return bindings

    @staticmethod
    def _audit(
        connection: sqlite3.Connection,
        actor: str,
        action: str,
        agent_id: str,
        *,
        target_version: str | None = None,
        before_digest: str | None = None,
        after_digest: str | None = None,
        result: str = "succeeded",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        connection.execute(
            """INSERT INTO audit_events(
               actor_type, actor_ref, action, target_type, target_id,
               target_version, before_digest, after_digest, result,
               metadata_json, created_at
            ) VALUES ('admin', ?, ?, 'agent', ?, ?, ?, ?, ?, ?, ?)""",
            (
                actor,
                action,
                agent_id,
                target_version,
                before_digest,
                after_digest,
                result,
                json.dumps(metadata or {}, ensure_ascii=False),
                iso(),
            ),
        )

    @staticmethod
    def _model_version_for_resource(
        connection: sqlite3.Connection,
        model_profile_id: str,
    ) -> sqlite3.Row:
        row = connection.execute(
            """SELECT binding_profile.id AS model_profile_id,
                      binding_profile.name AS model_profile_name,
                      binding_profile.status AS model_profile_status,
                      version.id AS model_profile_version_id,
                      version.version AS model_profile_version,
                      version.model_id, version.provider_version_id,
                      version.max_input_length, version.max_output_tokens,
                      version.temperature, version.timeout_seconds,
                      version.capabilities_json, version.routing_json,
                      version.digest AS model_profile_digest,
                      provider.id AS provider_id, provider.name AS provider_name,
                      provider.status AS provider_status, provider.protocol
                 FROM model_profiles binding_profile
                 JOIN model_profile_versions version
                   ON version.id=(
                        SELECT current_version.id
                          FROM model_profile_versions current_version
                         WHERE current_version.model_profile_id=binding_profile.id
                         ORDER BY current_version.version DESC LIMIT 1
                      )
                 JOIN model_provider_versions provider_version
                   ON provider_version.id=version.provider_version_id
                 JOIN model_providers provider ON provider.id=provider_version.provider_id
                WHERE binding_profile.id=? AND binding_profile.status='active'""",
            (model_profile_id,),
        ).fetchone()
        if not row:
            raise KeyError(model_profile_id)
        if row["provider_status"] != "active":
            raise ValueError("model resource Provider is not active")
        return row

    @classmethod
    def _current_model_binding(
        cls,
        connection: sqlite3.Connection,
        agent_id: str,
    ) -> dict[str, Any] | None:
        binding = connection.execute(
            """SELECT model_profile_id, revision AS binding_revision,
                      updated_by AS binding_updated_by, updated_at AS binding_updated_at
                 FROM agent_model_bindings WHERE agent_id=?""",
            (agent_id,),
        ).fetchone()
        if not binding:
            return None
        model = cls._model_version_for_resource(connection, binding["model_profile_id"])
        return {
            **dict(model),
            "binding_revision": binding["binding_revision"],
            "binding_updated_by": binding["binding_updated_by"],
            "binding_updated_at": binding["binding_updated_at"],
        }

    @staticmethod
    def _current_persona_binding(
        connection: sqlite3.Connection,
        agent_id: str,
    ) -> dict[str, Any] | None:
        binding = connection.execute(
            """SELECT persona_id, revision AS binding_revision,
                      updated_by AS binding_updated_by, updated_at AS binding_updated_at
                 FROM agent_persona_bindings WHERE agent_id=?""",
            (agent_id,),
        ).fetchone()
        if not binding:
            return None
        persona = get_persona(str(binding["persona_id"]))
        return {
            **persona.public_view(),
            "binding_revision": binding["binding_revision"],
            "binding_updated_by": binding["binding_updated_by"],
            "binding_updated_at": binding["binding_updated_at"],
        }

    def list_agents(self, *, include_archived: bool = False) -> list[dict[str, Any]]:
        query = "SELECT id FROM agents"
        if not include_archived:
            query += " WHERE status<>'archived'"
        query += " ORDER BY updated_at DESC, id"
        with self.database.connect() as connection:
            rows = connection.execute(query).fetchall()
        return [self.get_agent(row["id"]) for row in rows]

    def list_agents_page(
        self,
        limit: int = 50,
        offset: int = 0,
        *,
        include_archived: bool = False,
    ) -> dict[str, Any]:
        limit = max(1, min(limit, 500))
        offset = max(0, min(offset, 1_000_000))
        where = "" if include_archived else " WHERE status<>'archived'"
        with self.database.connect() as connection:
            total = int(connection.execute(f"SELECT COUNT(*) FROM agents{where}").fetchone()[0])
            rows = connection.execute(
                f"SELECT id FROM agents{where} ORDER BY updated_at DESC, id LIMIT ? OFFSET ?",
                (limit, offset),
            ).fetchall()
        items = [self.get_agent(row["id"]) for row in rows]
        return {
            "items": items,
            "page": {
                "total": total,
                "limit": limit,
                "offset": offset,
                "has_previous": offset > 0,
                "has_next": offset + len(items) < total,
            },
        }

    def selection_options(self) -> list[dict[str, Any]]:
        """Return only fields required by management selectors."""
        with self.database.connect() as connection:
            default_setting = connection.execute(
                "SELECT value_json FROM system_settings WHERE key='default_agent_id'"
            ).fetchone()
            default_agent_id = _loads(default_setting["value_json"], None) if default_setting else None
            rows = connection.execute(
                """SELECT id, name, status, active_version_id
                   FROM agents ORDER BY name, id"""
            ).fetchall()
        return [{**dict(row), "is_default": row["id"] == default_agent_id} for row in rows]

    def create_from_profile(
        self,
        profile_id: str,
        profile_version: str,
        profile_digest: str,
        agent_id: str,
        name: str,
        actor: str,
        *,
        description: str = "",
        language: str | None = None,
        model_profile_id: str | None = None,
        persona_id: str = DEFAULT_PERSONA_ID,
    ) -> dict[str, Any]:
        """Create a Draft from one exact, ready first-party Agent Profile.

        The Profile owns only composition fields.  This method deliberately does
        not publish, activate, configure a Channel, or load a Profile at Run time.
        """

        resolution = self._resolve_ready_profile(profile_id, profile_version, profile_digest)
        config = self._profile_owned_config({}, resolution)
        agent = self.create_agent(
            agent_id,
            name,
            actor,
            description=description,
            language=language or resolution.profile.language,
            model_profile_id=model_profile_id,
            persona_id=persona_id,
            prompt_bundle_version_id=str(resolution.prompt_bundle_version_id),
            config=config,
            pack_version_ids=list(resolution.pack_version_ids),
            capability_bindings=list(resolution.capability_bindings),
        )
        return {"agent": agent, "profile": resolution.public_view(include_composition=True)}

    def preview_profile(
        self,
        agent_id: str,
        profile_id: str,
        profile_version: str,
        profile_digest: str,
        *,
        expected_draft_digest: str | None = None,
    ) -> dict[str, Any]:
        """Return a non-mutating structured diff for applying an Agent Profile."""

        resolution = self._resolve_ready_profile(profile_id, profile_version, profile_digest)
        with self.database.connect() as connection:
            draft = connection.execute(
                """SELECT * FROM agent_versions
                   WHERE agent_id=? AND status='draft' ORDER BY version DESC LIMIT 1""",
                (agent_id,),
            ).fetchone()
            if draft is None:
                raise ValueError("Agent has no Draft to preview")
            if expected_draft_digest is not None and draft["digest"] != expected_draft_digest:
                raise ValueError("Agent Draft digest has changed")
            diff = self._profile_diff(connection, draft, resolution)
        return {
            "agent_id": agent_id,
            "draft_version_id": draft["id"],
            "draft_digest": draft["digest"],
            "profile": resolution.public_view(include_composition=True),
            "diff": diff,
            "will_publish": False,
            "will_activate": False,
        }

    def apply_profile(
        self,
        agent_id: str,
        profile_id: str,
        profile_version: str,
        profile_digest: str,
        actor: str,
        *,
        expected_draft_digest: str | None = None,
    ) -> dict[str, Any]:
        """Atomically apply Profile-owned fields to an Agent Draft only."""

        resolution = self._resolve_ready_profile(profile_id, profile_version, profile_digest)
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing_draft = connection.execute(
                """SELECT * FROM agent_versions
                   WHERE agent_id=? AND status='draft' ORDER BY version DESC LIMIT 1""",
                (agent_id,),
            ).fetchone()
            comparison_version = existing_draft
            if comparison_version is None:
                comparison_version = connection.execute(
                    """SELECT av.* FROM agents a
                       JOIN agent_versions av ON av.id=a.active_version_id
                       WHERE a.id=?""",
                    (agent_id,),
                ).fetchone()
            if comparison_version is None:
                connection.rollback()
                raise ValueError("Agent has neither a Draft nor an active version")
            if expected_draft_digest is not None and comparison_version["digest"] != expected_draft_digest:
                connection.rollback()
                raise ValueError("Agent Draft digest has changed")
            draft = self._ensure_draft(connection, agent_id, actor)
            before_digest = str(draft["digest"])
            self._assert_dependencies(
                connection,
                str(resolution.prompt_bundle_version_id),
                list(resolution.pack_version_ids),
                list(resolution.capability_bindings),
            )
            policies = {
                field.removesuffix("_json"): _loads(draft[field], {}) for field in _VERSION_JSON_FIELDS
            }
            policies["config"] = self._profile_owned_config(policies["config"], resolution)
            self._validate_policies(policies)
            self._validate_policy_values(policies)
            # The profile resolution already derives the exact allowlist from the
            # shared composition.  Re-normalize only as a defensive local check.
            policies["config"] = self._normalize_tool_policy(
                connection,
                list(resolution.pack_version_ids),
                list(resolution.capability_bindings),
                policies["config"],
            )
            diff = self._profile_diff(connection, draft, resolution)
            digest = self._configuration_digest(
                str(resolution.prompt_bundle_version_id),
                policies,
                list(resolution.pack_version_ids),
                list(resolution.capability_bindings),
            )
            connection.execute(
                """UPDATE agent_versions
                   SET prompt_bundle_version_id=?, runtime_policy_json=?, context_policy_json=?,
                       channel_policy_json=?, review_policy_json=?, presentation_policy_json=?,
                       config_json=?, tool_schema_digest=NULL, digest=?
                   WHERE id=? AND status='draft'""",
                (
                    resolution.prompt_bundle_version_id,
                    json.dumps(policies["runtime_policy"]),
                    json.dumps(policies["context_policy"]),
                    json.dumps(policies["channel_policy"]),
                    json.dumps(policies["review_policy"]),
                    json.dumps(policies["presentation_policy"]),
                    json.dumps(policies["config"], ensure_ascii=False),
                    digest,
                    draft["id"],
                ),
            )
            self._replace_packs(connection, str(draft["id"]), list(resolution.pack_version_ids))
            self._replace_capabilities(
                connection,
                str(draft["id"]),
                list(resolution.capability_bindings),
            )
            self._audit(
                connection,
                actor,
                "agent.profile_applied",
                agent_id,
                target_version=str(draft["version"]),
                before_digest=before_digest,
                after_digest=digest,
                metadata={
                    "agent_profile": {
                        "id": resolution.profile.id,
                        "version": resolution.profile.version,
                        "digest": resolution.profile.digest,
                        "composition_digest": resolution.composition.digest
                        if resolution.composition
                        else None,
                    },
                    "changed_fields": [item["field"] for item in diff["changed"]],
                    "published": False,
                    "activated": False,
                },
            )
            connection.commit()
        return {
            "agent": self.get_agent(agent_id),
            "profile": resolution.public_view(include_composition=True),
            "diff": diff,
            "will_publish": False,
            "will_activate": False,
            "applied_at": at,
        }

    def _resolve_ready_profile(
        self,
        profile_id: str,
        profile_version: str,
        profile_digest: str,
    ) -> AgentProfileResolution:
        if self.agent_profiles is None:
            raise RuntimeError("first-party Agent Profile registry is unavailable")
        resolution = self.agent_profiles.get(profile_id, profile_version, profile_digest)
        if not resolution.ready:
            codes = ", ".join(item["code"] for item in resolution.findings)
            raise ValueError(f"Agent Profile is not ready: {codes or 'unknown'}")
        return resolution

    @staticmethod
    def _profile_owned_config(
        existing: dict[str, Any],
        resolution: AgentProfileResolution,
    ) -> dict[str, Any]:
        config = dict(existing)
        config.update(
            {
                "schema": "suwen.agent-config.v1",
                "max_tool_risk": resolution.profile.max_tool_risk,
                "tool_allowlist": list(resolution.tool_allowlist),
                "agent_profile_id": resolution.profile.id,
                "agent_profile_version": resolution.profile.version,
                "agent_profile_digest": resolution.profile.digest,
                "connector_bindings": [dict(item) for item in resolution.connector_bindings],
            }
        )
        if resolution.installation_id:
            config.update(
                {
                    "agent_profile_artifact_digest": resolution.artifact_digest,
                    "agent_profile_installation_id": resolution.installation_id,
                    "agent_profile_install_digest": resolution.install_digest,
                    "agent_profile_composition_lock_digest": resolution.composition_lock_digest,
                }
            )
        else:
            for key in (
                "agent_profile_artifact_digest",
                "agent_profile_installation_id",
                "agent_profile_install_digest",
                "agent_profile_composition_lock_digest",
            ):
                config.pop(key, None)
        return config

    def _profile_diff(
        self,
        connection: sqlite3.Connection,
        draft: sqlite3.Row,
        resolution: AgentProfileResolution,
    ) -> dict[str, Any]:
        config = _loads(draft["config_json"], {})
        current_packs = [
            str(row["pack_version_id"])
            for row in connection.execute(
                """SELECT pack_version_id FROM agent_version_packs
                   WHERE agent_version_id=? AND enabled=1 ORDER BY position, pack_version_id""",
                (draft["id"],),
            ).fetchall()
        ]
        current_capabilities = [
            {
                "capability_version_id": item.capability_version_id,
                "role": item.role,
                "position": item.position,
            }
            for item in self._capability_bindings(connection, str(draft["id"]))
        ]
        target_capabilities = [
            {
                "capability_version_id": item.capability_version_id,
                "role": item.role,
                "position": item.position,
            }
            for item in resolution.capability_bindings
        ]
        before = {
            "prompt_bundle_version_id": draft["prompt_bundle_version_id"],
            "pack_version_ids": current_packs,
            "capability_bindings": current_capabilities,
            "max_tool_risk": config.get("max_tool_risk"),
            "tool_allowlist": config.get("tool_allowlist"),
            "connector_bindings": config.get("connector_bindings", []),
            "agent_profile": {
                "id": config.get("agent_profile_id"),
                "version": config.get("agent_profile_version"),
                "digest": config.get("agent_profile_digest"),
            },
        }
        after = {
            "prompt_bundle_version_id": resolution.prompt_bundle_version_id,
            "pack_version_ids": list(resolution.pack_version_ids),
            "capability_bindings": target_capabilities,
            "max_tool_risk": resolution.profile.max_tool_risk,
            "tool_allowlist": list(resolution.tool_allowlist),
            "connector_bindings": [dict(item) for item in resolution.connector_bindings],
            "agent_profile": {
                "id": resolution.profile.id,
                "version": resolution.profile.version,
                "digest": resolution.profile.digest,
            },
        }
        return {
            "before": before,
            "after": after,
            "changed": [
                {"field": key, "before": before[key], "after": after[key]}
                for key in before
                if before[key] != after[key]
            ],
        }

    def get_agent(self, agent_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            agent = connection.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
            current_model = self._current_model_binding(connection, agent_id)
            current_persona = self._current_persona_binding(connection, agent_id)
            versions = connection.execute(
                """SELECT * FROM agent_versions
                   WHERE agent_id=? ORDER BY version DESC""",
                (agent_id,),
            ).fetchall()
            default_setting = connection.execute(
                "SELECT value_json FROM system_settings WHERE key='default_agent_id'"
            ).fetchone()
            channel_bindings = connection.execute(
                """SELECT acb.id, acb.channel_instance_id, ci.name,
                          ci.channel_type, ci.status, acb.policy_json, acb.updated_at
                   FROM agent_channel_bindings acb
                   JOIN channel_instances ci ON ci.id=acb.channel_instance_id
                   WHERE acb.agent_id=? AND acb.active=1
                   ORDER BY ci.channel_type, ci.id""",
                (agent_id,),
            ).fetchall()
            recent_run = connection.execute(
                """SELECT r.id, r.case_id, r.agent_version_id,
                          r.model_profile_version_id, mpv.model_id,
                          r.status, r.stop_reason, r.started_at, r.finished_at
                   FROM runs r
                   JOIN cases c ON c.id=r.case_id
                   JOIN model_profile_versions mpv ON mpv.id=r.model_profile_version_id
                   WHERE c.agent_id=?
                   ORDER BY r.started_at DESC, r.id DESC LIMIT 1""",
                (agent_id,),
            ).fetchone()
            publish_events = connection.execute(
                """SELECT id, from_version_id, to_version_id, kind,
                          actor_ref, note, created_at
                   FROM publish_events WHERE agent_id=?
                   ORDER BY created_at DESC, id DESC""",
                (agent_id,),
            ).fetchall()
        if not agent:
            raise KeyError(agent_id)
        result = dict(agent)
        result["is_default"] = bool(
            default_setting and _loads(default_setting["value_json"], None) == agent_id
        )
        result["current_model"] = dict(current_model) if current_model else None
        result["current_persona"] = dict(current_persona) if current_persona else None
        if result["current_model"]:
            result["current_model"]["capabilities"] = model_capabilities(
                result["current_model"].pop("capabilities_json")
            )
            result["current_model"]["routing"] = _loads(
                result["current_model"].pop("routing_json"), {}
            )
        result["versions"] = [self._version_view(row) for row in versions]
        _annotate_release_versions(result["versions"])
        result["channel_bindings"] = []
        for row in channel_bindings:
            item = dict(row)
            item["policy"] = _loads(item.pop("policy_json"), {})
            result["channel_bindings"].append(item)
        result["recent_run"] = dict(recent_run) if recent_run else None
        result["publish_events"] = [dict(row) for row in publish_events]
        result["draft_version_id"] = next(
            (item["id"] for item in result["versions"] if item["status"] == "draft"), None
        )
        return result

    def _version_view(self, row: sqlite3.Row) -> dict[str, Any]:
        item = dict(row)
        for field in _VERSION_JSON_FIELDS:
            item[field.removesuffix("_json")] = _loads(item.pop(field), {})
        with self.database.connect() as connection:
            packs = connection.execute(
                """SELECT avp.pack_version_id, avp.position, avp.enabled,
                          cpv.pack_id, cpv.version, cpv.digest
                   FROM agent_version_packs avp
                   JOIN capability_pack_versions cpv ON cpv.id=avp.pack_version_id
                   WHERE avp.agent_version_id=? ORDER BY avp.position, avp.pack_version_id""",
                (item["id"],),
            ).fetchall()
            capabilities = connection.execute(
                """SELECT avc.capability_version_id, avc.role, avc.position, avc.enabled,
                          cpv.version, cpv.content_digest, cp.id AS capability_id, cp.kind,
                          cpv.lifecycle_state
                   FROM agent_version_capabilities avc
                   JOIN capability_package_versions cpv ON cpv.id=avc.capability_version_id
                   JOIN capability_packages cp ON cp.id=cpv.capability_id
                   WHERE avc.agent_version_id=?
                   ORDER BY avc.position, avc.capability_version_id""",
                (item["id"],),
            ).fetchall()
            validation = connection.execute(
                """SELECT status, findings_json, created_at, finished_at
                   FROM config_validation_runs
                   WHERE target_type='agent_version' AND target_id=?
                   ORDER BY created_at DESC LIMIT 1""",
                (item["id"],),
            ).fetchone()
        item["packs"] = [dict(pack) for pack in packs]
        item["capabilities"] = [dict(capability) for capability in capabilities]
        item["last_validation"] = None
        if validation:
            item["last_validation"] = dict(validation)
            item["last_validation"]["findings"] = _loads(item["last_validation"].pop("findings_json"), [])
        return item

    def set_current_model(
        self,
        agent_id: str,
        model_profile_id: str,
        actor: str,
    ) -> dict[str, Any]:
        """Switch one Agent to an instance-level model resource for subsequent Runs."""

        version = self.models.current_profile_version(model_profile_id)
        configuration = version["configuration"]
        if configuration["status"] != "valid":
            codes = ", ".join(item["code"] for item in configuration["findings"])
            raise ValueError(f"model resource is not usable: {codes}")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            agent = connection.execute(
                "SELECT status FROM agents WHERE id=?", (agent_id,)
            ).fetchone()
            if not agent:
                raise KeyError(agent_id)
            if agent["status"] == "archived":
                raise ValueError("archived Agent cannot switch models")
            before = self._current_model_binding(connection, agent_id)
            if before and before["model_profile_id"] == model_profile_id:
                connection.rollback()
                return self.get_agent(agent_id)
            updated = connection.execute(
                """UPDATE agent_model_bindings
                   SET model_profile_id=?, revision=revision+1,
                       updated_by=?, updated_at=? WHERE agent_id=?""",
                (model_profile_id, actor, at, agent_id),
            ).rowcount
            if updated != 1:
                raise RuntimeError("Agent current model binding is missing")
            after = self._current_model_binding(connection, agent_id)
            self._audit(
                connection,
                actor,
                "agent.current_model_changed",
                agent_id,
                target_version=str(after["binding_revision"]),
                metadata={
                    "from_model_profile_id": before["model_profile_id"] if before else None,
                    "to_model_profile_id": model_profile_id,
                    "from_model_profile_version_id": (
                        before["model_profile_version_id"] if before else None
                    ),
                    "to_model_profile_version_id": after["model_profile_version_id"],
                    "effective_from": "next_run",
                },
            )
            connection.execute("UPDATE agents SET updated_at=? WHERE id=?", (at, agent_id))
            connection.commit()
        return self.get_agent(agent_id)

    def set_current_persona(
        self,
        agent_id: str,
        persona_id: str,
        actor: str,
    ) -> dict[str, Any]:
        """Switch one Agent's communication Persona for subsequently created Cases."""

        persona = get_persona(persona_id)
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            agent = connection.execute(
                "SELECT status FROM agents WHERE id=?", (agent_id,)
            ).fetchone()
            if not agent:
                raise KeyError(agent_id)
            if agent["status"] == "archived":
                raise ValueError("archived Agent cannot switch Personas")
            before = self._current_persona_binding(connection, agent_id)
            if before and before["id"] == persona.id:
                connection.rollback()
                return self.get_agent(agent_id)
            updated = connection.execute(
                """UPDATE agent_persona_bindings
                   SET persona_id=?, revision=revision+1,
                       updated_by=?, updated_at=? WHERE agent_id=?""",
                (persona.id, actor, at, agent_id),
            ).rowcount
            if updated != 1:
                raise RuntimeError("Agent current Persona binding is missing")
            after = self._current_persona_binding(connection, agent_id)
            self._audit(
                connection,
                actor,
                "agent.current_persona_changed",
                agent_id,
                target_version=str(after["binding_revision"]),
                metadata={
                    "from_persona_id": before["id"] if before else None,
                    "to_persona_id": persona.id,
                    "effective_from": "next_case",
                },
            )
            connection.execute("UPDATE agents SET updated_at=? WHERE id=?", (at, agent_id))
            connection.commit()
        return self.get_agent(agent_id)

    def create_agent(
        self,
        agent_id: str,
        name: str,
        actor: str,
        *,
        description: str = "",
        language: str = "zh-CN",
        model_profile_id: str | None = None,
        persona_id: str = DEFAULT_PERSONA_ID,
        prompt_bundle_version_id: str = SUWEN_CORE_PROMPT_BUNDLE_VERSION_ID,
        runtime_policy: dict[str, Any] | None = None,
        context_policy: dict[str, Any] | None = None,
        channel_policy: dict[str, Any] | None = None,
        review_policy: dict[str, Any] | None = None,
        presentation_policy: dict[str, Any] | None = None,
        config: dict[str, Any] | None = None,
        pack_version_ids: list[str] | None = None,
        capability_bindings: list[dict[str, Any] | CapabilityBinding] | None = None,
    ) -> dict[str, Any]:
        agent_id = self._stable_id(agent_id)
        if not name.strip():
            raise ValueError("Agent name is required")
        if not model_profile_id:
            raise ValueError("Agent must explicitly select a model")
        persona = get_persona(persona_id)
        runtime_policy = runtime_policy or {
            "max_tool_calls": 60,
            "max_tool_waves": 30,
            "max_concurrency": 3,
            "run_timeout_seconds": 900,
        }
        policies = {
            "runtime_policy": runtime_policy,
            "context_policy": context_policy or {},
            "channel_policy": channel_policy or {},
            "review_policy": review_policy or {},
            "presentation_policy": presentation_policy or {},
            "config": config or {},
        }
        self._validate_policies(policies)
        self._validate_policy_values(policies)
        pack_version_ids = pack_version_ids or [GENERIC_PACK_VERSION_ID]
        capability_bindings = self._coerce_capability_bindings(capability_bindings)
        at = iso()
        version_id = new_id("agentver")
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            self._model_version_for_resource(connection, model_profile_id)
            self._assert_dependencies(
                connection,
                prompt_bundle_version_id,
                pack_version_ids,
                capability_bindings,
            )
            policies["config"] = self._normalize_tool_policy(
                connection,
                pack_version_ids,
                capability_bindings,
                policies["config"],
            )
            digest = self._configuration_digest(
                prompt_bundle_version_id,
                policies,
                pack_version_ids,
                capability_bindings,
            )
            connection.execute(
                """INSERT INTO agents(
                   id, name, description, language, status, created_at, updated_at
                ) VALUES (?, ?, ?, ?, 'draft', ?, ?)""",
                (agent_id, name.strip(), description.strip(), language, at, at),
            )
            connection.execute(
                """INSERT INTO agent_model_bindings(
                   agent_id, model_profile_id, revision, updated_by, updated_at
                ) VALUES (?, ?, 1, ?, ?)""",
                (agent_id, model_profile_id, actor, at),
            )
            connection.execute(
                """INSERT INTO agent_persona_bindings(
                   agent_id, persona_id, revision, updated_by, updated_at
                ) VALUES (?, ?, 1, ?, ?)""",
                (agent_id, persona.id, actor, at),
            )
            connection.execute(
                """INSERT INTO agent_versions(
                   id, agent_id, version, status, prompt_bundle_version_id,
                   runtime_policy_json, context_policy_json,
                   channel_policy_json, review_policy_json, presentation_policy_json,
                   config_json, digest, created_by, created_at
                ) VALUES (?, ?, 1, 'draft', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    version_id,
                    agent_id,
                    prompt_bundle_version_id,
                    json.dumps(runtime_policy),
                    json.dumps(policies["context_policy"]),
                    json.dumps(policies["channel_policy"]),
                    json.dumps(policies["review_policy"]),
                    json.dumps(policies["presentation_policy"]),
                    json.dumps(policies["config"], ensure_ascii=False),
                    digest,
                    actor,
                    at,
                ),
            )
            self._replace_packs(connection, version_id, pack_version_ids)
            self._replace_capabilities(connection, version_id, capability_bindings)
            self._audit(
                connection,
                actor,
                "agent.created",
                agent_id,
                target_version="1",
                after_digest=digest,
                metadata=(
                    {
                        "agent_profile": {
                            "id": policies["config"]["agent_profile_id"],
                            "version": policies["config"]["agent_profile_version"],
                            "digest": policies["config"]["agent_profile_digest"],
                        }
                    }
                    if policies["config"].get("agent_profile_id")
                    else None
                ),
            )
            connection.commit()
        return self.get_agent(agent_id)

    def _assert_dependencies(
        self,
        connection: sqlite3.Connection,
        prompt_bundle_version_id: str | None,
        pack_version_ids: list[str],
        capability_bindings: list[CapabilityBinding],
    ) -> None:
        if (
            prompt_bundle_version_id
            and not connection.execute(
                "SELECT 1 FROM prompt_bundle_versions WHERE id=?", (prompt_bundle_version_id,)
            ).fetchone()
        ):
            raise KeyError(prompt_bundle_version_id)
        if len(pack_version_ids) != len(set(pack_version_ids)):
            raise ValueError("Pack versions must be unique")
        pack_ids: list[str] = []
        for pack_version_id in pack_version_ids:
            row = connection.execute(
                "SELECT pack_id FROM capability_pack_versions WHERE id=?",
                (pack_version_id,),
            ).fetchone()
            if not row:
                raise KeyError(pack_version_id)
            pack_ids.append(row["pack_id"])
        if len(pack_ids) != len(set(pack_ids)):
            raise ValueError("Agent cannot select multiple versions of the same Pack")
        if capability_bindings:
            if self.capability_packages is None:
                raise RuntimeError("first-party capability packages are unavailable")
            self.capability_packages.validate_bindings(connection, capability_bindings)

    @staticmethod
    def _validate_policies(policies: dict[str, Any]) -> None:
        for name, value in policies.items():
            if not isinstance(value, dict):
                raise ValueError(f"{name} must be an object")
            if len(json.dumps(value, ensure_ascii=False)) > 50_000:
                raise ValueError(f"{name} is too large")
            if _contains_sensitive_key(value):
                raise ValueError(f"{name} must use Secret Refs instead of secret values")
            allowed = _POLICY_ALLOWED_KEYS.get(name)
            if allowed is None:
                raise ValueError(f"不支持的智能体策略分组：{name}")
            unknown = sorted(set(value) - allowed)
            if unknown:
                raise ValueError(f"{name} 包含不支持且不会生效的字段：{'、'.join(unknown)}")

    @staticmethod
    def _validate_policy_values(policies: dict[str, Any]) -> None:
        config = policies["config"]
        if "schema" in config and config["schema"] != "suwen.agent-config.v1":
            raise ValueError("智能体配置 schema 必须是 suwen.agent-config.v1")
        for provenance_key in ("cloned_from",):
            if provenance_key in config and (
                not isinstance(config[provenance_key], str)
                or not _STABLE_ID.fullmatch(config[provenance_key])
            ):
                raise ValueError(f"{provenance_key} 必须是稳定标识")
        profile_keys = (
            "agent_profile_id",
            "agent_profile_version",
            "agent_profile_digest",
        )
        present_profile_keys = [key for key in profile_keys if key in config]
        if present_profile_keys and len(present_profile_keys) != len(profile_keys):
            raise ValueError("Agent Profile provenance 必须完整提供")
        if present_profile_keys:
            if not _STABLE_ID.fullmatch(str(config["agent_profile_id"])):
                raise ValueError("agent_profile_id 必须是稳定标识")
            if (
                not isinstance(config["agent_profile_version"], str)
                or not config["agent_profile_version"].strip()
            ):
                raise ValueError("agent_profile_version 必须是非空版本")
            digest = config["agent_profile_digest"]
            if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
                raise ValueError("agent_profile_digest 必须是 sha256 摘要")
            release_keys = (
                "agent_profile_artifact_digest",
                "agent_profile_installation_id",
                "agent_profile_install_digest",
                "agent_profile_composition_lock_digest",
            )
            present_release_keys = [key for key in release_keys if key in config]
            if present_release_keys and len(present_release_keys) != len(release_keys):
                raise ValueError("Agent Profile release provenance 必须完整提供")
            for key in (
                "agent_profile_artifact_digest",
                "agent_profile_install_digest",
                "agent_profile_composition_lock_digest",
            ):
                if key in config and not re.fullmatch(r"[0-9a-f]{64}", str(config[key])):
                    raise ValueError(f"{key} 必须是 sha256 摘要")
            if "agent_profile_installation_id" in config and not str(
                config["agent_profile_installation_id"]
            ).startswith("install_"):
                raise ValueError("agent_profile_installation_id 必须是受管安装标识")
        tags = config.get("tags", [])
        if (
            not isinstance(tags, list)
            or len(tags) > _MAX_AGENT_TAGS
            or any(
                not isinstance(tag, str) or not tag.strip() or len(tag.strip()) > _MAX_AGENT_TAG_LENGTH
                for tag in tags
            )
            or len({tag.strip() for tag in tags if isinstance(tag, str)}) != len(tags)
        ):
            raise ValueError("智能体标签必须是最多 20 个不重复的非空短文本")
        max_tool_risk = config.get("max_tool_risk", ToolRisk.CONTROLLED_ACTION.value)
        if max_tool_risk not in {
            ToolRisk.READ_ONLY.value,
            ToolRisk.CONTROLLED_ACTION.value,
        }:
            raise ValueError("工具风险上限只能是只读或受控动作")

        channel = policies["channel_policy"]
        if "reply_enabled" in channel and not isinstance(channel["reply_enabled"], bool):
            raise ValueError("渠道回复开关必须是布尔值")

        review = policies["review_policy"]
        if "enabled" in review and not isinstance(review["enabled"], bool):
            raise ValueError("复盘开关必须是布尔值")
        if "delay_seconds" in review and (
            not isinstance(review["delay_seconds"], int)
            or isinstance(review["delay_seconds"], bool)
            or not 0 <= review["delay_seconds"] <= _MAX_REVIEW_DELAY_SECONDS
        ):
            raise ValueError("复盘延迟必须是 0 到 604800 秒之间的整数")

        presentation = policies["presentation_policy"]
        reply_footer = presentation.get("reply_footer", "")
        if not isinstance(reply_footer, str) or len(reply_footer) > _MAX_REPLY_FOOTER_LENGTH:
            raise ValueError("答复页脚必须是不超过 500 个字符的文本")

    def _configuration_digest(
        self,
        prompt_bundle_version_id: str | None,
        policies: dict[str, Any],
        pack_version_ids: list[str],
        capability_bindings: list[CapabilityBinding],
        tool_schema_digest_value: str | None = None,
    ) -> str:
        payload = {
            "prompt_bundle_version_id": prompt_bundle_version_id,
            **policies,
            "pack_version_ids": pack_version_ids,
            "capability_bindings": [
                {
                    "capability_version_id": item.capability_version_id,
                    "role": item.role,
                    "position": item.position,
                }
                for item in capability_bindings
            ],
        }
        if tool_schema_digest_value is not None:
            payload["tool_schema_digest"] = tool_schema_digest_value
        return _digest(payload)

    def _normalize_tool_policy(
        self,
        connection: sqlite3.Connection,
        pack_version_ids: list[str],
        capability_bindings: list[CapabilityBinding],
        config: dict[str, Any],
    ) -> dict[str, Any]:
        selected = dict(config)
        available: set[str] = {
            "find_artifact_text",
            "read_artifact_chunk",
            CASE_RECALL_TOOL_NAME,
            *SKILL_RUNTIME_TOOL_NAMES,
        }
        definitions: dict[str, Any] = {}
        rows = (
            connection.execute(
                f"""SELECT id, pack_id, version, digest, manifest_json
                    FROM capability_pack_versions
                    WHERE id IN ({",".join("?" for _ in pack_version_ids)})""",
                tuple(pack_version_ids),
            ).fetchall()
            if pack_version_ids
            else []
        )
        if self.packs is not None and self.tools is not None:
            refs = [
                {
                    "pack_version_id": row["id"],
                    "pack_id": row["pack_id"],
                    "version": row["version"],
                    "digest": row["digest"],
                }
                for row in rows
            ]
            definitions = {item.name: item for item in self.packs.tools_for(refs, self.tools).definitions()}
            available = set(definitions)
        else:
            for row in rows:
                manifest = _loads(row["manifest_json"], {})
                available.update(str(name) for name in manifest.get("tools", []))
                if row["pack_id"] == "generic":
                    available.add("inspect_claim")
        if capability_bindings:
            if self.capability_packages is None:
                raise RuntimeError("first-party capability packages are unavailable")
            capability_tools = self.capability_packages.tools_for(capability_bindings)
            for definition in capability_tools.definitions():
                if definition.name in definitions:
                    raise ValueError(f"capability Tool conflicts with Pack Tool: {definition.name}")
                definitions[definition.name] = definition
                available.add(definition.name)
        if self.tools is not None:
            connector_resolution = resolve_connector_bindings(
                connection,
                self.tools,
                selected.get("connector_bindings"),
                normalize=True,
            )
            for definition in connector_resolution.tools.definitions():
                if definition.name in definitions:
                    raise ValueError(f"Connector Tool conflicts with Agent Tool: {definition.name}")
                definitions[definition.name] = definition
                available.add(definition.name)
            selected["connector_bindings"] = list(connector_resolution.bindings)
        max_tool_risk = selected.get("max_tool_risk", ToolRisk.CONTROLLED_ACTION.value)
        selected["max_tool_risk"] = max_tool_risk
        normalized_tags = [tag.strip() for tag in selected.get("tags", [])]
        selected["tags"] = normalized_tags
        configured = selected.get("tool_allowlist")
        if configured is None:
            configured = sorted(
                name
                for name in available
                if not definitions
                or _TOOL_RISK_RANK[definitions[name].risk] <= _TOOL_RISK_RANK[ToolRisk(max_tool_risk)]
            )
        if (
            not isinstance(configured, list)
            or any(not isinstance(name, str) or not name for name in configured)
            or len(configured) != len(set(configured))
        ):
            raise ValueError("Agent Tool allowlist must be a unique array of names")
        unknown = sorted(set(configured) - available)
        if unknown:
            raise ValueError(f"Agent Tool allowlist contains unavailable tools: {', '.join(unknown)}")
        disallowed_by_risk = sorted(
            name
            for name in configured
            if name in definitions
            and _TOOL_RISK_RANK[definitions[name].risk] > _TOOL_RISK_RANK[ToolRisk(max_tool_risk)]
        )
        if disallowed_by_risk:
            raise ValueError("工具白名单超过当前风险上限：" + "、".join(disallowed_by_risk))
        raw_call_limits = selected.get("tool_call_limit_overrides", {})
        if not isinstance(raw_call_limits, dict):
            raise ValueError("Agent Tool call limit overrides must be an object")
        normalized_call_limits: dict[str, int] = {}
        for name, value in raw_call_limits.items():
            if not isinstance(name, str) or name not in available:
                raise ValueError("Agent Tool call limit override references an unavailable Tool")
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError("Agent Tool call limit override must be an integer")
            definition = definitions.get(name)
            bounds = definition.run_call_limit_range if definition is not None else None
            minimum, maximum = bounds or (1, 120)
            if not minimum <= value <= maximum:
                raise ValueError(
                    f"Agent Tool call limit override for {name} must be between "
                    f"{minimum} and {maximum}"
                )
            normalized_call_limits[name] = value
        selected["schema"] = "suwen.agent-config.v1"
        selected["tool_allowlist"] = sorted(configured)
        selected["tool_call_limit_overrides"] = {
            name: normalized_call_limits[name] for name in sorted(normalized_call_limits)
        }
        return selected

    def _freeze_tool_schema(self, connection: sqlite3.Connection, version: sqlite3.Row) -> sqlite3.Row:
        if self.packs is None or self.tools is None:
            return version
        pack_rows = connection.execute(
            """SELECT cpv.id, cpv.pack_id, cpv.version, cpv.digest
               FROM agent_version_packs avp
               JOIN capability_pack_versions cpv ON cpv.id=avp.pack_version_id
               WHERE avp.agent_version_id=? AND avp.enabled=1
               ORDER BY avp.position, cpv.id""",
            (version["id"],),
        ).fetchall()
        pack_refs = [
            {
                "pack_version_id": row["id"],
                "pack_id": row["pack_id"],
                "version": row["version"],
                "digest": row["digest"],
            }
            for row in pack_rows
        ]
        capability_bindings = self._capability_bindings(connection, version["id"])
        policies = {field.removesuffix("_json"): _loads(version[field], {}) for field in _VERSION_JSON_FIELDS}
        prompt = connection.execute(
            "SELECT content_json FROM prompt_bundle_versions WHERE id=?",
            (version["prompt_bundle_version_id"],),
        ).fetchone()
        try:
            composition = compose_agent_surface(
                packs=self.packs,
                runtime_tools=self.tools,
                capability_packages=self.capability_packages,
                pack_refs=pack_refs,
                capability_bindings=capability_bindings,
                prompt_content_json=str(prompt["content_json"]) if prompt else None,
            )
        except AgentCompositionError as exc:
            raise RuntimeError(f"Agent composition is invalid: {exc}") from exc
        connector_resolution = resolve_connector_bindings(
            connection,
            self.tools,
            policies["config"].get("connector_bindings"),
            normalize=False,
        )
        base_tools = ToolRegistry()
        base_tools.merge_from(composition.tools)
        try:
            composition.tools.merge_from(connector_resolution.tools)
        except ValueError as exc:
            raise RuntimeError(f"Agent Connector composition is invalid: {exc}") from exc
        allowlist = policies["config"].get("tool_allowlist", [])
        effective_allowlist = effective_connector_allowlist(allowlist, connector_resolution)
        composition.tools.subset(effective_allowlist)
        frozen = published_tool_baseline_digest(base_tools, connector_resolution, allowlist)
        configuration_digest = self._configuration_digest(
            version["prompt_bundle_version_id"],
            policies,
            [row["id"] for row in pack_rows],
            capability_bindings,
            frozen,
        )
        connection.execute(
            """UPDATE agent_versions SET tool_schema_digest=?, digest=?
               WHERE id=? AND status='draft'""",
            (frozen, configuration_digest, version["id"]),
        )
        return connection.execute("SELECT * FROM agent_versions WHERE id=?", (version["id"],)).fetchone()

    @staticmethod
    def _replace_packs(
        connection: sqlite3.Connection,
        version_id: str,
        pack_version_ids: list[str],
    ) -> None:
        connection.execute("DELETE FROM agent_version_packs WHERE agent_version_id=?", (version_id,))
        connection.executemany(
            """INSERT INTO agent_version_packs(
               agent_version_id, pack_version_id, position, enabled
            ) VALUES (?, ?, ?, 1)""",
            [
                (version_id, pack_version_id, position)
                for position, pack_version_id in enumerate(pack_version_ids)
            ],
        )

    @staticmethod
    def _replace_capabilities(
        connection: sqlite3.Connection,
        version_id: str,
        bindings: list[CapabilityBinding],
    ) -> None:
        connection.execute("DELETE FROM agent_version_capabilities WHERE agent_version_id=?", (version_id,))
        values: list[tuple[Any, ...]] = []
        for item in bindings:
            formal = connection.execute(
                """SELECT nwi.id AS installation_id, nra.artifact_digest
                   FROM native_workspace_installations nwi
                   JOIN native_release_artifacts nra ON nra.id=nwi.artifact_id
                   WHERE nwi.capability_version_id=? AND nwi.status='installed'""",
                (item.capability_version_id,),
            ).fetchone()
            values.append(
                (
                    version_id,
                    item.capability_version_id,
                    item.role,
                    item.position,
                    str(formal["installation_id"]) if formal else None,
                    str(formal["artifact_digest"]) if formal else None,
                )
            )
        connection.executemany(
            """INSERT INTO agent_version_capabilities(
               agent_version_id, capability_version_id, role, position, enabled,
               installation_id, artifact_digest
            ) VALUES (?, ?, ?, ?, 1, ?, ?)""",
            values,
        )

    @staticmethod
    def _capability_bindings(
        connection: sqlite3.Connection,
        version_id: str,
    ) -> list[CapabilityBinding]:
        rows = connection.execute(
            """SELECT capability_version_id, role, position
               FROM agent_version_capabilities
               WHERE agent_version_id=? AND enabled=1
               ORDER BY position, capability_version_id""",
            (version_id,),
        ).fetchall()
        return [
            CapabilityBinding(str(row["capability_version_id"]), str(row["role"]), int(row["position"]))
            for row in rows
        ]

    def _ensure_draft(self, connection: sqlite3.Connection, agent_id: str, actor: str) -> sqlite3.Row:
        agent = connection.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
        if not agent:
            raise KeyError(agent_id)
        if agent["status"] == "archived":
            raise ValueError("archived Agent cannot be edited")
        draft = connection.execute(
            """SELECT * FROM agent_versions
               WHERE agent_id=? AND status='draft' ORDER BY version DESC LIMIT 1""",
            (agent_id,),
        ).fetchone()
        if draft:
            return draft
        if not agent["active_version_id"]:
            raise RuntimeError("Agent has neither a Draft nor an active version")
        source = connection.execute(
            "SELECT * FROM agent_versions WHERE id=?", (agent["active_version_id"],)
        ).fetchone()
        version = connection.execute(
            "SELECT COALESCE(MAX(version), 0)+1 FROM agent_versions WHERE agent_id=?",
            (agent_id,),
        ).fetchone()[0]
        version_id = new_id("agentver")
        connection.execute(
            """INSERT INTO agent_versions(
               id, agent_id, version, status, prompt_bundle_version_id,
               runtime_policy_json, context_policy_json,
               channel_policy_json, review_policy_json, presentation_policy_json,
               config_json, digest, created_by, created_at
            ) VALUES (?, ?, ?, 'draft', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                version_id,
                agent_id,
                version,
                source["prompt_bundle_version_id"],
                source["runtime_policy_json"],
                source["context_policy_json"],
                source["channel_policy_json"],
                source["review_policy_json"],
                source["presentation_policy_json"],
                source["config_json"],
                source["digest"],
                actor,
                iso(),
            ),
        )
        connection.execute(
            """INSERT INTO agent_version_packs(
               agent_version_id, pack_version_id, position, enabled
            ) SELECT ?, pack_version_id, position, enabled
              FROM agent_version_packs WHERE agent_version_id=?""",
            (version_id, source["id"]),
        )
        connection.execute(
            """INSERT INTO agent_version_capabilities(
               agent_version_id, capability_version_id, role, position, enabled,
               installation_id, artifact_digest
            ) SELECT ?, capability_version_id, role, position, enabled,
                     installation_id, artifact_digest
              FROM agent_version_capabilities WHERE agent_version_id=?""",
            (version_id, source["id"]),
        )
        return connection.execute("SELECT * FROM agent_versions WHERE id=?", (version_id,)).fetchone()

    def update_draft(
        self,
        agent_id: str,
        actor: str,
        *,
        name: str | None = None,
        description: str | None = None,
        language: str | None = None,
        prompt_bundle_version_id: str | None = None,
        runtime_policy: dict[str, Any] | None = None,
        context_policy: dict[str, Any] | None = None,
        channel_policy: dict[str, Any] | None = None,
        review_policy: dict[str, Any] | None = None,
        presentation_policy: dict[str, Any] | None = None,
        config: dict[str, Any] | None = None,
        pack_version_ids: list[str] | None = None,
        capability_bindings: list[dict[str, Any] | CapabilityBinding] | None = None,
    ) -> dict[str, Any]:
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            draft = self._ensure_draft(connection, agent_id, actor)
            before_digest = draft["digest"]
            effective_prompt = (
                prompt_bundle_version_id
                if prompt_bundle_version_id is not None
                else draft["prompt_bundle_version_id"]
            )
            current_packs = [
                row["pack_version_id"]
                for row in connection.execute(
                    """SELECT pack_version_id FROM agent_version_packs
                       WHERE agent_version_id=? AND enabled=1 ORDER BY position""",
                    (draft["id"],),
                ).fetchall()
            ]
            effective_packs = pack_version_ids if pack_version_ids is not None else current_packs
            current_capabilities = self._capability_bindings(connection, draft["id"])
            effective_capabilities = (
                self._coerce_capability_bindings(capability_bindings)
                if capability_bindings is not None
                else current_capabilities
            )
            self._assert_dependencies(
                connection,
                effective_prompt,
                effective_packs,
                effective_capabilities,
            )
            effective_config = config if config is not None else _loads(draft["config_json"], {})
            if config is None and (
                (pack_version_ids is not None and effective_packs != current_packs)
                or (capability_bindings is not None and effective_capabilities != current_capabilities)
            ):
                effective_config = dict(effective_config)
                effective_config.pop("tool_allowlist", None)
            policies = {
                "runtime_policy": runtime_policy
                if runtime_policy is not None
                else _loads(draft["runtime_policy_json"], {}),
                "context_policy": context_policy
                if context_policy is not None
                else _loads(draft["context_policy_json"], {}),
                "channel_policy": channel_policy
                if channel_policy is not None
                else _loads(draft["channel_policy_json"], {}),
                "review_policy": review_policy
                if review_policy is not None
                else _loads(draft["review_policy_json"], {}),
                "presentation_policy": presentation_policy
                if presentation_policy is not None
                else _loads(draft["presentation_policy_json"], {}),
                "config": effective_config,
            }
            self._validate_policies(policies)
            self._validate_policy_values(policies)
            policies["config"] = self._normalize_tool_policy(
                connection,
                effective_packs,
                effective_capabilities,
                policies["config"],
            )
            digest = self._configuration_digest(
                effective_prompt,
                policies,
                effective_packs,
                effective_capabilities,
            )
            connection.execute(
                """UPDATE agent_versions SET prompt_bundle_version_id=?,
                   runtime_policy_json=?, context_policy_json=?,
                   channel_policy_json=?, review_policy_json=?, presentation_policy_json=?,
                   config_json=?, digest=? WHERE id=? AND status='draft'""",
                (
                    effective_prompt,
                    json.dumps(policies["runtime_policy"]),
                    json.dumps(policies["context_policy"]),
                    json.dumps(policies["channel_policy"]),
                    json.dumps(policies["review_policy"]),
                    json.dumps(policies["presentation_policy"]),
                    json.dumps(policies["config"], ensure_ascii=False),
                    digest,
                    draft["id"],
                ),
            )
            if pack_version_ids is not None:
                self._replace_packs(connection, draft["id"], effective_packs)
            if capability_bindings is not None:
                self._replace_capabilities(connection, draft["id"], effective_capabilities)
            if name is not None and not name.strip():
                raise ValueError("Agent name is required")
            connection.execute(
                """UPDATE agents SET name=COALESCE(?, name),
                   description=COALESCE(?, description), language=COALESCE(?, language),
                   updated_at=? WHERE id=?""",
                (
                    name.strip() if name is not None else None,
                    description.strip() if description is not None else None,
                    language,
                    at,
                    agent_id,
                ),
            )
            self._audit(
                connection,
                actor,
                "agent.draft_updated",
                agent_id,
                target_version=str(draft["version"]),
                before_digest=before_digest,
                after_digest=digest,
            )
            connection.commit()
        return self.get_agent(agent_id)

    def validate_draft(self, agent_id: str, actor: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            draft = self._ensure_draft(connection, agent_id, actor)
            findings = self._validate_version(connection, draft)
            result = self._save_validation(connection, draft, findings, actor)
            self._audit(
                connection,
                actor,
                "agent.draft_validated",
                agent_id,
                target_version=str(draft["version"]),
                result="succeeded" if result["status"] == "passed" else "failed",
                metadata={"validation_run_id": result["id"]},
            )
            connection.commit()
        return result

    def _validate_version(self, connection: sqlite3.Connection, version: sqlite3.Row) -> list[dict[str, str]]:
        findings: list[dict[str, str]] = []
        runtime = _loads(version["runtime_policy_json"], {})
        config = _loads(version["config_json"], {})
        model_capability_flags: dict[str, Any] = {}
        current_model = self._current_model_binding(connection, str(version["agent_id"]))
        current_model_version_id = (
            str(current_model["model_profile_version_id"]) if current_model else ""
        )
        model = connection.execute(
            """SELECT mp.status AS profile_status, p.status AS provider_status,
                      p.protocol, pv.endpoint_ref, pv.secret_ref_id,
                      mpv.capabilities_json
               FROM model_profile_versions mpv
               JOIN model_profiles mp ON mp.id=mpv.model_profile_id
               JOIN model_provider_versions pv ON pv.id=mpv.provider_version_id
               JOIN model_providers p ON p.id=pv.provider_id
               WHERE mpv.id=?""",
            (current_model_version_id,),
        ).fetchone()
        if not model:
            findings.append(self._finding("model_profile_missing"))
        else:
            if model["profile_status"] != "active":
                findings.append(self._finding("model_profile_not_active"))
            if model["provider_status"] != "active":
                findings.append(self._finding("model_provider_not_active"))
            model_capability_flags = model_capabilities(model["capabilities_json"])
            if not model_capability_flags.get("tool_calling"):
                findings.append(self._finding("model_tool_calling_missing"))
            if model["protocol"] == "openai-compatible":
                endpoint_ready = self._validate_secret_ref(
                    connection, model["endpoint_ref"], "model_endpoint_unresolved", findings
                )
                secret_ready = True
                if model["secret_ref_id"]:
                    secret_ready = self._validate_secret_ref(
                        connection, model["secret_ref_id"], "model_api_key_unresolved", findings
                    )
                if endpoint_ready and secret_ready:
                    readiness = self.models.probe_readiness(current_model_version_id)
                    if readiness["finding"]:
                        findings.append(self._finding(readiness["finding"]["code"]))
        prompt = None
        if version["prompt_bundle_version_id"]:
            prompt = connection.execute(
                """SELECT pbv.id, pbv.content_json, pb.status AS bundle_status
                   FROM prompt_bundle_versions pbv
                   JOIN prompt_bundles pb ON pb.id=pbv.prompt_bundle_id
                   WHERE pbv.id=?""",
                (version["prompt_bundle_version_id"],),
            ).fetchone()
        if version["prompt_bundle_version_id"] and prompt is None:
            findings.append(self._finding("prompt_bundle_missing"))
        elif prompt is not None and prompt["bundle_status"] != "active":
            findings.append(self._finding("prompt_bundle_not_active"))
        packs = connection.execute(
            """SELECT cp.status, cp.id AS pack_id, cp.trust_level,
                      cpv.id, cpv.version, cpv.digest, cpv.manifest_json
               FROM agent_version_packs avp
               JOIN capability_pack_versions cpv ON cpv.id=avp.pack_version_id
               JOIN capability_packs cp ON cp.id=cpv.pack_id
               WHERE avp.agent_version_id=? AND avp.enabled=1
               ORDER BY avp.position, cpv.id""",
            (version["id"],),
        ).fetchall()
        capability_rows = connection.execute(
            """SELECT avc.capability_version_id, avc.role, avc.position,
                      cp.id AS capability_id, cp.kind, cp.status,
                      cpv.version, cpv.content_digest, cpv.lifecycle_state
               FROM agent_version_capabilities avc
               JOIN capability_package_versions cpv ON cpv.id=avc.capability_version_id
               JOIN capability_packages cp ON cp.id=cpv.capability_id
               WHERE avc.agent_version_id=? AND avc.enabled=1
               ORDER BY avc.position, avc.capability_version_id""",
            (version["id"],),
        ).fetchall()
        capability_bindings = [
            CapabilityBinding(
                str(row["capability_version_id"]),
                str(row["role"]),
                int(row["position"]),
            )
            for row in capability_rows
        ]
        if any(row["kind"] != row["role"] for row in capability_rows):
            findings.append(self._finding("capability_package_role_mismatch"))
        if any(
            row["status"] != "available" or row["lifecycle_state"] != "workspace-installed"
            for row in capability_rows
        ):
            findings.append(self._finding("capability_package_unavailable"))
        native_tools = ToolRegistry()
        if capability_bindings:
            if self.capability_packages is None:
                findings.append(self._finding("capability_package_loader_unavailable"))
            else:
                try:
                    native_tools = self.capability_packages.tools_for(capability_bindings)
                except (KeyError, RuntimeError, ValueError) as exc:
                    findings.append(self._finding("capability_package_not_loadable", str(exc)))
        if not packs:
            findings.append(self._finding("capability_pack_missing"))
        if any(pack["status"] != "installed" for pack in packs):
            findings.append(self._finding("capability_pack_not_installed"))
        if self.packs is not None and self.tools is not None and packs:
            pack_refs = [
                {
                    "pack_version_id": pack["id"],
                    "pack_id": pack["pack_id"],
                    "version": pack["version"],
                    "digest": pack["digest"],
                }
                for pack in packs
            ]
            try:
                loaded_packs = self.packs.resolve_refs(pack_refs)
                selected_tools = self.packs.tools_for(pack_refs, self.tools)
            except (KeyError, ValueError) as exc:
                code = (
                    "capability_pack_content_drift"
                    if "content digest mismatch" in str(exc)
                    else "capability_pack_version_not_loaded"
                )
                findings.append(self._finding(code))
            else:
                try:
                    selected_tools.merge_from(native_tools)
                except ValueError as exc:
                    findings.append(self._finding("capability_package_tool_conflict", str(exc)))
                connector_resolution = None
                baseline_tools = ToolRegistry()
                baseline_tools.merge_from(selected_tools)
                try:
                    connector_resolution = resolve_connector_bindings(
                        connection,
                        self.tools,
                        config.get("connector_bindings"),
                        normalize=False,
                    )
                    selected_tools.merge_from(connector_resolution.tools)
                except ValueError as exc:
                    findings.append(self._finding("connector_binding_invalid", str(exc)))
                allowlist = config.get("tool_allowlist")
                if not isinstance(allowlist, list):
                    findings.append(self._finding("agent_tool_allowlist_missing"))
                    allowlist = []
                self._validate_pack_contracts(
                    persisted_packs=packs,
                    loaded_packs=loaded_packs,
                    runtime=runtime,
                    allowlist=allowlist,
                    model_capabilities=model_capability_flags,
                    prompt_content=_loads(prompt["content_json"], {}) if prompt else {},
                    findings=findings,
                )
                available = {item.name for item in selected_tools.definitions()}
                unknown = sorted(set(allowlist) - available)
                if unknown:
                    findings.append(self._finding("agent_tool_allowlist_unavailable", ",".join(unknown)))
                effective_allowlist = [name for name in allowlist if name in available]
                if connector_resolution is not None:
                    effective_allowlist = effective_connector_allowlist(
                        effective_allowlist,
                        connector_resolution,
                    )
                selected_tools = selected_tools.subset(list(dict.fromkeys(effective_allowlist)))
                max_tool_risk = config.get("max_tool_risk", ToolRisk.CONTROLLED_ACTION.value)
                if max_tool_risk not in {
                    ToolRisk.READ_ONLY.value,
                    ToolRisk.CONTROLLED_ACTION.value,
                }:
                    findings.append(self._finding("max_tool_risk_invalid"))
                else:
                    risk_limit = _TOOL_RISK_RANK[ToolRisk(max_tool_risk)]
                    excessive = sorted(
                        definition.name
                        for definition in selected_tools.definitions()
                        if _TOOL_RISK_RANK[definition.risk] > risk_limit
                    )
                    if excessive:
                        findings.append(self._finding("agent_tool_risk_exceeds_limit", ",".join(excessive)))
                native_tool_names = native_tools.names()
                provider_ids = sorted(
                    {
                        item.provider_id
                        for item in selected_tools.definitions()
                        if item.name not in native_tool_names
                    }
                )
                provider_statuses = (
                    {
                        row["id"]: row["status"]
                        for row in connection.execute(
                            f"""SELECT id, status FROM tool_providers
                            WHERE id IN ({",".join("?" for _ in provider_ids)})""",
                            tuple(provider_ids),
                        ).fetchall()
                    }
                    if provider_ids
                    else {}
                )
                for provider_id in provider_ids:
                    status = provider_statuses.get(provider_id)
                    if status is None:
                        findings.append(self._finding("tool_provider_missing", provider_id))
                    elif status in {
                        "draft",
                        "disabled",
                        "unavailable",
                        "schema_mismatch",
                    }:
                        findings.append(
                            self._finding(
                                "tool_provider_unavailable",
                                f"{provider_id}:{status}",
                            )
                        )
                if connector_resolution is not None:
                    try:
                        baseline_digest = published_tool_baseline_digest(
                            baseline_tools,
                            connector_resolution,
                            allowlist,
                        )
                    except (KeyError, ValueError):
                        findings.append(self._finding("tool_schema_baseline_unavailable"))
                    else:
                        if (
                            version["tool_schema_digest"]
                            and version["tool_schema_digest"] != baseline_digest
                        ):
                            findings.append(self._finding("tool_schema_drift"))
        # This is the same first-party composition boundary used by Profile
        # readiness and Runtime resolution.
        # it: those remain a separate, later compatibility layer.
        if self.packs is not None and self.tools is not None and packs:
            composition_refs = [
                {
                    "pack_version_id": pack["id"],
                    "pack_id": pack["pack_id"],
                    "version": pack["version"],
                    "digest": pack["digest"],
                }
                for pack in packs
            ]
            try:
                compose_agent_surface(
                    packs=self.packs,
                    runtime_tools=self.tools,
                    capability_packages=self.capability_packages,
                    pack_refs=composition_refs,
                    capability_bindings=capability_bindings,
                    prompt_content_json=str(prompt["content_json"]) if prompt else None,
                )
            except AgentCompositionError as exc:
                findings.append(self._finding("agent_composition_invalid", str(exc)))
        if self.agent_profiles is not None and version["status"] == "draft":
            findings.extend(self.agent_profiles.validate_version_binding(connection, version))
        elif version["status"] == "draft" and any(
            config.get(key) is not None
            for key in ("agent_profile_id", "agent_profile_version", "agent_profile_digest")
        ):
            findings.append(self._finding("profile_registry_unavailable"))
        self._bounded(runtime, "max_tool_calls", 1, 120, findings)
        self._bounded(runtime, "max_tool_waves", 1, 60, findings)
        self._bounded(runtime, "max_concurrency", 1, 6, findings)
        if "tool_timeout_seconds" in runtime:
            self._bounded_number(runtime, "tool_timeout_seconds", 0.1, 300, findings)
        if "run_timeout_seconds" in runtime:
            self._bounded_number(runtime, "run_timeout_seconds", 0.1, 1800, findings)
        context = _loads(version["context_policy_json"], {})
        if "message_limit" in context:
            self._bounded(context, "message_limit", 1, 500, findings)
        if "compact_after_messages" in context:
            self._bounded(context, "compact_after_messages", 1, 500, findings)
        if "tool_result_recent_count" in context:
            self._bounded(context, "tool_result_recent_count", 1, 10, findings)
        if "tool_result_old_max_chars" in context:
            self._bounded(context, "tool_result_old_max_chars", 500, 20_000, findings)
        if "tool_result_recent_max_chars" in context:
            self._bounded(context, "tool_result_recent_max_chars", 1_000, 100_000, findings)
        if "safety_margin_ratio" in context:
            self._bounded_number(context, "safety_margin_ratio", 0.01, 0.20, findings)
        if "safety_margin_min_tokens" in context:
            self._bounded(context, "safety_margin_min_tokens", 1_024, 32_768, findings)
        for key in ("checkpoint_ratio", "reference_ratio", "minimal_ratio"):
            if key in context:
                self._bounded_number(context, key, 0.50, 0.99, findings)
        if "recent_protocol_pairs" in context:
            self._bounded(context, "recent_protocol_pairs", 1, 8, findings)
        if "recent_history_messages" in context:
            self._bounded(context, "recent_history_messages", 4, 64, findings)
        if "evidence_card_max_chars" in context:
            self._bounded(context, "evidence_card_max_chars", 800, 8_000, findings)
        ratios = [
            context.get("checkpoint_ratio"),
            context.get("reference_ratio"),
            context.get("minimal_ratio"),
        ]
        if all(isinstance(value, (int, float)) and not isinstance(value, bool) for value in ratios):
            if not ratios[0] < ratios[1] < ratios[2]:
                findings.append(self._finding("context_pressure_ratios_not_increasing"))
        if (
            isinstance(context.get("message_limit"), int)
            and isinstance(context.get("compact_after_messages"), int)
            and context["compact_after_messages"] > context["message_limit"]
        ):
            findings.append(self._finding("compact_after_messages_exceeds_message_limit"))
        if (
            isinstance(context.get("tool_result_old_max_chars"), int)
            and isinstance(context.get("tool_result_recent_max_chars"), int)
            and context["tool_result_old_max_chars"] > context["tool_result_recent_max_chars"]
        ):
            findings.append(self._finding("tool_result_old_limit_exceeds_recent_limit"))
        channel = _loads(version["channel_policy_json"], {})
        instance_ids = channel.get("channel_instance_ids", [])
        if (
            not isinstance(instance_ids, list)
            or any(not isinstance(item, str) or not item for item in instance_ids)
            or len(instance_ids) != len(set(instance_ids))
        ):
            findings.append(self._finding("channel_instance_ids_invalid"))
            instance_ids = []
        for instance_id in instance_ids:
            if not connection.execute(
                "SELECT 1 FROM channel_instances WHERE id=?", (instance_id,)
            ).fetchone():
                findings.append(self._finding("channel_instance_missing", instance_id))
        active_bindings = {
            row["channel_instance_id"]
            for row in connection.execute(
                """SELECT channel_instance_id FROM agent_channel_bindings
                   WHERE agent_id=? AND active=1""",
                (version["agent_id"],),
            ).fetchall()
        }
        if instance_ids and not active_bindings.issubset(set(instance_ids)):
            findings.append(self._finding("active_channel_binding_not_allowed"))
        if "reply_enabled" in channel and not isinstance(channel["reply_enabled"], bool):
            findings.append(self._finding("channel_reply_enabled_must_be_boolean"))
        review = _loads(version["review_policy_json"], {})
        if "enabled" in review and not isinstance(review["enabled"], bool):
            findings.append(self._finding("review_enabled_must_be_boolean"))
        if "delay_seconds" in review and (
            not isinstance(review["delay_seconds"], int)
            or isinstance(review["delay_seconds"], bool)
            or not 0 <= review["delay_seconds"] <= _MAX_REVIEW_DELAY_SECONDS
        ):
            findings.append(self._finding("review_delay_seconds_outside_limit"))
        presentation = _loads(version["presentation_policy_json"], {})
        reply_footer = presentation.get("reply_footer", "")
        if not isinstance(reply_footer, str) or len(reply_footer) > _MAX_REPLY_FOOTER_LENGTH:
            findings.append(self._finding("reply_footer_invalid"))
        tags = config.get("tags", [])
        if (
            not isinstance(tags, list)
            or len(tags) > _MAX_AGENT_TAGS
            or any(
                not isinstance(tag, str) or not tag.strip() or len(tag.strip()) > _MAX_AGENT_TAG_LENGTH
                for tag in tags
            )
            or len({tag.strip() for tag in tags if isinstance(tag, str)}) != len(tags)
        ):
            findings.append(self._finding("agent_tags_invalid"))
        return findings

    def _validate_pack_contracts(
        self,
        *,
        persisted_packs: list[sqlite3.Row],
        loaded_packs: list[Any],
        runtime: dict[str, Any],
        allowlist: list[Any],
        model_capabilities: dict[str, Any],
        prompt_content: dict[str, Any],
        findings: list[dict[str, str]],
    ) -> None:
        selected_names = {str(item) for item in allowlist if isinstance(item, str)}
        for persisted, loaded in zip(persisted_packs, loaded_packs, strict=True):
            detail = f"{loaded.id}@{loaded.version}"
            manifest = _loads(persisted["manifest_json"], {})
            if persisted["digest"] != loaded.digest:
                findings.append(self._finding("capability_pack_content_drift", detail))
            if persisted["trust_level"] != loaded.trust_level:
                findings.append(self._finding("capability_pack_trust_mismatch", detail))
            if "source_revision" in manifest and manifest.get("source_revision") != loaded.source_revision:
                findings.append(self._finding("capability_pack_source_revision_mismatch", detail))
            declared_skills = manifest.get("skills")
            if declared_skills is not None and set(declared_skills) != {skill.id for skill in loaded.skills}:
                findings.append(self._finding("capability_pack_skill_contract_mismatch", detail))
            declared_tools = manifest.get("tools")
            if declared_tools is not None and set(declared_tools) != set(loaded.tool_names):
                findings.append(self._finding("capability_pack_tool_contract_mismatch", detail))

            contract = loaded.domain_config.get("agent_validation", {})
            if not isinstance(contract, Mapping):
                findings.append(self._finding("capability_pack_agent_contract_invalid", detail))
                continue
            required_trust = contract.get("required_trust_level")
            if required_trust and persisted["trust_level"] != required_trust:
                findings.append(self._finding("capability_pack_required_trust_mismatch", detail))
            for capability in contract.get("required_model_capabilities", ()):
                if not model_capabilities.get(str(capability)):
                    findings.append(
                        self._finding(
                            "capability_pack_model_capability_missing",
                            f"{detail}:{capability}",
                        )
                    )
            fallback_skills = {skill.id for skill in loaded.skills if skill.fallback}
            for skill_id in contract.get("required_fallback_skills", ()):
                if skill_id not in fallback_skills:
                    findings.append(
                        self._finding(
                            "capability_pack_fallback_skill_missing",
                            f"{detail}:{skill_id}",
                        )
                    )
            providers = {definition.provider_id for definition in loaded.tools.definitions()}
            for provider_id in contract.get("required_tool_providers", ()):
                if provider_id not in providers:
                    findings.append(
                        self._finding(
                            "capability_pack_tool_provider_mismatch",
                            f"{detail}:{provider_id}",
                        )
                    )
            if contract.get("require_all_pack_tools"):
                missing_tools = sorted(set(loaded.tool_names) - selected_names)
                if missing_tools:
                    findings.append(
                        self._finding(
                            "capability_pack_required_tools_disabled",
                            f"{detail}:{','.join(missing_tools)}",
                        )
                    )
            required_runtime = contract.get("runtime_policy", {})
            if isinstance(required_runtime, Mapping):
                for field, expected in required_runtime.items():
                    if runtime.get(str(field)) != expected:
                        findings.append(
                            self._finding(
                                "capability_pack_runtime_policy_mismatch",
                                f"{detail}:{field}",
                            )
                        )
            required_prompt_revision = contract.get("prompt_source_revision")
            if required_prompt_revision:
                expected_revision = (
                    loaded.source_revision
                    if required_prompt_revision == "pack"
                    else str(required_prompt_revision)
                )
                if prompt_content.get("source_revision") != expected_revision:
                    findings.append(self._finding("capability_pack_prompt_revision_mismatch", detail))

    @staticmethod
    def _finding(code: str, detail: str = "") -> dict[str, str]:
        item = {"code": code, "level": "error"}
        if detail:
            item["detail"] = detail
        return item

    @classmethod
    def _bounded(
        cls,
        policy: dict[str, Any],
        field: str,
        minimum: int,
        maximum: int,
        findings: list[dict[str, str]],
    ) -> None:
        value = policy.get(field)
        if not isinstance(value, int) or not minimum <= value <= maximum:
            findings.append(cls._finding(f"{field}_outside_limit"))

    @classmethod
    def _bounded_number(
        cls,
        policy: dict[str, Any],
        field: str,
        minimum: float,
        maximum: float,
        findings: list[dict[str, str]],
    ) -> None:
        value = policy.get(field)
        if (
            not isinstance(value, (int, float))
            or isinstance(value, bool)
            or not minimum <= float(value) <= maximum
        ):
            findings.append(cls._finding(f"{field}_outside_limit"))

    def _validate_secret_ref(
        self,
        connection: sqlite3.Connection,
        ref_id: str,
        code: str,
        findings: list[dict[str, str]],
    ) -> bool:
        # Confirm the metadata in the same publish transaction, then resolve
        # through the boundary adapter without placing the value in SQL.
        if not connection.execute("SELECT 1 FROM secret_refs WHERE id=?", (ref_id,)).fetchone():
            findings.append(self._finding(code))
            return False
        try:
            self.models.secrets.resolve(ref_id)
        except (KeyError, ValueError, OSError):
            findings.append(self._finding(code))
            return False
        return True

    @staticmethod
    def _save_validation(
        connection: sqlite3.Connection,
        version: sqlite3.Row,
        findings: list[dict[str, str]],
        actor: str,
    ) -> dict[str, Any]:
        validation_id = new_id("validation")
        at = iso()
        status = "failed" if findings else "passed"
        connection.execute(
            """INSERT INTO config_validation_runs(
               id, target_type, target_id, target_digest, status, findings_json,
               actor_ref, created_at, finished_at
            ) VALUES (?, 'agent_version', ?, ?, ?, ?, ?, ?, ?)""",
            (
                validation_id,
                version["id"],
                version["digest"],
                status,
                json.dumps(findings, ensure_ascii=False),
                actor,
                at,
                at,
            ),
        )
        return {
            "id": validation_id,
            "agent_version_id": version["id"],
            "status": status,
            "findings": findings,
            "created_at": at,
            "finished_at": at,
        }

    def publish(self, agent_id: str, actor: str, note: str = "") -> dict[str, Any]:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            agent = connection.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
            if not agent:
                raise KeyError(agent_id)
            if agent["status"] == "archived":
                raise ValueError("archived Agent cannot be published")
            draft = connection.execute(
                """SELECT * FROM agent_versions
                   WHERE agent_id=? AND status='draft' ORDER BY version DESC LIMIT 1""",
                (agent_id,),
            ).fetchone()
            if not draft:
                raise ValueError("Agent has no Draft to publish")
            findings = self._validate_version(connection, draft)
            if not findings:
                draft = self._freeze_tool_schema(connection, draft)
            validation = self._save_validation(connection, draft, findings, actor)
            if findings:
                self._audit(
                    connection,
                    actor,
                    "agent.publish_failed",
                    agent_id,
                    target_version=str(draft["version"]),
                    after_digest=draft["digest"],
                    result="failed",
                    metadata={"validation_run_id": validation["id"], "findings": findings},
                )
                connection.commit()
                raise AgentValidationError(findings)
            at = iso()
            connection.execute(
                """UPDATE agent_versions SET status='published', published_at=?
                   WHERE id=? AND status='draft'""",
                (at, draft["id"]),
            )
            connection.execute(
                """UPDATE agents SET active_version_id=?, status='published', updated_at=?
                   WHERE id=?""",
                (draft["id"], at, agent_id),
            )
            connection.execute(
                """INSERT INTO publish_events(
                   id, agent_id, from_version_id, to_version_id, kind,
                   actor_ref, note, created_at
                ) VALUES (?, ?, ?, ?, 'publish', ?, ?, ?)""",
                (
                    new_id("publish"),
                    agent_id,
                    agent["active_version_id"],
                    draft["id"],
                    actor,
                    note[:1000],
                    at,
                ),
            )
            self._audit(
                connection,
                actor,
                "agent.published",
                agent_id,
                target_version=str(draft["version"]),
                after_digest=draft["digest"],
                metadata={"previous_version_id": agent["active_version_id"], "note": note[:1000]},
            )
            connection.commit()
        return self.get_agent(agent_id)

    def rollback(self, agent_id: str, target_version_id: str, actor: str, note: str = "") -> dict[str, Any]:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            agent = connection.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
            if not agent:
                raise KeyError(agent_id)
            if agent["status"] == "archived":
                raise ValueError("archived Agent cannot be rolled back")
            target = connection.execute(
                """SELECT * FROM agent_versions
                   WHERE id=? AND agent_id=? AND status='published'""",
                (target_version_id, agent_id),
            ).fetchone()
            if not target:
                raise ValueError("rollback target must be a published version of this Agent")
            candidate = dict(target)
            candidate["id"] = new_id("agentver")
            candidate["version"] = connection.execute(
                "SELECT COALESCE(MAX(version), 0)+1 FROM agent_versions WHERE agent_id=?",
                (agent_id,),
            ).fetchone()[0]
            candidate["status"] = "draft"
            connection.execute(
                """INSERT INTO agent_versions(
                   id, agent_id, version, status, prompt_bundle_version_id,
                   runtime_policy_json, context_policy_json,
                   channel_policy_json, review_policy_json, presentation_policy_json,
                   config_json, tool_schema_digest, digest, created_by, created_at
                ) VALUES (?, ?, ?, 'draft', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    candidate["id"],
                    agent_id,
                    candidate["version"],
                    target["prompt_bundle_version_id"],
                    target["runtime_policy_json"],
                    target["context_policy_json"],
                    target["channel_policy_json"],
                    target["review_policy_json"],
                    target["presentation_policy_json"],
                    target["config_json"],
                    target["tool_schema_digest"],
                    target["digest"],
                    actor,
                    iso(),
                ),
            )
            connection.execute(
                """INSERT INTO agent_version_packs(
                   agent_version_id, pack_version_id, position, enabled
                ) SELECT ?, pack_version_id, position, enabled
                  FROM agent_version_packs WHERE agent_version_id=?""",
                (candidate["id"], target["id"]),
            )
            connection.execute(
                """INSERT INTO agent_version_capabilities(
                   agent_version_id, capability_version_id, role, position, enabled,
                   installation_id, artifact_digest
                ) SELECT ?, capability_version_id, role, position, enabled,
                         installation_id, artifact_digest
                  FROM agent_version_capabilities WHERE agent_version_id=?""",
                (candidate["id"], target["id"]),
            )
            candidate_row = connection.execute(
                "SELECT * FROM agent_versions WHERE id=?", (candidate["id"],)
            ).fetchone()
            findings = self._validate_version(connection, candidate_row)
            validation = self._save_validation(connection, candidate_row, findings, actor)
            if findings:
                self._audit(
                    connection,
                    actor,
                    "agent.rollback_failed",
                    agent_id,
                    target_version=str(candidate["version"]),
                    result="failed",
                    metadata={
                        "validation_run_id": validation["id"],
                        "findings": findings,
                        "candidate_draft_id": candidate["id"],
                    },
                )
                connection.commit()
                raise AgentValidationError(findings)
            at = iso()
            connection.execute(
                """UPDATE agent_versions SET status='published', published_at=? WHERE id=?""",
                (at, candidate["id"]),
            )
            connection.execute(
                """UPDATE agents SET active_version_id=?, status='published', updated_at=?
                   WHERE id=?""",
                (candidate["id"], at, agent_id),
            )
            connection.execute(
                """INSERT INTO publish_events(
                   id, agent_id, from_version_id, to_version_id, kind,
                   actor_ref, note, created_at
                ) VALUES (?, ?, ?, ?, 'rollback', ?, ?, ?)""",
                (
                    new_id("publish"),
                    agent_id,
                    agent["active_version_id"],
                    candidate["id"],
                    actor,
                    note[:1000],
                    at,
                ),
            )
            self._audit(
                connection,
                actor,
                "agent.rolled_back",
                agent_id,
                target_version=str(candidate["version"]),
                after_digest=candidate["digest"],
                metadata={"copied_from": target_version_id, "note": note[:1000]},
            )
            connection.commit()
        return self.get_agent(agent_id)

    def clone(
        self,
        source_agent_id: str,
        new_agent_id: str,
        name: str,
        actor: str,
    ) -> dict[str, Any]:
        source = self.get_agent(source_agent_id)
        source_version = next(
            (version for version in source["versions"] if version["id"] == source["active_version_id"]),
            source["versions"][0],
        )
        return self.create_agent(
            new_agent_id,
            name,
            actor,
            description=f"Cloned from {source_agent_id}",
            language=source["language"],
            model_profile_id=source["current_model"]["model_profile_id"],
            persona_id=source["current_persona"]["id"],
            prompt_bundle_version_id=source_version["prompt_bundle_version_id"],
            runtime_policy=source_version["runtime_policy"],
            context_policy=source_version["context_policy"],
            channel_policy={},
            review_policy=source_version["review_policy"],
            presentation_policy=source_version["presentation_policy"],
            config={**source_version["config"], "cloned_from": source_agent_id},
            pack_version_ids=[pack["pack_version_id"] for pack in source_version["packs"]],
            capability_bindings=[
                {
                    "capability_version_id": item["capability_version_id"],
                    "role": item["role"],
                }
                for item in source_version["capabilities"]
                if item["enabled"]
            ],
        )

    def set_status(self, agent_id: str, status: str, actor: str) -> dict[str, Any]:
        if status not in {"enabled", "disabled", "archived"}:
            raise ValueError("status transition must be enabled, disabled, or archived")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            agent = connection.execute(
                "SELECT status, active_version_id FROM agents WHERE id=?",
                (agent_id,),
            ).fetchone()
            if not agent:
                raise KeyError(agent_id)
            if agent["status"] == "archived":
                raise ValueError("archived Agent status cannot be changed")
            default = connection.execute(
                "SELECT value_json FROM system_settings WHERE key='default_agent_id'"
            ).fetchone()
            if (
                status in {"disabled", "archived"}
                and default
                and _loads(default["value_json"], None) == agent_id
            ):
                raise ValueError("default Agent must be changed before disabling or archiving")
            if status == "enabled":
                if agent["status"] != "disabled" or not agent["active_version_id"]:
                    raise ValueError("only a disabled Agent with a published version can be enabled")
                version = connection.execute(
                    "SELECT * FROM agent_versions WHERE id=? AND status='published'",
                    (agent["active_version_id"],),
                ).fetchone()
                if not version:
                    raise ValueError("Agent has no published version to enable")
                findings = self._validate_version(connection, version)
                if findings:
                    raise AgentValidationError(findings)
                stored_status = "published"
                action = "agent.enabled"
            else:
                stored_status = status
                action = f"agent.{status}"
            connection.execute(
                """UPDATE agents SET status=?, updated_at=?, archived_at=? WHERE id=?""",
                (
                    stored_status,
                    at,
                    at if stored_status == "archived" else None,
                    agent_id,
                ),
            )
            if stored_status == "archived":
                connection.execute(
                    "UPDATE agent_channel_bindings SET active=0, updated_at=? WHERE agent_id=?",
                    (at, agent_id),
                )
            self._audit(
                connection,
                actor,
                action,
                agent_id,
                metadata={
                    "previous_status": agent["status"],
                    "new_status": stored_status,
                },
            )
            connection.commit()
        return self.get_agent(agent_id)

    def set_default_agent(self, agent_id: str, actor: str) -> None:
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            agent = connection.execute("SELECT status FROM agents WHERE id=?", (agent_id,)).fetchone()
            if not agent:
                raise KeyError(agent_id)
            if agent["status"] != "published":
                raise ValueError("default Agent must be published")
            before = connection.execute(
                "SELECT value_json FROM system_settings WHERE key='default_agent_id'"
            ).fetchone()
            connection.execute(
                """INSERT INTO system_settings(key, value_json, version, updated_by, updated_at)
                   VALUES ('default_agent_id', ?, 1, ?, ?)
                   ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,
                     version=system_settings.version+1, updated_by=excluded.updated_by,
                     updated_at=excluded.updated_at""",
                (json.dumps(agent_id), actor, at),
            )
            self._audit(
                connection,
                actor,
                "agent.default_changed",
                agent_id,
                metadata={"previous": _loads(before["value_json"], None) if before else None},
            )
            connection.commit()

    def pin_case_version(
        self,
        case_id: str,
        version_id: str | None,
        actor: str,
    ) -> dict[str, Any]:
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            case = connection.execute("SELECT * FROM cases WHERE id=?", (case_id,)).fetchone()
            if not case:
                raise KeyError(case_id)
            if version_id:
                version = connection.execute(
                    """SELECT id FROM agent_versions
                       WHERE id=? AND agent_id=? AND status='published'""",
                    (version_id, case["agent_id"]),
                ).fetchone()
                if not version:
                    raise ValueError("pinned version must be a published version of the Case Agent")
            connection.execute(
                "UPDATE cases SET pinned_agent_version_id=?, updated_at=? WHERE id=?",
                (version_id, at, case_id),
            )
            connection.execute(
                """INSERT INTO events(
                   case_id, agent_id, kind, payload_json, created_at
                ) VALUES (?, ?, 'case.agent_version_pin_changed', ?, ?)""",
                (
                    case_id,
                    case["agent_id"],
                    json.dumps(
                        {
                            "from": case["pinned_agent_version_id"],
                            "to": version_id,
                            "actor": actor,
                        }
                    ),
                    at,
                ),
            )
            connection.execute(
                """INSERT INTO audit_events(
                   actor_type, actor_ref, action, target_type, target_id,
                   result, metadata_json, created_at
                ) VALUES ('admin', ?, 'case.agent_version_pin_changed', 'case', ?,
                          'succeeded', ?, ?)""",
                (
                    actor,
                    case_id,
                    json.dumps({"from": case["pinned_agent_version_id"], "to": version_id}),
                    at,
                ),
            )
            connection.commit()
        with self.database.connect() as connection:
            return dict(connection.execute("SELECT * FROM cases WHERE id=?", (case_id,)).fetchone())

    def diff_versions(self, agent_id: str, from_version_id: str, to_version_id: str) -> dict[str, Any]:
        agent = self.get_agent(agent_id)
        versions = {item["id"]: item for item in agent["versions"]}
        if from_version_id not in versions or to_version_id not in versions:
            raise KeyError("Agent version")
        before = versions[from_version_id]
        after = versions[to_version_id]
        comparable = (
            "prompt_bundle_version_id",
            "runtime_policy",
            "context_policy",
            "channel_policy",
            "review_policy",
            "presentation_policy",
            "config",
            "packs",
        )
        changes = [
            {"field": field, "before": before[field], "after": after[field]}
            for field in comparable
            if before[field] != after[field]
        ]
        return {
            "agent_id": agent_id,
            "from_version_id": from_version_id,
            "to_version_id": to_version_id,
            "changes": changes,
        }
