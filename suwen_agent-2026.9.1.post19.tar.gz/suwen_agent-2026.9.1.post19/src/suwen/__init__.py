"""Suwen（素问）工程命名空间。"""

from .release import SUWEN_RELEASE_VERSION, __version__

__all__ = ["SUWEN_RELEASE_VERSION", "__version__"]
