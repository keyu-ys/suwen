from __future__ import annotations

import asyncio
import json
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime, timedelta
from typing import Any, Protocol

from .artifacts import ArtifactStore
from .cases import CaseService
from .feishu_cards import adapt_markdown_for_feishu, apply_message_footer, card_summary
from .repository import Repository
from .types import InboundEvent, RunResult


class HarnessPort(Protocol):
    async def run(self, case_id: str, trigger_message_id: str) -> RunResult: ...


class OutboxPort(Protocol):
    async def dispatch_outbox(self, outbox_id: str) -> dict[str, Any]: ...


class DiagnosticService:
    _INBOUND_JOB_LEASE_SECONDS = 20 * 60
    _FAILURE_REPLY = (
        "本次排查未能完成，系统已经结束了这一轮处理，不会继续停留在处理中。"
        "你可以重新发送问题；本轮已经保存的 Case 记录不会丢失。"
    )
    _STOPPED_REPLY = "本次排查已停止，不会继续停留在处理中。"

    def __init__(
        self,
        repository: Repository,
        cases: CaseService,
        harness: HarnessPort,
        review_delay_seconds: int,
        artifacts: ArtifactStore | None = None,
    ) -> None:
        self.repository = repository
        self.cases = cases
        self.harness = harness
        self.review_delay_seconds = review_delay_seconds
        self.artifacts = artifacts
        self._case_locks: dict[str, asyncio.Lock] = {}
        self._ingest_locks: dict[str, asyncio.Lock] = {}
        self._inbound_tasks: dict[str, set[asyncio.Task[Any]]] = {}
        self._active_execution_tasks: dict[str, set[asyncio.Task[Any]]] = {}
        self._inbound_idle = asyncio.Event()
        self._inbound_idle.set()
        self._execution_idle = asyncio.Event()
        self._execution_idle.set()
        self._draining = False
        self._outbox: OutboxPort | None = None

    async def create_case_and_message(
        self,
        content: str,
        actor_ref: str = "api:anonymous",
        agent_id: str | None = None,
        occurred_at: datetime | None = None,
    ) -> tuple[dict[str, Any], RunResult]:
        received_at = datetime.now(UTC)
        message_time = occurred_at or received_at
        if message_time.tzinfo is None or message_time.utcoffset() is None:
            raise ValueError("occurred_at must include a timezone")
        case = self.repository.create_case(content[:80] or "新问诊", message_time, agent_id)
        message = self.repository.add_message(
            case["id"],
            "user",
            content,
            actor_ref,
            now=message_time,
        )
        result = await self.harness.run(case["id"], message["id"])
        # Review scheduling is an execution concern. A replayed/imported
        # occurrence time must not move the scheduler into the past or future.
        self._schedule_review(case["id"], result.run_id, received_at)
        return self.repository.get_case(case["id"]), result

    def create_empty_case(self, agent_id: str | None = None) -> dict[str, Any]:
        # A Web draft is not yet an inquiry and therefore is not useful review input.
        return self.repository.create_case("新问诊", agent_id=agent_id)

    async def append_message(
        self,
        case_id: str,
        content: str,
        actor_ref: str = "api:anonymous",
        image_artifact_ids: tuple[str, ...] = (),
    ) -> RunResult:
        lock = self._case_locks.setdefault(case_id, asyncio.Lock())
        async with lock:
            case = self.repository.get_case(case_id)
            if self.repository.agent_status(case["agent_id"]) != "published":
                raise ValueError("case Agent is not accepting new messages")
            if case["lifecycle"] == "closed":
                self.repository.reopen_case(case_id, "api_activity")
            metadata: dict[str, Any] | None = None
            if image_artifact_ids:
                if self.artifacts is None:
                    raise ValueError("image attachment storage is unavailable")
                metadata = {
                    "attachments": self.artifacts.image_descriptors(
                        image_artifact_ids,
                        case_id=case_id,
                    )
                }
            message = self.repository.add_message(
                case_id,
                "user",
                content,
                actor_ref,
                metadata=metadata,
            )
            result = await self.harness.run(case_id, message["id"])
            self._schedule_review(case_id, result.run_id)
            return result

    async def handle_inbound(
        self,
        event: InboundEvent,
        on_admitted: Callable[[InboundEvent], Awaitable[Any]] | None = None,
        *,
        preclaimed: bool = False,
    ) -> dict[str, Any]:
        if event.command is not None:
            self.cases.assert_admitted(event)
        if event.command == "stop":
            return await self._handle_stop(event)
        if event.command in {"new_case", "clear"}:
            return await self._handle_reset(event)
        lock_key = self._inbound_lock_key(event)
        lock = self._ingest_locks.setdefault(lock_key, asyncio.Lock())
        task = asyncio.current_task()
        if task is not None:
            self._inbound_tasks.setdefault(lock_key, set()).add(task)
            self._inbound_idle.clear()
        try:
            async with lock:
                return await self._handle_inbound_locked(
                    event,
                    on_admitted,
                    preclaimed=preclaimed,
                )
        finally:
            if task is not None:
                tasks = self._inbound_tasks.get(lock_key)
                if tasks is not None:
                    tasks.discard(task)
                    if not tasks:
                        self._inbound_tasks.pop(lock_key, None)
                if not self._inbound_tasks:
                    self._inbound_idle.set()

    async def _handle_inbound_locked(
        self,
        event: InboundEvent,
        on_admitted: Callable[[InboundEvent], Awaitable[Any]] | None = None,
        *,
        preclaimed: bool = False,
    ) -> dict[str, Any]:
        case, message, duplicate = self.cases.ingest(event, preclaimed=preclaimed)
        if not duplicate and on_admitted is not None:
            await on_admitted(event)
        if self._draining:
            return {
                "case": case,
                "message": message,
                "duplicate": duplicate,
                "run": None,
                "queued": True,
            }

        now = datetime.now(UTC)
        job = self.repository.claim_job(
            self._inbound_job_key(message["id"]),
            now,
            now + timedelta(seconds=self._INBOUND_JOB_LEASE_SECONDS),
        )
        if job is not None:
            result = await self._execute_inbound_job(job, event)
            return {**result, "duplicate": duplicate}

        if duplicate:
            self._ensure_side_effects(case["id"], message)
        stored_job = self.repository.job_for_unique_key(self._inbound_job_key(message["id"]))
        return {
            "case": case,
            "message": message,
            "duplicate": duplicate,
            "run": None,
            "queued": bool(stored_job and stored_job["status"] != "completed"),
        }

    async def process_inbound_job(
        self,
        job: dict[str, Any],
        payload: dict[str, Any],
    ) -> bool:
        """Resume one already-leased inbound message after a worker handoff."""

        stored = self.repository.job_for_unique_key(str(job["unique_key"]))
        if stored is None or stored["status"] == "completed":
            return True
        if self._draining:
            self.repository.defer_job(
                job["id"],
                due_at=datetime.now(UTC) + timedelta(seconds=2),
                reason="runtime_draining",
            )
            return False
        self.repository.extend_job_lease(
            str(job["id"]),
            datetime.now(UTC) + timedelta(seconds=self._INBOUND_JOB_LEASE_SECONDS),
        )
        message = self.repository.get_message(str(payload["message_id"]))
        case = self.repository.get_case(str(payload["case_id"]))
        if message["case_id"] != case["id"] or job.get("case_id") != case["id"]:
            raise ValueError("process_inbound job does not match its persisted Case")
        event = self._event_from_message(case, message)
        try:
            result = await self._execute_inbound_job(job, event)
        except asyncio.CancelledError:
            stored = self.repository.job_for_unique_key(str(job["unique_key"]))
            if stored and stored["status"] == "completed":
                return True
            raise
        return not bool(result.get("queued"))

    async def _execute_inbound_job(
        self,
        job: dict[str, Any],
        event: InboundEvent,
    ) -> dict[str, Any]:
        payload = json.loads(job["payload_json"])
        message_id = str(payload["message_id"])
        event_id = str(payload["event_id"])
        message = self.repository.get_message(message_id)
        case = self.repository.get_case(str(job["case_id"]))
        task = asyncio.current_task()
        lock_key = self._inbound_lock_key(event)
        if task is not None:
            self._active_execution_tasks.setdefault(lock_key, set()).add(task)
            self._execution_idle.clear()
        try:
            result = await self._process_persisted_inbound(case, message, event)
        except asyncio.CancelledError as exc:
            cancel_reason = str(exc.args[0]) if exc.args else "runtime_cancelled"
            if cancel_reason != "user_stop":
                self.repository.defer_job(job["id"], reason=cancel_reason)
                raise
            try:
                await self._terminalize_inbound_failure(
                    case,
                    message,
                    event,
                    self._STOPPED_REPLY,
                    "user_stop",
                )
            except Exception as terminal_exc:
                self.repository.defer_job(
                    job["id"],
                    reason=f"terminal_reply_failed:{type(terminal_exc).__name__}",
                )
                return {
                    "case": case,
                    "message": message,
                    "run": None,
                    "queued": True,
                }
            self.repository.complete_inbound_job(
                job["id"],
                event_id,
                case["id"],
                "user_stop",
            )
            raise
        except Exception as exc:
            try:
                await self._terminalize_inbound_failure(
                    case,
                    message,
                    event,
                    self._FAILURE_REPLY,
                    "inbound_execution_failure",
                )
            except Exception as terminal_exc:
                self.repository.defer_job(
                    job["id"],
                    reason=f"terminal_reply_failed:{type(terminal_exc).__name__}",
                )
                return {
                    "case": case,
                    "message": message,
                    "run": None,
                    "queued": True,
                }
            self.repository.complete_inbound_job(
                job["id"],
                event_id,
                case["id"],
                f"{type(exc).__name__}: {exc}",
            )
            return {
                "case": self.repository.get_case(case["id"]),
                "message": message,
                "run": None,
                "failure": "terminal_fallback_delivered",
            }
        else:
            self.repository.complete_inbound_job(
                job["id"],
                event_id,
                case["id"],
            )
            return result
        finally:
            if task is not None:
                tasks = self._active_execution_tasks.get(lock_key)
                if tasks is not None:
                    tasks.discard(task)
                    if not tasks:
                        self._active_execution_tasks.pop(lock_key, None)
                if not self._active_execution_tasks:
                    self._execution_idle.set()

    async def _process_persisted_inbound(
        self,
        case: dict[str, Any],
        message: dict[str, Any],
        event: InboundEvent,
    ) -> dict[str, Any]:
        existing_run = self.repository.latest_run_for_trigger(case["id"], message["id"])
        if existing_run and existing_run["status"] not in {"running", "interrupted"}:
            existing_reply = self.repository.reply_for_run(existing_run["id"])
            if existing_reply:
                self._schedule_review(case["id"], existing_run["id"])
                await self._deliver_reply(
                    case,
                    message,
                    event,
                    existing_reply,
                    existing_run["id"],
                    "answered" if existing_run["status"] == "completed" else "failed",
                )
                return {
                    "case": self.repository.get_case(case["id"]),
                    "message": message,
                    "run": None,
                    "recovered": True,
                }

        pending = self.repository.awaiting_action_for_case(case["id"])
        if pending and event.content == pending["confirmation_phrase"]:
            resolver = getattr(self.harness, "resolver", None)
            resolved = (
                resolver.resolve(case["id"], pending["prepared_agent_version_id"])
                if resolver is not None
                else None
            )
            result = await self.harness_actions.confirm_and_commit(
                pending["id"],
                event.content,
                requester_ref=event.actor_ref,
                case_id=case["id"],
                confirmation_message_id=message["id"],
                agent_version_id=(resolved.snapshot["agent_version_id"] if resolved else None),
                tools=resolved.tools if resolved else None,
            )
            self._schedule_review(
                case["id"],
                pending["id"],
                agent_version_id=pending["prepared_agent_version_id"],
            )
            if event.reply_address and self._channel_reply_enabled(pending["prepared_agent_version_id"]):
                self.repository.enqueue_outbox(
                    case["id"],
                    event.channel,
                    event.reply_address,
                    {"type": "text", "text": result["message"]},
                    f"action-reply:{pending['id']}",
                )
            return {
                "case": self.repository.get_case(case["id"]),
                "message": message,
                "run": None,
                "action": result,
            }
        reply_enabled = self._channel_reply_enabled(self.repository.agent_version_for_case(case["id"]))
        if (
            reply_enabled
            and event.channel == "feishu"
            and event.reply_address
            and not event.reply_address.get("thread_id")
            and self._outbox is not None
        ):
            start_id = self.repository.enqueue_outbox(
                case["id"],
                event.channel,
                event.reply_address,
                {
                    "type": "card",
                    "operation": "card_start",
                    "text": "...",
                    "lifecycle_state": "processing",
                },
                f"card-start:{message['id']}",
            )
            await self._outbox.dispatch_outbox(start_id)

        result = await self.harness.run(case["id"], message["id"])
        self._schedule_review(case["id"], result.run_id)
        assistant = self.repository.reply_for_run(result.run_id)
        if not assistant:
            raise RuntimeError("completed Run lacks persisted assistant message")
        await self._deliver_reply(
            case,
            message,
            event,
            assistant,
            result.run_id,
            "answered" if result.status == "completed" else "failed",
        )
        return {
            "case": self.repository.get_case(case["id"]),
            "message": message,
            "run": result,
        }

    async def _terminalize_inbound_failure(
        self,
        case: dict[str, Any],
        message: dict[str, Any],
        event: InboundEvent,
        reply_text: str,
        stop_reason: str,
    ) -> None:
        latest_run = self.repository.latest_run_for_trigger(case["id"], message["id"])
        assistant = (
            self.repository.reply_for_run(latest_run["id"])
            if latest_run and latest_run["status"] != "running"
            else None
        )
        if assistant is None:
            assistant = self.repository.terminal_reply_for_trigger(message["id"])
        if assistant is None:
            metadata: dict[str, Any] = {
                "trigger_message_id": message["id"],
                "terminal_fallback": True,
                "stop_reason": stop_reason,
            }
            if latest_run:
                metadata["run_id"] = latest_run["id"]
            assistant = self.repository.add_message(
                case["id"],
                "assistant",
                reply_text,
                actor_ref="system:inbound-terminalizer",
                metadata=metadata,
            )
        await self._deliver_reply(
            case,
            message,
            event,
            assistant,
            str(latest_run["id"]) if latest_run else None,
            "failed",
        )

    async def _deliver_reply(
        self,
        case: dict[str, Any],
        message: dict[str, Any],
        event: InboundEvent,
        assistant: dict[str, Any],
        run_id: str | None,
        lifecycle_state: str,
    ) -> None:
        if not event.reply_address or not self._channel_reply_enabled(
            self.repository.agent_version_for_case(case["id"])
        ):
            return
        delivered_text = apply_message_footer(str(assistant["content"]), assistant["id"])
        channel_text = delivered_text
        artifact_images: tuple[dict[str, str], ...] = ()
        if event.channel == "feishu":
            channel_text, artifact_images = adapt_markdown_for_feishu(delivered_text)
        start = self.repository.outbox_for_idempotency(f"card-start:{message['id']}")
        if start and start["status"] in {"sent", "captured"}:
            receipt = json.loads(start.get("receipt_json") or "{}")
            if receipt.get("card_id") and receipt.get("message_id"):
                finish_key = f"card-finish:{run_id or message['id']}"
                outbox_id = self.repository.enqueue_outbox(
                    case["id"],
                    event.channel,
                    event.reply_address,
                    {
                        "type": "card",
                        "operation": "card_finish",
                        "card_id": receipt["card_id"],
                        "message_id": receipt["message_id"],
                        "sequence": int(receipt.get("sequence") or 0),
                        "text": channel_text,
                        "content_format": "text/markdown",
                        "presentation_profile": "suwen-markdown.v1",
                        "artifact_images": list(artifact_images),
                        "summary": card_summary(str(assistant["content"])),
                        "internal_message_id": assistant["id"],
                        "run_id": run_id,
                        "lifecycle_state": lifecycle_state,
                    },
                    finish_key,
                )
                if self._outbox is None:
                    return
                finish = await self._outbox.dispatch_outbox(outbox_id)
                if finish["status"] in {"sent", "captured"}:
                    await self._deliver_reply_images(
                        case_id=case["id"],
                        event=event,
                        assistant=assistant,
                        run_id=run_id,
                        artifact_images=artifact_images,
                    )
                    return

        text_key = f"reply:{run_id}" if run_id else f"reply-fallback:{message['id']}"
        outbox_id = self.repository.enqueue_outbox(
            case["id"],
            event.channel,
            event.reply_address,
            {
                "type": "markdown",
                "operation": "markdown_send",
                "text": channel_text,
                "content_format": "text/markdown",
                "presentation_profile": "suwen-markdown.v1",
                "artifact_images": list(artifact_images),
                "internal_message_id": assistant["id"],
                "run_id": run_id,
                "lifecycle_state": lifecycle_state,
            },
            text_key,
        )
        if self._outbox is not None:
            delivered = await self._outbox.dispatch_outbox(outbox_id)
            if delivered["status"] in {"sent", "captured"}:
                await self._deliver_reply_images(
                    case_id=case["id"],
                    event=event,
                    assistant=assistant,
                    run_id=run_id,
                    artifact_images=artifact_images,
                )

    async def _deliver_reply_images(
        self,
        *,
        case_id: str,
        event: InboundEvent,
        assistant: dict[str, Any],
        run_id: str | None,
        artifact_images: tuple[dict[str, str], ...],
    ) -> None:
        if self._outbox is None or event.channel != "feishu":
            return
        for image in artifact_images:
            artifact_id = image["artifact_id"]
            outbox_id = self.repository.enqueue_outbox(
                case_id,
                event.channel,
                event.reply_address,
                {
                    "type": "image",
                    "operation": "image_send",
                    "artifact_id": artifact_id,
                    "case_id": case_id,
                    "alt": image["alt"],
                    "internal_message_id": assistant["id"],
                    "run_id": run_id,
                    "lifecycle_state": "answered_attachment",
                },
                f"reply-image:{run_id or assistant['id']}:{artifact_id}",
            )
            await self._outbox.dispatch_outbox(outbox_id)

    @staticmethod
    def _inbound_job_key(message_id: str) -> str:
        return f"inbound-run:{message_id}"

    @staticmethod
    def _event_from_message(case: dict[str, Any], message: dict[str, Any]) -> InboundEvent:
        metadata = json.loads(message.get("metadata_json") or "{}")
        reply_address = metadata.get("reply_address")
        if not isinstance(reply_address, dict):
            reply_address = {}
        return InboundEvent(
            event_id=str(message.get("external_event_id") or message["id"]),
            channel=str(metadata.get("channel") or "unknown"),
            channel_instance=str(metadata.get("channel_instance") or "default"),
            scope_kind=str(metadata.get("scope_kind") or "dm"),
            scope_ref=str(metadata.get("scope_ref") or message.get("actor_ref") or "unknown"),
            actor_ref=str(message.get("actor_ref") or "unknown"),
            content=str(message["content"]),
            occurred_at=str(message["created_at"]),
            agent_id=str(case["agent_id"]),
            parent_event_ref=(
                str(metadata["parent_event_ref"]) if metadata.get("parent_event_ref") else None
            ),
            reply_address=reply_address,
        )

    def begin_drain(self) -> None:
        self._draining = True

    def cancel_drain(self) -> None:
        self._draining = False

    async def wait_for_active_executions(self) -> None:
        await self._execution_idle.wait()

    async def wait_for_inbound_idle(self) -> None:
        await self._inbound_idle.wait()

    @property
    def availability_state(self) -> dict[str, Any]:
        counts = self.repository.job_status_counts("process_inbound")
        return {
            "draining": self._draining,
            "active_executions": sum(len(tasks) for tasks in self._active_execution_tasks.values()),
            "active_ingress": sum(len(tasks) for tasks in self._inbound_tasks.values()),
            "queued_messages": counts.get("pending", 0),
            "leased_messages": counts.get("running", 0),
        }

    async def _handle_reset(self, event: InboundEvent) -> dict[str, Any]:
        """Run conversation reset commands outside the normal model queue."""

        await self.stop_inbound(event)
        lock = self._ingest_locks.setdefault(self._inbound_lock_key(event), asyncio.Lock())
        async with lock:
            self.cases.reset_binding(event)
            reply = (
                "已开始新的问诊，后续消息不会携带此前上下文。"
                if event.command == "new_case"
                else "已清空当前会话上下文，下一条消息将从新的问诊开始。"
            )
            outbox_id = self._enqueue_command_reply(None, event, reply)
        await self._dispatch_command_reply(outbox_id)
        return {
            "case": None,
            "message": None,
            "duplicate": False,
            "run": None,
            "command": {"name": event.command, "state": "completed"},
        }

    async def _handle_stop(self, event: InboundEvent) -> dict[str, Any]:
        stopped = await self.stop_inbound(event)
        if stopped > 1:
            reply = f"已停止当前任务，并清除 {stopped - 1} 条等待处理的消息。"
        elif stopped == 1:
            reply = "已停止当前任务。"
        else:
            reply = "当前没有正在运行的任务。"
        outbox_id = self._enqueue_command_reply(None, event, reply)
        await self._dispatch_command_reply(outbox_id)
        return {
            "case": None,
            "message": None,
            "duplicate": False,
            "run": None,
            "command": {"name": "stop", "state": "completed", "stopped": stopped},
        }

    async def stop_inbound(self, event: InboundEvent) -> int:
        """Cancel the active and queued work for this exact channel scope."""

        lock_key = self._inbound_lock_key(event)
        current = asyncio.current_task()
        tasks = list(
            {
                task
                for task in (
                    self._inbound_tasks.get(lock_key, set())
                    | self._active_execution_tasks.get(lock_key, set())
                )
                if task is not current and not task.done()
            }
        )
        for task in tasks:
            task.cancel("user_stop")
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        queued = self.repository.stop_inbound_jobs_for_scope(
            event.channel,
            event.channel_instance,
            event.scope_kind,
            event.scope_ref,
            event.actor_ref,
        )
        return len(tasks) + queued

    def _enqueue_command_reply(
        self,
        case_id: str | None,
        event: InboundEvent,
        reply: str,
    ) -> str | None:
        if not event.reply_address:
            return None
        return self.repository.enqueue_outbox(
            case_id,
            event.channel,
            event.reply_address,
            {"type": "text", "text": reply},
            ":".join(
                [
                    "command-reply",
                    event.channel,
                    event.channel_instance,
                    event.event_id,
                    str(event.command or "unknown"),
                ]
            ),
            agent_id=event.agent_id,
        )

    async def _dispatch_command_reply(self, outbox_id: str | None) -> None:
        if outbox_id is not None and self._outbox is not None:
            await self._outbox.dispatch_outbox(outbox_id)

    @staticmethod
    def _inbound_lock_key(event: InboundEvent) -> str:
        return ":".join(
            [
                event.channel,
                event.channel_instance,
                event.scope_kind,
                event.scope_ref,
                "" if event.scope_kind == "thread" else event.actor_ref,
            ]
        )

    def new_case_for_api(self, old_case_id: str, actor_ref: str) -> dict[str, Any]:
        old_case = self.repository.get_case(old_case_id)
        if self.repository.agent_status(old_case["agent_id"]) != "published":
            raise ValueError("case Agent is not accepting new messages")
        self.repository.close_case(old_case_id, "superseded")
        return self.repository.create_case("新问诊", agent_id=old_case["agent_id"])

    def _ensure_side_effects(self, case_id: str, message: dict[str, Any]) -> None:
        """Repair idempotent follow-ups after a process interruption.

        Reconciliation is deliberately conservative: only completed runs whose
        trigger is the already-persisted inbound message are considered.
        """
        for run in self.repository.list_runs(case_id):
            if run["trigger_message_id"] != message["id"] or run["status"] == "running":
                continue
            self._schedule_review(case_id, run["id"])
            reply = self.repository.reply_for_run(run["id"])
            metadata = __import__("json").loads(message.get("metadata_json") or "{}")
            address = metadata.get("reply_address") or {}
            if reply and address and self._channel_reply_enabled(run["agent_version_id"]):
                delivered_text = apply_message_footer(reply["content"], reply["id"])
                channel = str(metadata.get("channel") or "unknown")
                channel_text = delivered_text
                artifact_images: tuple[dict[str, str], ...] = ()
                if channel == "feishu":
                    channel_text, artifact_images = adapt_markdown_for_feishu(delivered_text)
                lifecycle_state = "answered" if run["status"] == "completed" else "failed"
                start = self.repository.outbox_for_idempotency(f"card-start:{message['id']}")
                if start and start["status"] in {"sent", "captured"}:
                    receipt = json.loads(start.get("receipt_json") or "{}")
                    if receipt.get("card_id") and receipt.get("message_id"):
                        self.repository.enqueue_outbox(
                            case_id,
                            str(metadata.get("channel") or "unknown"),
                            address,
                            {
                                "type": "card",
                                "operation": "card_finish",
                                "card_id": receipt["card_id"],
                                "message_id": receipt["message_id"],
                                "sequence": int(receipt.get("sequence") or 0),
                                "text": channel_text,
                                "content_format": "text/markdown",
                                "presentation_profile": "suwen-markdown.v1",
                                "artifact_images": list(artifact_images),
                                "summary": card_summary(reply["content"]),
                                "internal_message_id": reply["id"],
                                "run_id": run["id"],
                                "lifecycle_state": lifecycle_state,
                            },
                            f"card-finish:{run['id']}",
                        )
                        continue
                self.repository.enqueue_outbox(
                    case_id,
                    channel,
                    address,
                    {
                        "type": "markdown",
                        "operation": "markdown_send",
                        "text": channel_text,
                        "content_format": "text/markdown",
                        "presentation_profile": "suwen-markdown.v1",
                        "artifact_images": list(artifact_images),
                        "internal_message_id": reply["id"],
                        "run_id": run["id"],
                        "lifecycle_state": lifecycle_state,
                    },
                    f"reply:{run['id']}",
                )

    def _schedule_review(
        self,
        case_id: str,
        subject_id: str,
        now: datetime | None = None,
        *,
        agent_version_id: str | None = None,
    ) -> None:
        effective_version_id = agent_version_id
        if effective_version_id is None:
            try:
                effective_version_id = self.repository.agent_version_for_run(subject_id)
            except KeyError:
                return
        policies = self.repository.policies_for_agent_version(effective_version_id)
        review_policy = policies["review"]
        if review_policy.get("enabled", True) is False:
            return
        delay_seconds = review_policy.get("delay_seconds", self.review_delay_seconds)
        if not isinstance(delay_seconds, int) or isinstance(delay_seconds, bool):
            delay_seconds = self.review_delay_seconds
        now = now or datetime.now(UTC)
        self.repository.schedule_job(
            "review_case",
            f"review:{case_id}:{subject_id}",
            {"case_id": case_id, "subject_id": subject_id},
            now + timedelta(seconds=delay_seconds),
            case_id,
        )

    def _channel_reply_enabled(self, agent_version_id: str) -> bool:
        try:
            policy = self.repository.policies_for_agent_version(agent_version_id)["channel"]
        except KeyError:
            return False
        return policy.get("reply_enabled", True) is not False

    @property
    def harness_actions(self):
        action_service = getattr(self, "_actions", None)
        if action_service is None:
            raise RuntimeError("controlled action service is not configured")
        return action_service

    def set_action_service(self, action_service: Any) -> None:
        self._actions = action_service

    def set_outbox_dispatcher(self, outbox: OutboxPort) -> None:
        self._outbox = outbox
