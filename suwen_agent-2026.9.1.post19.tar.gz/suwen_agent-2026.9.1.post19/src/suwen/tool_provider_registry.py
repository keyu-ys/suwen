from __future__ import annotations

import asyncio
import hashlib
import json
import re
import sqlite3
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from .db import Database
from .mcp_adapter import (
    MCPClient,
    MCPProtocolError,
    MCPToolProvider,
    StdioMCPTransport,
    StreamableHTTPMCPTransport,
)
from .model_registry import SecretResolver
from .repository import iso, new_id
from .tools import ToolRegistry, is_system_required_tool, tool_schema_projection
from .types import ToolRisk

_STABLE_ID = re.compile(r"^[a-z][a-z0-9-]{1,63}$")
_PROVIDER_TYPES = {"fixture", "trusted_local", "mcp_stdio", "mcp_http"}
_SENSITIVE_CONNECTION_MARKERS = (
    "api_key=",
    "apikey=",
    "authorization:",
    "bearer ",
    "password=",
    "secret=",
    "token=",
)


def _digest(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


@dataclass(frozen=True)
class ConnectorRunLease:
    """Keep the exact MCP clients selected for one Run alive until it finishes."""

    clients: tuple[MCPClient, ...]


class ToolProviderRegistry:
    """Tool Provider catalog and immutable observed schema ledger."""

    def __init__(
        self,
        database: Database,
        tools: ToolRegistry,
        secrets: SecretResolver | None = None,
    ):
        self.database = database
        self.tools = tools
        self.secrets = secrets or SecretResolver(database)
        self._runtime_clients: dict[str, MCPClient] = {}
        self._retired_clients: list[MCPClient] = []
        self._client_leases: dict[MCPClient, int] = {}
        self._catalog_lock = asyncio.Lock()
        self._fallback_handlers: dict[str, ToolRegistry] = {}
        self._dynamic_provider_ids: set[str] = set()

    def sync_loaded_catalog(self, provider_types: Mapping[str, str]) -> None:
        by_provider: dict[str, list[dict[str, Any]]] = {}
        for item in tool_schema_projection(self.tools):
            by_provider.setdefault(str(item["provider_id"]), []).append(item)
        now = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing_types = {
                str(row["id"]): str(row["provider_type"])
                for row in connection.execute("SELECT id, provider_type FROM tool_providers")
            }
            for provider_id, schema in sorted(by_provider.items()):
                # A remotely observed MCP catalog is owned by its Connector
                # lifecycle, never reclassified as a Pack-owned loaded catalog.
                if existing_types.get(provider_id) == "mcp_http":
                    continue
                if provider_id == "runtime-core":
                    provider_type = "trusted_local"
                else:
                    provider_type = provider_types.get(
                        provider_id,
                        existing_types.get(provider_id, ""),
                    )
                if provider_type not in {"trusted_local", "mcp_stdio"}:
                    raise ValueError(
                        f"loaded Tool Provider lacks deployment-controlled provenance: {provider_id}"
                    )
                if provider_id == "builtin-generic":
                    name = "内置通用工具"
                elif provider_id == "runtime-core":
                    name = "运行时核心工具"
                else:
                    name = provider_id
                status = "connected" if provider_type == "trusted_local" else "source_gated"
                connection.execute(
                    """INSERT OR IGNORE INTO tool_providers(
                       id, name, provider_type, status, connection_ref,
                       created_at, updated_at
                    ) VALUES (?, ?, ?, ?, '', ?, ?)""",
                    (provider_id, name, provider_type, status, now, now),
                )
                connection.execute(
                    """UPDATE tool_providers
                       SET provider_type=?,
                           status=CASE
                             WHEN status IN ('disabled', 'unavailable', 'schema_mismatch')
                               THEN status
                             WHEN ?='trusted_local' THEN 'connected'
                             WHEN connection_ref<>'' THEN 'configured'
                             ELSE 'source_gated'
                           END,
                           updated_at=?
                       WHERE id=?""",
                    (provider_type, provider_type, now, provider_id),
                )
                # Keep product-owned display names aligned across older databases.
                if provider_id in {"builtin-generic", "runtime-core"}:
                    connection.execute(
                        "UPDATE tool_providers SET name=? WHERE id=?",
                        (name, provider_id),
                    )
                self._record_schema_if_changed(connection, provider_id, schema, "system:loaded-catalog", now)
            connection.commit()

    def configure_stdio(
        self,
        provider_id: str,
        config: dict[str, Any],
        secret_ref_id: str | None,
        actor: str,
    ) -> dict[str, Any]:
        normalized = self._validate_stdio_config(config)
        secret_env = normalized.get("secret_env")
        if bool(secret_env) != bool(secret_ref_id):
            raise ValueError("stdio MCP secret_env and Secret Ref must be configured together")
        now = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            provider = connection.execute(
                "SELECT provider_type, status, archived_at FROM tool_providers WHERE id=?",
                (provider_id,),
            ).fetchone()
            if not provider:
                raise KeyError(provider_id)
            if provider["provider_type"] != "mcp_stdio":
                raise ValueError("Tool Provider is not an MCP stdio provider")
            if provider["archived_at"]:
                raise ValueError("archived Tool Provider cannot be configured")
            if (
                secret_ref_id
                and not connection.execute(
                    "SELECT 1 FROM secret_refs WHERE id=?",
                    (secret_ref_id,),
                ).fetchone()
            ):
                raise KeyError(secret_ref_id)
            connection.execute(
                """UPDATE tool_providers
                   SET connection_ref=?, secret_ref_id=?, status='configured', updated_at=?
                   WHERE id=?""",
                (
                    json.dumps(normalized, ensure_ascii=False, sort_keys=True),
                    secret_ref_id,
                    now,
                    provider_id,
                ),
            )
            self._audit(
                connection,
                actor,
                "tool_provider.configured",
                provider_id,
                "succeeded",
                {
                    "transport": "stdio",
                    "configuration_digest": _digest(normalized),
                    "secret_ref_configured": bool(secret_ref_id),
                    "previous_status": provider["status"],
                },
            )
            connection.commit()
        return self.get_provider(provider_id)

    def configure_http(
        self,
        provider_id: str,
        config: dict[str, Any],
        actor: str,
    ) -> dict[str, Any]:
        normalized = self._validate_http_config(config)
        now = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            provider = connection.execute(
                "SELECT provider_type, status, archived_at FROM tool_providers WHERE id=?",
                (provider_id,),
            ).fetchone()
            if not provider:
                raise KeyError(provider_id)
            if provider["provider_type"] != "mcp_http":
                raise ValueError("Tool Provider is not an MCP HTTP Connector")
            if provider["archived_at"]:
                raise ValueError("archived Tool Provider cannot be configured")
            connection.execute(
                """UPDATE tool_providers
                   SET connection_ref=?, secret_ref_id=NULL, status='configured',
                       runtime_metadata_json='{}', updated_at=?
                   WHERE id=?""",
                (
                    json.dumps(normalized, ensure_ascii=False, sort_keys=True),
                    now,
                    provider_id,
                ),
            )
            self._audit(
                connection,
                actor,
                "tool_provider.configured",
                provider_id,
                "succeeded",
                {
                    "transport": "streamable_http",
                    "configuration_digest": _digest(normalized),
                    "previous_status": provider["status"],
                },
            )
            connection.commit()
        return self.get_provider(provider_id)

    async def connect(self, provider_id: str, actor: str) -> dict[str, Any]:
        async with self._catalog_lock:
            return await self._connect_locked(provider_id, actor)

    async def _connect_locked(self, provider_id: str, actor: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT * FROM tool_providers WHERE id=?",
                (provider_id,),
            ).fetchone()
        if not row:
            raise KeyError(provider_id)
        provider_type = str(row["provider_type"])
        if provider_type not in {"mcp_stdio", "mcp_http"}:
            raise ValueError("Tool Provider is not an MCP Connector")
        if row["status"] == "disabled" or row["archived_at"]:
            raise ValueError("disabled or archived Tool Provider cannot connect")
        if not row["connection_ref"]:
            raise ValueError("MCP Connector is not configured")
        try:
            raw_config = json.loads(row["connection_ref"])
        except json.JSONDecodeError as exc:
            raise ValueError("MCP Connector configuration is invalid") from exc
        if provider_type == "mcp_stdio":
            config = self._validate_stdio_config(raw_config)
            environment = dict(config["environment"])
            if row["secret_ref_id"]:
                environment[str(config["secret_env"])] = self.secrets.resolve(row["secret_ref_id"])
            transport = StdioMCPTransport(
                tuple(config["command"]),
                cwd=Path(config["cwd"]),
                environment=environment,
                timeout_seconds=float(config["timeout_seconds"]),
            )
            transport_name = "stdio"
        else:
            config = self._validate_http_config(raw_config)
            transport = StreamableHTTPMCPTransport(
                str(config["endpoint"]),
                timeout_seconds=float(config["timeout_seconds"]),
                max_response_bytes=int(config["max_response_bytes"]),
            )
            transport_name = "streamable_http"
        expected_names = {
            definition.name
            for definition in self.tools.definitions()
            if definition.provider_id == provider_id
        }
        dynamic_catalog = provider_type == "mcp_http"
        if not expected_names and not dynamic_catalog:
            raise ValueError("MCP Provider has no deployment-controlled Tool contract")
        controlled_actions = {
            definition.name
            for definition in self.tools.definitions()
            if definition.provider_id == provider_id and definition.risk == ToolRisk.CONTROLLED_ACTION
        }
        fallback = self.tools.subset(expected_names) if expected_names else ToolRegistry()
        client = MCPClient(transport)
        provider = MCPToolProvider(
            provider_id,
            client,
            controlled_actions=controlled_actions,
        )
        observed = ToolRegistry()
        catalog_replaced = False
        try:
            await provider.register(observed)
            if dynamic_catalog:
                _, bound_names = self.tools.replace_provider_catalog(provider_id, observed)
                catalog_replaced = True
            else:
                bound_names = self.tools.bind_provider_handlers(
                    provider_id,
                    observed,
                    expected_names=expected_names,
                )
            observed_schema = provider.catalog_snapshot
            now = iso()
            runtime_metadata = self._runtime_metadata(
                provider.initialize_result,
                transport_name,
                observed_schema,
                now,
            )
            with self.database.connect() as connection:
                connection.execute("BEGIN IMMEDIATE")
                schema_version_id = self._record_schema_if_changed(
                    connection,
                    provider_id,
                    observed_schema,
                    actor,
                    now,
                    observed_at=now,
                )
                connection.execute(
                    """UPDATE tool_providers
                       SET status='connected', binding_generation=binding_generation+1,
                           runtime_metadata_json=?, updated_at=? WHERE id=?""",
                    (
                        json.dumps(runtime_metadata, ensure_ascii=False, sort_keys=True),
                        now,
                        provider_id,
                    ),
                )
                self._audit(
                    connection,
                    actor,
                    "tool_provider.connected",
                    provider_id,
                    "succeeded",
                    {
                        "transport": transport_name,
                        "bound_tool_count": len(bound_names),
                        "catalog_read_count": 1,
                        "schema_version_id": schema_version_id,
                        "catalog_digest": _digest(observed_schema),
                    },
                )
                connection.commit()
        except BaseException as exc:
            if catalog_replaced:
                current_names = {
                    item.name for item in self.tools.definitions() if item.provider_id == provider_id
                }
                if current_names:
                    self.tools.unregister(current_names)
                self.tools.merge_from(fallback)
            elif expected_names:
                self.tools.restore_handlers_from(fallback, expected_names)
            await client.close()
            failure_status = "schema_mismatch" if isinstance(exc, ValueError) else "unavailable"
            with self.database.connect() as connection:
                connection.execute("BEGIN IMMEDIATE")
                now = iso()
                connection.execute(
                    "UPDATE tool_providers SET status=?, updated_at=? WHERE id=?",
                    (failure_status, now, provider_id),
                )
                self._audit(
                    connection,
                    actor,
                    "tool_provider.connect_failed",
                    provider_id,
                    "failed",
                    {
                        "failure_class": self._connection_failure_class(exc),
                        "catalog_read_count": 1,
                        "transport": transport_name,
                    },
                )
                connection.commit()
            raise
        previous = self._runtime_clients.get(provider_id)
        self._runtime_clients[provider_id] = client
        self._fallback_handlers.setdefault(provider_id, fallback)
        if dynamic_catalog:
            self._dynamic_provider_ids.add(provider_id)
        if previous:
            # A resolved in-flight Run owns handler closures bound to the prior
            # client. Retire it only after every such Run releases its lease.
            await self._retire_client_locked(previous)
        return self.get_provider(provider_id)

    async def prepare_run(
        self,
        case_id: str,
        resolver: Callable[[], Any],
    ) -> tuple[Any, ConnectorRunLease]:
        """Observe bound MCP catalogs, then freeze one Run while the surface is stable."""

        async with self._catalog_lock:
            provider_ids = self._case_connector_provider_ids(case_id)
            for provider_id in provider_ids:
                try:
                    await self._connect_locked(provider_id, "system:run-catalog-refresh")
                except Exception:
                    # Connector availability is an optional Run capability. The
                    # failed refresh has already persisted a safe Provider state;
                    # resolve the Run without that Provider instead of suppressing
                    # the model-only path or unrelated Connectors.
                    continue
            resolved = resolver()
            clients: list[MCPClient] = []
            for connector in resolved.snapshot.get("connectors", []):
                if not isinstance(connector, dict) or not connector.get("tool_names"):
                    continue
                provider_id = connector.get("provider_id")
                client = self._runtime_clients.get(str(provider_id)) if provider_id else None
                if client is None:
                    raise RuntimeError("case Agent Connector client is unavailable")
                if all(existing is not client for existing in clients):
                    clients.append(client)
            for client in clients:
                self._client_leases[client] = self._client_leases.get(client, 0) + 1
            return resolved, ConnectorRunLease(tuple(clients))

    async def release_run(self, lease: ConnectorRunLease) -> None:
        to_close: list[MCPClient] = []
        async with self._catalog_lock:
            for client in lease.clients:
                remaining = self._client_leases.get(client, 0) - 1
                if remaining > 0:
                    self._client_leases[client] = remaining
                    continue
                self._client_leases.pop(client, None)
                for index, retired in enumerate(self._retired_clients):
                    if retired is client:
                        self._retired_clients.pop(index)
                        to_close.append(client)
                        break
        for client in to_close:
            await client.close()

    def _case_connector_provider_ids(self, case_id: str) -> tuple[str, ...]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT av.config_json
                     FROM cases c
                     JOIN agents a ON a.id=c.agent_id
                     JOIN agent_versions av
                       ON av.id=COALESCE(c.pinned_agent_version_id, a.active_version_id)
                    WHERE c.id=? AND a.status='published'
                      AND av.agent_id=c.agent_id AND av.status='published'""",
                (case_id,),
            ).fetchone()
        if not row:
            raise RuntimeError("case Agent runtime configuration is unavailable")
        try:
            bindings = json.loads(row["config_json"] or "{}").get("connector_bindings", [])
        except (AttributeError, json.JSONDecodeError) as exc:
            raise RuntimeError("case Agent Connector configuration is unavailable") from exc
        if not isinstance(bindings, list):
            raise RuntimeError("case Agent Connector configuration is unavailable")
        provider_ids: list[str] = []
        for binding in bindings:
            provider_id = binding.get("provider_id") if isinstance(binding, dict) else None
            if (
                not isinstance(provider_id, str)
                or not provider_id
                or provider_id in provider_ids
            ):
                raise RuntimeError("case Agent Connector configuration is unavailable")
            provider_ids.append(provider_id)
        return tuple(provider_ids)

    async def _retire_client_locked(self, client: MCPClient) -> None:
        if self._client_leases.get(client, 0) > 0:
            if all(retired is not client for retired in self._retired_clients):
                self._retired_clients.append(client)
            return
        await client.close()

    async def connect_stdio(
        self,
        provider_id: str,
        actor: str,
        **_: Any,
    ) -> dict[str, Any]:
        """Compatibility method for internal callers while the stdio UI retires."""
        return await self.connect(provider_id, actor)

    async def connect_configured(self, actor: str = "system:startup") -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            provider_ids = [
                str(row["id"])
                for row in connection.execute(
                    """SELECT id FROM tool_providers
                       WHERE provider_type IN ('mcp_stdio', 'mcp_http')
                         AND connection_ref<>'' AND archived_at IS NULL AND status<>'disabled'
                       ORDER BY id"""
                ).fetchall()
            ]
        results: list[dict[str, Any]] = []
        for provider_id in provider_ids:
            try:
                results.append(await self.connect(provider_id, actor))
            except (ValueError, OSError, RuntimeError):
                # One unavailable Connector must not prevent the Runtime or
                # unrelated Agents from starting.
                continue
        return results

    async def close(self) -> None:
        async with self._catalog_lock:
            runtime_clients = list(self._runtime_clients.items())
            retired_clients = list(self._retired_clients)
            for provider_id, _client in runtime_clients:
                fallback = self._fallback_handlers.get(provider_id)
                if provider_id in self._dynamic_provider_ids:
                    names = {
                        definition.name
                        for definition in self.tools.definitions()
                        if definition.provider_id == provider_id
                    }
                    if names:
                        self.tools.unregister(names)
                    if fallback:
                        self.tools.merge_from(fallback)
                elif fallback:
                    names = {
                        definition.name
                        for definition in fallback.definitions()
                        if definition.provider_id == provider_id
                    }
                    self.tools.restore_handlers_from(fallback, names)
            self._runtime_clients.clear()
            self._retired_clients.clear()
            self._client_leases.clear()
            self._fallback_handlers.clear()
            self._dynamic_provider_ids.clear()
        closed: set[MCPClient] = set()
        for client in [*(item[1] for item in runtime_clients), *retired_clients]:
            if client in closed:
                continue
            closed.add(client)
            await client.close()

    def list_providers(self) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute("SELECT * FROM tool_providers ORDER BY updated_at DESC, id").fetchall()
            return [self._provider_view(connection, row) for row in rows]

    def get_provider(self, provider_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute("SELECT * FROM tool_providers WHERE id=?", (provider_id,)).fetchone()
            if not row:
                raise KeyError(provider_id)
            return self._provider_view(connection, row)

    def _provider_view(self, connection: sqlite3.Connection, row: sqlite3.Row) -> dict[str, Any]:
        item = dict(row)
        connection_ref = item.pop("connection_ref")
        item["connection_configured"] = bool(connection_ref)
        item["connection"] = None
        if item["provider_type"] == "mcp_http" and connection_ref:
            try:
                public_connection = self._validate_http_config(json.loads(connection_ref))
            except (json.JSONDecodeError, ValueError):
                public_connection = None
            item["connection"] = public_connection
        item["runtime_metadata"] = json.loads(item.pop("runtime_metadata_json") or "{}")
        secret_ref_id = item.pop("secret_ref_id")
        if secret_ref_id:
            metadata = self.secrets.metadata(secret_ref_id)
            item["secret"] = {
                "id": metadata["id"],
                "status": metadata["status"],
                "version": metadata["version"],
                "configured": metadata["configured"],
            }
        else:
            item["secret"] = None
        versions = connection.execute(
            """SELECT id, version, schema_json, digest, observed_at, created_by, created_at
               FROM tool_schema_versions WHERE tool_provider_id=? ORDER BY version DESC""",
            (row["id"],),
        ).fetchall()
        item["schema_versions"] = []
        for version in versions:
            view = dict(version)
            view["schema"] = json.loads(view.pop("schema_json"))
            item["schema_versions"].append(view)
        item["tools"] = [
            definition
            for definition in tool_schema_projection(self.tools)
            if definition["provider_id"] == row["id"]
        ]
        latest_schema = item["schema_versions"][0]["schema"] if item["schema_versions"] else []
        managed_tool_names = {
            str(tool["name"])
            for tool in [*item["tools"], *latest_schema]
            if isinstance(tool, dict) and tool.get("name")
        }
        item["agent_usage"] = self._agent_usage(connection, managed_tool_names)
        item["pack_usage"] = self._pack_usage(connection, managed_tool_names)
        item["health"] = self._health(item["status"])
        return item

    @staticmethod
    def _agent_usage(connection: sqlite3.Connection, tool_names: set[str]) -> list[dict[str, Any]]:
        if not tool_names:
            return []
        required_for_every_agent = any(is_system_required_tool(name) for name in tool_names)
        rows = connection.execute(
            """SELECT a.id AS agent_id, a.name AS agent_name, av.config_json
               FROM agents a
               JOIN agent_versions av ON av.id=a.active_version_id
               WHERE a.status='published'
               ORDER BY a.name, a.id"""
        ).fetchall()
        results: list[dict[str, Any]] = []
        for row in rows:
            allowlist = json.loads(row["config_json"] or "{}").get("tool_allowlist", [])
            if required_for_every_agent or set(allowlist) & tool_names:
                results.append(
                    {
                        "agent_id": row["agent_id"],
                        "agent_name": row["agent_name"],
                    }
                )
        return results

    @staticmethod
    def _pack_usage(connection: sqlite3.Connection, tool_names: set[str]) -> list[dict[str, Any]]:
        if not tool_names:
            return []
        rows = connection.execute(
            """SELECT cpv.id AS pack_version_id, cpv.pack_id, cpv.version,
                      cpv.manifest_json, cp.status
               FROM capability_pack_versions cpv
               JOIN capability_packs cp ON cp.id=cpv.pack_id
               ORDER BY cpv.pack_id, cpv.version"""
        ).fetchall()
        results: list[dict[str, Any]] = []
        for row in rows:
            manifest_tools = json.loads(row["manifest_json"] or "{}").get("tools", [])
            if set(manifest_tools) & tool_names:
                item = dict(row)
                item.pop("manifest_json")
                results.append(item)
        return results

    def create_provider(
        self,
        provider_id: str,
        name: str,
        provider_type: str,
        connection_ref: str,
        secret_ref_id: str | None,
        actor: str,
    ) -> dict[str, Any]:
        provider_id = self._stable_id(provider_id)
        if provider_type not in _PROVIDER_TYPES:
            raise ValueError("unsupported Tool Provider type")
        if not self.database.enable_test_fixture_agent and provider_type not in {
            "mcp_stdio",
            "mcp_http",
        }:
            raise ValueError("产品模式只能创建 MCP Connector")
        if not name.strip():
            raise ValueError("Tool Provider name is required")
        connection_ref = self._safe_connection_ref(connection_ref)
        if provider_type in {"mcp_stdio", "mcp_http"} and (connection_ref or secret_ref_id):
            raise ValueError("MCP Connector 必须在创建后通过结构化配置单独保存")
        now = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            if (
                secret_ref_id
                and not connection.execute(
                    "SELECT 1 FROM secret_refs WHERE id=?", (secret_ref_id,)
                ).fetchone()
            ):
                raise KeyError(secret_ref_id)
            connection.execute(
                """INSERT INTO tool_providers(
                   id, name, provider_type, status, connection_ref,
                   secret_ref_id, created_at, updated_at
                ) VALUES (?, ?, ?, 'draft', ?, ?, ?, ?)""",
                (
                    provider_id,
                    name.strip(),
                    provider_type,
                    connection_ref,
                    secret_ref_id,
                    now,
                    now,
                ),
            )
            self._audit(
                connection,
                actor,
                "tool_provider.created",
                provider_id,
                "succeeded",
                {"provider_type": provider_type, "connection_configured": bool(connection_ref)},
            )
            connection.commit()
        return self.get_provider(provider_id)

    def set_status(self, provider_id: str, status: str, actor: str) -> dict[str, Any]:
        if status not in {"enabled", "disabled"}:
            raise ValueError("Tool Provider status must be enabled or disabled")
        now = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            provider = connection.execute(
                "SELECT id, provider_type, status, archived_at FROM tool_providers WHERE id=?",
                (provider_id,),
            ).fetchone()
            if not provider:
                raise KeyError(provider_id)
            if provider["archived_at"]:
                raise ValueError("archived Tool Provider cannot change status")
            latest = connection.execute(
                """SELECT schema_json FROM tool_schema_versions
                   WHERE tool_provider_id=? ORDER BY version DESC LIMIT 1""",
                (provider_id,),
            ).fetchone()
            if status == "disabled":
                schema = json.loads(latest["schema_json"]) if latest else []
                tool_names = {
                    item["name"]
                    for item in schema
                    if isinstance(item, dict) and isinstance(item.get("name"), str)
                }
                tool_names.update(
                    item.name for item in self.tools.definitions() if item.provider_id == provider_id
                )
                active_usage = self._agent_usage(connection, tool_names)
                if active_usage:
                    raise ValueError("Tool Provider is used by a published Agent")
                next_status = "disabled"
            else:
                loaded = any(item.provider_id == provider_id for item in self.tools.definitions())
                is_dynamic = provider["provider_type"] == "mcp_http"
                if not loaded and not is_dynamic and not self.database.enable_test_fixture_agent:
                    raise ValueError("Tool Provider 必须先由已安装能力包加载工具契约")
                if not latest:
                    raise ValueError("Tool Provider requires a schema version before enabling")
                if loaded and provider["provider_type"] in {"fixture", "trusted_local"}:
                    next_status = "connected"
                elif loaded and provider["provider_type"] in {"mcp_stdio", "mcp_http"}:
                    next_status = "connected" if provider["status"] == "connected" else "configured"
                else:
                    next_status = "configured"
            connection.execute(
                "UPDATE tool_providers SET status=?, updated_at=? WHERE id=?",
                (next_status, now, provider_id),
            )
            self._audit(
                connection,
                actor,
                "tool_provider.status_changed",
                provider_id,
                "succeeded",
                {"from": provider["status"], "to": next_status},
            )
            connection.commit()
        return self.get_provider(provider_id)

    def create_schema_version(
        self,
        provider_id: str,
        schema: list[dict[str, Any]],
        actor: str,
        *,
        observed: bool = False,
    ) -> dict[str, Any]:
        self._validate_schema(schema)
        if not self.database.enable_test_fixture_agent and not observed:
            raise ValueError("产品模式的工具结构只能来自已安装能力包或连接观测，不能手工覆盖")
        now = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            if not connection.execute("SELECT 1 FROM tool_providers WHERE id=?", (provider_id,)).fetchone():
                raise KeyError(provider_id)
            created = self._record_schema_if_changed(
                connection,
                provider_id,
                schema,
                actor,
                now,
                observed_at=now if observed else None,
                reject_identical=True,
            )
            self._audit(
                connection,
                actor,
                "tool_provider.schema_version_created",
                provider_id,
                "succeeded",
                {"schema_version_id": created},
            )
            connection.commit()
        return self.get_provider(provider_id)

    async def probe(self, provider_id: str, actor: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            provider = connection.execute(
                "SELECT provider_type FROM tool_providers WHERE id=?", (provider_id,)
            ).fetchone()
        if not provider:
            raise KeyError(provider_id)
        if provider["provider_type"] in {"mcp_stdio", "mcp_http"}:
            connected = await self.connect(provider_id, actor)
            return {
                "provider_id": provider_id,
                "status": "passed",
                "findings": [],
                "external_calls": 1,
                "observed_at": connected["updated_at"],
                "binding_generation": connected["binding_generation"],
            }
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            provider = connection.execute(
                "SELECT * FROM tool_providers WHERE id=?", (provider_id,)
            ).fetchone()
            if not provider:
                raise KeyError(provider_id)
            if provider["status"] == "disabled":
                raise ValueError("disabled Tool Provider must be enabled before probing")
            now = iso()
            if provider["provider_type"] in {"fixture", "trusted_local"}:
                status = "passed"
                connection.execute(
                    "UPDATE tool_providers SET status='connected', updated_at=? WHERE id=?",
                    (now, provider_id),
                )
                connection.execute(
                    """UPDATE tool_schema_versions SET observed_at=?
                       WHERE id=(SELECT id FROM tool_schema_versions
                                WHERE tool_provider_id=? ORDER BY version DESC LIMIT 1)""",
                    (now, provider_id),
                )
                findings: list[dict[str, str]] = []
            self._audit(
                connection,
                actor,
                "tool_provider.probed",
                provider_id,
                status,
                {"findings": findings, "external_calls": 0},
            )
            connection.commit()
        return {
            "provider_id": provider_id,
            "status": status,
            "findings": findings,
            "external_calls": 0,
            "observed_at": now if status == "passed" else None,
        }

    def list_tools(self) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            providers = {
                row["id"]: row["status"]
                for row in connection.execute("SELECT id, status FROM tool_providers")
            }
            results: list[dict[str, Any]] = []
            for definition in tool_schema_projection(self.tools):
                item = dict(definition)
                item["provider_status"] = providers.get(item["provider_id"], "unknown")
                item["schema_digest"] = _digest(item)
                item["agent_usage"] = self._agent_usage(connection, {item["name"]})
                item["pack_usage"] = self._pack_usage(connection, {item["name"]})
                results.append(item)
            return results

    @staticmethod
    def _record_schema_if_changed(
        connection: sqlite3.Connection,
        provider_id: str,
        schema: list[dict[str, Any]],
        actor: str,
        now: str,
        *,
        observed_at: str | None = None,
        reject_identical: bool = False,
    ) -> str:
        digest = _digest(schema)
        latest = connection.execute(
            """SELECT id, version, digest FROM tool_schema_versions
               WHERE tool_provider_id=? ORDER BY version DESC LIMIT 1""",
            (provider_id,),
        ).fetchone()
        if latest and latest["digest"] == digest:
            if reject_identical:
                raise ValueError("identical Tool schema already has a version")
            return latest["id"]
        version = int(latest["version"]) + 1 if latest else 1
        schema_id = new_id("toolschema")
        connection.execute(
            """INSERT INTO tool_schema_versions(
               id, tool_provider_id, version, schema_json, digest,
               observed_at, created_by, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                schema_id,
                provider_id,
                version,
                json.dumps(schema, ensure_ascii=False),
                digest,
                observed_at,
                actor,
                now,
            ),
        )
        return schema_id

    @staticmethod
    def _validate_schema(schema: list[dict[str, Any]]) -> None:
        if not isinstance(schema, list) or not schema:
            raise ValueError("Tool schema must be a non-empty array")
        names: set[str] = set()
        for item in schema:
            if not isinstance(item, dict):
                raise ValueError("Tool schema entries must be objects")
            if not isinstance(item.get("name"), str) or not item["name"]:
                raise ValueError("Tool schema entry requires a name")
            if item["name"] in names:
                raise ValueError("Tool schema contains duplicate names")
            names.add(item["name"])
            if item.get("risk") not in {"read_only", "controlled_action", "unclassified"}:
                raise ValueError("Tool schema contains unsupported risk")
            if not isinstance(item.get("input_schema"), dict):
                raise ValueError("Tool schema entry requires input_schema")
            if item.get("output_schema") is not None and not isinstance(item["output_schema"], dict):
                raise ValueError("Tool schema output_schema must be an object")
            if item.get("annotations") is not None and not isinstance(item["annotations"], dict):
                raise ValueError("Tool schema annotations must be an object")

    @staticmethod
    def _health(status: str) -> str:
        return {
            "connected": "connected",
            "source_gated": "unknown",
            "unavailable": "unavailable",
            "schema_mismatch": "schema_mismatch",
        }.get(status, "unknown")

    @staticmethod
    def _stable_id(value: str) -> str:
        selected = value.strip()
        if not _STABLE_ID.fullmatch(selected):
            raise ValueError("id must use 2-64 lowercase letters, digits, or hyphens")
        return selected

    @staticmethod
    def _safe_connection_ref(value: str) -> str:
        selected = value.strip()
        if len(selected) > 2000:
            raise ValueError("Tool Provider connection reference is too large")
        lowered = selected.lower()
        if any(marker in lowered for marker in _SENSITIVE_CONNECTION_MARKERS):
            raise ValueError("Tool Provider connection must use a Secret Ref for credentials")
        parsed = urlsplit(selected)
        if parsed.username or parsed.password:
            raise ValueError("Tool Provider connection must not contain URL credentials")
        return selected

    @staticmethod
    def _validate_stdio_config(value: Any) -> dict[str, Any]:
        if not isinstance(value, dict):
            raise ValueError("MCP stdio connection must be an object")
        allowed = {"transport", "command", "cwd", "environment", "secret_env", "timeout_seconds"}
        if set(value) - allowed:
            raise ValueError("MCP stdio connection contains unsupported fields")
        if value.get("transport", "stdio") != "stdio":
            raise ValueError("MCP stdio connection transport must be stdio")
        command = value.get("command")
        if (
            not isinstance(command, list)
            or not 1 <= len(command) <= 16
            or any(
                not isinstance(item, str) or not item or len(item) > 2000 or "\x00" in item
                for item in command
            )
            or not Path(command[0]).is_absolute()
        ):
            raise ValueError("MCP stdio command must start with an absolute executable")
        cwd = value.get("cwd")
        if not isinstance(cwd, str) or not cwd or not Path(cwd).is_absolute() or "\x00" in cwd:
            raise ValueError("MCP stdio cwd must be an absolute path")
        environment = value.get("environment", {})
        if (
            not isinstance(environment, dict)
            or len(environment) > 32
            or any(
                not isinstance(key, str)
                or not re.fullmatch(r"[A-Z][A-Z0-9_]{1,127}", key)
                or any(marker in key.lower() for marker in ("key", "token", "secret", "password"))
                or not isinstance(item, str)
                or len(item) > 4000
                or "\x00" in item
                for key, item in environment.items()
            )
        ):
            raise ValueError("MCP stdio environment must contain bounded non-secret values")
        secret_env = value.get("secret_env")
        if secret_env is not None and (
            not isinstance(secret_env, str) or not re.fullmatch(r"[A-Z][A-Z0-9_]{1,127}", secret_env)
        ):
            raise ValueError("MCP stdio secret_env must be an environment variable name")
        timeout = value.get("timeout_seconds", 30.0)
        if (
            not isinstance(timeout, (int, float))
            or isinstance(timeout, bool)
            or not 0.1 <= float(timeout) <= 300
        ):
            raise ValueError("MCP stdio timeout must be between 0.1 and 300 seconds")
        return {
            "transport": "stdio",
            "command": list(command),
            "cwd": cwd,
            "environment": dict(sorted(environment.items())),
            "secret_env": secret_env,
            "timeout_seconds": float(timeout),
        }

    @staticmethod
    def _validate_http_config(value: Any) -> dict[str, Any]:
        if not isinstance(value, dict):
            raise ValueError("MCP HTTP connection must be an object")
        allowed = {"transport", "endpoint", "timeout_seconds", "max_response_bytes"}
        if set(value) - allowed:
            raise ValueError("MCP HTTP connection contains unsupported fields")
        if value.get("transport", "streamable_http") != "streamable_http":
            raise ValueError("MCP HTTP connection transport must be streamable_http")
        endpoint = value.get("endpoint")
        if not isinstance(endpoint, str):
            raise ValueError("MCP HTTP endpoint is required")
        selected_endpoint = endpoint.strip()
        parsed = urlsplit(selected_endpoint)
        if (
            parsed.scheme not in {"http", "https"}
            or not parsed.netloc
            or parsed.username is not None
            or parsed.password is not None
            or parsed.fragment
            or len(selected_endpoint) > 2000
        ):
            raise ValueError("MCP HTTP endpoint must be an HTTP(S) URL without credentials or fragment")
        timeout = value.get("timeout_seconds", 30.0)
        if (
            not isinstance(timeout, (int, float))
            or isinstance(timeout, bool)
            or not 0.1 <= float(timeout) <= 300
        ):
            raise ValueError("MCP HTTP timeout must be between 0.1 and 300 seconds")
        max_response_bytes = value.get("max_response_bytes", 2 * 1024 * 1024)
        if (
            not isinstance(max_response_bytes, int)
            or isinstance(max_response_bytes, bool)
            or not 1 <= max_response_bytes <= 16 * 1024 * 1024
        ):
            raise ValueError("MCP HTTP response limit must be between 1 byte and 16 MiB")
        return {
            "transport": "streamable_http",
            "endpoint": selected_endpoint,
            "timeout_seconds": float(timeout),
            "max_response_bytes": int(max_response_bytes),
        }

    @staticmethod
    def _runtime_metadata(
        initialize_result: dict[str, Any],
        transport: str,
        catalog: list[dict[str, Any]],
        connected_at: str,
    ) -> dict[str, Any]:
        server_info = initialize_result.get("serverInfo")
        if not isinstance(server_info, dict):
            server_info = {}

        def bounded_text(value: Any, limit: int = 200) -> str | None:
            return value[:limit] if isinstance(value, str) and value else None

        return {
            "transport": transport,
            "protocol_version": bounded_text(initialize_result.get("protocolVersion"), 80),
            "server_info": {
                "name": bounded_text(server_info.get("name")),
                "version": bounded_text(server_info.get("version")),
            },
            "catalog_digest": _digest(catalog),
            "tool_count": len(catalog),
            "connected_at": connected_at,
        }

    @staticmethod
    def _connection_failure_class(exc: BaseException) -> str:
        if isinstance(exc, ValueError):
            return "schema_mismatch"
        if isinstance(exc, MCPProtocolError):
            return "mcp_protocol"
        if isinstance(exc, (OSError, TimeoutError)):
            return "transport"
        return type(exc).__name__[:80]

    @staticmethod
    def _audit(
        connection: sqlite3.Connection,
        actor: str,
        action: str,
        target_id: str,
        result: str,
        metadata: dict[str, Any],
    ) -> None:
        connection.execute(
            """INSERT INTO audit_events(
               actor_type, actor_ref, action, target_type, target_id,
               result, metadata_json, created_at
            ) VALUES ('admin', ?, ?, 'tool_provider', ?, ?, ?, ?)""",
            (
                actor,
                action,
                target_id,
                result,
                json.dumps(metadata, ensure_ascii=False),
                iso(),
            ),
        )
