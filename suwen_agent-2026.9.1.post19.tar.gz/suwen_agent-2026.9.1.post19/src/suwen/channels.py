from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any
from urllib.parse import quote

import httpx
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from .config import FeishuConfig
from .types import InboundAttachment, InboundContext, InboundEvent

_MAX_FEISHU_MESSAGE_IMAGES = 4
_MAX_FEISHU_QUOTED_MESSAGE_CHARS = 20_000
_IMAGE_ONLY_PROMPT = "用户提交了一张图片，请根据图片中的可见信息协助排查。"


@dataclass(frozen=True, repr=False)
class FeishuRuntimeConfig:
    """Resolved per-instance configuration used only inside the Channel runtime.

    Secret values deliberately have no repr and are never returned by management APIs.
    """

    instance_id: str
    revision: int
    credential_revision: str
    enabled: bool
    mode: str
    sender: str
    external_instance_ref: str
    app_id: str
    app_secret: str
    verification_token: str
    encrypt_key: str
    bot_open_id: str
    allow_unverified_fixture_events: bool
    require_mention_in_group: bool
    api_base_url: str
    allowed_actor_refs: frozenset[str]
    allowed_chat_refs: frozenset[str]
    external_writes: int
    outbound_mode: str
    approval_note: str
    domain: str = "feishu"

    @property
    def transport_identity(self) -> str:
        """Non-secret identity for pinning a message to compatible credentials."""

        encoded = json.dumps(
            [self.credential_revision, self.domain],
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()


class ChannelDrop(ValueError):
    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(reason)


class FeishuMediaDownloader:
    """Download one resource named by a verified inbound Feishu event."""

    def __init__(
        self,
        config: FeishuRuntimeConfig,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        if not config.app_id or not config.app_secret:
            raise ValueError("Feishu media download requires app credentials")
        self.config = config
        self.client = httpx.AsyncClient(
            base_url=config.api_base_url.rstrip("/"),
            timeout=30,
            transport=transport,
        )
        self._token: str | None = None
        self._token_expiry = datetime.min.replace(tzinfo=UTC)

    async def _tenant_token(self) -> str:
        now = datetime.now(UTC)
        if self._token and now < self._token_expiry:
            return self._token
        response = await self.client.post(
            "/auth/v3/tenant_access_token/internal/",
            json={"app_id": self.config.app_id, "app_secret": self.config.app_secret},
        )
        response.raise_for_status()
        body = response.json()
        if not isinstance(body, dict):
            raise RuntimeError("Feishu tenant token request failed")
        token = body.get("tenant_access_token")
        if body.get("code") != 0 or not isinstance(token, str) or not token:
            raise RuntimeError("Feishu tenant token request failed")
        self._token = token
        expires = max(60, int(body.get("expire", 3600)) - 300)
        self._token_expiry = now + timedelta(seconds=expires)
        return token

    async def download_image(
        self,
        message_id: str,
        image_key: str,
        *,
        max_bytes: int,
    ) -> InboundAttachment:
        if not message_id or len(message_id) > 512 or not image_key or len(image_key) > 512:
            raise ValueError("Feishu image resource reference is invalid")
        token = await self._tenant_token()
        chunks: list[bytes] = []
        observed = 0
        async with self.client.stream(
            "GET",
            (
                f"/im/v1/messages/{quote(message_id, safe='')}/resources/"
                f"{quote(image_key, safe='')}"
            ),
            params={"type": "image"},
            headers={"Authorization": f"Bearer {token}"},
        ) as response:
            response.raise_for_status()
            declared_length = response.headers.get("content-length")
            if declared_length:
                try:
                    declared_bytes = int(declared_length)
                except ValueError:
                    declared_bytes = 0
                if declared_bytes > max_bytes:
                    raise ValueError("Feishu image exceeds the configured Artifact size limit")
            async for chunk in response.aiter_bytes():
                observed += len(chunk)
                if observed > max_bytes:
                    raise ValueError("Feishu image exceeds the configured Artifact size limit")
                chunks.append(chunk)
            media_type = response.headers.get("content-type", "").split(";", 1)[0].strip().lower()
        if media_type not in {"image/png", "image/jpeg", "image/webp"}:
            media_type = None
        return InboundAttachment(
            kind="image",
            external_ref=image_key,
            media_type=media_type,
            content=b"".join(chunks),
        )

    async def read_message_context(self, message_id: str) -> InboundContext:
        """Read exactly one message explicitly selected by a reply event."""

        if not message_id or len(message_id) > 512:
            raise ValueError("Feishu message reference is invalid")
        token = await self._tenant_token()
        response = await self.client.get(
            f"/im/v1/messages/{quote(message_id, safe='')}",
            headers={"Authorization": f"Bearer {token}"},
        )
        response.raise_for_status()
        body = response.json()
        if not isinstance(body, dict) or body.get("code") != 0:
            raise RuntimeError("Feishu message read failed")
        data = body.get("data")
        items = data.get("items") if isinstance(data, dict) else None
        if not isinstance(items, list) or not items or not isinstance(items[0], dict):
            raise RuntimeError("Feishu message read returned no message")
        item = next(
            (
                candidate
                for candidate in items
                if isinstance(candidate, dict)
                and str(candidate.get("message_id") or "") == message_id
            ),
            items[0],
        )
        message_type = str(item.get("msg_type") or item.get("message_type") or "").lower()
        if message_type not in {"text", "post", "image"}:
            raise RuntimeError("Feishu replied message type is not supported")
        item_body = item.get("body")
        raw_content = item_body.get("content", "") if isinstance(item_body, dict) else ""
        content, image_keys = FeishuAdapter._message_content(message_type, raw_content)
        if len(image_keys) > _MAX_FEISHU_MESSAGE_IMAGES:
            raise RuntimeError("Feishu replied message contains too many images")
        if message_type == "post":
            content = "\n".join(line for line in content.splitlines() if line.strip())
        content = content.strip()
        if image_keys and not content:
            content = _IMAGE_ONLY_PROMPT
        limitations: list[str] = []
        if len(content) > _MAX_FEISHU_QUOTED_MESSAGE_CHARS:
            content = content[:_MAX_FEISHU_QUOTED_MESSAGE_CHARS]
            limitations.append("replied_message_text_truncated")
        return InboundContext(
            kind="replied_message",
            external_ref=message_id,
            content=content,
            limitations=tuple(limitations),
            attachments=tuple(
                InboundAttachment(kind="image", external_ref=image_key)
                for image_key in image_keys
            ),
        )

    async def close(self) -> None:
        await self.client.aclose()


class FeishuAdapter:
    """Normalize synthetic or verified Feishu event payloads.

    Real delivery is intentionally not implemented in the adapter; replies use the outbox Sender.
    """

    def __init__(self, config: FeishuConfig | FeishuRuntimeConfig):
        self.config = config

    def verify(self, headers: dict[str, str], raw_body: bytes, payload: dict[str, Any]) -> None:
        if "encrypt" in payload:
            self.decode(headers, raw_body, payload)
            return
        self._verify_signature(headers, raw_body)
        self._verify_token(payload)

    def decode(
        self,
        headers: dict[str, str],
        raw_body: bytes,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        if not isinstance(payload, dict):
            raise ChannelDrop("invalid_payload")
        if "encrypt" not in payload:
            self.verify(headers, raw_body, payload)
            return payload
        self._verify_signature(headers, raw_body, require=True)
        decrypted = self._decrypt_payload(payload.get("encrypt"))
        self._verify_token(decrypted)
        return decrypted

    def _verify_token(self, payload: dict[str, Any]) -> None:
        token = self.config.verification_token
        if not token and not self.config.encrypt_key:
            if self.config.allow_unverified_fixture_events:
                return
            raise ChannelDrop("verification_not_configured")
        if token:
            supplied = str(payload.get("token") or payload.get("header", {}).get("token") or "")
            if not __import__("hmac").compare_digest(supplied, token):
                raise ChannelDrop("invalid_verification_token")

    def _verify_signature(
        self,
        headers: dict[str, str],
        raw_body: bytes,
        *,
        require: bool = False,
    ) -> None:
        secret = self.config.encrypt_key
        if secret:
            normalized = {key.lower(): value for key, value in headers.items()}
            timestamp = normalized.get("x-lark-request-timestamp", "")
            nonce = normalized.get("x-lark-request-nonce", "")
            signature = normalized.get("x-lark-signature", "")
            if not timestamp or not nonce or not signature:
                raise ChannelDrop("missing_signature")
            expected = hashlib.sha256((timestamp + nonce + secret).encode() + raw_body).hexdigest()
            if not __import__("hmac").compare_digest(signature, expected):
                raise ChannelDrop("invalid_signature")
        elif require:
            raise ChannelDrop("encrypt_key_not_configured")

    def _decrypt_payload(self, encrypted_value: Any) -> dict[str, Any]:
        if not isinstance(encrypted_value, str) or not encrypted_value:
            raise ChannelDrop("invalid_encrypted_payload")
        try:
            encrypted = base64.b64decode(encrypted_value, validate=True)
            if len(encrypted) < 32 or (len(encrypted) - 16) % 16:
                raise ValueError("invalid encrypted payload length")
            iv, ciphertext = encrypted[:16], encrypted[16:]
            key = hashlib.sha256(self.config.encrypt_key.encode()).digest()
            decryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
            padded = decryptor.update(ciphertext) + decryptor.finalize()
            unpadder = padding.PKCS7(128).unpadder()
            plaintext = unpadder.update(padded) + unpadder.finalize()
            decoded = json.loads(plaintext)
        except (ValueError, TypeError, json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ChannelDrop("invalid_encrypted_payload") from exc
        if not isinstance(decoded, dict):
            raise ChannelDrop("invalid_encrypted_payload")
        return decoded

    def normalize(self, payload: dict[str, Any]) -> InboundEvent:
        if "encrypt" in payload:
            raise ChannelDrop("encrypted_payload_requires_decode")
        if payload.get("type") == "url_verification":
            raise ChannelDrop("url_verification")
        header = payload.get("header", {})
        event = payload.get("event", payload)
        message = event.get("message", {})
        sender = event.get("sender", {})
        event_id = str(header.get("event_id") or payload.get("event_id") or "")
        if not event_id:
            raise ChannelDrop("missing_event_id")
        message_type = str(message.get("message_type") or "text").strip().lower()
        if message_type not in {"text", "post", "image"}:
            raise ChannelDrop("unsupported_message_type")

        chat_type = message.get("chat_type", "p2p")
        mentions = message.get("mentions") or []
        parent_refs = self._parent_refs(message)
        thread_id = str(message.get("thread_id") or "")
        mentioned_bot = self._mentioned_bot(mentions)
        if chat_type == "group" and self.config.require_mention_in_group:
            if not self.config.allow_unverified_fixture_events and not self.config.bot_open_id:
                raise ChannelDrop("bot_open_id_not_configured")
            if not mentioned_bot:
                raise ChannelDrop("not_mentioned")
        content, image_keys = self._message_content(
            message_type,
            message.get("content", ""),
        )
        if len(image_keys) > _MAX_FEISHU_MESSAGE_IMAGES:
            raise ChannelDrop("too_many_images")
        for mention in mentions:
            if not self._is_bot_mention(mention):
                continue
            key = mention.get("key")
            name = mention.get("name")
            if key:
                content = content.replace(str(key), "")
            if name:
                content = content.replace(f"@{name}", "")
        if message_type == "post":
            content = "\n".join(line for line in content.splitlines() if line.strip())
        content = content.strip()
        if image_keys and not content:
            content = _IMAGE_ONLY_PROMPT
        command = {
            "/new": "new_case",
            "/新会话": "new_case",
            "新会话": "new_case",
            "/clear": "clear",
            "/stop": "stop",
        }.get(content.lower())

        actor_ref = str(
            sender.get("sender_id", {}).get("open_id")
            or sender.get("sender_id", {}).get("user_id")
            or sender.get("open_id")
            or ""
        )
        if not actor_ref:
            raise ChannelDrop("missing_actor")
        chat_id = str(message.get("chat_id") or actor_ref)
        actor_scope = bool(self.config.allowed_actor_refs)
        chat_scope = chat_type == "group" and bool(self.config.allowed_chat_refs)
        actor_allowed = actor_scope and actor_ref in self.config.allowed_actor_refs
        chat_allowed = chat_scope and chat_id in self.config.allowed_chat_refs
        if (actor_scope or chat_scope) and not (actor_allowed or chat_allowed):
            raise ChannelDrop("chat_not_allowed" if chat_scope else "actor_not_allowed")
        if thread_id:
            scope_kind = "thread"
            scope_ref = thread_id
        elif chat_type == "group":
            scope_kind = "group"
            scope_ref = chat_id
        else:
            scope_kind = "dm"
            scope_ref = actor_ref
        if command in {"new_case", "clear"} and scope_kind == "thread":
            raise ChannelDrop("new_case_requires_new_thread")
        occurred = message.get("create_time") or header.get("create_time")
        occurred_at = self._occurred_at(occurred)
        channel_instance = str(header.get("app_id") or payload.get("app_id") or "default")
        message_id = str(message.get("message_id") or "")
        if image_keys and not message_id:
            raise ChannelDrop("missing_message_id")
        return InboundEvent(
            event_id=event_id,
            channel="feishu",
            channel_instance=channel_instance,
            scope_kind=scope_kind,
            scope_ref=scope_ref,
            actor_ref=actor_ref,
            content=content,
            occurred_at=occurred_at,
            parent_event_ref=parent_refs[0] if parent_refs else None,
            reply_address={
                "chat_id": chat_id,
                "channel_instance": channel_instance,
                "thread_id": thread_id or None,
                "reply_to": message.get("message_id"),
                "parent_id": message.get("parent_id"),
                "root_id": message.get("root_id"),
                "mentioned_bot": mentioned_bot,
                "require_mention_in_group": bool(self.config.require_mention_in_group),
                "parent_refs": parent_refs,
            },
            command=command,
            attachments=tuple(
                InboundAttachment(
                    kind="image",
                    external_ref=image_key,
                )
                for image_key in image_keys
            ),
        )

    def _mentioned_bot(self, mentions: list[dict[str, Any]]) -> bool:
        return any(self._is_bot_mention(mention) for mention in mentions)

    def _is_bot_mention(self, mention: dict[str, Any]) -> bool:
        if self.config.allow_unverified_fixture_events:
            return True
        bot_open_id = self.config.bot_open_id
        mention_id = mention.get("id")
        if isinstance(mention_id, dict):
            mention_open_id = mention_id.get("open_id")
        else:
            mention_open_id = mention.get("open_id")
        return bool(bot_open_id and mention_open_id == bot_open_id)

    @classmethod
    def _message_content(
        cls,
        message_type: str,
        raw_content: Any,
    ) -> tuple[str, tuple[str, ...]]:
        if message_type == "image":
            return _IMAGE_ONLY_PROMPT, (cls._message_image_key(raw_content),)
        if isinstance(raw_content, dict):
            parsed: Any = raw_content
        elif isinstance(raw_content, str):
            try:
                parsed = json.loads(raw_content)
            except json.JSONDecodeError:
                return (raw_content, ()) if message_type == "text" else ("", ())
        else:
            return "", ()
        if message_type == "text":
            if isinstance(parsed, dict):
                return str(parsed.get("text") or ""), ()
            return str(parsed), ()
        return cls._post_content(parsed)

    @staticmethod
    def _message_image_key(raw_content: Any) -> str:
        if isinstance(raw_content, dict):
            parsed = raw_content
        elif isinstance(raw_content, str):
            try:
                parsed = json.loads(raw_content)
            except json.JSONDecodeError as exc:
                raise ChannelDrop("invalid_image_content") from exc
        else:
            raise ChannelDrop("invalid_image_content")
        return FeishuAdapter._validated_image_key(parsed)

    @staticmethod
    def _validated_image_key(parsed: Any) -> str:
        image_key = parsed.get("image_key") if isinstance(parsed, dict) else None
        if not isinstance(image_key, str) or not image_key or len(image_key) > 512:
            raise ChannelDrop("invalid_image_key")
        return image_key

    @classmethod
    def _post_content(cls, parsed: Any) -> tuple[str, tuple[str, ...]]:
        if not isinstance(parsed, dict):
            return "", ()
        body = parsed
        if not isinstance(body.get("content"), list):
            localized = [
                value
                for key, value in parsed.items()
                if key in {"zh_cn", "en_us", "ja_jp"} and isinstance(value, dict)
            ]
            if not localized:
                localized = [value for value in parsed.values() if isinstance(value, dict)]
            body = localized[0] if localized else {}
        parts: list[str] = []
        image_keys: list[str] = []
        title = body.get("title") if isinstance(body, dict) else None
        if isinstance(title, str) and title.strip():
            parts.append(title.strip())

        def collect(value: Any) -> None:
            if isinstance(value, list):
                for item in value:
                    collect(item)
                return
            if not isinstance(value, dict):
                return
            tag = str(value.get("tag") or "")
            if tag == "text":
                text = value.get("text")
                if isinstance(text, str) and text.strip():
                    parts.append(text.strip())
                return
            if tag == "a":
                text = value.get("text")
                label = text.strip() if isinstance(text, str) else ""
                raw_href = value.get("href") or value.get("url")
                href = raw_href.strip() if isinstance(raw_href, str) else ""
                if len(href) > 4096:
                    href = href[:4096]
                if label and href and label != href:
                    parts.append(f"{label} ({href})")
                elif label or href:
                    parts.append(label or href)
                return
            if tag == "at":
                name = value.get("user_name")
                if isinstance(name, str) and name.strip():
                    parts.append(f"@{name.strip()}")
                return
            if tag == "img":
                image_keys.append(cls._validated_image_key(value))
                return
            for nested in value.values():
                if isinstance(nested, (dict, list)):
                    collect(nested)

        collect(body.get("content") if isinstance(body, dict) else None)
        return "\n".join(parts), tuple(image_keys)

    @staticmethod
    def _parent_refs(message: dict[str, Any]) -> list[str]:
        refs: list[str] = []
        for key in ("parent_id", "root_id"):
            value = str(message.get(key) or "")
            if value and value not in refs:
                refs.append(value)
        return refs

    @staticmethod
    def _occurred_at(value: Any) -> str:
        if value is None:
            return datetime.now(UTC).isoformat()
        text = str(value)
        if text.isdigit():
            timestamp = int(text)
            if timestamp > 10_000_000_000:
                timestamp /= 1000
            return datetime.fromtimestamp(timestamp, UTC).isoformat()
        return datetime.fromisoformat(text).astimezone(UTC).isoformat()
