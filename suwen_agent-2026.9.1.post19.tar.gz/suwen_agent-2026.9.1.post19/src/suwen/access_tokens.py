from __future__ import annotations

import json
import os
import secrets
import stat
import tempfile
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

SCHEMA_VERSION = "suwen-access-tokens.v1"
DEFAULT_TTL_DAYS = 365
MINIMUM_TOKEN_LENGTH = 32


@dataclass(frozen=True)
class AccessTokenBundle:
    admin_token: str = field(repr=False)
    api_token: str = field(repr=False)
    created_at: datetime
    expires_at: datetime

    def expired(self, at: datetime | None = None) -> bool:
        observed_at = at or datetime.now(UTC)
        if observed_at.tzinfo is None:
            raise ValueError("access token expiry checks require a timezone-aware timestamp")
        return observed_at >= self.expires_at

    def metadata(self, path: Path, *, status: str) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "status": status,
            "path": str(path),
            "created_at": _iso(self.created_at),
            "expires_at": _iso(self.expires_at),
            "ttl_days": (self.expires_at - self.created_at).days,
            "contains_secret_values": False,
        }


def default_access_tokens_path(data_dir: str | Path) -> Path:
    return Path(data_dir) / "private" / "access-tokens.json"


def load_access_token_bundle(path: str | Path) -> AccessTokenBundle:
    target = Path(path).expanduser()
    if target.is_symlink():
        raise ValueError("access token file cannot be a symbolic link")
    try:
        file_stat = target.stat()
    except OSError as exc:
        raise ValueError("access token file is unavailable") from exc
    if not stat.S_ISREG(file_stat.st_mode):
        raise ValueError("access token path must be a regular file")
    if stat.S_IMODE(file_stat.st_mode) & 0o077:
        raise ValueError("access token file must not be accessible by group or other users")
    try:
        payload = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("access token file is invalid") from exc
    if not isinstance(payload, dict) or payload.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("access token file uses an unsupported schema")
    admin_token = payload.get("admin_token")
    api_token = payload.get("api_token")
    if not isinstance(admin_token, str) or len(admin_token) < MINIMUM_TOKEN_LENGTH:
        raise ValueError("access token file has an invalid admin token")
    if not isinstance(api_token, str) or len(api_token) < MINIMUM_TOKEN_LENGTH:
        raise ValueError("access token file has an invalid API token")
    if secrets.compare_digest(admin_token, api_token):
        raise ValueError("access token file must use distinct admin and API tokens")
    created_at = _parse_timestamp(payload.get("created_at"), "created_at")
    expires_at = _parse_timestamp(payload.get("expires_at"), "expires_at")
    if expires_at <= created_at:
        raise ValueError("access token expiry must be later than creation")
    return AccessTokenBundle(
        admin_token=admin_token,
        api_token=api_token,
        created_at=created_at,
        expires_at=expires_at,
    )


def provision_access_token_bundle(
    path: str | Path,
    *,
    ttl_days: int = DEFAULT_TTL_DAYS,
    rotate: bool = False,
    now: datetime | None = None,
) -> dict[str, Any]:
    if isinstance(ttl_days, bool) or not 1 <= ttl_days <= 3650:
        raise ValueError("access token TTL must be between 1 and 3650 days")
    target = Path(path).expanduser().absolute()
    if target.exists() and not rotate:
        return load_access_token_bundle(target).metadata(target, status="already_provisioned")
    if target.exists() and target.is_symlink():
        raise ValueError("access token file cannot be a symbolic link")
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    target.parent.chmod(0o700)
    created_at = now or datetime.now(UTC)
    if created_at.tzinfo is None:
        raise ValueError("access token provisioning requires a timezone-aware timestamp")
    bundle = AccessTokenBundle(
        admin_token=secrets.token_urlsafe(48),
        api_token=secrets.token_urlsafe(48),
        created_at=created_at.astimezone(UTC),
        expires_at=created_at.astimezone(UTC) + timedelta(days=ttl_days),
    )
    payload = {
        "schema_version": SCHEMA_VERSION,
        "admin_token": bundle.admin_token,
        "api_token": bundle.api_token,
        "created_at": _iso(bundle.created_at),
        "expires_at": _iso(bundle.expires_at),
    }
    encoded = (json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{target.name}.", dir=target.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())
            os.fchmod(handle.fileno(), 0o600)
        if target.exists() and not rotate:
            temporary.unlink(missing_ok=True)
            return load_access_token_bundle(target).metadata(target, status="already_provisioned")
        os.replace(temporary, target)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    status = "rotated" if rotate else "provisioned"
    return bundle.metadata(target, status=status)


def _parse_timestamp(value: object, field_name: str) -> datetime:
    if not isinstance(value, str):
        raise ValueError(f"access token file is missing {field_name}")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"access token file has an invalid {field_name}") from exc
    if parsed.tzinfo is None:
        raise ValueError(f"access token file {field_name} must include a timezone")
    return parsed.astimezone(UTC)


def _iso(value: datetime) -> str:
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")
