from __future__ import annotations

import asyncio
import json
import uuid
from typing import Any

from .channel_registry import ChannelRegistry
from .channels import FeishuRuntimeConfig
from .feishu_long_connection import FeishuCredentialProbe, FeishuLongConnectionSupervisor
from .model_registry import ModelRegistry


class FeishuConfigurationError(ValueError):
    """A bounded configuration failure suitable for the management API."""

    def __init__(self, message: str, failure_class: str):
        super().__init__(message)
        self.failure_class = failure_class


class FeishuChannelConfigurator:
    """Converge one management save into a usable or safely disabled Channel."""

    def __init__(
        self,
        registry: ChannelRegistry,
        models: ModelRegistry,
        probe: FeishuCredentialProbe,
        supervisor: FeishuLongConnectionSupervisor,
        *,
        connection_timeout_seconds: float = 12.0,
    ) -> None:
        self.registry = registry
        self.models = models
        self.probe = probe
        self.supervisor = supervisor
        self.connection_timeout_seconds = connection_timeout_seconds
        self._instance_locks: dict[str, asyncio.Lock] = {}

    async def configure(
        self,
        *,
        instance_id: str,
        name: str,
        agent_id: str | None,
        enabled: bool,
        domain: str,
        app_id: str,
        app_secret: str | None,
        verification_token: str | None,
        encrypt_key: str | None,
        require_mention_in_group: bool,
        allowed_actor_refs: str,
        allowed_chat_refs: str,
        actor: str,
    ) -> dict[str, Any]:
        lock = self._instance_locks.setdefault(instance_id, asyncio.Lock())
        async with lock:
            return await self._configure_locked(
                instance_id=instance_id,
                name=name,
                agent_id=agent_id,
                enabled=enabled,
                domain=domain,
                app_id=app_id,
                app_secret=app_secret,
                verification_token=verification_token,
                encrypt_key=encrypt_key,
                require_mention_in_group=require_mention_in_group,
                allowed_actor_refs=allowed_actor_refs,
                allowed_chat_refs=allowed_chat_refs,
                actor=actor,
            )

    async def _configure_locked(
        self,
        *,
        instance_id: str,
        name: str,
        agent_id: str | None,
        enabled: bool,
        domain: str,
        app_id: str,
        app_secret: str | None,
        verification_token: str | None,
        encrypt_key: str | None,
        require_mention_in_group: bool,
        allowed_actor_refs: str,
        allowed_chat_refs: str,
        actor: str,
    ) -> dict[str, Any]:
        previous = self._current(instance_id)
        if previous and previous["channel_type"] != "feishu":
            raise FeishuConfigurationError("该实例不是飞书渠道", "channel_type_mismatch")
        if enabled:
            self._validate_agent(instance_id, agent_id)

        previous_refs = self._binding_map(previous)
        previous_values = self._resolved_values(previous_refs)
        values = {
            "app_id": app_id.strip(),
            "app_secret": self._preserved_value(
                app_secret,
                previous_values.get("app_secret"),
            ),
        }
        for purpose, supplied in (
            ("verification_token", verification_token),
            ("encrypt_key", encrypt_key),
        ):
            value = self._preserved_value(supplied, previous_values.get(purpose))
            if value:
                values[purpose] = value
        if not values["app_id"] or not values["app_secret"]:
            raise FeishuConfigurationError(
                "App ID 与 App Secret 不能为空",
                "feishu_credentials_missing",
            )
        transport_change_requested = previous is not None and (
            domain != previous.get("config", {}).get("domain", "feishu")
            or any(previous_values.get(purpose, "") != value for purpose, value in values.items())
            or any(purpose not in values for purpose in previous_values)
        )
        if transport_change_requested:
            self.registry.assert_feishu_transport_switch_available(instance_id)

        api_base_url = (
            "https://open.larksuite.com/open-apis"
            if domain == "lark"
            else "https://open.feishu.cn/open-apis"
        )
        config = {
            "domain": domain,
            "mode": "long_connection",
            "sender": "feishu" if enabled else "capture",
            "external_instance_ref": values["app_id"],
            "bot_open_id": str((previous or {}).get("config", {}).get("bot_open_id") or ""),
            "require_mention_in_group": require_mention_in_group,
            "allowed_actor_refs": allowed_actor_refs.strip(),
            "allowed_chat_refs": allowed_chat_refs.strip(),
            "external_writes": 1 if enabled else 0,
            "outbound_mode": "reply_only" if enabled else "disabled",
            "approval_note": (
                "管理端启用飞书渠道，仅回复该渠道已准入的入站消息" if enabled else ""
            ),
            "api_base_url": api_base_url,
        }
        candidate = FeishuRuntimeConfig(
            instance_id=instance_id,
            revision=int((previous or {}).get("revision") or 0) + 1,
            credential_revision="candidate",
            enabled=enabled,
            mode="long_connection",
            sender=str(config["sender"]),
            external_instance_ref=values["app_id"],
            app_id=values["app_id"],
            app_secret=values["app_secret"],
            verification_token=values.get("verification_token", ""),
            encrypt_key=values.get("encrypt_key", ""),
            bot_open_id=str(config["bot_open_id"]),
            allow_unverified_fixture_events=False,
            require_mention_in_group=require_mention_in_group,
            api_base_url=api_base_url,
            allowed_actor_refs=self._csv(config["allowed_actor_refs"]),
            allowed_chat_refs=self._csv(config["allowed_chat_refs"]),
            external_writes=int(config["external_writes"]),
            outbound_mode=str(config["outbound_mode"]),
            approval_note=str(config["approval_note"]),
            domain=domain,
        )
        probe = await self.probe.probe(candidate)
        if probe.status != "passed":
            failure_class = probe.failure_class or "feishu_credentials_rejected"
            message = (
                "服务器无法连接飞书开放平台，请检查 DNS 与外网 HTTPS 访问"
                if failure_class == "feishu_connectivity_failed"
                else "应用身份验证失败，请检查 App ID 与 App Secret"
            )
            raise FeishuConfigurationError(
                message,
                failure_class,
            )
        if probe.bot_open_id:
            config["bot_open_id"] = probe.bot_open_id

        bindings = self._materialize_secret_refs(
            name,
            values,
            previous_refs,
            previous_values,
            actor,
        )
        configuration_applied = False
        try:
            configured = self.registry.apply_feishu_configuration(
                instance_id,
                name,
                config,
                bindings,
                agent_id,
                enabled,
                actor,
            )
            configuration_applied = True
            configuration_changed = configured["configuration_changed"]
            await self.supervisor.reconcile()
            if enabled:
                configured = await self._wait_until_ready(instance_id)
                configured["configuration_changed"] = configuration_changed
                if not configured["readiness"]["reply_ready"]:
                    raise FeishuConfigurationError(
                        "飞书配置通过验证，但长连接未能进入可回复状态",
                        str(configured.get("last_error_class") or "feishu_connection_not_ready"),
                    )
        except Exception:
            if configuration_applied:
                await self._restore_previous(instance_id, previous, actor)
            raise

        return {
            "status": "ready" if enabled else "disabled",
            "instance": configured,
            "readiness": configured["readiness"],
            "message_accessed": False,
            "message_sent": False,
        }

    def _current(self, instance_id: str) -> dict[str, Any] | None:
        try:
            return self.registry.get_instance(instance_id)
        except KeyError:
            return None

    @staticmethod
    def _binding_map(instance: dict[str, Any] | None) -> dict[str, str]:
        if not instance:
            return {}
        return {
            item["purpose"]: item["secret_ref_id"]
            for item in instance.get("secret_bindings", [])
        }

    def _resolved_values(self, refs: dict[str, str]) -> dict[str, str]:
        values: dict[str, str] = {}
        for purpose, ref_id in refs.items():
            try:
                values[purpose] = self.models.secrets.resolve(ref_id, required=False)
            except (KeyError, ValueError):
                values[purpose] = ""
        return values

    @staticmethod
    def _preserved_value(supplied: str | None, previous: str | None) -> str:
        return supplied if supplied else (previous or "")

    @staticmethod
    def _csv(value: Any) -> frozenset[str]:
        if not isinstance(value, str):
            raise FeishuConfigurationError("访问范围格式无效", "feishu_scope_invalid")
        items = [item.strip() for item in value.split(",") if item.strip()]
        if len(items) > 200 or any(len(item) > 200 for item in items):
            raise FeishuConfigurationError("访问范围过大", "feishu_scope_invalid")
        return frozenset(items)

    def _validate_agent(self, instance_id: str, agent_id: str | None) -> None:
        if not agent_id:
            raise FeishuConfigurationError(
                "启用飞书渠道必须选择一个智能体",
                "channel_agent_not_selected",
            )
        with self.registry.database.connect() as connection:
            agent = connection.execute(
                "SELECT status, active_version_id FROM agents WHERE id=?",
                (agent_id,),
            ).fetchone()
            if not agent or agent["status"] != "published" or not agent["active_version_id"]:
                raise FeishuConfigurationError(
                    "所选智能体尚未发布",
                    "channel_agent_not_published",
                )
            version = connection.execute(
                "SELECT channel_policy_json FROM agent_versions WHERE id=?",
                (agent["active_version_id"],),
            ).fetchone()
        policy = json.loads(version["channel_policy_json"] or "{}")
        allowed = policy.get("channel_instance_ids", [])
        if allowed and instance_id not in allowed:
            raise FeishuConfigurationError(
                "所选智能体未允许绑定此渠道",
                "channel_agent_policy_denied",
            )

    def _materialize_secret_refs(
        self,
        name: str,
        values: dict[str, str],
        previous_refs: dict[str, str],
        previous_values: dict[str, str],
        actor: str,
    ) -> dict[str, str]:
        bindings: dict[str, str] = {}
        pending_values: dict[str, str] = {}
        for purpose, value in values.items():
            if previous_refs.get(purpose) and previous_values.get(purpose) == value:
                bindings[purpose] = previous_refs[purpose]
                continue
            suffix = uuid.uuid4().hex
            ref_id = f"managed-{suffix}"
            self.models.create_secret_ref(
                ref_id,
                f"{name.strip()} {purpose} {suffix[:8]}",
                f"SUWEN_MANAGED_SECRET_{suffix.upper()}",
                actor,
            )
            bindings[purpose] = ref_id
            pending_values[ref_id] = value
        if pending_values:
            self.models.secrets.store_private_values(pending_values, actor)
        return bindings

    async def _wait_until_ready(self, instance_id: str) -> dict[str, Any]:
        loop = asyncio.get_running_loop()
        deadline = loop.time() + self.connection_timeout_seconds
        latest = self.registry.get_instance(instance_id)
        while loop.time() < deadline:
            latest = self.registry.get_instance(instance_id)
            if latest.get("readiness", {}).get("reply_ready"):
                return latest
            if latest.get("last_error_class") and latest.get("health_state") in {
                "disconnected",
                "misconfigured",
                "credential_rejected",
            }:
                return latest
            await asyncio.sleep(0.2)
        return latest

    async def _restore_previous(
        self,
        instance_id: str,
        previous: dict[str, Any] | None,
        actor: str,
    ) -> None:
        try:
            if previous is None:
                current = self._current(instance_id)
                if current and current["status"] != "disabled":
                    self.registry.set_status(instance_id, "disabled", actor)
                await self.supervisor.reconcile()
                return
            previous_agent = next(
                (
                    item["agent_id"]
                    for item in previous.get("agent_bindings", [])
                    if item.get("active")
                ),
                None,
            )
            self.registry.apply_feishu_configuration(
                instance_id,
                previous["name"],
                previous["config"],
                self._binding_map(previous),
                previous_agent,
                previous["status"] == "active",
                f"{actor}:automatic-rollback",
            )
            await self.supervisor.reconcile()
        except Exception as exc:
            raise RuntimeError("飞书配置失败，且上一版本未能自动恢复") from exc
