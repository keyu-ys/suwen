from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, replace
from typing import Any

from .actions import ActionService
from .agent_composition import AgentCompositionError, compose_agent_surface
from .artifacts import ArtifactStore
from .capability_packages import (
    CapabilityBinding,
    CapabilityPackageRegistry,
    capability_prompt_digest,
    capability_reference_digest,
    capability_skill_digest,
)
from .config import DEFAULT_MODEL_REASONING_EFFORT, HarnessConfig, ModelConfig
from .connectors import (
    effective_connector_allowlist,
    published_tool_baseline_digest,
    resolve_connector_bindings,
)
from .db import Database
from .harness import DiagnosticHarness
from .model_registry import ModelRegistry, model_capabilities
from .models import ModelProvider, UnavailableModelProvider, build_model
from .packs import PackRegistry
from .personas import normalize_persona_snapshot, render_persona_instruction
from .repository import Repository
from .skills import SkillRegistry
from .tool_provider_registry import ConnectorRunLease, ToolProviderRegistry
from .tools import ToolRegistry, tool_schema_digest, tool_schema_projection
from .types import RunResult


@dataclass(frozen=True)
class ResolvedRuntime:
    snapshot: dict[str, Any]
    model_config: ModelConfig
    harness_config: HarnessConfig
    system_prompt: str
    persona_prompt: str
    skills: SkillRegistry
    tools: ToolRegistry
    configuration_error: str | None = None


class RuntimeResolver:
    """Resolve one immutable Agent configuration for one Run."""

    def __init__(
        self,
        database: Database,
        models: ModelRegistry,
        base_harness_config: HarnessConfig,
        packs: PackRegistry,
        tools: ToolRegistry,
        capability_packages: CapabilityPackageRegistry | None = None,
    ) -> None:
        self.database = database
        self.models = models
        self.base_harness_config = base_harness_config
        self.packs = packs
        self.tools = tools
        self.capability_packages = capability_packages

    def resolve(
        self,
        case_id: str,
        agent_version_id: str | None = None,
    ) -> ResolvedRuntime:
        with self.database.connect() as connection:
            connection.execute("BEGIN")
            row = connection.execute(
                """SELECT c.agent_id, c.pinned_agent_version_id,
                          c.persona_snapshot_json,
                          a.status AS agent_status, a.active_version_id,
                          av.id AS agent_version_id, av.version AS agent_version,
                          av.digest AS agent_version_digest,
                          binding.model_profile_id, binding.revision AS model_binding_revision,
                          mpv.id AS model_profile_version_id,
                          av.prompt_bundle_version_id,
                          av.tool_schema_digest,
                          av.runtime_policy_json, av.context_policy_json,
                          av.channel_policy_json, av.review_policy_json,
                          av.presentation_policy_json, av.config_json,
                          mpv.model_id, mpv.digest AS model_profile_digest,
                          mpv.provider_version_id, mpv.max_input_length,
                          mpv.max_output_tokens, mpv.temperature, mpv.reasoning_effort,
                          mpv.timeout_seconds,
                          mpv.capabilities_json, mpv.routing_json,
                          pv.digest AS provider_version_digest, p.id AS provider_id,
                          p.protocol, pbv.digest AS prompt_bundle_digest,
                          pbv.content_json AS prompt_content_json
                   FROM cases c
                   JOIN agents a ON a.id=c.agent_id
                   JOIN agent_versions av
                     ON av.id=COALESCE(?, c.pinned_agent_version_id, a.active_version_id)
                   JOIN agent_model_bindings binding ON binding.agent_id=a.id
                   JOIN model_profile_versions mpv
                     ON mpv.id=(
                          SELECT current_model.id
                            FROM model_profile_versions current_model
                           WHERE current_model.model_profile_id=binding.model_profile_id
                           ORDER BY current_model.version DESC LIMIT 1
                        )
                   JOIN model_provider_versions pv ON pv.id=mpv.provider_version_id
                   JOIN model_providers p ON p.id=pv.provider_id
                   LEFT JOIN prompt_bundle_versions pbv ON pbv.id=av.prompt_bundle_version_id
                   WHERE c.id=? AND av.agent_id=c.agent_id AND av.status='published'""",
                (agent_version_id, case_id),
            ).fetchone()
            if not row:
                raise RuntimeError("case Agent runtime configuration is unavailable")
            if row["agent_status"] != "published":
                raise RuntimeError("case Agent is not accepting new Runs")
            packs = connection.execute(
                """SELECT cpv.id, cpv.pack_id, cpv.version, cpv.digest, cp.status
                   FROM agent_version_packs avp
                   JOIN capability_pack_versions cpv ON cpv.id=avp.pack_version_id
                   JOIN capability_packs cp ON cp.id=cpv.pack_id
                   WHERE avp.agent_version_id=? AND avp.enabled=1
                   ORDER BY avp.position, cpv.id""",
                (row["agent_version_id"],),
            ).fetchall()
            capability_rows = connection.execute(
                """SELECT avc.capability_version_id, avc.role, avc.position,
                          cp.id AS capability_id, cp.kind, cp.status,
                          cpv.version, cpv.content_digest, cpv.lifecycle_state
                   FROM agent_version_capabilities avc
                   JOIN capability_package_versions cpv ON cpv.id=avc.capability_version_id
                   JOIN capability_packages cp ON cp.id=cpv.capability_id
                   WHERE avc.agent_version_id=? AND avc.enabled=1
                   ORDER BY avc.position, avc.capability_version_id""",
                (row["agent_version_id"],),
            ).fetchall()
            previous = connection.execute(
                """SELECT agent_version_id FROM runs
                   WHERE case_id=? ORDER BY started_at DESC LIMIT 1""",
                (case_id,),
            ).fetchone()
            tool_provider_statuses = {
                item["id"]: item["status"]
                for item in connection.execute("SELECT id, status FROM tool_providers").fetchall()
            }
            connection.commit()
        if not packs or any(pack["status"] != "installed" for pack in packs):
            raise RuntimeError("case Agent capability configuration is unavailable")
        try:
            frozen_persona = normalize_persona_snapshot(row["persona_snapshot_json"])
        except ValueError as exc:
            raise RuntimeError("case Persona snapshot is unavailable") from exc
        capability_bindings = [
            CapabilityBinding(
                str(item["capability_version_id"]),
                str(item["role"]),
                int(item["position"]),
            )
            for item in capability_rows
        ]
        if any(
            item["kind"] != item["role"]
            or item["status"] != "available"
            or item["lifecycle_state"] != "workspace-installed"
            for item in capability_rows
        ):
            raise RuntimeError("case Agent capability package configuration is unavailable")
        if capability_bindings and self.capability_packages is None:
            raise RuntimeError("first-party capability package runtime is unavailable")
        runtime_policy = json.loads(row["runtime_policy_json"] or "{}")
        context_policy = json.loads(row["context_policy_json"] or "{}")
        agent_config = json.loads(row["config_json"] or "{}")
        harness_config = replace(
            self.base_harness_config,
            max_tool_calls=int(runtime_policy.get("max_tool_calls", self.base_harness_config.max_tool_calls)),
            max_tool_waves=int(runtime_policy.get("max_tool_waves", self.base_harness_config.max_tool_waves)),
            tool_timeout_seconds=float(
                runtime_policy.get("tool_timeout_seconds", self.base_harness_config.tool_timeout_seconds)
            ),
            run_timeout_seconds=float(
                runtime_policy.get("run_timeout_seconds", self.base_harness_config.run_timeout_seconds)
            ),
            max_concurrency=int(
                runtime_policy.get("max_concurrency", self.base_harness_config.max_concurrency)
            ),
            tool_call_limit_overrides={
                str(name): int(value)
                for name, value in agent_config.get("tool_call_limit_overrides", {}).items()
            },
            context_message_limit=int(
                context_policy.get("message_limit", self.base_harness_config.context_message_limit)
            ),
            compact_after_messages=int(
                context_policy.get(
                    "compact_after_messages",
                    self.base_harness_config.compact_after_messages,
                )
            ),
            tool_result_recent_count=int(
                context_policy.get(
                    "tool_result_recent_count",
                    self.base_harness_config.tool_result_recent_count,
                )
            ),
            tool_result_old_max_chars=int(
                context_policy.get(
                    "tool_result_old_max_chars",
                    self.base_harness_config.tool_result_old_max_chars,
                )
            ),
            tool_result_recent_max_chars=int(
                context_policy.get(
                    "tool_result_recent_max_chars",
                    self.base_harness_config.tool_result_recent_max_chars,
                )
            ),
            context_safety_margin_ratio=float(
                context_policy.get(
                    "safety_margin_ratio",
                    self.base_harness_config.context_safety_margin_ratio,
                )
            ),
            context_safety_margin_min_tokens=int(
                context_policy.get(
                    "safety_margin_min_tokens",
                    self.base_harness_config.context_safety_margin_min_tokens,
                )
            ),
            context_checkpoint_ratio=float(
                context_policy.get(
                    "checkpoint_ratio",
                    self.base_harness_config.context_checkpoint_ratio,
                )
            ),
            context_reference_ratio=float(
                context_policy.get(
                    "reference_ratio",
                    self.base_harness_config.context_reference_ratio,
                )
            ),
            context_minimal_ratio=float(
                context_policy.get(
                    "minimal_ratio",
                    self.base_harness_config.context_minimal_ratio,
                )
            ),
            context_recent_protocol_pairs=int(
                context_policy.get(
                    "recent_protocol_pairs",
                    self.base_harness_config.context_recent_protocol_pairs,
                )
            ),
            context_recent_history_messages=int(
                context_policy.get(
                    "recent_history_messages",
                    self.base_harness_config.context_recent_history_messages,
                )
            ),
            context_evidence_card_max_chars=int(
                context_policy.get(
                    "evidence_card_max_chars",
                    self.base_harness_config.context_evidence_card_max_chars,
                )
            ),
        )
        effective_runtime_policy = {
            **runtime_policy,
            "max_tool_calls": harness_config.max_tool_calls,
            "max_tool_waves": harness_config.max_tool_waves,
            "tool_timeout_seconds": harness_config.tool_timeout_seconds,
            "run_timeout_seconds": harness_config.run_timeout_seconds,
            "max_concurrency": harness_config.max_concurrency,
            "tool_call_limit_overrides": dict(harness_config.tool_call_limit_overrides),
        }
        effective_context_policy = {
            **context_policy,
            "message_limit": harness_config.context_message_limit,
            "compact_after_messages": harness_config.compact_after_messages,
            "tool_result_recent_count": harness_config.tool_result_recent_count,
            "tool_result_old_max_chars": harness_config.tool_result_old_max_chars,
            "tool_result_recent_max_chars": harness_config.tool_result_recent_max_chars,
            "safety_margin_ratio": harness_config.context_safety_margin_ratio,
            "safety_margin_min_tokens": harness_config.context_safety_margin_min_tokens,
            "checkpoint_ratio": harness_config.context_checkpoint_ratio,
            "reference_ratio": harness_config.context_reference_ratio,
            "minimal_ratio": harness_config.context_minimal_ratio,
            "recent_protocol_pairs": harness_config.context_recent_protocol_pairs,
            "recent_history_messages": harness_config.context_recent_history_messages,
            "evidence_card_max_chars": harness_config.context_evidence_card_max_chars,
        }
        pack_refs = [
            {
                "pack_version_id": pack["id"],
                "pack_id": pack["pack_id"],
                "version": pack["version"],
                "digest": pack["digest"],
            }
            for pack in packs
        ]
        try:
            composition = compose_agent_surface(
                packs=self.packs,
                runtime_tools=self.tools,
                capability_packages=self.capability_packages,
                pack_refs=pack_refs,
                capability_bindings=capability_bindings,
                prompt_content_json=row["prompt_content_json"],
            )
        except AgentCompositionError as exc:
            # Keep the existing configuration-drift contract as a ValueError so
            # callers can distinguish an invalid frozen assembly from a missing
            # runtime service dependency.
            raise ValueError(str(exc)) from exc
        loaded_packs = composition.loaded_packs
        loaded_capabilities = composition.loaded_capabilities
        if self.capability_packages is not None:
            self.capability_packages.record_process_loads(loaded_capabilities)
        capability_tool_owners = dict(composition.capability_tool_owners)
        system_prompt = composition.system_prompt
        selected_skills = composition.skills
        selected_tools = composition.tools
        base_tools = ToolRegistry()
        base_tools.merge_from(selected_tools)
        try:
            with self.database.connect() as connection:
                connector_resolution = resolve_connector_bindings(
                    connection,
                    self.tools,
                    agent_config.get("connector_bindings"),
                    normalize=False,
                )
            selected_tools.merge_from(connector_resolution.tools)
        except ValueError as exc:
            raise RuntimeError(f"case Agent Connector configuration is unavailable: {exc}") from exc
        allowlist = agent_config.get("tool_allowlist")
        if not isinstance(allowlist, list):
            raise RuntimeError("case Agent Tool allowlist is unavailable")
        frozen_tool_schema_digest = row["tool_schema_digest"]
        try:
            baseline_digest = published_tool_baseline_digest(
                base_tools,
                connector_resolution,
                allowlist,
            )
        except (KeyError, ValueError) as exc:
            raise RuntimeError("case Agent published Tool baseline is unavailable") from exc
        if frozen_tool_schema_digest and frozen_tool_schema_digest != baseline_digest:
            raise RuntimeError("case Agent Tool baseline has drifted from its published version")
        available_tools = {item.name for item in selected_tools.definitions()}
        unavailable_connector_tools = set(connector_resolution.unavailable_tool_names)
        if any(
            not isinstance(name, str)
            or (name not in available_tools and name not in unavailable_connector_tools)
            for name in allowlist
        ):
            raise RuntimeError("case Agent Tool allowlist references an unavailable Tool")
        effective_allowlist = effective_connector_allowlist(allowlist, connector_resolution)
        selected_tools = selected_tools.subset(effective_allowlist)
        # Rebind reference handlers for the selected native capability Skills.
        selected_reference_tools = ToolRegistry()
        selected_skills.register_reference_tools(selected_reference_tools)
        selected_reference_tools = selected_reference_tools.subset(
            selected_reference_tools.names().intersection(selected_tools.names())
        )
        selected_tools.merge_from(selected_reference_tools, replace=True)
        for definition in selected_tools.definitions():
            if definition.name in capability_tool_owners:
                continue
            status = tool_provider_statuses.get(definition.provider_id)
            if status is None or status in {
                "draft",
                "disabled",
                "unavailable",
                "schema_mismatch",
            }:
                raise RuntimeError("case Agent Tool Provider dependency is unavailable")
        tool_schema = tool_schema_projection(selected_tools)
        effective_tool_schema_digest = tool_schema_digest(selected_tools)
        model_capability_flags = model_capabilities(row["capabilities_json"])
        model_readiness = self.models.probe_readiness(row["model_profile_version_id"])
        model_capabilities_ready = model_readiness["status"] == "ready"
        snapshot = {
            "agent_id": row["agent_id"],
            "agent_version_id": row["agent_version_id"],
            "agent_version": row["agent_version"],
            "agent_version_digest": row["agent_version_digest"],
            "model_profile_id": row["model_profile_id"],
            "model_binding_revision": row["model_binding_revision"],
            "model_profile_version_id": row["model_profile_version_id"],
            "model_profile_digest": row["model_profile_digest"],
            "provider_id": row["provider_id"],
            "provider_version_id": row["provider_version_id"],
            "provider_version_digest": row["provider_version_digest"],
            "model_id": row["model_id"],
            "prompt_bundle_version_id": row["prompt_bundle_version_id"],
            "prompt_bundle_digest": row["prompt_bundle_digest"],
            "persona": frozen_persona,
            "persona_delivery": {
                "protocol": row["protocol"],
                "request_field": "messages[0].content",
                "message_role": "system",
            },
            "agent_profile": {
                "id": agent_config.get("agent_profile_id"),
                "version": agent_config.get("agent_profile_version"),
                "digest": agent_config.get("agent_profile_digest"),
                "artifact_digest": agent_config.get("agent_profile_artifact_digest"),
                "installation_id": agent_config.get("agent_profile_installation_id"),
                "install_digest": agent_config.get("agent_profile_install_digest"),
                "composition_lock_digest": agent_config.get("agent_profile_composition_lock_digest"),
                "composition_digest": composition.digest,
            },
            "packs": [
                {
                    "pack_version_id": pack["id"],
                    "pack_id": pack["pack_id"],
                    "version": pack["version"],
                    "digest": pack["digest"],
                    "loaded_content_digest": loaded.digest,
                    "source_revision": loaded.source_revision,
                    "trust_level": loaded.trust_level,
                }
                for pack, loaded in zip(packs, loaded_packs, strict=True)
            ],
            "capabilities": [
                {
                    "capability_version_id": capability.version_id,
                    "capability_id": capability.manifest.id,
                    "kind": capability.manifest.kind,
                    "role": binding.role,
                    "version": capability.manifest.version,
                    "digest": capability.content_digest,
                    "artifact_digest": capability.artifact_digest,
                    "installation_id": capability.installation_id,
                    "install_digest": capability.install_digest,
                    "load_state": "process-loaded",
                    "external_dependencies": [
                        {"id": item["id"], "contract": item["contract"]}
                        for item in capability.manifest.external_dependencies
                    ],
                    "tool_names": [item.name for item in capability.tools.definitions()],
                    "prompt_ids": [item.id for item in capability.prompts],
                    "skill_ids": [item.id for item in capability.skills],
                    "prompt_delivery": [
                        {
                            "id": item.id,
                            "content_digest": capability_prompt_digest(item),
                        }
                        for item in capability.prompts
                    ],
                    "skill_delivery": [
                        {
                            "id": item.id,
                            "content_digest": capability_skill_digest(item),
                            "fallback": item.is_fallback,
                            "references": [
                                {
                                    "id": reference.id,
                                    "content_digest": capability_reference_digest(reference),
                                }
                                for reference in item.references
                            ],
                        }
                        for item in capability.skills
                    ],
                }
                for binding, capability in zip(capability_bindings, loaded_capabilities, strict=True)
            ],
            "capability_tool_owners": {
                name: capability_tool_owners[name]
                for name in sorted(capability_tool_owners)
                if name in selected_tools.names()
            },
            "connectors": list(connector_resolution.provenance),
            "published_tool_schema_digest": frozen_tool_schema_digest,
            "tool_schema_digest": effective_tool_schema_digest,
            "effective_tool_schema_digest": effective_tool_schema_digest,
            "tool_delivery": tool_schema,
            "skill_delivery": selected_skills.delivery_manifest(),
            "model": {
                "provider_id": row["provider_id"],
                "model_id": row["model_id"],
                "max_input_length": row["max_input_length"],
                "max_output_tokens": row["max_output_tokens"],
                "temperature": row["temperature"],
                "reasoning_effort": row["reasoning_effort"] or DEFAULT_MODEL_REASONING_EFFORT,
                "reasoning_effort_source": (
                    "profile" if row["reasoning_effort"] else "runtime_default"
                ),
                "timeout_seconds": row["timeout_seconds"],
                "capabilities": model_capability_flags,
                "probe_readiness": model_readiness["status"],
                "capability_observed": {
                    name: bool(model_capabilities_ready and model_capability_flags.get(name))
                    for name in ("tool_calling", "vision", "structured_output")
                },
                "routing": json.loads(row["routing_json"]),
            },
            "policies": {
                "runtime": effective_runtime_policy,
                "context": effective_context_policy,
                "channel": json.loads(row["channel_policy_json"] or "{}"),
                "review": json.loads(row["review_policy_json"] or "{}"),
                "presentation": json.loads(row["presentation_policy_json"] or "{}"),
                "tools": {
                    "mode": "optional_connector_catalog",
                    "configured_allowlist": list(allowlist),
                    "allowlist": list(effective_allowlist),
                    "unavailable_connector_tools": sorted(unavailable_connector_tools),
                },
            },
            "version_transition": {
                "from": previous["agent_version_id"] if previous else None,
                "to": row["agent_version_id"],
                "changed": bool(previous and previous["agent_version_id"] != row["agent_version_id"]),
            },
            "pinned": bool(row["pinned_agent_version_id"]),
            "version_override": bool(agent_version_id),
        }
        configuration_error = None
        try:
            model_config = self.models.resolve_model_config(row["model_profile_version_id"])
        except (KeyError, ValueError, OSError):
            configuration_error = "model_configuration_unavailable"
            model_config = ModelConfig(
                provider=row["protocol"],
                model=row["model_id"],
                timeout_seconds=row["timeout_seconds"],
                temperature=row["temperature"],
                max_output_tokens=row["max_output_tokens"],
                reasoning_effort=row["reasoning_effort"] or DEFAULT_MODEL_REASONING_EFFORT,
            )
        snapshot["model"]["retry_policy"] = {
            "transport_max_retries": model_config.transport_max_retries,
            "protocol_max_retries": model_config.protocol_max_retries,
            "backoff_base_seconds": model_config.transport_backoff_base_seconds,
            "backoff_cap_seconds": model_config.transport_backoff_cap_seconds,
            "protocol_temperature_step": model_config.protocol_temperature_step,
            "temperature_baseline": model_config.temperature,
        }
        return ResolvedRuntime(
            snapshot=snapshot,
            model_config=model_config,
            harness_config=harness_config,
            system_prompt=system_prompt,
            persona_prompt=render_persona_instruction(frozen_persona),
            skills=selected_skills,
            tools=selected_tools,
            configuration_error=configuration_error,
        )


class RuntimeHarness:
    def __init__(
        self,
        repository: Repository,
        resolver: RuntimeResolver,
        actions: ActionService | None = None,
        artifacts: ArtifactStore | None = None,
        connector_catalogs: ToolProviderRegistry | None = None,
    ) -> None:
        self.repository = repository
        self.resolver = resolver
        self.actions = actions
        self.artifacts = artifacts
        self.connector_catalogs = connector_catalogs
        self._locks: dict[str, asyncio.Lock] = {}
        self._heavy_media_semaphores: dict[str, asyncio.Semaphore] = {}

    async def run(self, case_id: str, trigger_message_id: str) -> RunResult:
        lock = self._locks.setdefault(case_id, asyncio.Lock())
        async with lock:
            lease: ConnectorRunLease | None = None
            if self.connector_catalogs is None:
                resolved = self.resolver.resolve(case_id)
            else:
                resolved, lease = await self.connector_catalogs.prepare_run(
                    case_id,
                    lambda: self.resolver.resolve(case_id),
                )
            try:
                model = self._build_model(resolved)
                heavy_media = self._heavy_media_semaphores.setdefault(
                    str(resolved.snapshot["agent_id"]), asyncio.Semaphore(1)
                )
                harness = DiagnosticHarness(
                    self.repository,
                    model,
                    resolved.model_config,
                    resolved.harness_config,
                    resolved.skills,
                    resolved.tools,
                    self.actions,
                    system_prompt=resolved.system_prompt,
                    persona_prompt=resolved.persona_prompt,
                    runtime_snapshot=resolved.snapshot,
                    heavy_media_semaphore=heavy_media,
                    artifacts=self.artifacts,
                )
                try:
                    return await harness._run_locked(case_id, trigger_message_id)
                finally:
                    close = getattr(model, "close", None)
                    if close:
                        await close()
            finally:
                if lease is not None:
                    await self.connector_catalogs.release_run(lease)

    def _build_context(self, case_id: str, trigger_message_id: str | None = None) -> dict[str, Any]:
        resolved = self.resolver.resolve(case_id)
        heavy_media = self._heavy_media_semaphores.setdefault(
            str(resolved.snapshot["agent_id"]), asyncio.Semaphore(1)
        )
        harness = DiagnosticHarness(
            self.repository,
            UnavailableModelProvider("context_only"),
            resolved.model_config,
            resolved.harness_config,
            resolved.skills,
            resolved.tools,
            self.actions,
            system_prompt=resolved.system_prompt,
            persona_prompt=resolved.persona_prompt,
            runtime_snapshot=resolved.snapshot,
            heavy_media_semaphore=heavy_media,
            artifacts=self.artifacts,
        )
        return harness._build_context(case_id, trigger_message_id)

    @staticmethod
    def _build_model(resolved: ResolvedRuntime) -> ModelProvider:
        if resolved.configuration_error:
            return UnavailableModelProvider(resolved.configuration_error)
        try:
            return build_model(resolved.model_config)
        except (KeyError, ValueError):
            return UnavailableModelProvider("model_configuration_unavailable")
