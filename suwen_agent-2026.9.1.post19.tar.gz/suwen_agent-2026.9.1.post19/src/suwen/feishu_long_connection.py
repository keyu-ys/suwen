from __future__ import annotations

import asyncio
import logging
import threading
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

import httpx
import lark_oapi as lark
import lark_oapi.ws.client as lark_ws

from .channel_registry import ChannelRegistry, ChannelResolutionError
from .channels import FeishuRuntimeConfig

logger = logging.getLogger(__name__)

FEISHU_WS_HEALTH_CHECK_SECONDS = 30
FEISHU_WS_RECV_TIMEOUT_SECONDS = 240
FEISHU_EVENT_ACK_TIMEOUT_SECONDS = 2.5
FEISHU_PENDING_DRAIN_SECONDS = 10

InboundCallback = Callable[[str, dict[str, Any]], Awaitable[dict[str, Any]]]


class _EventLoopProxy:
    """Resolve the Feishu SDK module-level loop inside its worker thread."""

    def __getattr__(self, name: str) -> Any:
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.get_event_loop()
        return getattr(loop, name)


# lark-oapi keeps a module-level loop. A proxy lets each managed connection use
# the loop belonging to its own worker thread instead of the import-time loop.
lark_ws.loop = _EventLoopProxy()


@dataclass(frozen=True)
class FeishuCredentialProbeResult:
    status: str
    failure_class: str | None = None
    bot_open_id: str | None = None


class FeishuCredentialProbe:
    """Validate App credentials without reading or sending any message."""

    def __init__(self, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.transport = transport

    async def probe(self, config: FeishuRuntimeConfig) -> FeishuCredentialProbeResult:
        try:
            async with httpx.AsyncClient(
                base_url=config.api_base_url.rstrip("/"),
                timeout=15,
                transport=self.transport,
            ) as client:
                response = await client.post(
                    "/auth/v3/tenant_access_token/internal/",
                    json={"app_id": config.app_id, "app_secret": config.app_secret},
                )
                response.raise_for_status()
                body = response.json()
                token = body.get("tenant_access_token")
                if body.get("code") != 0 or not isinstance(token, str) or not token:
                    return FeishuCredentialProbeResult("failed", "feishu_credentials_rejected")
                bot_open_id = None
                info = await client.get(
                    "/bot/v3/info",
                    headers={"Authorization": f"Bearer {token}"},
                )
                if info.status_code < 400:
                    info_body = info.json()
                    observed = (info_body.get("bot") or {}).get("open_id")
                    if info_body.get("code") == 0 and isinstance(observed, str) and observed:
                        bot_open_id = observed
                return FeishuCredentialProbeResult("passed", bot_open_id=bot_open_id)
        except (httpx.HTTPError, ValueError, TypeError):
            return FeishuCredentialProbeResult("failed", "feishu_connectivity_failed")


def _attr(value: Any, name: str, default: Any = "") -> Any:
    observed = getattr(value, name, default) if value is not None else default
    return default if observed is None else observed


def feishu_event_payload(data: Any) -> dict[str, Any]:
    """Convert the official SDK event object into the core adapter contract."""

    header = _attr(data, "header", None)
    event = _attr(data, "event", None)
    sender = _attr(event, "sender", None)
    sender_id = _attr(sender, "sender_id", None)
    message = _attr(event, "message", None)
    mentions = []
    for mention in _attr(message, "mentions", []) or []:
        mention_id = _attr(mention, "id", None)
        mentions.append(
            {
                "key": str(_attr(mention, "key")),
                "name": str(_attr(mention, "name")),
                "id": {
                    "open_id": str(_attr(mention_id, "open_id")),
                    "user_id": str(_attr(mention_id, "user_id")),
                    "union_id": str(_attr(mention_id, "union_id")),
                },
            }
        )
    return {
        "schema": "2.0",
        "header": {
            "event_id": str(_attr(header, "event_id")),
            "event_type": str(_attr(header, "event_type")),
            "create_time": str(_attr(header, "create_time")),
            "tenant_key": str(_attr(header, "tenant_key")),
            "app_id": str(_attr(header, "app_id")),
        },
        "event": {
            "sender": {
                "sender_id": {
                    "open_id": str(_attr(sender_id, "open_id")),
                    "user_id": str(_attr(sender_id, "user_id")),
                    "union_id": str(_attr(sender_id, "union_id")),
                },
                "sender_type": str(_attr(sender, "sender_type")),
                "tenant_key": str(_attr(sender, "tenant_key")),
            },
            "message": {
                "message_id": str(_attr(message, "message_id")),
                "root_id": str(_attr(message, "root_id")),
                "parent_id": str(_attr(message, "parent_id")),
                "thread_id": str(_attr(message, "thread_id")),
                "create_time": str(_attr(message, "create_time")),
                "chat_id": str(_attr(message, "chat_id")),
                "chat_type": str(_attr(message, "chat_type", "p2p")),
                "message_type": str(_attr(message, "message_type", "text")),
                "content": _attr(message, "content"),
                "mentions": mentions,
            },
        },
    }


class _ManagedFeishuConnection:
    def __init__(
        self,
        config: FeishuRuntimeConfig,
        main_loop: asyncio.AbstractEventLoop,
        callback: InboundCallback,
        registry: ChannelRegistry,
    ) -> None:
        self.config = config
        self.main_loop = main_loop
        self.callback = callback
        self.registry = registry
        self.thread: threading.Thread | None = None
        self.ws_loop: asyncio.AbstractEventLoop | None = None
        self.client: Any = None
        self.stopping = threading.Event()
        self.last_ws_receive_at = 0.0
        self._pending_callbacks: set[Any] = set()
        self._pending_lock = threading.Lock()

    @property
    def identity(self) -> str:
        # Access scope and reply policy are read from the registry for every
        # inbound event. Only transport identity changes require a socket restart.
        return self.config.transport_identity

    @property
    def alive(self) -> bool:
        return bool(self.thread and self.thread.is_alive())

    @property
    def pending_callback_count(self) -> int:
        with self._pending_lock:
            return len(self._pending_callbacks)

    def start(self) -> None:
        if self.alive:
            return
        self.thread = threading.Thread(
            target=self._run,
            name=f"trace-feishu-{self.config.instance_id}",
            daemon=True,
        )
        self.thread.start()

    def _on_message(self, data: Any) -> None:
        if self.stopping.is_set():
            # Returning normally tells the SDK to acknowledge the event.  Once
            # shutdown starts, fail the callback so Feishu retains responsibility
            # for redelivery instead of creating a handoff loss window.
            raise RuntimeError("feishu connection is draining")
        payload = feishu_event_payload(data)
        future = asyncio.run_coroutine_threadsafe(
            self.callback(self.config.instance_id, payload),
            self.main_loop,
        )
        with self._pending_lock:
            self._pending_callbacks.add(future)

        def release(result: Any) -> None:
            with self._pending_lock:
                self._pending_callbacks.discard(result)

        future.add_done_callback(release)
        # The SDK writes a success response as soon as this synchronous handler
        # returns.  Wait only for the Runtime's durable-envelope transaction;
        # slow media/OCR/model work has already moved to a recoverable Job.
        future.result(timeout=FEISHU_EVENT_ACK_TIMEOUT_SECONDS)

    def _run(self) -> None:
        self.ws_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.ws_loop)
        self.registry.record_runtime_health(self.config.instance_id, "connecting")
        try:
            event_handler = (
                lark.EventDispatcherHandler.builder(
                    self.config.encrypt_key,
                    self.config.verification_token,
                )
                .register_p2_im_message_receive_v1(self._on_message)
                .register_p2_im_message_reaction_created_v1(lambda _event: None)
                .register_p2_im_message_reaction_deleted_v1(lambda _event: None)
                .build()
            )
            self.client = lark.ws.Client(
                self.config.app_id,
                self.config.app_secret,
                event_handler=event_handler,
                log_level=lark.LogLevel.WARNING,
                domain=(lark.LARK_DOMAIN if self.config.domain == "lark" else lark.FEISHU_DOMAIN),
                auto_reconnect=False,
            )
            original_connect = self.client._connect
            original_handle_message = self.client._handle_message

            async def observed_connect() -> None:
                await original_connect()
                self.last_ws_receive_at = time.monotonic()
                self.registry.record_runtime_health(self.config.instance_id, "connected")

            async def observed_handle_message(message: bytes) -> None:
                self.last_ws_receive_at = time.monotonic()
                await original_handle_message(message)

            self.client._connect = observed_connect
            self.client._handle_message = observed_handle_message
            self.ws_loop.create_task(
                self._monitor_connection_health(),
                name=f"trace-feishu-health-{self.config.instance_id}",
            )
            self.client.start()
        except Exception as exc:
            if not self.stopping.is_set():
                logger.warning(
                    "飞书长连接退出 instance=%s class=%s",
                    self.config.instance_id,
                    type(exc).__name__,
                )
                self.registry.record_runtime_health(
                    self.config.instance_id,
                    "disconnected",
                    "feishu_long_connection_failed",
                )
        finally:
            if self.ws_loop and not self.ws_loop.is_closed():
                pending = [task for task in asyncio.all_tasks(self.ws_loop) if not task.done()]
                for task in pending:
                    task.cancel()
                if pending:
                    self.ws_loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
                self.ws_loop.close()
            self.ws_loop = None

    def _connection_failure(self, now: float | None = None) -> str | None:
        client = self.client
        if client is None:
            return None
        if getattr(client, "_conn", None) is None:
            return "feishu_long_connection_lost"
        observed_at = self.last_ws_receive_at
        observed_now = time.monotonic() if now is None else now
        if observed_at and observed_now - observed_at > FEISHU_WS_RECV_TIMEOUT_SECONDS:
            return "feishu_long_connection_silent"
        return None

    async def _monitor_connection_health(self) -> None:
        while not self.stopping.is_set():
            await asyncio.sleep(FEISHU_WS_HEALTH_CHECK_SECONDS)
            if self.stopping.is_set():
                return
            failure = self._connection_failure()
            if failure is None:
                continue
            self.registry.record_runtime_health(
                self.config.instance_id,
                "reconnecting",
                failure,
            )
            client = self.client
            if client is not None:
                try:
                    await client._disconnect()
                except Exception:
                    logger.debug(
                        "飞书长连接健康检查断开失败 instance=%s",
                        self.config.instance_id,
                        exc_info=True,
                    )
            loop = self.ws_loop
            if loop and not loop.is_closed():
                loop.stop()
            return

    async def stop(self) -> None:
        self.stopping.set()
        loop = self.ws_loop
        client = self.client
        if loop and not loop.is_closed():

            async def disconnect() -> None:
                if client is not None:
                    try:
                        await client._disconnect()
                    except Exception:
                        pass
                loop.stop()

            loop.call_soon_threadsafe(lambda: asyncio.create_task(disconnect()))
        if self.thread:
            await asyncio.to_thread(self.thread.join, 5)
            if self.thread.is_alive():
                raise RuntimeError("feishu connection thread did not stop")
        await self.wait_for_pending_callbacks()
        self.registry.record_runtime_health(self.config.instance_id, "stopped")

    async def wait_for_pending_callbacks(self) -> None:
        with self._pending_lock:
            pending = tuple(self._pending_callbacks)
        if not pending:
            return
        await asyncio.wait_for(
            asyncio.gather(
                *(asyncio.wrap_future(item) for item in pending),
                return_exceptions=True,
            ),
            timeout=FEISHU_PENDING_DRAIN_SECONDS,
        )


class FeishuLongConnectionSupervisor:
    """Keep active managed Feishu long connections aligned with the registry."""

    def __init__(self, registry: ChannelRegistry, callback: InboundCallback) -> None:
        self.registry = registry
        self.callback = callback
        self.connections: dict[str, _ManagedFeishuConnection] = {}
        self.task: asyncio.Task[None] | None = None
        self.stopping = asyncio.Event()
        self._reconcile_lock = asyncio.Lock()

    def start(self) -> None:
        if self.task and not self.task.done():
            return
        self.stopping.clear()
        self.task = asyncio.create_task(self._run(), name="feishu-long-connection-supervisor")

    async def stop(self) -> None:
        self.stopping.set()
        if self.task:
            await self.task
        results = await asyncio.gather(
            *(connection.stop() for connection in list(self.connections.values())),
            return_exceptions=True,
        )
        self.connections.clear()
        failures = [result for result in results if isinstance(result, BaseException)]
        if failures:
            raise RuntimeError(f"feishu connection drain failed: {type(failures[0]).__name__}") from failures[
                0
            ]

    @property
    def pending_callback_count(self) -> int:
        return sum(item.pending_callback_count for item in self.connections.values())

    async def reconcile(self) -> None:
        async with self._reconcile_lock:
            await self._reconcile_locked()

    async def _reconcile_locked(self) -> None:
        if self.registry.runtime_mode == "development":
            for instance_id, connection in list(self.connections.items()):
                await connection.stop()
                self.connections.pop(instance_id, None)
            return
        desired: dict[str, FeishuRuntimeConfig] = {}
        for item in self.registry.list_instances():
            if (
                item["channel_type"] != "feishu"
                or item["status"] != "active"
                or item["config"].get("mode") != "long_connection"
            ):
                continue
            try:
                desired[item["id"]] = self.registry.resolve_feishu_runtime(item["id"])
            except ChannelResolutionError:
                self.registry.record_runtime_health(
                    item["id"],
                    "misconfigured",
                    "feishu_runtime_resolution_failed",
                )

        for instance_id, connection in list(self.connections.items()):
            runtime = desired.get(instance_id)
            if runtime is None or connection.identity != runtime.transport_identity:
                await connection.stop()
                self.connections.pop(instance_id, None)

        loop = asyncio.get_running_loop()
        for instance_id, runtime in desired.items():
            connection = self.connections.get(instance_id)
            if connection and connection.alive:
                continue
            if connection:
                await connection.stop()
            connection = _ManagedFeishuConnection(runtime, loop, self.callback, self.registry)
            self.connections[instance_id] = connection
            connection.start()

    async def _run(self) -> None:
        while not self.stopping.is_set():
            await self.reconcile()
            try:
                await asyncio.wait_for(self.stopping.wait(), timeout=3)
            except TimeoutError:
                pass
