from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from datetime import UTC, datetime
from typing import Any

from .context.assembly import canonical_digest
from .db import (
    SUWEN_AGENT_ID,
    Database,
)
from .personas import normalize_persona_snapshot, persona_snapshot
from .security import redact_sensitive
from .types import Disposition, EvidenceEnvelope, Lifecycle, ReviewStatus


def utc_now() -> datetime:
    return datetime.now(UTC)


def iso(value: datetime | None = None) -> str:
    return (value or utc_now()).astimezone(UTC).isoformat()


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


def as_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row else None


class Repository:
    def __init__(self, database: Database):
        self.database = database

    def create_case(
        self,
        title: str = "新问诊",
        now: datetime | None = None,
        agent_id: str | None = None,
    ) -> dict[str, Any]:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            case = self._create_case(connection, title, now, agent_id)
            connection.commit()
        return case

    def _create_case(
        self,
        connection: sqlite3.Connection,
        title: str = "新问诊",
        now: datetime | None = None,
        agent_id: str | None = None,
    ) -> dict[str, Any]:
        case_id = new_id("case")
        at = iso(now)
        if agent_id is None:
            setting = connection.execute(
                "SELECT value_json FROM system_settings WHERE key='default_agent_id'"
            ).fetchone()
            agent_id = json.loads(setting["value_json"]) if setting else SUWEN_AGENT_ID
        agent = connection.execute("SELECT id, status FROM agents WHERE id=?", (agent_id,)).fetchone()
        if not agent:
            raise KeyError(agent_id)
        if agent["status"] != "published":
            raise ValueError("case requires a published Agent")
        persona_binding = connection.execute(
            """SELECT persona_id, revision FROM agent_persona_bindings
               WHERE agent_id=?""",
            (agent_id,),
        ).fetchone()
        if not persona_binding:
            raise RuntimeError("case Agent Persona binding is unavailable")
        frozen_persona = persona_snapshot(
            str(persona_binding["persona_id"]),
            int(persona_binding["revision"]),
        )
        connection.execute(
            """INSERT INTO cases(
                id, agent_id, title, lifecycle, disposition, created_at,
                updated_at, last_external_at, persona_snapshot_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                case_id,
                agent_id,
                title,
                Lifecycle.OPEN,
                Disposition.UNKNOWN,
                at,
                at,
                at,
                json.dumps(frozen_persona, ensure_ascii=False, sort_keys=True),
            ),
        )
        self._event(
            connection,
            case_id,
            None,
            "case.created",
            {
                "title": title,
                "agent_id": agent_id,
                "persona_id": frozen_persona["id"],
                "persona_digest": frozen_persona["digest"],
                "persona_binding_revision": frozen_persona["binding_revision"],
            },
            at,
        )
        return self._get_case(connection, case_id)

    def get_case(self, case_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            return self._get_case(connection, case_id)

    def agent_status(self, agent_id: str) -> str:
        with self.database.connect() as connection:
            row = connection.execute("SELECT status FROM agents WHERE id=?", (agent_id,)).fetchone()
        if not row:
            raise KeyError(agent_id)
        return row["status"]

    def review_enabled_for_agent_version(self, agent_version_id: str) -> bool:
        return self.policies_for_agent_version(agent_version_id)["review"].get("enabled", True) is not False

    def policies_for_agent_version(self, agent_version_id: str) -> dict[str, dict[str, Any]]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT channel_policy_json, review_policy_json,
                          presentation_policy_json
                   FROM agent_versions WHERE id=?""",
                (agent_version_id,),
            ).fetchone()
        if not row:
            raise KeyError(agent_version_id)
        return {
            "channel": json.loads(row["channel_policy_json"] or "{}"),
            "review": json.loads(row["review_policy_json"] or "{}"),
            "presentation": json.loads(row["presentation_policy_json"] or "{}"),
        }

    def agent_version_for_run(self, run_id: str) -> str:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT agent_version_id FROM runs WHERE id=?",
                (run_id,),
            ).fetchone()
        if not row:
            raise KeyError(run_id)
        return str(row["agent_version_id"])

    def agent_version_for_case(self, case_id: str) -> str:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT COALESCE(c.pinned_agent_version_id, a.active_version_id) AS version_id
                   FROM cases c JOIN agents a ON a.id=c.agent_id WHERE c.id=?""",
                (case_id,),
            ).fetchone()
        if not row or not row["version_id"]:
            raise KeyError(case_id)
        return str(row["version_id"])

    @staticmethod
    def _get_case(connection: sqlite3.Connection, case_id: str) -> dict[str, Any]:
        row = connection.execute("SELECT * FROM cases WHERE id=?", (case_id,)).fetchone()
        if not row:
            raise KeyError(case_id)
        item = dict(row)
        item["persona"] = normalize_persona_snapshot(item.pop("persona_snapshot_json"))
        return item

    def list_cases(self, limit: int = 100) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM cases ORDER BY updated_at DESC LIMIT ?", (limit,)
            ).fetchall()
        items = []
        for row in rows:
            item = dict(row)
            item["persona"] = normalize_persona_snapshot(item.pop("persona_snapshot_json"))
            items.append(item)
        return items

    def update_case_disposition(self, case_id: str, disposition: str) -> None:
        if disposition not in {item.value for item in Disposition}:
            raise ValueError("invalid disposition")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                "UPDATE cases SET disposition=?, updated_at=? WHERE id=?",
                (disposition, at, case_id),
            )
            self._event(connection, case_id, None, "case.disposition_changed", {"to": disposition}, at)
            connection.commit()

    def close_case(
        self,
        case_id: str,
        reason: str,
        now: datetime | None = None,
        expected_last_external: str | None = None,
    ) -> bool:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            changed = self._close_case(
                connection, case_id, reason, now, expected_last_external=expected_last_external
            )
            connection.commit()
        return changed

    def _close_case(
        self,
        connection: sqlite3.Connection,
        case_id: str,
        reason: str,
        now: datetime | None = None,
        expected_last_external: str | None = None,
    ) -> bool:
        at = iso(now)
        query = """UPDATE cases SET lifecycle='closed', close_reason=?, closed_at=?, updated_at=?
                   WHERE id=? AND lifecycle='open'"""
        params: list[Any] = [reason, at, at, case_id]
        if expected_last_external is not None:
            query += " AND last_external_at=?"
            params.append(expected_last_external)
        changed = connection.execute(query, params).rowcount == 1
        if changed:
            self._event(connection, case_id, None, "case.closed", {"reason": reason}, at)
        return changed

    def reopen_case(self, case_id: str, reason: str, now: datetime | None = None) -> bool:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            changed = self._reopen_case(connection, case_id, reason, now)
            connection.commit()
        return changed

    def _reopen_case(
        self,
        connection: sqlite3.Connection,
        case_id: str,
        reason: str,
        now: datetime | None = None,
    ) -> bool:
        at = iso(now)
        changed = (
            connection.execute(
                """UPDATE cases SET lifecycle='open', close_reason=NULL, closed_at=NULL,
                   reopened_count=reopened_count+1, updated_at=? WHERE id=? AND lifecycle='closed'""",
                (at, case_id),
            ).rowcount
            == 1
        )
        if changed:
            self._event(connection, case_id, None, "case.reopened", {"reason": reason}, at)
        return changed

    def find_binding(
        self,
        channel: str,
        channel_instance: str,
        scope_kind: str,
        scope_ref: str,
        actor_ref: str,
        agent_id: str = SUWEN_AGENT_ID,
    ) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            return self._find_binding(
                connection,
                channel,
                channel_instance,
                scope_kind,
                scope_ref,
                actor_ref,
                agent_id,
            )

    @staticmethod
    def _find_binding(
        connection: sqlite3.Connection,
        channel: str,
        channel_instance: str,
        scope_kind: str,
        scope_ref: str,
        actor_ref: str,
        agent_id: str = SUWEN_AGENT_ID,
    ) -> dict[str, Any] | None:
        row = connection.execute(
            """SELECT * FROM channel_bindings WHERE channel=? AND channel_instance=?
               AND scope_kind=? AND scope_ref=? AND actor_ref=? AND agent_id=? AND active=1""",
            (channel, channel_instance, scope_kind, scope_ref, actor_ref, agent_id),
        ).fetchone()
        return as_dict(row)

    def bind_case(
        self,
        case_id: str,
        channel: str,
        channel_instance: str,
        scope_kind: str,
        scope_ref: str,
        actor_ref: str,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            binding = self._bind_case(
                connection,
                case_id,
                channel,
                channel_instance,
                scope_kind,
                scope_ref,
                actor_ref,
                now,
            )
            connection.commit()
        return binding

    def _bind_case(
        self,
        connection: sqlite3.Connection,
        case_id: str,
        channel: str,
        channel_instance: str,
        scope_kind: str,
        scope_ref: str,
        actor_ref: str,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        binding_id = new_id("binding")
        at = iso(now)
        case = self._get_case(connection, case_id)
        connection.execute(
            """UPDATE channel_bindings SET active=0, updated_at=? WHERE channel=?
               AND channel_instance=? AND scope_kind=? AND scope_ref=? AND actor_ref=? AND active=1""",
            (at, channel, channel_instance, scope_kind, scope_ref, actor_ref),
        )
        connection.execute(
            """INSERT INTO channel_bindings(
               id, agent_id, channel, channel_instance, scope_kind, scope_ref,
               actor_ref, case_id, active, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)""",
            (
                binding_id,
                case["agent_id"],
                channel,
                channel_instance,
                scope_kind,
                scope_ref,
                actor_ref,
                case_id,
                at,
                at,
            ),
        )
        self._event(
            connection,
            case_id,
            None,
            "channel.bound",
            {"channel": channel, "scope_kind": scope_kind},
            at,
        )
        return (
            self._find_binding(
                connection,
                channel,
                channel_instance,
                scope_kind,
                scope_ref,
                actor_ref,
                case["agent_id"],
            )
            or {}
        )

    def _deactivate_binding(
        self,
        connection: sqlite3.Connection,
        binding_id: str,
        reason: str,
        now: datetime | None = None,
    ) -> bool:
        row = connection.execute(
            "SELECT case_id FROM channel_bindings WHERE id=? AND active=1",
            (binding_id,),
        ).fetchone()
        if not row:
            return False
        at = iso(now)
        changed = (
            connection.execute(
                "UPDATE channel_bindings SET active=0, updated_at=? WHERE id=? AND active=1",
                (at, binding_id),
            ).rowcount
            == 1
        )
        if changed:
            self._event(
                connection,
                row["case_id"],
                None,
                "channel.unbound",
                {"binding_id": binding_id, "reason": reason},
                at,
            )
        return changed

    def claim_inbound_event(self, event_id: str, channel: str, now: datetime | None = None) -> bool:
        with self.database.connect() as connection:
            return self._claim_inbound_event(connection, event_id, channel, now)

    @staticmethod
    def _claim_inbound_event(
        connection: sqlite3.Connection,
        event_id: str,
        channel: str,
        now: datetime | None = None,
    ) -> bool:
        try:
            connection.execute(
                "INSERT INTO inbound_events(event_id, channel, received_at, state) VALUES(?,?,?,?)",
                (event_id, channel, iso(now), "received"),
            )
            return True
        except sqlite3.IntegrityError:
            return False

    def link_inbound_event(self, event_id: str, case_id: str, state: str = "processed") -> None:
        with self.database.connect() as connection:
            self._link_inbound_event(connection, event_id, case_id, state)

    @staticmethod
    def _link_inbound_event(
        connection: sqlite3.Connection,
        event_id: str,
        case_id: str,
        state: str = "processed",
    ) -> None:
        connection.execute(
            "UPDATE inbound_events SET case_id=?, state=? WHERE event_id=?",
            (case_id, state, event_id),
        )

    def link_external_message(
        self,
        channel: str,
        channel_instance: str,
        message_ref: str,
        case_id: str,
        event_id: str | None,
        *,
        direction: str | None = None,
        message_kind: str | None = None,
        internal_message_id: str | None = None,
        run_id: str | None = None,
        created_outbox_id: str | None = None,
        last_outbox_id: str | None = None,
        card_id: str | None = None,
        parent_message_ref: str | None = None,
        root_message_ref: str | None = None,
        thread_ref: str | None = None,
        lifecycle_state: str | None = None,
        channel_revision: int | None = None,
    ) -> None:
        with self.database.connect() as connection:
            self._link_external_message(
                connection,
                channel,
                channel_instance,
                message_ref,
                case_id,
                event_id,
                direction=direction,
                message_kind=message_kind,
                internal_message_id=internal_message_id,
                run_id=run_id,
                created_outbox_id=created_outbox_id,
                last_outbox_id=last_outbox_id,
                card_id=card_id,
                parent_message_ref=parent_message_ref,
                root_message_ref=root_message_ref,
                thread_ref=thread_ref,
                lifecycle_state=lifecycle_state,
                channel_revision=channel_revision,
            )

    @staticmethod
    def _link_external_message(
        connection: sqlite3.Connection,
        channel: str,
        channel_instance: str,
        message_ref: str,
        case_id: str,
        event_id: str | None,
        *,
        direction: str | None = None,
        message_kind: str | None = None,
        internal_message_id: str | None = None,
        run_id: str | None = None,
        created_outbox_id: str | None = None,
        last_outbox_id: str | None = None,
        card_id: str | None = None,
        parent_message_ref: str | None = None,
        root_message_ref: str | None = None,
        thread_ref: str | None = None,
        lifecycle_state: str | None = None,
        channel_revision: int | None = None,
    ) -> None:
        existing = connection.execute(
            """SELECT case_id FROM external_messages
               WHERE channel=? AND channel_instance=? AND message_ref=?""",
            (channel, channel_instance, message_ref),
        ).fetchone()
        if existing and existing["case_id"] != case_id:
            raise ValueError("external message cannot be rebound to another Case")
        connection.execute(
            """INSERT OR IGNORE INTO external_messages(
               channel, channel_instance, message_ref, case_id, event_id
            ) VALUES (?, ?, ?, ?, ?)""",
            (channel, channel_instance, message_ref, case_id, event_id),
        )
        values: dict[str, Any] = {
            "event_id": event_id,
            "direction": direction,
            "message_kind": message_kind,
            "internal_message_id": internal_message_id,
            "run_id": run_id,
            "created_outbox_id": created_outbox_id,
            "last_outbox_id": last_outbox_id,
            "card_id": card_id,
            "parent_message_ref": parent_message_ref,
            "root_message_ref": root_message_ref,
            "thread_ref": thread_ref,
            "lifecycle_state": lifecycle_state,
            "channel_revision": channel_revision,
        }
        updates = [(key, value) for key, value in values.items() if value is not None]
        at = iso()
        assignments = [f"{key}=?" for key, _value in updates]
        assignments.extend(["linked_at=COALESCE(linked_at, ?)", "updated_at=?"])
        connection.execute(
            f"""UPDATE external_messages SET {", ".join(assignments)}
                WHERE channel=? AND channel_instance=? AND message_ref=?""",
            (
                *[value for _key, value in updates],
                at,
                at,
                channel,
                channel_instance,
                message_ref,
            ),
        )

    def external_message(
        self,
        channel: str,
        channel_instance: str,
        message_ref: str,
    ) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT * FROM external_messages WHERE channel=?
                   AND channel_instance=? AND message_ref=?""",
                (channel, channel_instance, message_ref),
            ).fetchone()
        return as_dict(row)

    def case_for_external_message(self, channel: str, channel_instance: str, message_ref: str) -> str | None:
        with self.database.connect() as connection:
            return self._case_for_external_message(connection, channel, channel_instance, message_ref)

    @staticmethod
    def _case_for_external_message(
        connection: sqlite3.Connection,
        channel: str,
        channel_instance: str,
        message_ref: str,
    ) -> str | None:
        row = Repository._external_message_context(
            connection,
            channel,
            channel_instance,
            message_ref,
        )
        return row["case_id"] if row else None

    @staticmethod
    def _external_message_context(
        connection: sqlite3.Connection,
        channel: str,
        channel_instance: str,
        message_ref: str,
    ) -> sqlite3.Row | None:
        return connection.execute(
            """SELECT case_id, direction, thread_ref FROM external_messages
               WHERE channel=? AND channel_instance=? AND message_ref=?""",
            (channel, channel_instance, message_ref),
        ).fetchone()

    def case_for_external_event(self, event_id: str) -> str | None:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT case_id FROM inbound_events WHERE event_id=? AND state='processed'",
                (event_id,),
            ).fetchone()
        return row["case_id"] if row and row["case_id"] else None

    def recover_interrupted_runs(self, *, reclassify_cancelled: bool = False) -> int:
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            rows = connection.execute(
                """SELECT id, case_id FROM runs WHERE status='running'
                   OR (?=1 AND status='interrupted'
                       AND stop_reason IN ('user_stop', 'process_shutdown'))""",
                (int(reclassify_cancelled),),
            ).fetchall()
            for row in rows:
                connection.execute(
                    """UPDATE runs SET status='interrupted', stop_reason='process_restart',
                       finished_at=? WHERE id=?""",
                    (at, row["id"]),
                )
                self._event(
                    connection,
                    row["case_id"],
                    row["id"],
                    "run.interrupted",
                    {"reason": "process_restart"},
                    at,
                )
            connection.execute(
                """UPDATE tool_calls SET status='interrupted', finished_at=?
                   WHERE status='running' AND run_id IN (
                       SELECT id FROM runs WHERE status='interrupted'
                   )""",
                (at,),
            )
            connection.commit()
        return len(rows)

    def recover_interrupted_actions(self) -> int:
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            rows = connection.execute(
                """SELECT id, case_id, prepared_run_id, action_type
                   FROM actions WHERE status='executing'"""
            ).fetchall()
            for row in rows:
                connection.execute(
                    """UPDATE actions SET status='outcome_unknown', finished_at=?,
                       result_json='{"reason":"process_restart"}' WHERE id=?""",
                    (at, row["id"]),
                )
                self._event(
                    connection,
                    row["case_id"],
                    row["prepared_run_id"],
                    "action.terminal",
                    {"action_id": row["id"], "status": "outcome_unknown"},
                    at,
                )
                connection.execute(
                    """INSERT INTO audit_events(
                       actor_type, actor_ref, action, target_type, target_id,
                       request_id, result, metadata_json, created_at
                    ) VALUES ('system', 'startup-recovery', 'action.terminal',
                              'controlled_action', ?, ?, 'outcome_unknown', ?, ?)""",
                    (
                        row["id"],
                        row["prepared_run_id"],
                        json.dumps(
                            {
                                "case_id": row["case_id"],
                                "action_type": row["action_type"],
                                "reason": "process_restart",
                            }
                        ),
                        at,
                    ),
                )
            connection.commit()
        return len(rows)

    def recover_incomplete_inbound_events(self) -> int:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            rows = connection.execute(
                """SELECT event_id FROM inbound_events
                   WHERE state IN ('received','materializing') AND case_id IS NULL"""
            ).fetchall()
            recovered = 0
            for row in rows:
                message = connection.execute(
                    "SELECT case_id FROM messages WHERE external_event_id=?", (row["event_id"],)
                ).fetchone()
                if message:
                    execution = connection.execute(
                        """SELECT status FROM jobs
                           WHERE kind='process_inbound'
                             AND json_extract(payload_json, '$.event_id')=?""",
                        (row["event_id"],),
                    ).fetchone()
                    connection.execute(
                        "UPDATE inbound_events SET case_id=?, state=? WHERE event_id=?",
                        (
                            message["case_id"],
                            "processed"
                            if execution and execution["status"] == "completed"
                            else "admitted",
                            row["event_id"],
                        ),
                    )
                    recovered += 1
                    continue
                preparation = connection.execute(
                    """SELECT status FROM jobs
                       WHERE kind='prepare_inbound' AND unique_key=?""",
                    (f"inbound-prepare:{row['event_id']}",),
                ).fetchone()
                if preparation and preparation["status"] != "completed":
                    recovered += 1
                    continue
                connection.execute(
                    "UPDATE inbound_events SET state='failed' WHERE event_id=?",
                    (row["event_id"],),
                )
            connection.commit()
        return recovered

    def accept_inbound_envelope(
        self,
        event_id: str,
        channel: str,
        agent_id: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Commit a recoverable Channel envelope before transport acknowledgement."""

        unique_key = f"inbound-prepare:{event_id}"
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            created = self._claim_inbound_event(connection, event_id, channel)
            if created:
                connection.execute(
                    "UPDATE inbound_events SET agent_id=? WHERE event_id=?",
                    (agent_id, event_id),
                )
                self._schedule_job(
                    connection,
                    "prepare_inbound",
                    unique_key,
                    payload,
                    utc_now(),
                    None,
                    agent_id=agent_id,
                )
            row = connection.execute(
                "SELECT * FROM inbound_events WHERE event_id=?",
                (event_id,),
            ).fetchone()
            job = connection.execute(
                "SELECT * FROM jobs WHERE unique_key=?",
                (unique_key,),
            ).fetchone()
            if not row:
                connection.rollback()
                raise RuntimeError("durable inbound envelope could not be read back")
            if row["channel"] != channel or (row["agent_id"] and row["agent_id"] != agent_id):
                connection.rollback()
                raise ValueError("inbound event identity conflicts with its durable envelope")
            if not job and not row["case_id"] and row["state"] in {"received", "materializing"}:
                self._schedule_job(
                    connection,
                    "prepare_inbound",
                    unique_key,
                    payload,
                    utc_now(),
                    None,
                    agent_id=agent_id,
                )
                job = connection.execute(
                    "SELECT * FROM jobs WHERE unique_key=?",
                    (unique_key,),
                ).fetchone()
            if not job:
                # Events completed by an older Runtime predate preparation Jobs.
                # Their immutable receipt is sufficient to acknowledge a retry.
                synthetic_job = {
                    "id": None,
                    "unique_key": unique_key,
                    "status": "completed",
                }
            else:
                synthetic_job = dict(job)
            connection.commit()
        return {"created": created, "event": dict(row), "job": synthetic_job}

    def inbound_event(self, event_id: str) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT * FROM inbound_events WHERE event_id=?",
                (event_id,),
            ).fetchone()
        return as_dict(row)

    def mark_inbound_materializing(self, event_id: str) -> None:
        with self.database.connect() as connection:
            connection.execute(
                """UPDATE inbound_events SET state='materializing'
                   WHERE event_id=? AND case_id IS NULL
                     AND state IN ('received','materializing')""",
                (event_id,),
            )

    def terminalize_inbound_preparation(
        self,
        job_id: str,
        event_id: str,
        reason: str,
    ) -> None:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """UPDATE jobs SET status='completed', lease_until=NULL, finished_at=?,
                   last_error=? WHERE id=? AND kind='prepare_inbound'""",
                (iso(), reason[:1000], job_id),
            )
            connection.execute(
                """UPDATE inbound_events SET state='rejected'
                   WHERE event_id=? AND case_id IS NULL""",
                (event_id,),
            )
            connection.commit()

    def complete_inbound_preparation(self, job_id: str, event_id: str) -> None:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """UPDATE jobs SET status='completed', lease_until=NULL, finished_at=?,
                   last_error=NULL WHERE id=? AND kind='prepare_inbound'""",
                (iso(), job_id),
            )
            connection.execute(
                """UPDATE inbound_events SET state='processed'
                   WHERE event_id=? AND case_id IS NULL
                     AND state IN ('received','materializing')""",
                (event_id,),
            )
            connection.commit()

    def add_message(
        self,
        case_id: str,
        role: str,
        content: str,
        actor_ref: str | None = None,
        external_event_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            message = self._add_message(
                connection,
                case_id,
                role,
                content,
                actor_ref=actor_ref,
                external_event_id=external_event_id,
                metadata=metadata,
                now=now,
            )
            connection.commit()
        return message

    def _add_message(
        self,
        connection: sqlite3.Connection,
        case_id: str,
        role: str,
        content: str,
        actor_ref: str | None = None,
        external_event_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        message_id = new_id("msg")
        at = iso(now)
        message_metadata = dict(metadata or {})
        if role == "assistant":
            message_metadata.setdefault("content_format", "text/markdown")
            message_metadata.setdefault("presentation_profile", "suwen-markdown.v1")
            message_metadata.setdefault(
                "content_sha256",
                hashlib.sha256(content.encode("utf-8")).hexdigest(),
            )
        seq = connection.execute(
            "SELECT COALESCE(MAX(seq), 0)+1 AS seq FROM messages WHERE case_id=?", (case_id,)
        ).fetchone()["seq"]
        connection.execute(
            """INSERT INTO messages(
               id, case_id, seq, role, actor_ref, content, external_event_id,
               created_at, metadata_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                message_id,
                case_id,
                seq,
                role,
                actor_ref,
                content,
                external_event_id,
                at,
                json.dumps(message_metadata, ensure_ascii=False),
            ),
        )
        if role == "user":
            connection.execute(
                "UPDATE cases SET updated_at=?, last_external_at=? WHERE id=?",
                (at, at, case_id),
            )
        else:
            connection.execute("UPDATE cases SET updated_at=? WHERE id=?", (at, case_id))
        self._event(
            connection,
            case_id,
            None,
            "message.created",
            {"message_id": message_id, "role": role, "seq": seq},
            at,
        )
        return self._get_message(connection, message_id)

    def get_message(self, message_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            return self._get_message(connection, message_id)

    def run_user_messages(self, run_id: str, limit: int = 4) -> list[dict[str, Any]]:
        """Return persisted user message rows visible to one Run trigger.

        Runtime convergence and repair instructions live only in the transient
        model projection and must never replace the user's diagnostic goal.
        Returning the complete immutable rows lets the Harness preserve reply
        context and OCR metadata instead of rebuilding terminal context from
        plain message text.
        """

        with self.database.connect() as connection:
            rows = connection.execute(
                """SELECT history.*
                   FROM runs r
                   JOIN messages trigger_message ON trigger_message.id=r.trigger_message_id
                   JOIN messages history ON history.case_id=r.case_id
                  WHERE r.id=? AND history.role='user'
                    AND history.seq<=trigger_message.seq
                  ORDER BY history.seq DESC LIMIT ?""",
                (run_id, max(1, int(limit))),
            ).fetchall()
        return [dict(row) for row in reversed(rows)]

    def run_user_context(self, run_id: str, limit: int = 4) -> list[str]:
        """Return the plain-text compatibility view of ``run_user_messages``."""

        return [str(row["content"]) for row in self.run_user_messages(run_id, limit)]

    def case_id_for_run(self, run_id: str) -> str:
        with self.database.connect() as connection:
            row = connection.execute("SELECT case_id FROM runs WHERE id=?", (run_id,)).fetchone()
        if not row:
            raise KeyError(run_id)
        return str(row["case_id"])

    @staticmethod
    def _get_message(connection: sqlite3.Connection, message_id: str) -> dict[str, Any]:
        row = connection.execute("SELECT * FROM messages WHERE id=?", (message_id,)).fetchone()
        if not row:
            raise KeyError(message_id)
        return dict(row)

    def list_messages(self, case_id: str, limit: int = 500) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM messages WHERE case_id=? ORDER BY seq LIMIT ?", (case_id, limit)
            ).fetchall()
        return [dict(row) for row in rows]

    def create_run(
        self,
        case_id: str,
        trigger_message_id: str,
        model_profile: dict[str, Any],
        context: dict[str, Any],
        runtime_snapshot: dict[str, Any] | None = None,
    ) -> str:
        run_id = new_id("run")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            query = """SELECT c.agent_id, c.persona_snapshot_json, a.active_version_id,
                          c.pinned_agent_version_id,
                          av.id AS resolved_agent_version_id,
                          binding.model_profile_id,
                          binding.revision AS model_binding_revision,
                          mpv.id AS model_profile_version_id,
                          av.tool_schema_digest AS frozen_tool_schema_digest,
                          mpv.provider_version_id,
                          pbv.digest AS prompt_bundle_digest
                   FROM cases c
                   JOIN agents a ON a.id=c.agent_id
                   JOIN agent_versions av
                     ON av.id=COALESCE(c.pinned_agent_version_id, a.active_version_id)
                   JOIN agent_model_bindings binding ON binding.agent_id=a.id
                   LEFT JOIN prompt_bundle_versions pbv
                     ON pbv.id=av.prompt_bundle_version_id
                   JOIN model_profile_versions mpv
                     ON mpv.id=(
                          SELECT current_model.id
                            FROM model_profile_versions current_model
                           WHERE current_model.model_profile_id=binding.model_profile_id
                           ORDER BY current_model.version DESC LIMIT 1
                        )
                   WHERE c.id=?"""
            params: tuple[Any, ...] = (case_id,)
            if runtime_snapshot is not None:
                query += " AND av.id=?"
                params += (runtime_snapshot["agent_version_id"],)
            provenance = connection.execute(query, params).fetchone()
            if not provenance:
                raise RuntimeError("case Agent runtime configuration is unavailable")
            pack_digests = [
                row["digest"]
                for row in connection.execute(
                    """SELECT cpv.digest
                       FROM agent_version_packs avp
                       JOIN capability_pack_versions cpv ON cpv.id=avp.pack_version_id
                       WHERE avp.agent_version_id=? AND avp.enabled=1
                       ORDER BY avp.position, cpv.id""",
                    (provenance["resolved_agent_version_id"],),
                ).fetchall()
            ]
            capability_rows = connection.execute(
                """SELECT avc.capability_version_id, avc.role, avc.position,
                          avc.installation_id, avc.artifact_digest,
                          cp.id AS capability_id, cpv.version, cpv.content_digest
                   FROM agent_version_capabilities avc
                   JOIN capability_package_versions cpv ON cpv.id=avc.capability_version_id
                   JOIN capability_packages cp ON cp.id=cpv.capability_id
                   WHERE avc.agent_version_id=? AND avc.enabled=1
                   ORDER BY avc.position, avc.capability_version_id""",
                (provenance["resolved_agent_version_id"],),
            ).fetchall()
            if runtime_snapshot is not None:
                expected = {
                    "agent_id": provenance["agent_id"],
                    "agent_version_id": provenance["resolved_agent_version_id"],
                    "model_profile_id": provenance["model_profile_id"],
                    "model_binding_revision": provenance["model_binding_revision"],
                    "model_profile_version_id": provenance["model_profile_version_id"],
                    "provider_version_id": provenance["provider_version_id"],
                }
                if any(runtime_snapshot.get(key) != value for key, value in expected.items()):
                    raise RuntimeError("resolved runtime snapshot does not match immutable configuration")
                frozen_persona = normalize_persona_snapshot(provenance["persona_snapshot_json"])
                if runtime_snapshot.get("persona") != frozen_persona:
                    raise RuntimeError("resolved Persona snapshot does not match Case")
                if (
                    provenance["frozen_tool_schema_digest"]
                    and runtime_snapshot.get("published_tool_schema_digest")
                    != provenance["frozen_tool_schema_digest"]
                ):
                    raise RuntimeError("resolved published Tool baseline does not match Agent")
                snapshot_capabilities = runtime_snapshot.get("capabilities", [])
                expected_capabilities = [
                    {
                        "capability_version_id": item["capability_version_id"],
                        "capability_id": item["capability_id"],
                        "role": item["role"],
                        "version": item["version"],
                        "digest": item["content_digest"],
                        "installation_id": item["installation_id"],
                        "artifact_digest": item["artifact_digest"],
                    }
                    for item in capability_rows
                ]
                observed_capabilities = [
                    {
                        "capability_version_id": item.get("capability_version_id"),
                        "capability_id": item.get("capability_id"),
                        "role": item.get("role"),
                        "version": item.get("version"),
                        "digest": item.get("digest"),
                        "installation_id": item.get("installation_id"),
                        "artifact_digest": item.get("artifact_digest"),
                    }
                    for item in snapshot_capabilities
                    if isinstance(item, dict)
                ]
                if observed_capabilities != expected_capabilities:
                    raise RuntimeError("resolved capability snapshot does not match immutable configuration")
            connection.execute(
                """INSERT INTO runs(
                   id, case_id, agent_version_id, model_profile_version_id,
                   provider_version_id, trigger_message_id, status,
                   model_profile_json, context_json, prompt_bundle_digest,
                   pack_digests_json, tool_schema_digest, context_layers_json,
                   context_chars, context_token_estimate, started_at
                ) VALUES (?, ?, ?, ?, ?, ?, 'running', ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    run_id,
                    case_id,
                    provenance["resolved_agent_version_id"],
                    provenance["model_profile_version_id"],
                    provenance["provider_version_id"],
                    trigger_message_id,
                    json.dumps(model_profile),
                    json.dumps(context, ensure_ascii=False),
                    provenance["prompt_bundle_digest"],
                    json.dumps(pack_digests),
                    runtime_snapshot.get("tool_schema_digest") if runtime_snapshot else None,
                    json.dumps(context.get("assembly", {}).get("layers", []), ensure_ascii=False),
                    int(context.get("assembly", {}).get("total_chars", 0)),
                    int(context.get("assembly", {}).get("token_estimate", 0)),
                    at,
                ),
            )
            if runtime_snapshot is not None:
                connection.executemany(
                    """INSERT INTO run_capabilities(
                       run_id, capability_version_id, role, content_digest, load_state,
                       tool_call_count, evidence_count, loaded_at,
                       installation_id, artifact_digest
                    ) VALUES (?, ?, ?, ?, 'process-loaded', 0, 0, ?, ?, ?)""",
                    [
                        (
                            run_id,
                            item["capability_version_id"],
                            item["role"],
                            item["content_digest"],
                            at,
                            item["installation_id"],
                            item["artifact_digest"],
                        )
                        for item in capability_rows
                    ],
                )
            self._event(
                connection,
                case_id,
                run_id,
                "run.started",
                {
                    "agent_version_id": provenance["resolved_agent_version_id"],
                    "persona_id": (
                        runtime_snapshot.get("persona", {}).get("id")
                        if runtime_snapshot is not None
                        else None
                    ),
                    "persona_digest": (
                        runtime_snapshot.get("persona", {}).get("digest")
                        if runtime_snapshot is not None
                        else None
                    ),
                },
                at,
            )
            connection.commit()
        return run_id

    def record_model_turn(
        self,
        run_id: str,
        turn_index: int,
        *,
        status: str,
        finish_reason: str | None,
        tool_request_count: int,
        request_chars: int,
        response_chars: int,
        latency_ms: int,
        usage: dict[str, int] | None,
        failure_class: str | None,
        started_at: str,
        finished_at: str,
        request: dict[str, Any] | None = None,
        response: dict[str, Any] | None = None,
        context_generation_id: str | None = None,
    ) -> dict[str, Any]:
        turn_id = new_id("modelturn")
        usage_state = "observed" if usage is not None else "not_observable"
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            run = connection.execute("SELECT id FROM runs WHERE id=?", (run_id,)).fetchone()
            if not run:
                raise KeyError(run_id)
            connection.execute(
                """INSERT INTO model_turns(
                   id, run_id, turn_index, status, finish_reason,
                   tool_request_count, request_chars, response_chars, latency_ms,
                   usage_state, usage_json, failure_class, started_at, finished_at,
                   request_json, response_json, context_generation_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    turn_id,
                    run_id,
                    turn_index,
                    status,
                    finish_reason,
                    max(0, tool_request_count),
                    max(0, request_chars),
                    max(0, response_chars),
                    max(0, latency_ms),
                    usage_state,
                    json.dumps(usage, sort_keys=True) if usage is not None else None,
                    failure_class,
                    started_at,
                    finished_at,
                    (
                        json.dumps(redact_sensitive(request), ensure_ascii=False)
                        if request is not None
                        else None
                    ),
                    (
                        json.dumps(redact_sensitive(response), ensure_ascii=False)
                        if response is not None
                        else None
                    ),
                    context_generation_id,
                ),
            )
            observed_rows = connection.execute(
                """SELECT usage_json FROM model_turns
                   WHERE run_id=? AND usage_state='observed' ORDER BY turn_index""",
                (run_id,),
            ).fetchall()
            if observed_rows:
                aggregate: dict[str, int] = {}
                for row in observed_rows:
                    for key, value in json.loads(row["usage_json"] or "{}").items():
                        if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
                            aggregate[key] = aggregate.get(key, 0) + value
                run_usage_state = "observed"
                run_usage_json = json.dumps(aggregate, sort_keys=True)
            else:
                run_usage_state = "not_observable"
                run_usage_json = None
            connection.execute(
                "UPDATE runs SET usage_state=?, usage_json=? WHERE id=?",
                (run_usage_state, run_usage_json, run_id),
            )
            connection.commit()
        return {
            "id": turn_id,
            "run_id": run_id,
            "turn_index": turn_index,
            "status": status,
            "usage_state": usage_state,
        }

    def list_model_turns(self, run_id: str) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM model_turns WHERE run_id=? ORDER BY turn_index", (run_id,)
            ).fetchall()
        result: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["usage"] = json.loads(item.pop("usage_json") or "null")
            item["request"] = json.loads(item.pop("request_json") or "null")
            item["response"] = json.loads(item.pop("response_json") or "null")
            result.append(item)
        return result

    def finish_run(self, run_id: str, status: str, stop_reason: str) -> None:
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT case_id FROM runs WHERE id=?", (run_id,)).fetchone()
            if not row:
                raise KeyError(run_id)
            connection.execute(
                "UPDATE runs SET status=?, stop_reason=?, finished_at=? WHERE id=?",
                (status, stop_reason, at, run_id),
            )
            self._event(connection, row["case_id"], run_id, "run.finished", {"status": status}, at)
            connection.commit()

    def interrupt_run(self, run_id: str, stop_reason: str) -> bool:
        """Terminalize one active run and any in-flight tool call after cancellation."""

        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT case_id, status FROM runs WHERE id=?",
                (run_id,),
            ).fetchone()
            if not row:
                raise KeyError(run_id)
            if row["status"] != "running":
                connection.commit()
                return False
            connection.execute(
                """UPDATE runs SET status='interrupted', stop_reason=?, finished_at=?
                   WHERE id=?""",
                (stop_reason, at, run_id),
            )
            connection.execute(
                """UPDATE tool_calls SET status='interrupted', finished_at=?
                   WHERE run_id=? AND status='running'""",
                (at, run_id),
            )
            self._event(
                connection,
                row["case_id"],
                run_id,
                "run.interrupted",
                {"reason": stop_reason},
                at,
            )
            connection.commit()
        return True

    def running_run_for_trigger(
        self,
        case_id: str,
        trigger_message_id: str,
    ) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT * FROM runs
                   WHERE case_id=? AND trigger_message_id=? AND status='running'
                   ORDER BY started_at DESC LIMIT 1""",
                (case_id, trigger_message_id),
            ).fetchone()
        return as_dict(row)

    def latest_run_for_trigger(
        self,
        case_id: str,
        trigger_message_id: str,
    ) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT * FROM runs WHERE case_id=? AND trigger_message_id=?
                   ORDER BY started_at DESC LIMIT 1""",
                (case_id, trigger_message_id),
            ).fetchone()
        return as_dict(row)

    def list_runs(self, case_id: str) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM runs WHERE case_id=? ORDER BY started_at", (case_id,)
            ).fetchall()
        return [dict(row) for row in rows]

    def reply_for_run(self, run_id: str) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT * FROM messages WHERE role='assistant'
                   AND json_extract(metadata_json, '$.run_id')=? ORDER BY seq DESC LIMIT 1""",
                (run_id,),
            ).fetchone()
        return as_dict(row)

    def terminal_reply_for_trigger(self, trigger_message_id: str) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT * FROM messages WHERE role='assistant'
                   AND json_extract(metadata_json, '$.trigger_message_id')=?
                   AND json_extract(metadata_json, '$.terminal_fallback')=1
                   ORDER BY seq DESC LIMIT 1""",
                (trigger_message_id,),
            ).fetchone()
        return as_dict(row)

    @staticmethod
    def _capability_owner_for_tool(
        connection: sqlite3.Connection,
        run_id: str,
        tool_name: str,
    ) -> str | None:
        row = connection.execute("SELECT context_json FROM runs WHERE id=?", (run_id,)).fetchone()
        if not row:
            return None
        try:
            context = json.loads(row["context_json"] or "{}")
            snapshot = context.get("runtime_snapshot", {})
            owners = snapshot.get("capability_tool_owners", {})
        except (TypeError, json.JSONDecodeError):
            return None
        owner = owners.get(tool_name) if isinstance(owners, dict) else None
        return str(owner) if isinstance(owner, str) and owner else None

    @classmethod
    def _mark_capability_tool_call(
        cls,
        connection: sqlite3.Connection,
        run_id: str,
        tool_name: str,
        at: str,
    ) -> None:
        owner = cls._capability_owner_for_tool(connection, run_id, tool_name)
        if owner is None:
            return
        connection.execute(
            """UPDATE run_capabilities
               SET load_state='real-called', tool_call_count=tool_call_count+1,
                   first_called_at=COALESCE(first_called_at, ?)
               WHERE run_id=? AND capability_version_id=?""",
            (at, run_id, owner),
        )

    @classmethod
    def _mark_capability_evidence(
        cls,
        connection: sqlite3.Connection,
        run_id: str,
        tool_name: str,
    ) -> None:
        owner = cls._capability_owner_for_tool(connection, run_id, tool_name)
        if owner is None:
            return
        connection.execute(
            """UPDATE run_capabilities
               SET evidence_count=evidence_count+1
               WHERE run_id=? AND capability_version_id=?""",
            (run_id, owner),
        )

    def create_tool_call(
        self,
        run_id: str,
        call_id: str,
        name: str,
        risk: str,
        arguments: dict[str, Any],
        *,
        call_fingerprint: str | None = None,
    ) -> str:
        tool_call_id = new_id("tool")
        provider_call_id = call_id or tool_call_id
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            run = connection.execute("SELECT case_id FROM runs WHERE id=?", (run_id,)).fetchone()
            if not run:
                raise KeyError(run_id)
            at = iso()
            connection.execute(
                """INSERT INTO tool_calls(
                   id, run_id, provider_call_id, tool_name, risk, arguments_json,
                   status, created_at, call_fingerprint
                ) VALUES (?, ?, ?, ?, ?, ?, 'running', ?, ?)""",
                (
                    tool_call_id,
                    run_id,
                    provider_call_id,
                    name,
                    risk,
                    json.dumps(arguments, ensure_ascii=False),
                    at,
                    call_fingerprint,
                ),
            )
            self._mark_capability_tool_call(connection, run_id, name, at)
            self._event(
                connection,
                run["case_id"],
                run_id,
                "tool.started",
                {"tool_call_id": tool_call_id, "tool_name": name},
                at,
            )
            connection.commit()
        return tool_call_id

    def finish_tool_call(
        self,
        tool_call_id: str,
        status: str,
        result: dict[str, Any],
        *,
        result_kind: str = "observation",
        duplicate_of_tool_call_id: str | None = None,
        reused_evidence_id: str | None = None,
    ) -> None:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT tc.run_id, r.case_id FROM tool_calls tc
                   JOIN runs r ON r.id=tc.run_id WHERE tc.id=?""",
                (tool_call_id,),
            ).fetchone()
            if not row:
                raise KeyError(tool_call_id)
            at = iso()
            connection.execute(
                """UPDATE tool_calls
                   SET status=?, result_json=?, finished_at=?, result_kind=?,
                       duplicate_of_tool_call_id=?, reused_evidence_id=?
                   WHERE id=?""",
                (
                    status,
                    json.dumps(result, ensure_ascii=False),
                    at,
                    result_kind,
                    duplicate_of_tool_call_id,
                    reused_evidence_id,
                    tool_call_id,
                ),
            )
            self._event(
                connection,
                row["case_id"],
                row["run_id"],
                "tool.finished",
                {"tool_call_id": tool_call_id, "status": status},
                at,
            )
            connection.commit()

    def list_tool_calls(self, case_id: str) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                """SELECT tc.*, r.agent_version_id, r.tool_schema_digest
                   FROM tool_calls tc JOIN runs r ON r.id=tc.run_id
                   WHERE r.case_id=? ORDER BY tc.created_at""",
                (case_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def list_run_tool_calls(self, run_id: str) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM tool_calls WHERE run_id=? ORDER BY created_at",
                (run_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def prior_tool_call_for_fingerprint(
        self,
        run_id: str,
        call_fingerprint: str,
        *,
        exclude_tool_call_id: str,
    ) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT tc.*, e.id AS evidence_id, e.state AS evidence_state,
                          e.summary AS evidence_summary, e.source_ref AS evidence_source_ref,
                          e.source_role AS evidence_source_role,
                          e.observed_at AS evidence_observed_at,
                          e.limitations_json AS evidence_limitations_json,
                          e.safe_statements_json AS evidence_safe_statements_json
                   FROM tool_calls tc
                   LEFT JOIN evidence e ON e.tool_call_id=tc.id
                   WHERE tc.run_id=? AND tc.call_fingerprint=? AND tc.id<>?
                   ORDER BY tc.created_at ASC LIMIT 1""",
                (run_id, call_fingerprint, exclude_tool_call_id),
            ).fetchone()
        return as_dict(row)

    def add_evidence(self, run_id: str, tool_call_id: str | None, envelope: EvidenceEnvelope) -> str:
        evidence_id = new_id("ev")
        observed_at = envelope.observed_at or iso()
        content_digest = canonical_digest(
            {
                "contract_version": envelope.contract_version,
                "state": str(envelope.state),
                "coverage_state": envelope.coverage_state,
                "summary": envelope.summary,
                "data": envelope.data,
                "source_ref": envelope.source_ref,
                "truncation_state": envelope.truncation_state,
                "source_role": envelope.source_role,
                "limitations": envelope.limitations,
                "safe_statements": envelope.safe_statements,
                "continuation": envelope.continuation,
            }
        )
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            prior = connection.execute(
                """SELECT previous.id FROM evidence previous
                   JOIN runs previous_run ON previous_run.id=previous.run_id
                   JOIN runs current_run ON current_run.id=?
                   WHERE previous_run.case_id=current_run.case_id
                     AND previous.content_digest=?
                     AND COALESCE(previous.source_ref, '')=COALESCE(?, '')
                   ORDER BY previous.created_at DESC LIMIT 1""",
                (run_id, content_digest, envelope.source_ref),
            ).fetchone()
            unchanged_from_evidence_id = prior["id"] if prior else None
            observation_id: str | None = None
            if envelope.provider_observation is not None:
                safe_observation = redact_sensitive(envelope.provider_observation)
                payload_json = json.dumps(
                    safe_observation,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                observation_id = new_id("observation")
                connection.execute(
                    """INSERT INTO evidence_observations(
                       id, run_id, tool_call_id, contract_version, payload_json,
                       sha256, sensitivity, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, 'management_visible', ?)""",
                    (
                        observation_id,
                        run_id,
                        tool_call_id,
                        envelope.contract_version,
                        payload_json,
                        hashlib.sha256(payload_json.encode()).hexdigest(),
                        observed_at,
                    ),
                )
            connection.execute(
                """INSERT INTO evidence(
                   id, run_id, tool_call_id, state, coverage_state, summary,
                   data_json, source_ref, contract_version, truncation_state,
                   source_role, limitations_json, safe_statements_json,
                   continuation_json, observed_at, created_at, observation_id,
                   content_digest, unchanged_from_evidence_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    evidence_id,
                    run_id,
                    tool_call_id,
                    envelope.state,
                    envelope.coverage_state,
                    envelope.summary,
                    json.dumps(envelope.data, ensure_ascii=False),
                    envelope.source_ref,
                    envelope.contract_version,
                    envelope.truncation_state,
                    envelope.source_role,
                    json.dumps(envelope.limitations, ensure_ascii=False),
                    json.dumps(envelope.safe_statements, ensure_ascii=False),
                    (
                        json.dumps(envelope.continuation, ensure_ascii=False)
                        if envelope.continuation is not None
                        else None
                    ),
                    observed_at,
                    observed_at,
                    observation_id,
                    content_digest,
                    unchanged_from_evidence_id,
                ),
            )
            if tool_call_id is not None:
                tool_call = connection.execute(
                    "SELECT tool_name FROM tool_calls WHERE id=? AND run_id=?",
                    (tool_call_id, run_id),
                ).fetchone()
                if tool_call:
                    self._mark_capability_evidence(
                        connection,
                        run_id,
                        str(tool_call["tool_name"]),
                    )
            connection.commit()
        return evidence_id

    def list_evidence(self, case_id: str) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                """SELECT e.* FROM evidence e JOIN runs r ON r.id=e.run_id
                   WHERE r.case_id=? ORDER BY e.created_at""",
                (case_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def list_run_evidence(self, run_id: str) -> list[dict[str, Any]]:
        """Return the durable Evidence ledger for one exact Run only."""
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM evidence WHERE run_id=? ORDER BY created_at",
                (run_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def save_diagnostic_checkpoint(
        self,
        case_id: str,
        content: dict[str, Any],
    ) -> dict[str, Any]:
        payload = json.dumps(content, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        digest = canonical_digest(content)
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            seq_row = connection.execute(
                "SELECT COALESCE(MAX(seq), 0) AS through_seq FROM messages WHERE case_id=?",
                (case_id,),
            ).fetchone()
            through_seq = int(seq_row["through_seq"])
            existing = connection.execute(
                """SELECT * FROM diagnostic_checkpoints
                   WHERE case_id=? AND through_message_seq=? AND content_digest=?""",
                (case_id, through_seq, digest),
            ).fetchone()
            checkpoint_id = existing["id"] if existing else new_id("checkpoint")
            at = iso()
            if not existing:
                connection.execute(
                    """INSERT INTO diagnostic_checkpoints(
                       id, case_id, through_message_seq, content_json,
                       content_digest, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?)""",
                    (checkpoint_id, case_id, through_seq, payload, digest, at),
                )
            connection.execute(
                """INSERT INTO case_context_heads(case_id, checkpoint_id, version, updated_at)
                   VALUES (?, ?, 1, ?)
                   ON CONFLICT(case_id) DO UPDATE SET
                       checkpoint_id=excluded.checkpoint_id,
                       version=case_context_heads.version+1,
                       updated_at=excluded.updated_at""",
                (case_id, checkpoint_id, at),
            )
            row = connection.execute(
                "SELECT * FROM diagnostic_checkpoints WHERE id=?",
                (checkpoint_id,),
            ).fetchone()
            connection.commit()
        return dict(row)

    def record_context_generation(
        self,
        run_id: str,
        turn_index: int,
        *,
        checkpoint: dict[str, Any],
        strategy: str,
        pressure_tier: str,
        budget: dict[str, Any],
        source_message_count: int,
        projected_message_count: int,
        omitted_protocol_groups: int,
        omitted_history_messages: int,
        evidence_refs: tuple[str, ...],
    ) -> dict[str, Any]:
        with self.database.connect() as connection:
            run = connection.execute(
                "SELECT case_id FROM runs WHERE id=?",
                (run_id,),
            ).fetchone()
        if not run:
            raise KeyError(run_id)
        saved = self.save_diagnostic_checkpoint(str(run["case_id"]), checkpoint)
        generation_id = new_id("ctxgen")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """INSERT INTO context_generations(
                   id, run_id, turn_index, checkpoint_id, strategy,
                   pressure_tier, budget_json, source_message_count,
                   projected_message_count, omitted_protocol_groups,
                   omitted_history_messages, evidence_refs_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    generation_id,
                    run_id,
                    turn_index,
                    saved["id"],
                    strategy,
                    pressure_tier,
                    json.dumps(budget, ensure_ascii=False, sort_keys=True),
                    source_message_count,
                    projected_message_count,
                    omitted_protocol_groups,
                    omitted_history_messages,
                    json.dumps(evidence_refs, ensure_ascii=False),
                    at,
                ),
            )
            for evidence_id in evidence_refs:
                connection.execute(
                    """INSERT OR IGNORE INTO context_generation_evidence(
                       context_generation_id, evidence_id, projection
                    ) VALUES (?, ?, 'evidence-card')""",
                    (generation_id, evidence_id),
                )
            connection.commit()
        return {
            "id": generation_id,
            "run_id": run_id,
            "turn_index": turn_index,
            "checkpoint_id": saved["id"],
            "strategy": strategy,
            "pressure_tier": pressure_tier,
        }

    def list_context_generations(self, run_id: str) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM context_generations WHERE run_id=? ORDER BY turn_index",
                (run_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def list_run_capabilities(self, run_id: str) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                """SELECT * FROM run_capabilities
                   WHERE run_id=? ORDER BY capability_version_id""",
                (run_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def latest_snapshot(self, case_id: str) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT * FROM snapshots WHERE case_id=? ORDER BY through_seq DESC LIMIT 1",
                (case_id,),
            ).fetchone()
        return as_dict(row)

    def list_snapshots(self, case_id: str) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM snapshots WHERE case_id=? ORDER BY through_seq", (case_id,)
            ).fetchall()
        return [dict(row) for row in rows]

    def add_feedback(
        self,
        case_id: str,
        actor_ref: str,
        kind: str,
        value: str,
        note: str = "",
        source: str = "api",
    ) -> dict[str, Any]:
        if kind != "resolution" or value not in {"resolved", "unresolved"}:
            raise ValueError("unsupported feedback")
        feedback_id = new_id("feedback")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """INSERT INTO feedback(id, case_id, actor_ref, kind, value, note, source, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (feedback_id, case_id, actor_ref, kind, value, note, source, at),
            )
            disposition = "resolved" if value == "resolved" else "unresolved"
            connection.execute(
                "UPDATE cases SET disposition=?, updated_at=? WHERE id=?",
                (disposition, at, case_id),
            )
            self._event(
                connection,
                case_id,
                None,
                "feedback.recorded",
                {"feedback_id": feedback_id, "kind": kind, "value": value},
                at,
            )
            connection.commit()
        return self.get_feedback(feedback_id)

    def record_manager_feedback(
        self, case_id: str, reviewer_ref: str, note: str, source: str = "review"
    ) -> dict[str, Any]:
        feedback_id = new_id("feedback")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """INSERT INTO feedback(id, case_id, actor_ref, kind, value, note, source, created_at)
                   VALUES (?, ?, ?, 'manager_review', 'comment', ?, ?, ?)""",
                (feedback_id, case_id, reviewer_ref, note, source, at),
            )
            self._event(
                connection,
                case_id,
                None,
                "feedback.recorded",
                {"feedback_id": feedback_id, "kind": "manager_review"},
                at,
            )
            connection.commit()
        return self.get_feedback(feedback_id)

    def get_feedback(self, feedback_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute("SELECT * FROM feedback WHERE id=?", (feedback_id,)).fetchone()
        if not row:
            raise KeyError(feedback_id)
        return dict(row)

    def list_feedback(self, case_id: str) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM feedback WHERE case_id=? ORDER BY created_at", (case_id,)
            ).fetchall()
        return [dict(row) for row in rows]

    def save_snapshot(self, case_id: str, through_seq: int, summary: str) -> dict[str, Any]:
        snapshot_id = new_id("snapshot")
        with self.database.connect() as connection:
            connection.execute(
                """INSERT OR IGNORE INTO snapshots(id, case_id, through_seq, summary, created_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (snapshot_id, case_id, through_seq, summary, iso()),
            )
        return self.latest_snapshot(case_id) or {}

    def create_review(
        self,
        case_id: str,
        snapshot_version: str,
        summary: str,
        conclusion: dict[str, Any],
        findings: list[dict[str, Any]],
        safety_findings: list[dict[str, Any]],
        capability_gaps: list[dict[str, Any]],
        evidence_refs: list[str],
        feedback_refs: list[str],
        confidence: str,
        *,
        input_snapshot_hash: str,
        agent_version_scope: list[str],
        model_profile_scope: list[str],
        pack_digest_scope: list[str],
        run_refs: list[str],
        reply_refs: list[str],
        limitations: list[dict[str, Any]],
        review_engine_version_id: str,
    ) -> dict[str, Any]:
        review_id = new_id("review")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            inserted = connection.execute(
                """INSERT OR IGNORE INTO reviews(
                   id, case_id, agent_id, snapshot_version, input_snapshot_hash,
                   agent_version_scope_json, review_engine_version_id,
                   model_profile_scope_json, pack_digest_scope_json,
                   run_refs_json, reply_refs_json, limitations_json,
                   status, summary, conclusion_json,
                   findings_json, safety_findings_json, capability_gaps_json,
                   evidence_refs_json, feedback_refs_json, confidence, created_at
                ) VALUES (?, ?, (SELECT agent_id FROM cases WHERE id=?), ?, ?, ?, ?, ?, ?, ?, ?, ?,
                          'pending', ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    review_id,
                    case_id,
                    case_id,
                    snapshot_version,
                    input_snapshot_hash,
                    json.dumps(agent_version_scope, sort_keys=True),
                    review_engine_version_id,
                    json.dumps(model_profile_scope, sort_keys=True),
                    json.dumps(pack_digest_scope, sort_keys=True),
                    json.dumps(run_refs, sort_keys=True),
                    json.dumps(reply_refs, sort_keys=True),
                    json.dumps(limitations, ensure_ascii=False, sort_keys=True),
                    summary,
                    json.dumps(conclusion, ensure_ascii=False, sort_keys=True),
                    json.dumps(findings, ensure_ascii=False, sort_keys=True),
                    json.dumps(safety_findings, ensure_ascii=False, sort_keys=True),
                    json.dumps(capability_gaps, ensure_ascii=False, sort_keys=True),
                    json.dumps(evidence_refs, sort_keys=True),
                    json.dumps(feedback_refs, sort_keys=True),
                    confidence,
                    at,
                ),
            ).rowcount
            row = connection.execute(
                "SELECT * FROM reviews WHERE case_id=? AND snapshot_version=?",
                (case_id, snapshot_version),
            ).fetchone()
            if inserted:
                self._event(
                    connection,
                    case_id,
                    run_refs[-1] if run_refs else None,
                    "review.created",
                    {
                        "review_id": review_id,
                        "input_snapshot_hash": input_snapshot_hash,
                        "review_engine_version_id": review_engine_version_id,
                    },
                    at,
                )
                connection.execute(
                    """INSERT INTO audit_events(
                       actor_type, actor_ref, action, target_type, target_id,
                       target_version, result, metadata_json, created_at
                    ) VALUES ('system', 'review-engine', 'review.created', 'review',
                              ?, ?, 'succeeded', ?, ?)""",
                    (
                        review_id,
                        snapshot_version,
                        json.dumps(
                            {
                                "case_id": case_id,
                                "agent_version_scope": agent_version_scope,
                                "review_engine_version_id": review_engine_version_id,
                            },
                            sort_keys=True,
                        ),
                        at,
                    ),
                )
            connection.commit()
        return dict(row)

    @staticmethod
    def _review_filters(
        status: str | None = None,
        *,
        agent_id: str | None = None,
        model_profile_version_id: str | None = None,
        capability_gap: str | None = None,
        created_from: str | None = None,
        created_to: str | None = None,
    ) -> tuple[str, list[Any]]:
        query = " FROM reviews WHERE 1=1"
        params: list[Any] = []
        if status:
            query += " AND status=?"
            params.append(status)
        if agent_id:
            query += " AND agent_id=?"
            params.append(agent_id)
        if model_profile_version_id:
            query += (
                " AND EXISTS (SELECT 1 FROM json_each(reviews.model_profile_scope_json)"
                " WHERE json_each.value=?)"
            )
            params.append(model_profile_version_id)
        if capability_gap:
            query += (
                " AND EXISTS (SELECT 1 FROM json_each(reviews.capability_gaps_json)"
                " WHERE json_extract(json_each.value, '$.kind')=?)"
            )
            params.append(capability_gap)
        if created_from:
            query += " AND created_at>=?"
            params.append(created_from)
        if created_to:
            query += " AND created_at<=?"
            params.append(created_to)
        return query, params

    def list_reviews(
        self,
        status: str | None = None,
        *,
        agent_id: str | None = None,
        model_profile_version_id: str | None = None,
        capability_gap: str | None = None,
        created_from: str | None = None,
        created_to: str | None = None,
    ) -> list[dict[str, Any]]:
        filters, params = self._review_filters(
            status,
            agent_id=agent_id,
            model_profile_version_id=model_profile_version_id,
            capability_gap=capability_gap,
            created_from=created_from,
            created_to=created_to,
        )
        with self.database.connect() as connection:
            rows = connection.execute(
                f"SELECT *{filters} ORDER BY created_at DESC, id DESC",
                params,
            ).fetchall()
        return [dict(row) for row in rows]

    def list_reviews_page(
        self,
        status: str | None = None,
        *,
        agent_id: str | None = None,
        model_profile_version_id: str | None = None,
        capability_gap: str | None = None,
        created_from: str | None = None,
        created_to: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        limit = max(1, min(limit, 500))
        offset = max(0, min(offset, 1_000_000))
        filters, params = self._review_filters(
            status,
            agent_id=agent_id,
            model_profile_version_id=model_profile_version_id,
            capability_gap=capability_gap,
            created_from=created_from,
            created_to=created_to,
        )
        with self.database.connect() as connection:
            total = int(connection.execute(f"SELECT COUNT(*){filters}", params).fetchone()[0])
            rows = connection.execute(
                f"SELECT *{filters} ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?",
                [*params, limit, offset],
            ).fetchall()
        items = [dict(row) for row in rows]
        return {
            "items": items,
            "page": {
                "total": total,
                "limit": limit,
                "offset": offset,
                "has_previous": offset > 0,
                "has_next": offset + len(items) < total,
            },
        }

    def active_review_engine_version(self) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT rev.*, rep.name AS profile_name,
                          mpv.model_profile_id, mpv.model_id,
                          pbv.prompt_bundle_id, pbv.digest AS prompt_bundle_digest
                   FROM review_engine_profiles rep
                   JOIN review_engine_versions rev ON rev.id=rep.active_version_id
                   JOIN model_profile_versions mpv ON mpv.id=rev.model_profile_version_id
                   JOIN prompt_bundle_versions pbv ON pbv.id=rev.prompt_bundle_version_id
                   WHERE rep.status='active'
                   ORDER BY rep.updated_at DESC LIMIT 1"""
            ).fetchone()
        if not row:
            raise RuntimeError("no active Review Engine version")
        return dict(row)

    def get_review(self, review_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute("SELECT * FROM reviews WHERE id=?", (review_id,)).fetchone()
        if not row:
            raise KeyError(review_id)
        return dict(row)

    def list_actions(self, case_id: str | None = None, status: str | None = None) -> list[dict[str, Any]]:
        query = """SELECT id, case_id, agent_id, tool_name, commit_tool_name,
                          action_type, status, prepared_run_id, prepared_agent_version_id,
                          prepared_message_id,
                          confirmed_message_id, requester_ref, confirmation_phrase,
                          prepare_result_json, prepared_at, expires_at, confirmed_at,
                          finished_at, result_json
                   FROM actions WHERE 1=1"""
        params: list[Any] = []
        if case_id:
            query += " AND case_id=?"
            params.append(case_id)
        if status:
            query += " AND status=?"
            params.append(status)
        query += " ORDER BY prepared_at DESC"
        with self.database.connect() as connection:
            rows = connection.execute(query, params).fetchall()
        return [dict(row) for row in rows]

    def get_action(self, action_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT id, case_id, agent_id, tool_name, commit_tool_name,
                          action_type, status, prepared_run_id, prepared_agent_version_id,
                          prepared_message_id,
                          confirmed_message_id, requester_ref, confirmation_phrase,
                          prepare_result_json, prepared_at, expires_at, confirmed_at,
                          finished_at, result_json
                   FROM actions WHERE id=?""",
                (action_id,),
            ).fetchone()
        if not row:
            raise KeyError(action_id)
        return dict(row)

    def awaiting_action_for_case(self, case_id: str) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT id, case_id, tool_name, action_type, status, requester_ref,
                          prepared_agent_version_id,
                          confirmation_phrase, prepared_message_id, prepared_at, expires_at
                   FROM actions WHERE case_id=? AND status='awaiting_confirmation'
                     AND expires_at>?
                   ORDER BY prepared_at DESC LIMIT 1""",
                (case_id, iso()),
            ).fetchone()
        return as_dict(row)

    def decide_review(self, review_id: str, decision: str, reviewer_ref: str, note: str) -> dict[str, Any]:
        if decision not in {ReviewStatus.APPROVED, ReviewStatus.REJECTED}:
            raise ValueError("decision must be approved or rejected")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT case_id, status FROM reviews WHERE id=?", (review_id,)
            ).fetchone()
            if not row:
                raise KeyError(review_id)
            if row["status"] != ReviewStatus.PENDING:
                raise ValueError("review already decided")
            connection.execute(
                """UPDATE reviews SET status=?, reviewer_ref=?, reviewer_note=?, decided_at=?
                   WHERE id=?""",
                (decision, reviewer_ref, note, at, review_id),
            )
            self._event(
                connection,
                row["case_id"],
                None,
                "review.decided",
                {"review_id": review_id, "decision": decision},
                at,
            )
            connection.execute(
                """INSERT INTO audit_events(
                   actor_type, actor_ref, action, target_type, target_id,
                   result, metadata_json, created_at
                ) VALUES ('reviewer', ?, 'review.decided', 'review', ?, ?, ?, ?)""",
                (
                    reviewer_ref,
                    review_id,
                    decision,
                    json.dumps({"case_id": row["case_id"], "decision": decision}),
                    at,
                ),
            )
            if note.strip():
                feedback_id = new_id("feedback")
                connection.execute(
                    """INSERT INTO feedback(
                       id, case_id, actor_ref, kind, value, note, source, created_at
                    ) VALUES (?, ?, ?, 'manager_review', ?, ?, 'review', ?)""",
                    (feedback_id, row["case_id"], reviewer_ref, decision, note, at),
                )
                self._event(
                    connection,
                    row["case_id"],
                    None,
                    "feedback.recorded",
                    {"feedback_id": feedback_id, "kind": "manager_review"},
                    at,
                )
            connection.commit()
        return self.get_review(review_id)

    def schedule_job(
        self,
        kind: str,
        unique_key: str,
        payload: dict[str, Any],
        due_at: datetime,
        case_id: str | None,
        *,
        agent_id: str | None = None,
    ) -> str:
        with self.database.connect() as connection:
            return self._schedule_job(
                connection,
                kind,
                unique_key,
                payload,
                due_at,
                case_id,
                agent_id=agent_id,
            )

    @staticmethod
    def _schedule_job(
        connection: sqlite3.Connection,
        kind: str,
        unique_key: str,
        payload: dict[str, Any],
        due_at: datetime,
        case_id: str | None,
        *,
        agent_id: str | None = None,
    ) -> str:
        job_id = new_id("job")
        connection.execute(
            """INSERT OR IGNORE INTO jobs(
               id, kind, case_id, agent_id, unique_key, payload_json, due_at, created_at
            ) VALUES (?, ?, ?, COALESCE(?, (SELECT agent_id FROM cases WHERE id=?)), ?, ?, ?, ?)""",
            (
                job_id,
                kind,
                case_id,
                agent_id,
                case_id,
                unique_key,
                json.dumps(payload),
                iso(due_at),
                iso(),
            ),
        )
        row = connection.execute(
            "SELECT id FROM jobs WHERE unique_key=?",
            (unique_key,),
        ).fetchone()
        if not row:
            raise RuntimeError("scheduled job could not be read back")
        return str(row["id"])

    def job_for_unique_key(self, unique_key: str) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT * FROM jobs WHERE unique_key=?",
                (unique_key,),
            ).fetchone()
        return as_dict(row)

    def claim_job(
        self,
        unique_key: str,
        now: datetime,
        lease_until: datetime,
    ) -> dict[str, Any] | None:
        """Lease one exact durable job without racing the scheduler."""

        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT * FROM jobs WHERE unique_key=? AND due_at<=?
                   AND (status='pending' OR (status='running' AND lease_until<?))""",
                (unique_key, iso(now), iso(now)),
            ).fetchone()
            if row:
                connection.execute(
                    """UPDATE jobs SET status='running', lease_until=?, attempts=attempts+1
                       WHERE id=?""",
                    (iso(lease_until), row["id"]),
                )
                row = connection.execute(
                    "SELECT * FROM jobs WHERE id=?",
                    (row["id"],),
                ).fetchone()
            connection.commit()
        return as_dict(row)

    def defer_job(
        self,
        job_id: str,
        *,
        due_at: datetime | None = None,
        reason: str | None = None,
    ) -> None:
        with self.database.connect() as connection:
            connection.execute(
                """UPDATE jobs SET status='pending', lease_until=NULL,
                   due_at=COALESCE(?, due_at), last_error=? WHERE id=?""",
                (iso(due_at) if due_at else None, (reason or "")[:1000] or None, job_id),
            )

    def extend_job_lease(self, job_id: str, lease_until: datetime) -> None:
        with self.database.connect() as connection:
            updated = connection.execute(
                "UPDATE jobs SET lease_until=? WHERE id=? AND status='running'",
                (iso(lease_until), job_id),
            ).rowcount
        if updated != 1:
            raise RuntimeError("running job lease could not be extended")

    def recover_running_jobs(self, kind: str) -> int:
        with self.database.connect() as connection:
            result = connection.execute(
                """UPDATE jobs SET status='pending', lease_until=NULL,
                   last_error='process_restart'
                   WHERE kind=? AND status='running'""",
                (kind,),
            )
        return int(result.rowcount)

    def stop_inbound_jobs_for_scope(
        self,
        channel: str,
        channel_instance: str,
        scope_kind: str,
        scope_ref: str,
        actor_ref: str,
    ) -> int:
        """Terminalize admitted but not yet completed messages for one channel scope."""

        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            rows = connection.execute(
                """SELECT j.id, m.external_event_id, m.case_id
                   FROM jobs j
                   JOIN messages m
                     ON m.id=json_extract(j.payload_json, '$.message_id')
                   WHERE j.kind='process_inbound' AND j.status IN ('pending','running')
                     AND json_extract(m.metadata_json, '$.channel')=?
                     AND json_extract(m.metadata_json, '$.channel_instance')=?
                     AND json_extract(m.metadata_json, '$.scope_kind')=?
                     AND json_extract(m.metadata_json, '$.scope_ref')=?
                     AND (?='thread' OR m.actor_ref=?)""",
                (
                    channel,
                    channel_instance,
                    scope_kind,
                    scope_ref,
                    scope_kind,
                    actor_ref,
                ),
            ).fetchall()
            at = iso()
            for row in rows:
                connection.execute(
                    """UPDATE jobs SET status='completed', lease_until=NULL, finished_at=?,
                       last_error='user_stop' WHERE id=?""",
                    (at, row["id"]),
                )
                if row["external_event_id"]:
                    connection.execute(
                        """UPDATE inbound_events SET case_id=?, state='processed'
                           WHERE event_id=?""",
                        (row["case_id"], row["external_event_id"]),
                    )
            connection.commit()
        return len(rows)

    def job_status_counts(self, kind: str) -> dict[str, int]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT status, COUNT(*) AS count FROM jobs WHERE kind=? GROUP BY status",
                (kind,),
            ).fetchall()
        return {str(row["status"]): int(row["count"]) for row in rows}

    def lease_due_jobs(self, now: datetime, lease_until: datetime, limit: int = 20) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            rows = connection.execute(
                """SELECT * FROM jobs WHERE (status='pending' OR (status='running' AND lease_until<?))
                   AND due_at<=? ORDER BY due_at LIMIT ?""",
                (iso(now), iso(now), limit),
            ).fetchall()
            ids = [row["id"] for row in rows]
            for job_id in ids:
                connection.execute(
                    "UPDATE jobs SET status='running', lease_until=?, attempts=attempts+1 WHERE id=?",
                    (iso(lease_until), job_id),
                )
            connection.commit()
        return [dict(row) for row in rows]

    def finish_job(self, job_id: str, error: str | None = None) -> None:
        with self.database.connect() as connection:
            if error:
                connection.execute(
                    "UPDATE jobs SET status='pending', lease_until=NULL, last_error=? WHERE id=?",
                    (error[:1000], job_id),
                )
            else:
                connection.execute(
                    "UPDATE jobs SET status='completed', lease_until=NULL, finished_at=? WHERE id=?",
                    (iso(), job_id),
                )

    def complete_job(self, job_id: str, terminal_error: str | None = None) -> None:
        with self.database.connect() as connection:
            connection.execute(
                """UPDATE jobs SET status='completed', lease_until=NULL, finished_at=?,
                   last_error=? WHERE id=?""",
                (iso(), (terminal_error or "")[:1000] or None, job_id),
            )

    def complete_inbound_job(
        self,
        job_id: str,
        event_id: str,
        case_id: str,
        terminal_error: str | None = None,
    ) -> None:
        """Atomically close the execution responsibility and ingress receipt."""

        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """UPDATE jobs SET status='completed', lease_until=NULL, finished_at=?,
                   last_error=? WHERE id=? AND kind='process_inbound'""",
                (iso(), (terminal_error or "")[:1000] or None, job_id),
            )
            connection.execute(
                "UPDATE inbound_events SET case_id=?, state='processed' WHERE event_id=?",
                (case_id, event_id),
            )
            connection.commit()

    def list_inactive_candidates(self, cutoff: datetime) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                """SELECT c.* FROM cases c WHERE c.lifecycle='open' AND c.last_external_at<?
                   AND NOT EXISTS (SELECT 1 FROM runs r WHERE r.case_id=c.id AND r.status='running')
                   AND NOT EXISTS (SELECT 1 FROM actions a WHERE a.case_id=c.id
                       AND a.status IN ('prepared','awaiting_confirmation','executing'))
                   AND NOT EXISTS (SELECT 1 FROM outbox o WHERE o.case_id=c.id AND o.status='pending')""",
                (iso(cutoff),),
            ).fetchall()
        return [dict(row) for row in rows]

    def enqueue_outbox(
        self,
        case_id: str | None,
        channel: str,
        address: dict[str, Any],
        payload: dict[str, Any],
        idempotency_key: str,
        *,
        agent_id: str | None = None,
    ) -> str:
        outbox_id = new_id("outbox")
        at = iso()
        with self.database.connect() as connection:
            if case_id is not None:
                case = connection.execute("SELECT agent_id FROM cases WHERE id=?", (case_id,)).fetchone()
                if not case:
                    raise KeyError(case_id)
                if agent_id is not None and agent_id != case["agent_id"]:
                    raise ValueError("outbox Agent does not match Case")
                agent_id = case["agent_id"]
            elif agent_id is None:
                raise ValueError("outbox without Case requires agent_id")
            connection.execute(
                """INSERT OR IGNORE INTO outbox(
                   id, case_id, agent_id, channel, address_json, payload_json, idempotency_key,
                   created_at, available_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    outbox_id,
                    case_id,
                    agent_id,
                    channel,
                    json.dumps(address),
                    json.dumps(payload, ensure_ascii=False),
                    idempotency_key,
                    at,
                    at,
                ),
            )
            row = connection.execute(
                "SELECT id FROM outbox WHERE idempotency_key=?", (idempotency_key,)
            ).fetchone()
        return row["id"]

    def lease_pending_outbox(
        self,
        owner: str,
        now: datetime,
        lease_until: datetime,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            rows = connection.execute(
                """SELECT * FROM outbox
                   WHERE (status='pending' OR (status='sending' AND lease_until<?))
                     AND available_at<=?
                   ORDER BY CASE WHEN idempotency_key LIKE 'command-reply:%' THEN 0 ELSE 1 END,
                            created_at LIMIT ?""",
                (iso(now), iso(now), limit),
            ).fetchall()
            for row in rows:
                connection.execute(
                    """UPDATE outbox SET status='sending', lease_owner=?, lease_until=?
                       WHERE id=?""",
                    (owner, iso(lease_until), row["id"]),
                )
            connection.commit()
        return [dict(row) for row in rows]

    def lease_outbox(
        self,
        outbox_id: str,
        owner: str,
        now: datetime,
        lease_until: datetime,
    ) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT * FROM outbox WHERE id=?
                   AND (status='pending' OR (status='sending' AND lease_until<?))
                   AND available_at<=?""",
                (outbox_id, iso(now), iso(now)),
            ).fetchone()
            if row:
                connection.execute(
                    """UPDATE outbox SET status='sending', lease_owner=?, lease_until=?
                       WHERE id=?""",
                    (owner, iso(lease_until), outbox_id),
                )
            connection.commit()
        return dict(row) if row else None

    def get_outbox(self, outbox_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute("SELECT * FROM outbox WHERE id=?", (outbox_id,)).fetchone()
        if not row:
            raise KeyError(outbox_id)
        return dict(row)

    def outbox_for_idempotency(self, idempotency_key: str) -> dict[str, Any] | None:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT * FROM outbox WHERE idempotency_key=?",
                (idempotency_key,),
            ).fetchone()
        return as_dict(row)

    def list_pending_outbox(self, limit: int = 20) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                """SELECT * FROM outbox WHERE status IN ('pending','sending')
                   ORDER BY created_at LIMIT ?""",
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def mark_outbox(
        self,
        outbox_id: str,
        outcome: str | bool,
        error: str | None = None,
        receipt: dict[str, Any] | None = None,
    ) -> None:
        if isinstance(outcome, bool):
            outcome = "sent" if outcome else "outcome_unknown"
        if outcome not in {"sent", "captured", "failed", "outcome_unknown"}:
            raise ValueError("invalid Outbox outcome")
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT attempts FROM outbox WHERE id=?", (outbox_id,)).fetchone()
            if not row:
                raise KeyError(outbox_id)
            attempts = row["attempts"] + 1
            safe_receipt = {
                key: value
                for key, value in (receipt or {}).items()
                if key in {"state", "message_id", "card_id", "sequence", "index"}
                and isinstance(value, (str, int, bool, type(None)))
            }
            if outcome in {"sent", "captured"}:
                connection.execute(
                    """UPDATE outbox SET status=?, outcome_state=?, attempts=?,
                       sent_at=?, finished_at=?, receipt_json=?, external_message_ref=?,
                       lease_owner=NULL, lease_until=NULL, last_error=NULL WHERE id=?""",
                    (
                        outcome,
                        outcome,
                        attempts,
                        iso() if outcome == "sent" else None,
                        iso(),
                        json.dumps(safe_receipt, ensure_ascii=False),
                        safe_receipt.get("message_id"),
                        outbox_id,
                    ),
                )
            else:
                # A failed network call can have an unknown delivery outcome.  The
                # dispatcher therefore never retries automatically; an operator may
                # inspect/dead-letter it without risking duplicate external sends.
                available = utc_now()
                connection.execute(
                    """UPDATE outbox SET status=?, outcome_state=?, attempts=?,
                       available_at=?, finished_at=?, receipt_json=?,
                       lease_owner=NULL, lease_until=NULL, last_error=? WHERE id=?""",
                    (
                        outcome,
                        outcome,
                        attempts,
                        iso(available),
                        iso(),
                        json.dumps(safe_receipt, ensure_ascii=False),
                        (error or "delivery failed")[:1000],
                        outbox_id,
                    ),
                )
            connection.commit()

    def list_events(self, case_id: str, after: int = 0) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT * FROM events WHERE case_id=? AND id>? ORDER BY id", (case_id, after)
            ).fetchall()
        return [dict(row) for row in rows]

    def event_in_transaction(
        self,
        connection: sqlite3.Connection,
        case_id: str | None,
        run_id: str | None,
        kind: str,
        payload: dict[str, Any],
        at: str | None = None,
    ) -> None:
        self._event(connection, case_id, run_id, kind, payload, at or iso())

    def _event(
        self,
        connection: sqlite3.Connection,
        case_id: str | None,
        run_id: str | None,
        kind: str,
        payload: dict[str, Any],
        at: str,
    ) -> None:
        agent_id = None
        if case_id is not None:
            row = connection.execute("SELECT agent_id FROM cases WHERE id=?", (case_id,)).fetchone()
            agent_id = row["agent_id"] if row else None
        connection.execute(
            """INSERT INTO events(
               case_id, agent_id, run_id, kind, payload_json, created_at
            ) VALUES(?,?,?,?,?,?)""",
            (case_id, agent_id, run_id, kind, json.dumps(payload, ensure_ascii=False), at),
        )
