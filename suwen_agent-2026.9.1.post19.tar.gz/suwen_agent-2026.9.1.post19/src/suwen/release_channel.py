from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
from datetime import UTC, datetime
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import urlsplit

from .deployment import (
    RELEASE_CHANNEL_SCHEMA_VERSION,
    RELEASE_RETENTION_GENERATIONS,
    RELEASE_RETENTION_SCHEMA_VERSION,
    inspect_wheel,
)
from .release import product_release_label

_GIT_OBJECT_ID = re.compile(r"(?:[0-9a-f]{40}|[0-9a-f]{64})\Z")
_CANDIDATE_ID = re.compile(r"rc-[0-9a-f]{20}\Z")
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")


def publish_release_channel(
    wheel: str | Path,
    repository: str | Path,
    *,
    source_identity: dict[str, str],
) -> dict[str, Any]:
    source = Path(wheel).expanduser().resolve()
    root = Path(repository).expanduser().resolve()
    if not source.is_file() or source.suffix != ".whl":
        raise ValueError("release-channel publish requires one Suwen wheel")
    package, version = inspect_wheel(source)
    if package.replace("_", "-").lower() != "suwen-agent":
        raise ValueError("release channel only accepts the suwen-agent package")
    required_identity = {"git_commit", "git_tree", "candidate_id", "acceptance_sha256"}
    if (
        set(source_identity) != required_identity
        or not isinstance(source_identity.get("git_commit"), str)
        or _GIT_OBJECT_ID.fullmatch(source_identity["git_commit"]) is None
        or not isinstance(source_identity.get("git_tree"), str)
        or _GIT_OBJECT_ID.fullmatch(source_identity["git_tree"]) is None
        or not isinstance(source_identity.get("candidate_id"), str)
        or _CANDIDATE_ID.fullmatch(source_identity["candidate_id"]) is None
        or not isinstance(source_identity.get("acceptance_sha256"), str)
        or _SHA256.fullmatch(source_identity["acceptance_sha256"]) is None
    ):
        raise ValueError("release channel requires exact Git and candidate source identity")
    digest = _sha256(source)
    artifacts = root / "artifacts"
    artifacts.mkdir(mode=0o700, parents=True, exist_ok=True)
    root.chmod(0o700)
    artifacts.chmod(0o700)
    previous_artifact = _published_artifact(root / "channel.json", artifacts)
    # Wheel installers parse compatibility tags from the filename. Keep the
    # standards-compliant artifact name and reject same-version content drift.
    filename = source.name
    target = artifacts / filename
    if target.exists():
        if not target.is_file() or _sha256(target) != digest:
            raise ValueError("release-channel artifact path contains conflicting content")
    else:
        descriptor, temporary_name = tempfile.mkstemp(prefix=f".{filename}.", dir=artifacts)
        temporary = Path(temporary_name)
        try:
            with os.fdopen(descriptor, "wb") as handle, source.open("rb") as reader:
                shutil.copyfileobj(reader, handle, length=1024 * 1024)
                handle.flush()
                os.fsync(handle.fileno())
                os.fchmod(handle.fileno(), 0o600)
            os.replace(temporary, target)
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
    payload = {
        "schema_version": RELEASE_CHANNEL_SCHEMA_VERSION,
        "product": "suwen-agent",
        "channel": "stable",
        "package_version": version,
        "release_version": product_release_label(version),
        "published_at": datetime.now(UTC).isoformat(),
        "source_identity": dict(source_identity),
        "artifact": {
            "path": f"artifacts/{filename}",
            "sha256": digest,
            "size_bytes": target.stat().st_size,
        },
    }
    _atomic_manifest(root / "channel.json", payload)
    retention = _prune_channel_artifacts(
        artifacts,
        current=target,
        previous=previous_artifact,
    )
    return {
        **payload,
        "repository": str(root),
        "manifest": str(root / "channel.json"),
        "release_retention": retention,
    }


def _published_artifact(manifest_path: Path, artifacts: Path) -> Path | None:
    if not manifest_path.is_file():
        return None
    try:
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    artifact = payload.get("artifact") if isinstance(payload, dict) else None
    relative = (
        PurePosixPath(artifact.get("path"))
        if isinstance(artifact, dict) and isinstance(artifact.get("path"), str)
        else None
    )
    if (
        relative is None
        or len(relative.parts) != 2
        or relative.parts[0] != "artifacts"
        or relative.suffix != ".whl"
    ):
        return None
    candidate = artifacts / relative.name
    return candidate if candidate.is_file() and not candidate.is_symlink() else None


def _prune_channel_artifacts(
    artifacts: Path,
    *,
    current: Path,
    previous: Path | None,
) -> dict[str, Any]:
    candidates = [
        path
        for path in artifacts.iterdir()
        if path.is_file() and not path.is_symlink() and path.suffix == ".whl"
    ]
    retained = {current}
    if previous is not None:
        retained.add(previous)
    for path in sorted(candidates, key=lambda item: (item.stat().st_mtime_ns, item.name), reverse=True):
        if len(retained) >= RELEASE_RETENTION_GENERATIONS:
            break
        retained.add(path)
    removed: list[str] = []
    for path in sorted(candidates, key=lambda item: item.name):
        if path in retained:
            continue
        path.unlink()
        removed.append(path.name)
    return {
        "schema_version": RELEASE_RETENTION_SCHEMA_VERSION,
        "retain_generations": RELEASE_RETENTION_GENERATIONS,
        "retained_artifacts": sorted(path.name for path in retained),
        "removed_artifacts": removed,
    }


def serve_release_channel(
    repository: str | Path,
    *,
    host: str = "0.0.0.0",
    port: int = 4020,
) -> None:
    root = Path(repository).expanduser().resolve()
    if not (root / "channel.json").is_file():
        raise ValueError("release-channel repository has no published channel.json")
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError("release-channel port is invalid")
    handler = partial(_ReleaseChannelHandler, directory=str(root))
    server = _ReleaseChannelServer((host, port), handler)
    print(
        json.dumps(
            {
                "schema_version": RELEASE_CHANNEL_SCHEMA_VERSION,
                "status": "serving",
                "host": host,
                "port": port,
                "repository": str(root),
                "external_writes": 0,
            },
            ensure_ascii=False,
            sort_keys=True,
        ),
        flush=True,
    )
    try:
        server.serve_forever()
    finally:
        server.server_close()


class _ReleaseChannelServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


class _ReleaseChannelHandler(SimpleHTTPRequestHandler):
    server_version = "SuwenReleaseChannel/1"

    def _allowed_path(self) -> bool:
        path = PurePosixPath(urlsplit(self.path).path)
        return path == PurePosixPath("/channel.json") or (
            len(path.parts) == 3
            and path.parts[1] == "artifacts"
            and path.name.endswith(".whl")
            and all(part not in {"", ".", ".."} for part in path.parts[1:])
        )

    def do_GET(self) -> None:  # noqa: N802 - stdlib handler contract
        if urlsplit(self.path).path == "/health":
            payload = json.dumps(
                {
                    "schema_version": RELEASE_CHANNEL_SCHEMA_VERSION,
                    "status": "ready",
                    "external_writes": 0,
                },
                sort_keys=True,
            ).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(payload)
            return
        if not self._allowed_path():
            self.send_error(404)
            return
        super().do_GET()

    def do_HEAD(self) -> None:  # noqa: N802 - stdlib handler contract
        if not self._allowed_path():
            self.send_error(404)
            return
        super().do_HEAD()

    def list_directory(self, _path: str) -> None:
        self.send_error(404)
        return None

    def end_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def log_message(self, format: str, *args: object) -> None:
        print(f"release-channel {self.address_string()} {format % args}", flush=True)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_manifest(path: Path, payload: dict[str, Any]) -> None:
    encoded = (json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())
            os.fchmod(handle.fileno(), 0o600)
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
