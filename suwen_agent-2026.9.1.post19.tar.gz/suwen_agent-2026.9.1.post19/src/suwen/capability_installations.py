"""Managed catalog and atomic workspace installation for native releases."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
from pathlib import Path
from typing import Any

from .agent_profiles import inspect_agent_profile_source
from .capability_packages import CapabilityPackageRegistry
from .db import Database
from .release_artifacts import (
    ReleaseArtifact,
    ReleaseArtifactError,
    build_release_artifact,
    canonical_json_bytes,
    extract_verified_release,
    file_digest,
    sha256_bytes,
    verify_release_artifact,
)
from .repository import iso, new_id


class NativeReleaseManager:
    """Import immutable artifacts, then install them without changing any Agent."""

    def __init__(
        self,
        database: Database,
        workspace_root: Path,
        capability_packages: CapabilityPackageRegistry,
    ) -> None:
        self.database = database
        self.root = workspace_root.resolve()
        self.artifact_root = self.root / "artifacts" / "sha256"
        self.installation_root = self.root / "installations"
        self.staging_root = self.root / "staging"
        self.capability_packages = capability_packages

    def preview(self, artifact_path: Path, *, expected_digest: str | None = None) -> dict[str, Any]:
        artifact = verify_release_artifact(artifact_path, expected_digest=expected_digest)
        with self.database.connect() as connection:
            conflict = connection.execute(
                """SELECT artifact_digest FROM native_release_artifacts
                   WHERE resource_type=? AND resource_id=? AND version=?""",
                (artifact.resource_type, artifact.resource_id, artifact.version),
            ).fetchone()
        findings: list[dict[str, str]] = []
        if conflict and conflict["artifact_digest"] != artifact.artifact_digest:
            findings.append({"code": "release_version_conflict", "level": "error"})
        if artifact.trusted_code:
            findings.append({"code": "trusted_code_confirmation_required", "level": "warning"})
        return {
            **artifact.public_view(),
            "ready": not any(item["level"] == "error" for item in findings),
            "findings": findings,
        }

    def import_artifact(
        self,
        artifact_path: Path,
        actor: str,
        *,
        expected_digest: str,
        trust_code: bool = False,
    ) -> dict[str, Any]:
        artifact = verify_release_artifact(artifact_path, expected_digest=expected_digest)
        transaction_id = self._start_transaction("import", actor, artifact)
        target = self.artifact_root / f"{artifact.artifact_digest}.suwenpkg"
        created_file = False
        try:
            with self.database.connect() as connection:
                conflict = connection.execute(
                    """SELECT * FROM native_release_artifacts
                       WHERE resource_type=? AND resource_id=? AND version=?""",
                    (artifact.resource_type, artifact.resource_id, artifact.version),
                ).fetchone()
                if conflict and conflict["artifact_digest"] != artifact.artifact_digest:
                    raise ValueError("release resource version cannot change in place")
            self.artifact_root.mkdir(mode=0o700, parents=True, exist_ok=True)
            if target.exists():
                if file_digest(target) != artifact.artifact_digest:
                    raise RuntimeError("managed release artifact has content drift")
            else:
                temporary = target.with_name(f".{target.name}.{transaction_id}.tmp")
                shutil.copyfile(artifact.path, temporary)
                temporary.chmod(0o600)
                if file_digest(temporary) != artifact.artifact_digest:
                    temporary.unlink(missing_ok=True)
                    raise RuntimeError("copied release artifact digest mismatch")
                os.replace(temporary, target)
                created_file = True
            with self.database.connect() as connection:
                connection.execute("BEGIN IMMEDIATE")
                existing = connection.execute(
                    "SELECT id, artifact_digest FROM native_release_artifacts WHERE artifact_digest=?",
                    (artifact.artifact_digest,),
                ).fetchone()
                artifact_id = str(existing["id"]) if existing else new_id("release")
                if existing is None:
                    connection.execute(
                        """INSERT INTO native_release_artifacts(
                           id, artifact_digest, resource_type, resource_id, version,
                           source_content_digest, payload_digest, trusted_code,
                           release_json, inventory_json, artifact_path, status,
                           trust_confirmed, imported_by, imported_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'verified', ?, ?, ?)""",
                        (
                            artifact_id,
                            artifact.artifact_digest,
                            artifact.resource_type,
                            artifact.resource_id,
                            artifact.version,
                            artifact.source_content_digest,
                            artifact.payload_digest,
                            int(artifact.trusted_code),
                            json.dumps(artifact.release, ensure_ascii=False, sort_keys=True),
                            json.dumps(list(artifact.inventory), ensure_ascii=False, sort_keys=True),
                            str(target),
                            int(trust_code and artifact.trusted_code),
                            actor,
                            iso(),
                        ),
                    )
                elif trust_code and artifact.trusted_code:
                    connection.execute(
                        "UPDATE native_release_artifacts SET trust_confirmed=1 WHERE id=?",
                        (artifact_id,),
                    )
                self._finish_transaction(
                    connection, transaction_id, "succeeded", {"artifact_id": artifact_id}
                )
                self._audit(
                    connection, actor, "native_release.imported", artifact, {"artifact_id": artifact_id}
                )
                connection.commit()
            return self.artifact_view(artifact.artifact_digest)
        except BaseException as exc:
            if created_file:
                target.unlink(missing_ok=True)
            self._fail_transaction(transaction_id, exc)
            raise

    def install_artifact(
        self,
        artifact_digest: str,
        actor: str,
        *,
        trust_code: bool = False,
    ) -> dict[str, Any]:
        row = self._artifact_row(artifact_digest)
        artifact = verify_release_artifact(Path(row["artifact_path"]), expected_digest=artifact_digest)
        if artifact.trusted_code and not (trust_code or bool(row["trust_confirmed"])):
            raise PermissionError("trusted code installation requires confirmation for this artifact digest")
        transaction_id = self._start_transaction("install", actor, artifact)
        staging = self.staging_root / transaction_id
        target = (
            self.installation_root
            / artifact.resource_type
            / artifact.resource_id
            / artifact.version
            / artifact.artifact_digest
        )
        created_target = False
        try:
            if target.exists():
                existing = self._installation_for_artifact(str(row["id"]))
                if existing is None:
                    raise RuntimeError("untracked native release installation already exists")
                if self._installed_tree_digest(target) != existing["install_digest"]:
                    raise RuntimeError("existing native release installation has content drift")
                with self.database.connect() as connection:
                    connection.execute("BEGIN IMMEDIATE")
                    self._finish_transaction(
                        connection,
                        transaction_id,
                        "succeeded",
                        {"installation_id": str(existing["id"]), "idempotent": True},
                    )
                    connection.commit()
                return self.installation_view(str(existing["id"]))
            self.staging_root.mkdir(mode=0o700, parents=True, exist_ok=True)
            install_digest = extract_verified_release(artifact, staging)
            capability_version_id: str | None = None
            composition_lock_digest = ""
            profile_digest = ""
            if artifact.resource_type == "capability":
                registered = self.capability_packages.register_source(staging / "source", actor)
                capability_version_id = str(registered["capability_version_id"])
            else:
                profile = inspect_agent_profile_source(staging / "source" / "profile.toml")
                if profile.digest != artifact.source_content_digest:
                    raise RuntimeError("installed Agent Profile source digest mismatch")
                profile_digest = profile.digest
                composition_lock = self._composition_lock(profile.manifest(), artifact)
                lock_bytes = canonical_json_bytes(composition_lock)
                (staging / "composition.lock.json").write_bytes(lock_bytes)
                (staging / "composition.lock.json").chmod(0o600)
                composition_lock_digest = sha256_bytes(lock_bytes)
                install_digest = self._installed_tree_digest(staging)
            target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            os.replace(staging, target)
            created_target = True
            with self.database.connect() as connection:
                connection.execute("BEGIN IMMEDIATE")
                installation_id = new_id("install")
                connection.execute(
                    """INSERT INTO native_workspace_installations(
                       id, artifact_id, capability_version_id, install_digest,
                       workspace_path, status, transaction_id, installed_by, installed_at
                    ) VALUES (?, ?, ?, ?, ?, 'installed', ?, ?, ?)""",
                    (
                        installation_id,
                        row["id"],
                        capability_version_id,
                        install_digest,
                        str(target),
                        transaction_id,
                        actor,
                        iso(),
                    ),
                )
                if capability_version_id:
                    connection.execute(
                        """UPDATE capability_package_versions
                           SET lifecycle_state='workspace-installed', artifact_digest=?, artifact_path=?,
                               workspace_path=?, artifact_built_at=COALESCE(artifact_built_at, ?),
                               installed_at=? WHERE id=? AND content_digest=?""",
                        (
                            artifact.artifact_digest,
                            str(row["artifact_path"]),
                            str(target / "source"),
                            iso(),
                            iso(),
                            capability_version_id,
                            artifact.source_content_digest,
                        ),
                    )
                else:
                    connection.execute(
                        """INSERT INTO agent_profile_releases(
                           id, profile_id, version, source_content_digest, artifact_id,
                           installation_id, composition_lock_digest, status, installed_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'installed', ?)""",
                        (
                            new_id("profilerelease"),
                            artifact.resource_id,
                            artifact.version,
                            profile_digest,
                            row["id"],
                            installation_id,
                            composition_lock_digest,
                            iso(),
                        ),
                    )
                if trust_code and artifact.trusted_code:
                    connection.execute(
                        "UPDATE native_release_artifacts SET trust_confirmed=1 WHERE id=?",
                        (row["id"],),
                    )
                self._finish_transaction(
                    connection,
                    transaction_id,
                    "succeeded",
                    {"installation_id": installation_id, "install_digest": install_digest},
                )
                self._audit(
                    connection,
                    actor,
                    "native_release.workspace_installed",
                    artifact,
                    {"installation_id": installation_id, "install_digest": install_digest},
                )
                connection.commit()
            return self.installation_view(installation_id)
        except BaseException as exc:
            if staging.exists():
                shutil.rmtree(staging)
            if created_target and target.exists():
                shutil.rmtree(target)
            self._fail_transaction(transaction_id, exc)
            raise

    def install_markdown_domain(
        self,
        *,
        capability_id: str,
        version: str,
        capability_name: str,
        skill_id: str,
        skill_name: str,
        description: str,
        applicability: str,
        instructions: str,
        source_url: str,
        source_revision: str,
        source_updated: str,
        references: list[dict[str, str]],
        actor: str,
    ) -> dict[str, Any]:
        """Install one Markdown-only domain Skill bundle through the management API.

        The caller supplies one entry document and its bounded references. The service keeps the
        existing immutable version and provenance guarantees internally, so
        clients do not need to build, upload, or install a release artifact.
        """

        text_fields = {
            "capability_name": capability_name,
            "skill_name": skill_name,
            "description": description,
            "applicability": applicability,
            "instructions": instructions,
            "source_url": source_url,
            "source_revision": source_revision,
            "source_updated": source_updated,
        }
        for field, value in text_fields.items():
            if not isinstance(value, str) or not value.strip() or "\x00" in value:
                raise ValueError(f"{field} must be non-empty safe text")
        if len(instructions) > 30_000:
            raise ValueError("instructions exceeds 30000 characters")
        if len(source_url) > 2_000 or len(source_revision) > 500:
            raise ValueError("domain Skill source provenance is too long")
        if len(references) > 8:
            raise ValueError("domain Skill references exceed the configured limit")

        normalized_references: list[dict[str, str]] = []
        reference_ids: set[str] = set()
        for reference in references:
            if not isinstance(reference, dict):
                raise ValueError("domain Skill reference must be an object")
            reference_id = reference.get("id", "")
            if not isinstance(reference_id, str) or not re.fullmatch(
                r"[a-z][a-z0-9-]{1,63}", reference_id
            ):
                raise ValueError("domain Skill reference id is invalid")
            if reference_id in reference_ids:
                raise ValueError("duplicate domain Skill reference id")
            normalized: dict[str, str] = {"id": reference_id}
            limits = {
                "title": 240,
                "description": 1_000,
                "content": 100_000,
                "source_url": 2_000,
                "source_revision": 500,
                "source_updated": 100,
            }
            for field, maximum in limits.items():
                value = reference.get(field, "")
                if (
                    not isinstance(value, str)
                    or not value.strip()
                    or "\x00" in value
                    or len(value) > maximum
                ):
                    raise ValueError(f"domain Skill reference {field} is invalid")
                normalized[field] = value
            reference_ids.add(reference_id)
            normalized_references.append(normalized)

        markdown_digest = hashlib.sha256(instructions.encode("utf-8")).hexdigest()
        self.staging_root.mkdir(mode=0o700, parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(
            prefix="markdown-domain-",
            dir=self.staging_root,
        ) as temporary:
            temporary_root = Path(temporary)
            source_root = temporary_root / "source"
            skill_root = source_root / "skills" / skill_id
            knowledge_root = source_root / "knowledge"
            prompt_root = source_root / "prompts"
            output_root = temporary_root / "release"
            skill_root.mkdir(mode=0o700, parents=True)
            knowledge_root.mkdir(mode=0o700, parents=True)
            prompt_root.mkdir(mode=0o700)

            toml = lambda value: json.dumps(value, ensure_ascii=False)  # noqa: E731
            (source_root / "manifest.toml").write_text(
                "\n".join(
                    (
                        'schema = "suwen-capability.v1"',
                        f"id = {toml(capability_id)}",
                        'kind = "domain"',
                        f"version = {toml(version)}",
                        f"name = {toml(capability_name)}",
                        f"description = {toml(description)}",
                        'capability_api = ">=1.2,<2.0"',
                        'content_entrypoint = "domain.toml"',
                        "trusted_code = false",
                        "external_dependencies = []",
                        "",
                    )
                ),
                encoding="utf-8",
            )
            domain_lines = [
                'schema = "suwen-domain.v1"',
                'skills_dir = "skills"',
                "",
                "[[prompts]]",
                f"id = {toml(capability_id + '-prompt')}",
                'path = "prompts/domain.md"',
                "",
            ]
            for reference in normalized_references:
                domain_lines.extend(
                    (
                        "[[knowledge]]",
                        f"id = {toml(reference['id'])}",
                        f"title = {toml(reference['title'])}",
                        f"description = {toml(reference['description'])}",
                        f"path = {toml('knowledge/' + reference['id'] + '.md')}",
                        'source_role = "mechanism"',
                        "",
                    )
                )
            (source_root / "domain.toml").write_text(
                "\n".join(domain_lines),
                encoding="utf-8",
            )
            (prompt_root / "domain.md").write_text(
                "Use the single Wiki-maintained Skill in this frozen capability snapshot as domain "
                "guidance. Treat referenced knowledge as mechanism or context; make current-case claims "
                "only from current Evidence.\n",
                encoding="utf-8",
            )
            reference_items = ",\n  ".join(
                "{ "
                + f"id = {toml(reference['id'])}, "
                + f"knowledge_id = {toml(reference['id'])}, "
                + f"title = {toml(reference['title'])}, "
                + f"description = {toml(reference['description'])}"
                + " }"
                for reference in normalized_references
            )
            skill_lines = [
                f"id = {toml(skill_id)}",
                f"name = {toml(skill_name)}",
                f"description = {toml(description)}",
                f"applicability = {toml(applicability)}",
                'instruction_file = "SKILL.md"',
                "fallback = true",
            ]
            if reference_items:
                skill_lines.extend(("references = [", f"  {reference_items},", "]"))
            else:
                skill_lines.append("references = []")
            skill_lines.append("")
            (skill_root / "skill.toml").write_text(
                "\n".join(skill_lines),
                encoding="utf-8",
            )
            (skill_root / "SKILL.md").write_text(instructions.strip() + "\n", encoding="utf-8")
            for reference in normalized_references:
                (knowledge_root / f"{reference['id']}.md").write_text(
                    reference["content"].strip() + "\n",
                    encoding="utf-8",
                )
            provenance_references = [
                item
                for reference in normalized_references
                for item in (
                    f"- Reference `{reference['id']}`: `{reference['source_url']}`",
                    f"  - Revision: `{reference['source_revision']}`",
                    f"  - Updated: `{reference['source_updated']}`",
                )
            ]
            (source_root / "PROVENANCE.md").write_text(
                "\n".join(
                    (
                        "# Wiki Skill bundle source",
                        "",
                        "- Schema: `suwen-wiki-skill-source.v2`",
                        f"- Entry source: `{source_url}`",
                        f"- Bundle revision: `{source_revision}`",
                        f"- Wiki version: `{version}`",
                        f"- Wiki updated: `{source_updated}`",
                        "",
                        *provenance_references,
                        "",
                    )
                ),
                encoding="utf-8",
            )

            artifact = build_release_artifact(
                source_root,
                output_root,
                source_revision=source_revision,
                release_notes=(
                    f"# {capability_name} {version}\n\n"
                    f"Frozen from {source_url} at {source_revision} with "
                    f"{len(normalized_references)} on-demand references.\n"
                ),
            )
            self.import_artifact(
                artifact.path,
                actor,
                expected_digest=artifact.artifact_digest,
            )
            installed = self.install_artifact(artifact.artifact_digest, actor)

        return {
            **installed,
            "markdown_sha256": markdown_digest,
            "source_url": source_url,
            "source_revision": source_revision,
            "source_updated": source_updated,
            "reference_count": len(normalized_references),
        }

    def list_artifacts(self) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT artifact_digest FROM native_release_artifacts ORDER BY imported_at, artifact_digest"
            ).fetchall()
        return [self.artifact_view(str(row["artifact_digest"])) for row in rows]

    def list_installations(self) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            rows = connection.execute(
                "SELECT id FROM native_workspace_installations ORDER BY installed_at, id"
            ).fetchall()
        return [self.installation_view(str(row["id"])) for row in rows]

    def prepare_profile_rollback(
        self,
        agent_id: str,
        profile_id: str,
        version: str,
        source_content_digest: str,
    ) -> dict[str, Any]:
        """Describe an exact historical Profile selection without changing the Agent."""

        with self.database.connect() as connection:
            target = connection.execute(
                """SELECT apr.profile_id, apr.version, apr.source_content_digest,
                          apr.composition_lock_digest, nra.artifact_digest,
                          nwi.id AS installation_id, nwi.install_digest
                   FROM agent_profile_releases apr
                   JOIN native_release_artifacts nra ON nra.id=apr.artifact_id
                   JOIN native_workspace_installations nwi ON nwi.id=apr.installation_id
                   WHERE apr.profile_id=? AND apr.version=? AND apr.source_content_digest=?
                     AND apr.status='installed' AND nwi.status='installed'""",
                (profile_id, version, source_content_digest),
            ).fetchone()
            active = connection.execute(
                """SELECT av.id, av.version, av.config_json
                   FROM agents a JOIN agent_versions av ON av.id=a.active_version_id
                   WHERE a.id=?""",
                (agent_id,),
            ).fetchone()
        if not target:
            raise KeyError(f"{profile_id}@{version}")
        if not active:
            raise KeyError(agent_id)
        config = json.loads(active["config_json"] or "{}")
        current = {
            "id": config.get("agent_profile_id"),
            "version": config.get("agent_profile_version"),
            "source_content_digest": config.get("agent_profile_digest"),
            "artifact_digest": config.get("agent_profile_artifact_digest"),
            "installation_id": config.get("agent_profile_installation_id"),
        }
        return {
            "operation": "prepare-rollback",
            "agent_id": agent_id,
            "active_agent_version_id": active["id"],
            "current": current,
            "target": dict(target),
            "ready": current
            != {
                "id": target["profile_id"],
                "version": target["version"],
                "source_content_digest": target["source_content_digest"],
                "artifact_digest": target["artifact_digest"],
                "installation_id": target["installation_id"],
            },
            "will_publish": False,
            "will_activate": False,
            "affects_future_runs_only": True,
        }

    def artifact_view(self, artifact_digest: str) -> dict[str, Any]:
        row = self._artifact_row(artifact_digest)
        item = dict(row)
        item["release"] = json.loads(item.pop("release_json"))
        item["inventory"] = json.loads(item.pop("inventory_json"))
        item["trusted_code"] = bool(item["trusted_code"])
        item["trust_confirmed"] = bool(item["trust_confirmed"])
        item["state"] = "artifact-built"
        item["artifact_class"] = "release"
        return item

    def installation_view(self, installation_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT nwi.*, nra.artifact_digest, nra.resource_type, nra.resource_id,
                          nra.version, nra.source_content_digest, nra.payload_digest,
                          apr.composition_lock_digest
                   FROM native_workspace_installations nwi
                   JOIN native_release_artifacts nra ON nra.id=nwi.artifact_id
                   LEFT JOIN agent_profile_releases apr ON apr.installation_id=nwi.id
                   WHERE nwi.id=?""",
                (installation_id,),
            ).fetchone()
        if not row:
            raise KeyError(installation_id)
        item = dict(row)
        with self.database.connect() as connection:
            if item["resource_type"] == "capability":
                enabled = connection.execute(
                    """SELECT COUNT(*) FROM agent_version_capabilities
                       WHERE installation_id=? AND enabled=1""",
                    (installation_id,),
                ).fetchone()[0]
                loaded = connection.execute(
                    """SELECT COUNT(*) FROM capability_process_loads
                       WHERE installation_id=? AND state='process-loaded'""",
                    (installation_id,),
                ).fetchone()[0]
                called = connection.execute(
                    """SELECT COALESCE(SUM(tool_call_count), 0) FROM run_capabilities
                       WHERE installation_id=?""",
                    (installation_id,),
                ).fetchone()[0]
            else:
                enabled = connection.execute(
                    """SELECT COUNT(*) FROM agent_versions
                       WHERE json_extract(config_json, '$.agent_profile_installation_id')=?""",
                    (installation_id,),
                ).fetchone()[0]
                loaded = 0
                called = 0
        item["profile_enabled_bindings"] = int(enabled)
        item["process_loaded_records"] = int(loaded)
        item["real_called_tool_calls"] = int(called)
        item["state"] = "workspace-installed" if item["status"] == "installed" else "disabled"
        item["artifact_class"] = "release"
        return item

    def _composition_lock(self, profile: dict[str, Any], artifact: ReleaseArtifact) -> dict[str, Any]:
        capabilities: list[dict[str, Any]] = []
        with self.database.connect() as connection:
            for reference in profile["capabilities"]:
                row = connection.execute(
                    """SELECT cpv.id AS capability_version_id, nwi.id AS installation_id,
                              nwi.install_digest, nra.artifact_digest
                       FROM capability_package_versions cpv
                       JOIN native_workspace_installations nwi
                         ON nwi.capability_version_id=cpv.id AND nwi.status='installed'
                       JOIN native_release_artifacts nra ON nra.id=nwi.artifact_id
                       WHERE cpv.capability_id=? AND cpv.version=? AND cpv.content_digest=?""",
                    (reference["id"], reference["version"], reference["digest"]),
                ).fetchone()
                if not row:
                    raise ValueError(
                        "Profile dependency is not formally installed: "
                        f"{reference['id']}@{reference['version']}"
                    )
                capabilities.append({**reference, **dict(row)})
        return {
            "schema": "suwen-agent-composition-lock.v2",
            "profile": {
                "id": artifact.resource_id,
                "version": artifact.version,
                "source_content_digest": artifact.source_content_digest,
                "artifact_digest": artifact.artifact_digest,
            },
            "host_prompt": profile["host_prompt"],
            "packs": profile["packs"],
            "capabilities": capabilities,
            "connectors": profile.get("connectors", []),
        }

    def _artifact_row(self, artifact_digest: str) -> Any:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT * FROM native_release_artifacts WHERE artifact_digest=?",
                (artifact_digest,),
            ).fetchone()
        if not row:
            raise KeyError(artifact_digest)
        return row

    def _installation_for_artifact(self, artifact_id: str) -> Any:
        with self.database.connect() as connection:
            return connection.execute(
                "SELECT * FROM native_workspace_installations WHERE artifact_id=?",
                (artifact_id,),
            ).fetchone()

    def _start_transaction(self, operation: str, actor: str, artifact: ReleaseArtifact) -> str:
        transaction_id = new_id("nativetxn")
        with self.database.connect() as connection:
            connection.execute(
                """INSERT INTO native_install_transactions(
                   id, operation, artifact_digest, resource_type, resource_id, version,
                   state, input_json, actor, started_at
                ) VALUES (?, ?, ?, ?, ?, ?, 'started', ?, ?, ?)""",
                (
                    transaction_id,
                    operation,
                    artifact.artifact_digest,
                    artifact.resource_type,
                    artifact.resource_id,
                    artifact.version,
                    json.dumps(artifact.public_view(), ensure_ascii=False, sort_keys=True),
                    actor,
                    iso(),
                ),
            )
        return transaction_id

    @staticmethod
    def _finish_transaction(
        connection: Any,
        transaction_id: str,
        state: str,
        result: dict[str, Any],
    ) -> None:
        connection.execute(
            """UPDATE native_install_transactions
               SET state=?, result_json=?, finished_at=? WHERE id=?""",
            (state, json.dumps(result, ensure_ascii=False, sort_keys=True), iso(), transaction_id),
        )

    def _fail_transaction(self, transaction_id: str, exc: BaseException) -> None:
        try:
            with self.database.connect() as connection:
                connection.execute(
                    """UPDATE native_install_transactions
                       SET state='failed', error_code=?, result_json=?, finished_at=? WHERE id=?""",
                    (
                        type(exc).__name__,
                        json.dumps({"detail": str(exc)[:1_000]}, ensure_ascii=False),
                        iso(),
                        transaction_id,
                    ),
                )
        except Exception:
            pass

    @staticmethod
    def _audit(
        connection: Any,
        actor: str,
        action: str,
        artifact: ReleaseArtifact,
        metadata: dict[str, Any],
    ) -> None:
        connection.execute(
            """INSERT INTO audit_events(
               actor_type, actor_ref, action, target_type, target_id, target_version,
               result, metadata_json, created_at
            ) VALUES ('operator', ?, ?, 'native_release', ?, ?, 'succeeded', ?, ?)""",
            (
                actor,
                action,
                artifact.resource_id,
                artifact.version,
                json.dumps(metadata, ensure_ascii=False, sort_keys=True),
                iso(),
            ),
        )

    @staticmethod
    def _installed_tree_digest(root: Path) -> str:
        digest = hashlib.sha256()
        for path in sorted(
            (item for item in root.rglob("*") if item.is_file()),
            key=lambda item: item.relative_to(root).as_posix(),
        ):
            name = path.relative_to(root).as_posix().encode()
            payload = path.read_bytes()
            digest.update(len(name).to_bytes(4, "big"))
            digest.update(name)
            digest.update(len(payload).to_bytes(8, "big"))
            digest.update(payload)
        return digest.hexdigest()


__all__ = ["NativeReleaseManager", "ReleaseArtifactError"]
