from __future__ import annotations

import hashlib
import json
import re
from abc import ABC, abstractmethod
from typing import Any

import httpx

from .config import ModelConfig
from .types import ModelTurn, ToolDefinition, ToolRequest

MAX_MODEL_RESPONSE_BYTES = 4_000_000
MAX_MODEL_CATALOG_BYTES = 1_000_000
MAX_MODEL_CATALOG_ITEMS = 1_000
RETRYABLE_MODEL_HTTP_STATUSES = frozenset({408, 429, 500, 502, 503, 504})

_TEXTUAL_TOOL_MARKER = re.compile(
    r"<\s*/?\s*tool_call\s*>|<\s*(?:function|parameter)\s*=[^>]+>",
    re.IGNORECASE,
)
_TEXTUAL_TOOL_BLOCK = re.compile(
    r"<\s*tool_call\s*>\s*(.*?)\s*<\s*/\s*tool_call\s*>",
    re.IGNORECASE | re.DOTALL,
)
_TEXTUAL_FUNCTION_BLOCK = re.compile(
    r"<\s*function\s*=\s*([A-Za-z_][A-Za-z0-9_.-]*)\s*>\s*"
    r"(.*?)\s*<\s*/\s*function\s*>",
    re.IGNORECASE | re.DOTALL,
)
_TEXTUAL_PARAMETER_BLOCK = re.compile(
    r"<\s*parameter\s*=\s*([A-Za-z_][A-Za-z0-9_.-]*)\s*>\s*"
    r"(.*?)\s*<\s*/\s*parameter\s*>",
    re.IGNORECASE | re.DOTALL,
)


class ModelProtocolError(ValueError):
    """The endpoint replied, but not with the declared compatible protocol."""


def model_failure_projection(exc: BaseException) -> dict[str, Any] | None:
    """Return a provider-safe failure receipt without endpoint or response content."""

    if not isinstance(exc, httpx.HTTPStatusError):
        return None
    status_code = exc.response.status_code
    return {
        "error": {
            "kind": "http_status",
            "status_code": status_code,
            "retryable": status_code in RETRYABLE_MODEL_HTTP_STATUSES,
        }
    }


def retryable_model_failure(exc: BaseException) -> bool:
    return (
        isinstance(exc, httpx.HTTPStatusError) and exc.response.status_code in RETRYABLE_MODEL_HTTP_STATUSES
    )


def normalize_model_turn(turn: ModelTurn) -> ModelTurn:
    """Convert one known textual tool-call dialect or reject it without disclosure."""

    textual_requests = _parse_textual_tool_requests(turn.content)
    if textual_requests is None:
        return turn
    if turn.tool_requests:
        raise ModelProtocolError("model response mixes structured and textual tool calls")
    return ModelTurn(
        content="",
        tool_requests=textual_requests,
        finish_reason="tool_calls",
        usage=turn.usage,
        reasoning_chars=turn.reasoning_chars,
        reasoning_control_applied=turn.reasoning_control_applied,
    )


def _parse_textual_tool_requests(content: str) -> tuple[ToolRequest, ...] | None:
    if not _TEXTUAL_TOOL_MARKER.search(content):
        return None

    requests: list[ToolRequest] = []
    cursor = 0
    for call_index, call_match in enumerate(_TEXTUAL_TOOL_BLOCK.finditer(content), start=1):
        if content[cursor : call_match.start()].strip():
            raise ModelProtocolError("model textual tool call contains visible content")
        function_match = _TEXTUAL_FUNCTION_BLOCK.fullmatch(call_match.group(1))
        if function_match is None:
            raise ModelProtocolError("model textual tool call function is malformed")
        name = function_match.group(1)
        parameter_source = function_match.group(2)
        arguments: dict[str, Any] = {}
        parameter_cursor = 0
        for parameter_match in _TEXTUAL_PARAMETER_BLOCK.finditer(parameter_source):
            if parameter_source[parameter_cursor : parameter_match.start()].strip():
                raise ModelProtocolError("model textual tool call parameter is malformed")
            parameter_name = parameter_match.group(1)
            if parameter_name in arguments:
                raise ModelProtocolError("model textual tool call parameter is duplicated")
            arguments[parameter_name] = _parse_textual_parameter_value(parameter_match.group(2))
            parameter_cursor = parameter_match.end()
        if parameter_source[parameter_cursor:].strip():
            raise ModelProtocolError("model textual tool call parameter is malformed")
        digest = hashlib.sha256(
            f"{call_index}:{name}:{json.dumps(arguments, ensure_ascii=False, sort_keys=True)}".encode()
        ).hexdigest()[:16]
        requests.append(ToolRequest(f"text-tool-{call_index}-{digest}", name, arguments))
        cursor = call_match.end()

    if not requests or content[cursor:].strip():
        raise ModelProtocolError("model textual tool call is malformed")
    return tuple(requests)


def _parse_textual_parameter_value(value: str) -> Any:
    stripped = value.strip()
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        return stripped


class ModelProvider(ABC):
    @abstractmethod
    async def complete(self, messages: list[dict[str, Any]], tools: list[ToolDefinition]) -> ModelTurn: ...

    async def complete_with_options(
        self,
        messages: list[dict[str, Any]],
        tools: list[ToolDefinition],
        *,
        reasoning_effort: str | None = None,
    ) -> ModelTurn:
        """Complete one turn with optional, provider-neutral request controls.

        Fixture and non-reasoning providers keep their existing contract.  A
        compatible provider may override this method to transmit supported
        controls without forcing every provider implementation to change.
        """

        del reasoning_effort
        return await self.complete(messages, tools)

    async def complete_with_controls(
        self,
        messages: list[dict[str, Any]],
        tools: list[ToolDefinition],
        *,
        response_format: dict[str, Any] | None = None,
        reasoning_effort: str | None = None,
        temperature: float | None = None,
    ) -> ModelTurn:
        """Apply optional per-turn controls while preserving older providers."""

        del temperature
        if response_format is not None:
            return await self.complete_structured(messages, tools, response_format)
        return await self.complete_with_options(
            messages,
            tools,
            reasoning_effort=reasoning_effort,
        )

    async def complete_structured(
        self,
        messages: list[dict[str, Any]],
        tools: list[ToolDefinition],
        response_format: dict[str, Any],
    ) -> ModelTurn:
        """Request one schema-bound turn while preserving fixture compatibility.

        Providers that can transmit a native response format override this method.
        The default keeps existing deterministic fixture providers usable, but still
        validates their returned JSON against the requested schema.
        """

        turn = await self.complete(messages, tools)
        _validate_structured_turn(turn, response_format)
        return turn


class StubModelProvider(ModelProvider):
    async def complete(self, messages: list[dict[str, Any]], tools: list[ToolDefinition]) -> ModelTurn:
        latest = next(
            (str(message.get("content", "")) for message in reversed(messages) if message["role"] == "user"),
            "",
        )
        return ModelTurn(
            content=(
                "我已记录这个问题。当前还没有直接证据足以确认根因；"
                f"已知现象是：{latest[:240]}。建议先提供一个可核验的对象标识或发生时间，"
                "我会继续做只读检查。"
            ),
            finish_reason="stop",
        )


class UnavailableModelProvider(ModelProvider):
    def __init__(self, reason: str):
        self.reason = reason

    async def complete(self, messages: list[dict[str, Any]], tools: list[ToolDefinition]) -> ModelTurn:
        raise RuntimeError(self.reason)


class OpenAICompatibleProvider(ModelProvider):
    def __init__(self, config: ModelConfig, transport: httpx.AsyncBaseTransport | None = None):
        if not config.base_url:
            raise ValueError("OpenAI-compatible provider requires base_url")
        self.config = config
        self.last_response_model: str | None = None
        self.client = httpx.AsyncClient(
            base_url=config.base_url.rstrip("/"),
            timeout=config.timeout_seconds,
            transport=transport,
            headers={"Authorization": f"Bearer {config.api_key}"} if config.api_key else {},
        )

    async def list_models(self) -> tuple[list[str], bool]:
        response = await self.client.get("/models")
        response.raise_for_status()
        if len(response.content) > MAX_MODEL_CATALOG_BYTES:
            raise ModelProtocolError("model catalog exceeds the configured size limit")
        try:
            body = response.json()
            items = body["data"]
            if not isinstance(items, list):
                raise ModelProtocolError("model catalog data is not a list")
            model_ids: list[str] = []
            observed: set[str] = set()
            for item in items:
                if not isinstance(item, dict):
                    raise ModelProtocolError("model catalog item is invalid")
                model_id = item.get("id")
                if not isinstance(model_id, str) or not model_id.strip() or len(model_id) > 200:
                    raise ModelProtocolError("model catalog item has an invalid id")
                normalized = model_id.strip()
                if normalized not in observed:
                    observed.add(normalized)
                    model_ids.append(normalized)
        except ModelProtocolError:
            raise
        except (KeyError, TypeError, ValueError) as exc:
            raise ModelProtocolError("model catalog does not match the OpenAI-compatible protocol") from exc
        truncated = len(model_ids) > MAX_MODEL_CATALOG_ITEMS
        return model_ids[:MAX_MODEL_CATALOG_ITEMS], truncated

    async def complete(
        self,
        messages: list[dict[str, Any]],
        tools: list[ToolDefinition],
        *,
        tool_choice: dict[str, Any] | str | None = None,
        response_format: dict[str, Any] | None = None,
        reasoning_effort: str | None = None,
        temperature: float | None = None,
    ) -> ModelTurn:
        effective_reasoning_effort = (
            self.config.reasoning_effort if reasoning_effort is None else reasoning_effort
        )
        payload: dict[str, Any] = {
            "model": self.config.model,
            "messages": messages,
            "temperature": self.config.temperature if temperature is None else temperature,
            "max_tokens": self.config.max_output_tokens,
        }
        if tools:
            payload["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description,
                        "parameters": tool.input_schema,
                    },
                }
                for tool in tools
            ]
            if tool_choice is not None:
                payload["tool_choice"] = tool_choice
        if response_format is not None:
            if tools:
                raise ValueError("structured response requests cannot include tools")
            _structured_schema(response_format)
            payload["response_format"] = response_format
        if effective_reasoning_effort is not None:
            payload["reasoning_effort"] = effective_reasoning_effort
        reasoning_control_applied = effective_reasoning_effort is not None
        response = await self.client.post("/chat/completions", json=payload)
        if (
            effective_reasoning_effort is not None
            and response.status_code in {400, 422}
            and "reasoning_effort" in response.text[:4_000].lower()
        ):
            # Older compatible endpoints may explicitly reject the optional
            # control. Preserve compatibility, but make the downgrade visible.
            payload.pop("reasoning_effort", None)
            reasoning_control_applied = False
            response = await self.client.post("/chat/completions", json=payload)
        response.raise_for_status()
        if len(response.content) > MAX_MODEL_RESPONSE_BYTES:
            raise ModelProtocolError("model response exceeds the configured size limit")
        try:
            body = response.json()
            choices = body["choices"]
            if not isinstance(choices, list) or not choices:
                raise ModelProtocolError("model response contains no choices")
            choice = choices[0]
            message = choice["message"]
            if not isinstance(message, dict):
                raise ModelProtocolError("model response message is invalid")
            content = message.get("content")
            if content is None:
                content = ""
            if not isinstance(content, str):
                raise ModelProtocolError("model response content is invalid")
            reasoning_content = message.get("reasoning_content")
            if reasoning_content is None:
                reasoning_chars = 0
            elif isinstance(reasoning_content, str):
                reasoning_chars = len(reasoning_content)
            else:
                raise ModelProtocolError("model response reasoning_content is invalid")
            tool_calls = message.get("tool_calls", [])
            if tool_calls is None:
                tool_calls = []
            if not isinstance(tool_calls, list):
                raise ModelProtocolError("model response tool_calls is invalid")
            requests = tuple(
                ToolRequest(
                    call_id=_required_string(item, "id"),
                    name=_required_string(item.get("function"), "name"),
                    arguments=_parse_arguments(item["function"].get("arguments", "{}")),
                )
                for item in tool_calls
                if isinstance(item, dict) and isinstance(item.get("function"), dict)
            )
            if len(requests) != len(tool_calls):
                raise ModelProtocolError("model response tool call is invalid")
        except ModelProtocolError:
            raise
        except (KeyError, TypeError, ValueError) as exc:
            raise ModelProtocolError("model response does not match chat completions") from exc
        observed_model = body.get("model")
        self.last_response_model = observed_model if isinstance(observed_model, str) else None
        turn = normalize_model_turn(
            ModelTurn(
                content=content,
                tool_requests=requests,
                finish_reason=choice.get("finish_reason", "stop"),
                usage=_usage_projection(body.get("usage")),
                reasoning_chars=reasoning_chars,
                reasoning_control_applied=(
                    reasoning_control_applied if effective_reasoning_effort is not None else None
                ),
            )
        )
        if response_format is not None:
            _validate_structured_turn(turn, response_format)
        return turn

    async def complete_with_options(
        self,
        messages: list[dict[str, Any]],
        tools: list[ToolDefinition],
        *,
        reasoning_effort: str | None = None,
    ) -> ModelTurn:
        return await self.complete(
            messages,
            tools,
            reasoning_effort=reasoning_effort,
        )

    async def complete_with_controls(
        self,
        messages: list[dict[str, Any]],
        tools: list[ToolDefinition],
        *,
        response_format: dict[str, Any] | None = None,
        reasoning_effort: str | None = None,
        temperature: float | None = None,
    ) -> ModelTurn:
        return await self.complete(
            messages,
            tools,
            response_format=response_format,
            reasoning_effort=reasoning_effort,
            temperature=temperature,
        )

    async def complete_structured(
        self,
        messages: list[dict[str, Any]],
        tools: list[ToolDefinition],
        response_format: dict[str, Any],
    ) -> ModelTurn:
        return await self.complete(messages, tools, response_format=response_format)

    async def close(self) -> None:
        await self.client.aclose()


def _parse_arguments(value: str | dict[str, Any]) -> dict[str, Any]:
    if isinstance(value, dict):
        return value

    try:
        parsed = json.loads(value or "{}")
    except json.JSONDecodeError as exc:
        raise ModelProtocolError("model response tool arguments are not valid JSON") from exc
    if not isinstance(parsed, dict):
        raise ModelProtocolError("model response tool arguments must be an object")
    return parsed


def _required_string(value: Any, key: str) -> str:
    if not isinstance(value, dict):
        raise ModelProtocolError("model response tool call is invalid")
    item = value.get(key)
    if not isinstance(item, str) or not item:
        raise ModelProtocolError(f"model response tool call {key} is invalid")
    return item


def _usage_projection(value: Any) -> dict[str, int] | None:
    """Keep only non-negative aggregate counters returned by the Provider."""
    if not isinstance(value, dict):
        return None
    aliases = {
        "prompt_tokens": "input_tokens",
        "completion_tokens": "output_tokens",
        "input_tokens": "input_tokens",
        "output_tokens": "output_tokens",
        "total_tokens": "total_tokens",
    }
    projected: dict[str, int] = {}
    for source, target in aliases.items():
        item = value.get(source)
        if isinstance(item, int) and not isinstance(item, bool) and item >= 0:
            projected[target] = item
    return projected or None


def _structured_schema(response_format: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(response_format, dict) or response_format.get("type") != "json_schema":
        raise ValueError("structured response format must use json_schema")
    declaration = response_format.get("json_schema")
    if not isinstance(declaration, dict):
        raise ValueError("structured response format lacks json_schema")
    name = declaration.get("name")
    schema = declaration.get("schema")
    if (
        not isinstance(name, str)
        or not name
        or len(name) > 64
        or declaration.get("strict") is not True
        or not isinstance(schema, dict)
    ):
        raise ValueError("structured response format is not a bounded strict schema")
    return schema


def _validate_structured_turn(turn: ModelTurn, response_format: dict[str, Any]) -> None:
    if turn.tool_requests or turn.finish_reason == "length" or not turn.content:
        raise ModelProtocolError("structured model response is incomplete")
    try:
        value = json.loads(turn.content)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise ModelProtocolError("structured model response is not valid JSON") from exc
    _validate_schema_value(value, _structured_schema(response_format), path="$")


def _validate_schema_value(value: Any, schema: dict[str, Any], *, path: str) -> None:
    expected = schema.get("type")
    valid_type = {
        "object": isinstance(value, dict),
        "array": isinstance(value, list),
        "string": isinstance(value, str),
        "boolean": isinstance(value, bool),
        "integer": isinstance(value, int) and not isinstance(value, bool),
        "number": isinstance(value, (int, float)) and not isinstance(value, bool),
        "null": value is None,
    }.get(expected)
    if expected is not None and valid_type is not True:
        raise ModelProtocolError(f"structured model response violates schema at {path}")
    if "enum" in schema and value not in schema["enum"]:
        raise ModelProtocolError(f"structured model response violates enum at {path}")
    if expected == "object":
        properties = schema.get("properties", {})
        required = schema.get("required", [])
        if not isinstance(properties, dict) or not isinstance(required, list):
            raise ValueError("structured response schema has invalid object constraints")
        if any(not isinstance(item, str) for item in required):
            raise ValueError("structured response schema has invalid required fields")
        missing = [item for item in required if item not in value]
        if missing:
            raise ModelProtocolError(f"structured model response lacks required field at {path}")
        if schema.get("additionalProperties") is False and any(
            item not in properties for item in value
        ):
            raise ModelProtocolError(f"structured model response has extra field at {path}")
        for key, item in value.items():
            child = properties.get(key)
            if isinstance(child, dict):
                _validate_schema_value(item, child, path=f"{path}.{key}")
    elif expected == "array":
        items = schema.get("items")
        if not isinstance(items, dict):
            raise ValueError("structured response schema has invalid array constraints")
        for index, item in enumerate(value):
            _validate_schema_value(item, items, path=f"{path}[{index}]")


def build_model(config: ModelConfig) -> ModelProvider:
    if config.provider == "stub":
        return StubModelProvider()
    if config.provider in {"openai", "openai-compatible"}:
        return OpenAICompatibleProvider(config)
    raise ValueError(f"unsupported model provider: {config.provider}")
