from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from typing import Any

from .db import REVIEW_ENGINE_PROFILE_ID, Database
from .repository import iso, new_id
from .review import normalize_review_config


def _digest(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode()
    return hashlib.sha256(encoded).hexdigest()


def _loads(value: str | None, fallback: Any) -> Any:
    return json.loads(value) if value else fallback


class ReviewEngineRegistry:
    """Versioned configuration for the bounded Review Engine."""

    def __init__(self, database: Database):
        self.database = database

    def list_profiles(self) -> list[dict[str, Any]]:
        with self.database.connect() as connection:
            profiles = connection.execute(
                "SELECT * FROM review_engine_profiles ORDER BY updated_at DESC, id"
            ).fetchall()
            result = []
            for profile_row in profiles:
                profile = dict(profile_row)
                versions = connection.execute(
                    """SELECT rev.*, mpv.model_profile_id, mpv.model_id,
                              pbv.prompt_bundle_id,
                              pbv.digest AS prompt_bundle_digest
                       FROM review_engine_versions rev
                       JOIN model_profile_versions mpv
                         ON mpv.id=rev.model_profile_version_id
                       JOIN prompt_bundle_versions pbv
                         ON pbv.id=rev.prompt_bundle_version_id
                       WHERE rev.review_engine_profile_id=?
                       ORDER BY rev.version DESC""",
                    (profile["id"],),
                ).fetchall()
                profile["versions"] = [self._version_view(row) for row in versions]
                result.append(profile)
        return result

    def create_version(
        self,
        profile_id: str,
        actor: str,
        *,
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        config = normalize_review_config(config or {}, strict=True)
        forbidden = {"secret", "token", "password", "credential", "api_key"}
        if forbidden.intersection(key.lower() for key in config):
            raise ValueError("Review Engine config must not contain credential fields")
        at = iso()
        version_id = new_id("reviewengine")
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            profile = connection.execute(
                """SELECT rep.id, rev.model_profile_version_id,
                          rev.prompt_bundle_version_id
                   FROM review_engine_profiles rep
                   JOIN review_engine_versions rev ON rev.id=rep.active_version_id
                   WHERE rep.id=?""",
                (profile_id,),
            ).fetchone()
            if not profile:
                raise KeyError(profile_id)
            model_profile_version_id = profile["model_profile_version_id"]
            prompt_bundle_version_id = profile["prompt_bundle_version_id"]
            version = connection.execute(
                """SELECT COALESCE(MAX(version), 0)+1 AS next_version
                   FROM review_engine_versions WHERE review_engine_profile_id=?""",
                (profile_id,),
            ).fetchone()["next_version"]
            definition = {
                "profile_id": profile_id,
                "version": version,
                "engine_kind": "deterministic",
                "algorithm_version": "bounded-review.v1",
                "model_profile_version_id": model_profile_version_id,
                "prompt_bundle_version_id": prompt_bundle_version_id,
                "config": config,
            }
            connection.execute(
                """INSERT INTO review_engine_versions(
                   id, review_engine_profile_id, version, status, engine_kind,
                   algorithm_version, model_profile_version_id,
                   prompt_bundle_version_id, config_json, digest, created_by, created_at
                ) VALUES (?, ?, ?, 'draft', 'deterministic', 'bounded-review.v1',
                          ?, ?, ?, ?, ?, ?)""",
                (
                    version_id,
                    profile_id,
                    version,
                    model_profile_version_id,
                    prompt_bundle_version_id,
                    json.dumps(config, ensure_ascii=False, sort_keys=True),
                    _digest(definition),
                    actor,
                    at,
                ),
            )
            self._audit(
                connection,
                actor,
                "review_engine.version_created",
                profile_id,
                target_version=str(version),
                after_digest=_digest(definition),
                metadata={"version_id": version_id},
            )
            connection.commit()
        return self.get_version(version_id)

    def activate_version(self, profile_id: str, version_id: str, actor: str) -> dict[str, Any]:
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            profile = connection.execute(
                "SELECT * FROM review_engine_profiles WHERE id=?", (profile_id,)
            ).fetchone()
            version = connection.execute(
                """SELECT * FROM review_engine_versions
                   WHERE id=? AND review_engine_profile_id=?""",
                (version_id, profile_id),
            ).fetchone()
            if not profile or not version:
                raise KeyError(version_id)
            previous_id = profile["active_version_id"]
            if previous_id == version_id:
                connection.commit()
                return self.get_version(version_id)
            connection.execute(
                """UPDATE review_engine_versions SET status='historical'
                   WHERE review_engine_profile_id=? AND status='active'""",
                (profile_id,),
            )
            connection.execute(
                "UPDATE review_engine_versions SET status='active' WHERE id=?",
                (version_id,),
            )
            connection.execute(
                """UPDATE review_engine_profiles
                   SET active_version_id=?, status='active', updated_at=? WHERE id=?""",
                (version_id, at, profile_id),
            )
            self._audit(
                connection,
                actor,
                "review_engine.version_activated",
                profile_id,
                target_version=str(version["version"]),
                before_digest=(
                    connection.execute(
                        "SELECT digest FROM review_engine_versions WHERE id=?",
                        (previous_id,),
                    ).fetchone()["digest"]
                    if previous_id
                    else None
                ),
                after_digest=version["digest"],
                metadata={"version_id": version_id, "previous_version_id": previous_id},
            )
            connection.commit()
        return self.get_version(version_id)

    def get_version(self, version_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                """SELECT rev.*, mpv.model_profile_id, mpv.model_id,
                          pbv.prompt_bundle_id,
                          pbv.digest AS prompt_bundle_digest
                   FROM review_engine_versions rev
                   JOIN model_profile_versions mpv
                     ON mpv.id=rev.model_profile_version_id
                   JOIN prompt_bundle_versions pbv
                     ON pbv.id=rev.prompt_bundle_version_id
                   WHERE rev.id=?""",
                (version_id,),
            ).fetchone()
        if not row:
            raise KeyError(version_id)
        return self._version_view(row)

    @staticmethod
    def _version_view(row: sqlite3.Row) -> dict[str, Any]:
        item = dict(row)
        item["config"] = normalize_review_config(_loads(item.pop("config_json"), {}))
        item["runtime_effect"] = {
            "mode": "deterministic_rules",
            "model_calls": 0,
            "external_calls": 0,
            "automatic_agent_mutation": False,
        }
        if item["engine_kind"] == "deterministic":
            for unused_binding in (
                "model_profile_version_id",
                "prompt_bundle_version_id",
                "model_profile_id",
                "model_id",
                "prompt_bundle_id",
                "prompt_bundle_digest",
            ):
                item.pop(unused_binding, None)
        return item

    @staticmethod
    def _audit(
        connection: sqlite3.Connection,
        actor: str,
        action: str,
        target_id: str,
        *,
        target_version: str | None = None,
        before_digest: str | None = None,
        after_digest: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        connection.execute(
            """INSERT INTO audit_events(
               actor_type, actor_ref, action, target_type, target_id,
               target_version, before_digest, after_digest, result,
               metadata_json, created_at
            ) VALUES ('admin', ?, ?, 'review_engine', ?, ?, ?, ?, 'succeeded', ?, ?)""",
            (
                actor,
                action,
                target_id,
                target_version,
                before_digest,
                after_digest,
                json.dumps(metadata or {}, sort_keys=True),
                iso(),
            ),
        )


_KNOWN_GAPS: dict[str, dict[str, Any]] = {
    "evidence_provider_candidate": {
        "summary": "已审核案件可能缺少可复用的只读证据入口；重复性尚需门控确认。",
        "change_slice": {
            "layer": "tool_or_source_adapter",
            "scope": "evaluate one bounded read-only evidence contract",
        },
        "risk": ["source authorization", "privacy projection", "zero-match semantics"],
    },
    "runtime_reliability_candidate": {
        "summary": "已审核案件可能暴露运行可靠性缺口；重复性尚需门控确认。",
        "change_slice": {
            "layer": "runtime_or_model_adapter",
            "scope": "classify one repeated terminal failure without automatic retry",
        },
        "risk": ["retry amplification", "outcome ambiguity", "revision mismatch"],
    },
    "source_coverage_candidate": {
        "summary": "已审核案件可能暴露证据覆盖缺口；重复性尚需门控确认。",
        "change_slice": {
            "layer": "source_query_or_presentation",
            "scope": "test one coverage hypothesis against fixed synthetic cases",
        },
        "risk": ["zero-match overclaim", "truncation", "cross-source conflict"],
    },
    "other_candidate": {
        "summary": "已审核案件包含尚未归类的结构化能力缺口候选。",
        "change_slice": {
            "layer": "research_only",
            "scope": "classify before any implementation work",
        },
        "risk": ["insufficient classification", "single-case overfitting"],
    },
}


class ResearchService:
    """Aggregates approved safe Review projections; it has no Agent publish dependency."""

    def __init__(self, database: Database):
        self.database = database

    def generate(self, agent_id: str, actor: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            if not connection.execute("SELECT 1 FROM agents WHERE id=?", (agent_id,)).fetchone():
                raise KeyError(agent_id)
            reviews = connection.execute(
                """SELECT id, case_id, agent_version_scope_json,
                          model_profile_scope_json, pack_digest_scope_json,
                          capability_gaps_json, input_snapshot_hash
                   FROM reviews
                   WHERE agent_id=? AND status='approved'
                   ORDER BY created_at, id""",
                (agent_id,),
            ).fetchall()
            if not reviews:
                raise ValueError("Research requires at least one approved Review")

            projections = [self._review_projection(row) for row in reviews]
            input_snapshot_hash = _digest(projections)
            existing = connection.execute(
                """SELECT id FROM research_digests
                   WHERE agent_id=? AND input_snapshot_hash=?""",
                (agent_id, input_snapshot_hash),
            ).fetchone()
            if existing:
                return self.get_digest(existing["id"])

            capability_map = self._capability_map(connection, projections)
            digest_id = new_id("research")
            at = iso()
            kinds = sorted({kind for item in projections for kind in item["gap_kinds"]})
            summary = (
                f"基于 {len(projections)} 个已批准结构化 Review，发现 {len(kinds)} 类候选。"
                "该 Digest 不包含会话正文、人员标识或私有 URL，也不会修改或发布 Agent。"
            )
            risk = {
                "automatic_agent_mutation": False,
                "automatic_publish": False,
                "raw_message_content_consumed": False,
                "candidate_confirmation_requires_independent_cases": 2,
            }
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """INSERT INTO research_digests(
                   id, agent_id, input_snapshot_hash, status, summary,
                   existing_capability_map_json, risk_json, created_by, created_at
                ) VALUES (?, ?, ?, 'pending', ?, ?, ?, ?, ?)""",
                (
                    digest_id,
                    agent_id,
                    input_snapshot_hash,
                    summary,
                    json.dumps(capability_map, sort_keys=True),
                    json.dumps(risk, sort_keys=True),
                    actor,
                    at,
                ),
            )
            for item in projections:
                connection.execute(
                    """INSERT INTO research_digest_reviews(
                       research_digest_id, review_id, role
                    ) VALUES (?, ?, 'approved_source')""",
                    (digest_id, item["review_id"]),
                )
            for kind in kinds:
                supporting = [item for item in projections if kind in item["gap_kinds"]]
                counters = [item for item in projections if kind not in item["gap_kinds"]]
                common_revisions = self._common_values([item["agent_version_scope"] for item in supporting])
                independent_cases = len({item["case_id"] for item in supporting})
                definition = _KNOWN_GAPS[kind]
                validation = {
                    "minimum_independent_cases": 2,
                    "independent_case_count": independent_cases,
                    "common_agent_version_scope": common_revisions,
                    "confirmation_gate": (
                        "eligible"
                        if independent_cases >= 2 and common_revisions
                        else "insufficient_repeated_same_revision_evidence"
                    ),
                    "required_next_steps": [
                        "human confirmation",
                        "requirements and design",
                        "isolated implementation",
                        "multi-case validation",
                        "separate Agent Draft and publish acceptance",
                    ],
                    "stop_conditions": [
                        "contradicting approved review",
                        "revision scope diverges",
                        "source authorization unavailable",
                    ],
                }
                connection.execute(
                    """INSERT INTO capability_candidates(
                       id, research_digest_id, kind, summary, status,
                       supporting_review_count, counterexample_count,
                       support_refs_json, counter_refs_json,
                       existing_capability_map_json, change_slice_json,
                       risk_json, validation_json, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, 'discovered', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        new_id("candidate"),
                        digest_id,
                        kind,
                        definition["summary"],
                        len(supporting),
                        len(counters),
                        json.dumps([item["review_id"] for item in supporting]),
                        json.dumps([item["review_id"] for item in counters]),
                        json.dumps(capability_map, sort_keys=True),
                        json.dumps(definition["change_slice"], sort_keys=True),
                        json.dumps(definition["risk"], sort_keys=True),
                        json.dumps(validation, sort_keys=True),
                        at,
                        at,
                    ),
                )
            self._audit(
                connection,
                actor,
                "research.generated",
                "research_digest",
                digest_id,
                result="succeeded",
                metadata={
                    "agent_id": agent_id,
                    "approved_review_count": len(projections),
                    "candidate_count": len(kinds),
                    "input_snapshot_hash": input_snapshot_hash,
                },
            )
            connection.commit()
        return self.get_digest(digest_id)

    def list_digests(
        self,
        *,
        agent_id: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        query = "SELECT id FROM research_digests WHERE 1=1"
        params: list[Any] = []
        if agent_id:
            query += " AND agent_id=?"
            params.append(agent_id)
        if status:
            query += " AND status=?"
            params.append(status)
        query += " ORDER BY created_at DESC, id DESC"
        with self.database.connect() as connection:
            rows = connection.execute(query, params).fetchall()
        return [self.get_digest(row["id"]) for row in rows]

    def list_digests_page(
        self,
        *,
        agent_id: str | None = None,
        status: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        limit = max(1, min(limit, 500))
        offset = max(0, min(offset, 1_000_000))
        filters = " WHERE 1=1"
        params: list[Any] = []
        if agent_id:
            filters += " AND agent_id=?"
            params.append(agent_id)
        if status:
            filters += " AND status=?"
            params.append(status)
        with self.database.connect() as connection:
            total = int(
                connection.execute(
                    f"SELECT COUNT(*) FROM research_digests{filters}",
                    params,
                ).fetchone()[0]
            )
            rows = connection.execute(
                f"""SELECT id FROM research_digests{filters}
                    ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?""",
                [*params, limit, offset],
            ).fetchall()
        items = [self.get_digest(row["id"]) for row in rows]
        return {
            "items": items,
            "page": {
                "total": total,
                "limit": limit,
                "offset": offset,
                "has_previous": offset > 0,
                "has_next": offset + len(items) < total,
            },
        }

    def get_digest(self, digest_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute("SELECT * FROM research_digests WHERE id=?", (digest_id,)).fetchone()
            if not row:
                raise KeyError(digest_id)
            review_rows = connection.execute(
                """SELECT review_id, role FROM research_digest_reviews
                   WHERE research_digest_id=? ORDER BY review_id""",
                (digest_id,),
            ).fetchall()
            candidates = connection.execute(
                """SELECT * FROM capability_candidates
                   WHERE research_digest_id=? ORDER BY kind""",
                (digest_id,),
            ).fetchall()
        item = dict(row)
        item["existing_capability_map"] = _loads(item.pop("existing_capability_map_json"), [])
        item["risk"] = _loads(item.pop("risk_json"), {})
        item["review_refs"] = [dict(review) for review in review_rows]
        item["candidates"] = [self._candidate_view(candidate) for candidate in candidates]
        item["state_semantics"] = {
            "pending": "Digest awaits human decision",
            "approved": "research evidence accepted; no implementation or publish occurred",
            "rejected": "Digest rejected",
        }
        return item

    def decide_digest(
        self,
        digest_id: str,
        decision: str,
        actor: str,
        note: str,
    ) -> dict[str, Any]:
        if decision not in {"approved", "rejected"}:
            raise ValueError("decision must be approved or rejected")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT status FROM research_digests WHERE id=?", (digest_id,)
            ).fetchone()
            if not row:
                raise KeyError(digest_id)
            if row["status"] != "pending":
                raise ValueError("Research Digest already decided")
            connection.execute(
                """UPDATE research_digests
                   SET status=?, reviewer_ref=?, reviewer_note=?, decided_at=? WHERE id=?""",
                (decision, actor, note, at, digest_id),
            )
            if decision == "rejected":
                connection.execute(
                    """UPDATE capability_candidates SET status='rejected', updated_at=?
                       WHERE research_digest_id=? AND status='discovered'""",
                    (at, digest_id),
                )
            self._audit(
                connection,
                actor,
                "research.decided",
                "research_digest",
                digest_id,
                result=decision,
                metadata={"decision": decision},
            )
            connection.commit()
        return self.get_digest(digest_id)

    def decide_candidate(
        self,
        candidate_id: str,
        decision: str,
        actor: str,
    ) -> dict[str, Any]:
        if decision not in {"confirmed", "rejected"}:
            raise ValueError("decision must be confirmed or rejected")
        at = iso()
        with self.database.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT cc.*, rd.status AS digest_status
                   FROM capability_candidates cc
                   JOIN research_digests rd ON rd.id=cc.research_digest_id
                   WHERE cc.id=?""",
                (candidate_id,),
            ).fetchone()
            if not row:
                raise KeyError(candidate_id)
            if row["status"] != "discovered":
                raise ValueError("Research candidate already decided")
            if decision == "confirmed":
                validation = _loads(row["validation_json"], {})
                if row["digest_status"] != "approved":
                    raise ValueError("candidate confirmation requires an approved Digest")
                if validation.get("confirmation_gate") != "eligible":
                    raise ValueError(
                        "candidate requires two independent approved cases on a common Agent revision"
                    )
            connection.execute(
                "UPDATE capability_candidates SET status=?, updated_at=? WHERE id=?",
                (decision, at, candidate_id),
            )
            self._audit(
                connection,
                actor,
                "research_candidate.decided",
                "capability_candidate",
                candidate_id,
                result=decision,
                metadata={
                    "decision": decision,
                    "automatic_agent_mutation": False,
                    "automatic_publish": False,
                },
            )
            connection.commit()
        return self.get_candidate(candidate_id)

    def get_candidate(self, candidate_id: str) -> dict[str, Any]:
        with self.database.connect() as connection:
            row = connection.execute(
                "SELECT * FROM capability_candidates WHERE id=?", (candidate_id,)
            ).fetchone()
        if not row:
            raise KeyError(candidate_id)
        return self._candidate_view(row)

    @staticmethod
    def _review_projection(row: sqlite3.Row) -> dict[str, Any]:
        gap_kinds = []
        for gap in _loads(row["capability_gaps_json"], []):
            supplied = gap.get("kind") if isinstance(gap, dict) else None
            gap_kinds.append(supplied if supplied in _KNOWN_GAPS else "other_candidate")
        return {
            "review_id": row["id"],
            "case_id": row["case_id"],
            "input_snapshot_hash": row["input_snapshot_hash"],
            "agent_version_scope": sorted(_loads(row["agent_version_scope_json"], [])),
            "model_profile_scope": sorted(_loads(row["model_profile_scope_json"], [])),
            "pack_digest_scope": sorted(_loads(row["pack_digest_scope_json"], [])),
            "gap_kinds": sorted(set(gap_kinds)),
        }

    @staticmethod
    def _capability_map(
        connection: sqlite3.Connection,
        projections: list[dict[str, Any]],
    ) -> list[dict[str, str]]:
        digests = sorted({digest for projection in projections for digest in projection["pack_digest_scope"]})
        result = []
        for digest in digests:
            row = connection.execute(
                """SELECT pack_id, version, digest FROM capability_pack_versions
                   WHERE digest=?""",
                (digest,),
            ).fetchone()
            result.append(
                dict(row) if row else {"pack_id": "unmapped", "version": "unknown", "digest": digest}
            )
        return result

    @staticmethod
    def _common_values(scopes: list[list[str]]) -> list[str]:
        if not scopes:
            return []
        common = set(scopes[0])
        for scope in scopes[1:]:
            common.intersection_update(scope)
        return sorted(common)

    @staticmethod
    def _candidate_view(row: sqlite3.Row) -> dict[str, Any]:
        item = dict(row)
        for field in (
            "support_refs_json",
            "counter_refs_json",
            "existing_capability_map_json",
            "change_slice_json",
            "risk_json",
            "validation_json",
        ):
            item[field.removesuffix("_json")] = _loads(item.pop(field), [])
        item["state_semantics"] = {
            "discovered": "research candidate only",
            "confirmed": "repeated gap confirmed; no Agent Draft or publish occurred",
            "rejected": "candidate rejected",
        }
        return item

    @staticmethod
    def _audit(
        connection: sqlite3.Connection,
        actor: str,
        action: str,
        target_type: str,
        target_id: str,
        *,
        result: str,
        metadata: dict[str, Any],
    ) -> None:
        # Keep free-form notes and Review content out of Audit metadata.
        safe_metadata = {
            key: value
            for key, value in metadata.items()
            if re.fullmatch(r"[a-z0-9_]+", key) and key not in {"note", "content"}
        }
        connection.execute(
            """INSERT INTO audit_events(
               actor_type, actor_ref, action, target_type, target_id,
               result, metadata_json, created_at
            ) VALUES ('admin', ?, ?, ?, ?, ?, ?, ?)""",
            (
                actor,
                action,
                target_type,
                target_id,
                result,
                json.dumps(safe_metadata, sort_keys=True),
                iso(),
            ),
        )


DEFAULT_REVIEW_ENGINE_PROFILE_ID = REVIEW_ENGINE_PROFILE_ID
