from __future__ import annotations

import asyncio
import json
import logging
import uuid
from abc import ABC, abstractmethod
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from typing import Any
from urllib.parse import quote

import httpx

from .channel_registry import ChannelRegistry, ChannelResolutionError
from .channels import FeishuRuntimeConfig
from .config import FeishuConfig
from .feishu_cards import (
    STREAMING_ELEMENT_ID,
    card_reference,
    card_summary,
    markdown_card,
    streaming_card,
)
from .repository import Repository

logger = logging.getLogger(__name__)


class Sender(ABC):
    @abstractmethod
    async def send(
        self,
        channel: str,
        address: dict[str, Any],
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]: ...

    async def add_reaction(
        self,
        channel: str,
        address: dict[str, Any],
        message_id: str,
        emoji_type: str,
    ) -> bool:
        """Best-effort channel lifecycle feedback; never model-controlled."""

        return False

    async def remove_reaction(
        self,
        channel: str,
        address: dict[str, Any],
        message_id: str,
        emoji_type: str,
    ) -> bool:
        """Best-effort removal of this sender's lifecycle feedback."""

        return False


class DeliveryRejected(RuntimeError):
    """The Sender has a definitive non-delivery result."""


class CaptureSender(Sender):
    def __init__(self) -> None:
        self.deliveries: list[dict[str, Any]] = []
        self.reactions: list[dict[str, Any]] = []
        self.reaction_removals: list[dict[str, Any]] = []

    async def send(
        self,
        channel: str,
        address: dict[str, Any],
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]:
        receipt = {
            "channel": channel,
            "address": address,
            "payload": payload,
            "idempotency_key": idempotency_key,
        }
        self.deliveries.append(receipt)
        index = len(self.deliveries) - 1
        operation = payload.get("operation")
        if operation == "card_start":
            return {
                "state": "captured",
                "index": index,
                "card_id": f"capture-card-{index}",
                "message_id": f"capture-message-{index}",
                "sequence": 0,
            }
        if operation == "card_finish":
            return {
                "state": "captured",
                "index": index,
                "card_id": payload.get("card_id"),
                "message_id": payload.get("message_id"),
                "sequence": 2,
            }
        return {
            "state": "captured",
            "index": index,
            "message_id": f"capture-message-{index}",
        }

    async def add_reaction(
        self,
        channel: str,
        address: dict[str, Any],
        message_id: str,
        emoji_type: str,
    ) -> bool:
        self.reactions.append(
            {
                "channel": channel,
                "address": address,
                "message_id": message_id,
                "emoji_type": emoji_type,
            }
        )
        return True

    async def remove_reaction(
        self,
        channel: str,
        address: dict[str, Any],
        message_id: str,
        emoji_type: str,
    ) -> bool:
        self.reaction_removals.append(
            {
                "channel": channel,
                "address": address,
                "message_id": message_id,
                "emoji_type": emoji_type,
            }
        )
        return True


class FeishuSender(Sender):
    def __init__(
        self,
        config: FeishuConfig | FeishuRuntimeConfig,
        transport: httpx.AsyncBaseTransport | None = None,
        artifact_reader: Callable[[str, str], dict[str, object]] | None = None,
    ) -> None:
        if not config.app_id or not config.app_secret:
            raise ValueError("Feishu sender requires app id and app secret environment variables")
        self.config = config
        self.client = httpx.AsyncClient(
            base_url=config.api_base_url.rstrip("/"),
            timeout=30,
            transport=transport,
        )
        self._token: str | None = None
        self._token_expiry = datetime.min.replace(tzinfo=UTC)
        self.artifact_reader = artifact_reader

    async def _tenant_token(self) -> str:
        now = datetime.now(UTC)
        if self._token and now < self._token_expiry:
            return self._token
        response = await self.client.post(
            "/auth/v3/tenant_access_token/internal/",
            json={"app_id": self.config.app_id, "app_secret": self.config.app_secret},
        )
        response.raise_for_status()
        body = response.json()
        if body.get("code") != 0 or not body.get("tenant_access_token"):
            raise RuntimeError("Feishu tenant token request failed")
        self._token = body["tenant_access_token"]
        expires = max(60, int(body.get("expire", 3600)) - 300)
        self._token_expiry = now + timedelta(seconds=expires)
        return self._token

    async def send(
        self,
        channel: str,
        address: dict[str, Any],
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]:
        if channel != "feishu":
            raise ValueError("FeishuSender only handles the feishu channel")
        operation = payload.get("operation")
        if operation == "card_start":
            return await self._start_card(address, payload, idempotency_key)
        if operation == "card_finish":
            return await self._finish_card(payload, idempotency_key)
        if operation == "markdown_send":
            return await self._send_markdown_card(address, payload, idempotency_key)
        if operation == "image_send":
            return await self._send_artifact_image(address, payload, idempotency_key)
        return await self._send_message(address, "text", str(payload.get("text", "")), idempotency_key)

    async def _send_markdown_card(
        self,
        address: dict[str, Any],
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]:
        token = await self._tenant_token()
        response = await self.client.post(
            "/cardkit/v1/cards",
            headers={
                "Authorization": f"Bearer {token}",
                "X-Idempotency-Key": f"{idempotency_key}:card",
            },
            json={
                "type": "card_json",
                "data": json.dumps(
                    markdown_card(str(payload.get("text") or "")),
                    ensure_ascii=False,
                ),
            },
        )
        response.raise_for_status()
        body = response.json()
        card_id = body.get("data", {}).get("card_id")
        if body.get("code") != 0 or not card_id:
            raise DeliveryRejected("Feishu Markdown card creation was rejected")
        receipt = await self._send_message(
            address,
            "interactive",
            card_reference(str(card_id)),
            idempotency_key,
        )
        return {**receipt, "card_id": str(card_id), "sequence": 0}

    async def _send_artifact_image(
        self,
        address: dict[str, Any],
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]:
        if self.artifact_reader is None:
            raise DeliveryRejected("Feishu image delivery lacks a Run Artifact reader")
        artifact_id = str(payload.get("artifact_id") or "")
        case_id = str(payload.get("case_id") or "")
        if not artifact_id or not case_id:
            raise DeliveryRejected("Feishu image delivery lacks a Case-bound Artifact")
        try:
            artifact = self.artifact_reader(artifact_id, case_id)
        except (KeyError, ValueError) as exc:
            raise DeliveryRejected("Feishu image Artifact is unavailable for this Case") from exc
        media_type = str(artifact.get("media_type") or "")
        content = artifact.get("content")
        if media_type != "image/png" or not isinstance(content, bytes):
            raise DeliveryRejected("Feishu image Artifact must be a PNG")
        token = await self._tenant_token()
        response = await self.client.post(
            "/im/v1/images",
            headers={"Authorization": f"Bearer {token}"},
            data={"image_type": "message"},
            files={"image": (f"{artifact_id}.png", content, media_type)},
        )
        response.raise_for_status()
        body = response.json()
        image_key = body.get("data", {}).get("image_key")
        if body.get("code") != 0 or not image_key:
            raise DeliveryRejected("Feishu image upload was rejected")
        receipt = await self._send_message(
            address,
            "image",
            json.dumps({"image_key": str(image_key)}, ensure_ascii=False),
            idempotency_key,
        )
        return {**receipt, "image_key": str(image_key), "artifact_id": artifact_id}

    async def _send_message(
        self,
        address: dict[str, Any],
        msg_type: str,
        content: str,
        idempotency_key: str,
    ) -> dict[str, Any]:
        token = await self._tenant_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "X-Idempotency-Key": idempotency_key,
        }
        encoded_content = json.dumps({"text": content}, ensure_ascii=False) if msg_type == "text" else content
        reply_to = address.get("reply_to")
        if reply_to:
            response = await self.client.post(
                f"/im/v1/messages/{quote(str(reply_to), safe='')}/reply",
                headers=headers,
                json={
                    "msg_type": msg_type,
                    "content": encoded_content,
                    "reply_in_thread": bool(address.get("thread_id")),
                },
            )
        else:
            receive_id = address.get("chat_id")
            if not receive_id:
                raise ValueError("Feishu delivery address lacks chat_id")
            response = await self.client.post(
                "/im/v1/messages",
                params={"receive_id_type": "chat_id"},
                headers=headers,
                json={"receive_id": receive_id, "msg_type": msg_type, "content": encoded_content},
            )
        response.raise_for_status()
        body = response.json()
        if body.get("code") != 0:
            raise DeliveryRejected("Feishu message delivery was rejected")
        message_id = body.get("data", {}).get("message_id")
        return {"state": "sent", "message_id": message_id}

    async def _start_card(
        self,
        address: dict[str, Any],
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]:
        token = await self._tenant_token()
        response = await self.client.post(
            "/cardkit/v1/cards",
            headers={
                "Authorization": f"Bearer {token}",
                "X-Idempotency-Key": idempotency_key,
            },
            json={
                "type": "card_json",
                "data": json.dumps(
                    streaming_card(str(payload.get("text") or "...")),
                    ensure_ascii=False,
                ),
            },
        )
        response.raise_for_status()
        body = response.json()
        card_id = body.get("data", {}).get("card_id")
        if body.get("code") != 0 or not card_id:
            raise DeliveryRejected("Feishu CardKit card creation was rejected")
        receipt = await self._send_message(
            address,
            "interactive",
            card_reference(str(card_id)),
            idempotency_key,
        )
        return {**receipt, "card_id": str(card_id), "sequence": 0}

    async def _finish_card(
        self,
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]:
        card_id = str(payload.get("card_id") or "")
        message_id = str(payload.get("message_id") or "")
        if not card_id or not message_id:
            raise DeliveryRejected("Feishu card finish lacks card_id or message_id")
        token = await self._tenant_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "X-Idempotency-Key": idempotency_key,
        }
        content_sequence = int(payload.get("sequence") or 0) + 1
        response = await self.client.put(
            (
                f"/cardkit/v1/cards/{quote(card_id, safe='')}/elements/"
                f"{quote(STREAMING_ELEMENT_ID, safe='')}/content"
            ),
            headers=headers,
            json={
                "uuid": str(uuid.uuid4()),
                "content": str(payload.get("text") or ""),
                "sequence": content_sequence,
            },
        )
        response.raise_for_status()
        body = response.json()
        if body.get("code") != 0:
            raise DeliveryRejected("Feishu CardKit content update was rejected")

        finish_sequence = content_sequence + 1
        summary = card_summary(str(payload.get("summary") or payload.get("text") or "")) or "✅"
        response = await self.client.patch(
            f"/cardkit/v1/cards/{quote(card_id, safe='')}/settings",
            headers=headers,
            json={
                "settings": json.dumps(
                    {
                        "config": {
                            "streaming_mode": False,
                            "summary": {"content": summary},
                        }
                    },
                    ensure_ascii=False,
                ),
                "sequence": finish_sequence,
                "uuid": str(uuid.uuid4()),
            },
        )
        response.raise_for_status()
        body = response.json()
        if body.get("code") != 0:
            # The content update already succeeded.  A settings rejection cannot
            # safely trigger a second visible answer because the card may already
            # contain the complete reply.
            raise RuntimeError("Feishu CardKit finalization outcome is partial")
        return {
            "state": "sent",
            "card_id": card_id,
            "message_id": message_id,
            "sequence": finish_sequence,
        }

    async def add_reaction(
        self,
        channel: str,
        address: dict[str, Any],
        message_id: str,
        emoji_type: str,
    ) -> bool:
        if channel != "feishu" or not message_id or not emoji_type:
            return False
        token = await self._tenant_token()
        response = await self.client.post(
            f"/im/v1/messages/{quote(message_id, safe='')}/reactions",
            headers={"Authorization": f"Bearer {token}"},
            json={"reaction_type": {"emoji_type": emoji_type}},
        )
        response.raise_for_status()
        return response.json().get("code") == 0

    async def remove_reaction(
        self,
        channel: str,
        address: dict[str, Any],
        message_id: str,
        emoji_type: str,
    ) -> bool:
        if channel != "feishu" or not message_id or not emoji_type:
            return False
        token = await self._tenant_token()
        headers = {"Authorization": f"Bearer {token}"}
        response = await self.client.get(
            f"/im/v1/messages/{quote(message_id, safe='')}/reactions",
            headers=headers,
            params={"reaction_type": emoji_type, "page_size": 50},
        )
        response.raise_for_status()
        body = response.json()
        if body.get("code") != 0:
            return False
        own_operator_ids = {self.config.app_id, self.config.external_instance_ref}
        reaction_ids = []
        for item in (body.get("data") or {}).get("items") or []:
            operator = item.get("operator") or {}
            reaction_type = item.get("reaction_type") or {}
            reaction_id = item.get("reaction_id")
            if (
                operator.get("operator_type") == "app"
                and operator.get("operator_id") in own_operator_ids
                and reaction_type.get("emoji_type") == emoji_type
                and isinstance(reaction_id, str)
                and reaction_id
            ):
                reaction_ids.append(reaction_id)
        for reaction_id in reaction_ids:
            deleted = await self.client.delete(
                (
                    f"/im/v1/messages/{quote(message_id, safe='')}/reactions/"
                    f"{quote(reaction_id, safe='')}"
                ),
                headers=headers,
            )
            deleted.raise_for_status()
            if deleted.json().get("code") != 0:
                return False
        return True

    async def close(self) -> None:
        await self.client.aclose()


class ChannelSenderRouter(Sender):
    """Resolve the sender from the exact managed Channel Instance on each delivery."""

    def __init__(
        self,
        channels: ChannelRegistry,
        fallback: Sender,
        transport_factory: (Callable[[FeishuRuntimeConfig], httpx.AsyncBaseTransport | None] | None) = None,
        artifact_reader: Callable[[str, str], dict[str, object]] | None = None,
    ) -> None:
        self.channels = channels
        self.fallback = fallback
        self.transport_factory = transport_factory
        self.artifact_reader = artifact_reader
        self.capture = fallback if isinstance(fallback, CaptureSender) else CaptureSender()
        self._feishu_senders: dict[tuple[str, int, str], FeishuSender] = {}

    @property
    def deliveries(self) -> list[dict[str, Any]]:
        return self.capture.deliveries

    async def send(
        self,
        channel: str,
        address: dict[str, Any],
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]:
        instance_id = address.get("channel_instance")
        if channel != "feishu" or not isinstance(instance_id, str) or not instance_id:
            return await self.fallback.send(channel, address, payload, idempotency_key)

        try:
            config = self.channels.resolve_feishu_runtime(instance_id)
        except ChannelResolutionError as exc:
            raise DeliveryRejected(f"managed Channel rejected delivery: {exc}") from exc
        if not self._address_matches_runtime(address, config):
            raise DeliveryRejected("managed Channel revision changed before delivery")
        if config.sender == "capture":
            return await self.capture.send(channel, address, payload, idempotency_key)
        if not self._managed_sender_authorized(config):
            raise DeliveryRejected("managed Channel sender authorization is incomplete")
        if not address.get("reply_to"):
            raise DeliveryRejected("managed Feishu sender only permits replies to admitted events")

        sender = await self._managed_sender(config)
        return await sender.send(channel, address, payload, idempotency_key)

    async def add_reaction(
        self,
        channel: str,
        address: dict[str, Any],
        message_id: str,
        emoji_type: str,
    ) -> bool:
        instance_id = address.get("channel_instance")
        if channel != "feishu" or not isinstance(instance_id, str) or not instance_id:
            try:
                return await self.fallback.add_reaction(
                    channel,
                    address,
                    message_id,
                    emoji_type,
                )
            except Exception:
                return False
        try:
            config = self.channels.resolve_feishu_runtime(instance_id)
            if not self._address_matches_runtime(address, config):
                return False
            if config.sender == "capture":
                return await self.capture.add_reaction(
                    channel,
                    address,
                    message_id,
                    emoji_type,
                )
            if not self._managed_sender_authorized(config):
                return False
            sender = await self._managed_sender(config)
            return await sender.add_reaction(
                channel,
                address,
                message_id,
                emoji_type,
            )
        except Exception:
            # Reactions are lifecycle hints: their failure must never reject
            # an admitted message or change a reply receipt.
            return False

    async def remove_reaction(
        self,
        channel: str,
        address: dict[str, Any],
        message_id: str,
        emoji_type: str,
    ) -> bool:
        instance_id = address.get("channel_instance")
        if channel != "feishu" or not isinstance(instance_id, str) or not instance_id:
            try:
                return await self.fallback.remove_reaction(
                    channel,
                    address,
                    message_id,
                    emoji_type,
                )
            except Exception:
                return False
        try:
            config = self.channels.resolve_feishu_runtime(instance_id)
            if not self._address_matches_runtime(address, config):
                return False
            if config.sender == "capture":
                return await self.capture.remove_reaction(
                    channel,
                    address,
                    message_id,
                    emoji_type,
                )
            if not self._managed_sender_authorized(config):
                return False
            sender = await self._managed_sender(config)
            return await sender.remove_reaction(
                channel,
                address,
                message_id,
                emoji_type,
            )
        except Exception:
            return False

    @staticmethod
    def _address_matches_runtime(
        address: dict[str, Any],
        config: FeishuRuntimeConfig,
    ) -> bool:
        expected_transport = address.get("channel_transport_identity")
        if expected_transport is not None:
            return (
                isinstance(expected_transport, str)
                and expected_transport == config.transport_identity
            )
        expected_revision = address.get("channel_revision")
        return expected_revision is None or (
            isinstance(expected_revision, int)
            and not isinstance(expected_revision, bool)
            and expected_revision == config.revision
        )

    @staticmethod
    def _managed_sender_authorized(config: FeishuRuntimeConfig) -> bool:
        return (
            config.sender == "feishu"
            and config.mode in {"verified", "long_connection"}
            and config.external_writes == 1
            and config.outbound_mode == "reply_only"
            and bool(config.approval_note.strip())
        )

    async def _managed_sender(self, config: FeishuRuntimeConfig) -> FeishuSender:
        key = (config.instance_id, config.revision, config.credential_revision)
        sender = self._feishu_senders.get(key)
        if sender is None:
            for stale_key in [item for item in self._feishu_senders if item[0] == config.instance_id]:
                await self._feishu_senders.pop(stale_key).close()
            transport = self.transport_factory(config) if self.transport_factory else None
            sender = FeishuSender(
                config,
                transport=transport,
                artifact_reader=self.artifact_reader,
            )
            self._feishu_senders[key] = sender
        return sender

    async def close(self) -> None:
        for sender in self._feishu_senders.values():
            await sender.close()
        self._feishu_senders.clear()
        close_fallback = getattr(self.fallback, "close", None)
        if close_fallback:
            await close_fallback()


def build_sender(
    config: FeishuConfig,
    *,
    artifact_reader: Callable[[str, str], dict[str, object]] | None = None,
) -> Sender:
    if config.sender == "capture":
        return CaptureSender()
    if config.sender == "feishu":
        return FeishuSender(config, artifact_reader=artifact_reader)
    raise ValueError(f"unsupported Feishu sender: {config.sender}")


class OutboxDispatcher:
    def __init__(self, repository: Repository, sender: Sender):
        self.repository = repository
        self.sender = sender
        self.owner = f"dispatcher-{uuid.uuid4().hex}"
        self._lock = asyncio.Lock()
        self._inflight: dict[str, asyncio.Future[bool]] = {}

    async def run_once(self) -> int:
        async with self._lock:
            now = datetime.now(UTC)
            items = self.repository.lease_pending_outbox(
                self.owner,
                now,
                now + timedelta(seconds=30),
            )
            loop = asyncio.get_running_loop()
            for item in items:
                self._inflight[item["id"]] = loop.create_future()
        sent = 0
        try:
            for item in items:
                delivered = False
                try:
                    if await self._deliver(item):
                        sent += 1
                        delivered = True
                finally:
                    self._finish_inflight(item["id"], delivered)
        finally:
            for item in items:
                self._finish_inflight(item["id"], False)
        return sent

    async def dispatch_outbox(self, outbox_id: str) -> dict[str, Any]:
        """Deliver one exact durable operation without racing the scheduler."""

        item: dict[str, Any] | None = None
        async with self._lock:
            inflight = self._inflight.get(outbox_id)
            if inflight is None:
                loop = asyncio.get_running_loop()
                inflight = loop.create_future()
                self._inflight[outbox_id] = inflight
            now = datetime.now(UTC)
            if not inflight.done():
                item = self.repository.lease_outbox(
                    outbox_id,
                    self.owner,
                    now,
                    now + timedelta(seconds=30),
                )
            if item is None and self._inflight.get(outbox_id) is inflight:
                stored = self.repository.get_outbox(outbox_id)
                if stored["status"] != "sending" or stored.get("lease_owner") != self.owner:
                    self._finish_inflight(outbox_id, stored["status"] in {"sent", "captured"})

        if item is not None:
            delivered = False
            try:
                delivered = await self._deliver(item)
            finally:
                self._finish_inflight(outbox_id, delivered)
        elif not inflight.done():
            await asyncio.shield(inflight)
        return self.repository.get_outbox(outbox_id)

    def _finish_inflight(self, outbox_id: str, delivered: bool) -> None:
        future = self._inflight.pop(outbox_id, None)
        if future is not None and not future.done():
            future.set_result(delivered)

    async def _deliver(self, item: dict[str, Any]) -> bool:
        address = json.loads(item["address_json"])
        payload = json.loads(item["payload_json"])
        try:
            receipt = await self.sender.send(
                item["channel"],
                address,
                payload,
                item["idempotency_key"],
            )
        except DeliveryRejected as exc:
            self.repository.mark_outbox(item["id"], "failed", str(exc))
            return False
        except Exception as exc:
            self.repository.mark_outbox(
                item["id"],
                "outcome_unknown",
                f"{type(exc).__name__}: delivery outcome unavailable",
            )
            return False

        outcome = str(receipt.get("state") or "outcome_unknown")
        if outcome not in {"sent", "captured"}:
            outcome = "outcome_unknown"
        self.repository.mark_outbox(item["id"], outcome, receipt=receipt)
        if outcome not in {"sent", "captured"}:
            return False

        message_id = receipt.get("message_id")
        if not message_id or item["case_id"] is None:
            return True
        channel_instance = str(address.get("channel_instance") or "default")
        operation = str(payload.get("operation") or "message_send")
        try:
            self.repository.link_external_message(
                item["channel"],
                channel_instance,
                str(message_id),
                item["case_id"],
                None,
                direction="outbound",
                message_kind=(
                    "card"
                    if operation.startswith("card_") or operation == "markdown_send"
                    else "image"
                    if operation == "image_send"
                    else "text"
                ),
                internal_message_id=payload.get("internal_message_id"),
                run_id=payload.get("run_id"),
                created_outbox_id=(item["id"] if operation == "card_start" else None),
                last_outbox_id=item["id"],
                card_id=(receipt.get("card_id") or payload.get("card_id")),
                parent_message_ref=(str(address.get("parent_id")) if address.get("parent_id") else None),
                root_message_ref=(str(address.get("root_id")) if address.get("root_id") else None),
                thread_ref=(str(address.get("thread_id")) if address.get("thread_id") else None),
                lifecycle_state=str(payload.get("lifecycle_state") or "sent"),
                channel_revision=(
                    address.get("channel_revision")
                    if isinstance(address.get("channel_revision"), int)
                    else None
                ),
            )
        except Exception:
            # The external outcome is already known and must never be rewritten as
            # uncertain merely because local receipt indexing failed.
            logger.exception("failed to persist external message linkage")

        if payload.get("lifecycle_state") == "answered" and operation != "card_start":
            try:
                # Lifecycle feedback belongs to the admitted user message.  The
                # outbound message id is only a delivery receipt; reacting to it
                # leaves the question/topic looking unfinished in Feishu.
                completion_message_id = str(address.get("reply_to") or "")
                if completion_message_id:
                    completed = await self.sender.add_reaction(
                        item["channel"],
                        address,
                        completion_message_id,
                        "DONE",
                    )
                    if completed:
                        await self.sender.remove_reaction(
                            item["channel"],
                            address,
                            completion_message_id,
                            "Typing",
                        )
            except Exception:
                logger.debug("Feishu DONE reaction failed", exc_info=True)
        self._enqueue_artifact_image_followups(item, address, payload, operation)
        return True

    def _enqueue_artifact_image_followups(
        self,
        item: dict[str, Any],
        address: dict[str, Any],
        payload: dict[str, Any],
        operation: str,
    ) -> None:
        """Create image operations only after the owning Markdown reply landed."""

        if (
            item["channel"] != "feishu"
            or operation not in {"card_finish", "markdown_send"}
            or item["case_id"] is None
        ):
            return
        images = payload.get("artifact_images")
        if not isinstance(images, list):
            return
        run_id = payload.get("run_id")
        internal_message_id = payload.get("internal_message_id")
        for image in images:
            if not isinstance(image, dict):
                continue
            artifact_id = image.get("artifact_id")
            alt = image.get("alt")
            if not isinstance(artifact_id, str) or not artifact_id:
                continue
            self.repository.enqueue_outbox(
                item["case_id"],
                item["channel"],
                address,
                {
                    "type": "image",
                    "operation": "image_send",
                    "artifact_id": artifact_id,
                    "case_id": item["case_id"],
                    "alt": alt if isinstance(alt, str) else "说明图",
                    "internal_message_id": internal_message_id,
                    "run_id": run_id,
                    "lifecycle_state": "answered_attachment",
                },
                f"reply-image:{run_id or internal_message_id}:{artifact_id}",
            )
