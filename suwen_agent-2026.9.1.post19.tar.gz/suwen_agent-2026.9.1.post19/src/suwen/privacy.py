from __future__ import annotations

import re
from typing import Any

from .security import redact_sensitive

_SENSITIVE_KEY = re.compile(
    r"(?:^|[_-])(?:api[_-]?key|access[_-]?token|refresh[_-]?token|action[_-]?token|"
    r"secret|password|passwd|authorization|cookie|signature|credential|private[_-]?key)"
    r"(?:$|[_-])",
    re.IGNORECASE,
)
_MAX_COLLECTION_ITEMS = 256
_MAX_STRING_CHARS = 100_000
_MAX_DEPTH = 16


def sanitize_provider_payload(value: Any, *, _depth: int = 0) -> Any:
    """Return bounded JSON-safe evidence while excluding credential-bearing leaves.

    Business identifiers, names, URLs, file paths, logs, errors and source results are
    evidence and remain visible to both the model and authenticated management views.
    """

    if _depth >= _MAX_DEPTH:
        return "[TRUNCATED_DEPTH]"
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for index, (raw_key, item) in enumerate(value.items()):
            if index >= _MAX_COLLECTION_ITEMS:
                result["_truncated_items"] = len(value) - _MAX_COLLECTION_ITEMS
                break
            key = str(raw_key)[:500]
            if _SENSITIVE_KEY.search(key):
                result[key] = "[REDACTED]"
            else:
                result[key] = sanitize_provider_payload(item, _depth=_depth + 1)
        return result
    if isinstance(value, (list, tuple)):
        items = [sanitize_provider_payload(item, _depth=_depth + 1) for item in value[:_MAX_COLLECTION_ITEMS]]
        if len(value) > _MAX_COLLECTION_ITEMS:
            items.append({"_truncated_items": len(value) - _MAX_COLLECTION_ITEMS})
        return items
    if isinstance(value, str):
        return str(redact_sensitive(value))[:_MAX_STRING_CHARS]
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return str(redact_sensitive(str(value)))[:_MAX_STRING_CHARS]
