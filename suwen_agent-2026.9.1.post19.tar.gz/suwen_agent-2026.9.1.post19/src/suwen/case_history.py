from __future__ import annotations

import json
import re
from typing import Any

from .repository import Repository
from .tools import ToolRegistry
from .types import EvidenceEnvelope, EvidenceState, ToolDefinition, ToolRisk

CASE_RECALL_TOOL_NAME = "recall_case_history"
_NON_DOMAIN_SOURCE_ROLES = frozenset({"case_history_recall"})
_OPAQUE_HEX_IDENTIFIER = re.compile(
    r"(?<![0-9A-Fa-f])[0-9A-Fa-f]{20,40}(?![0-9A-Fa-f])"
)
_MAX_RECALLED_REPLY_IDENTIFIERS = 32


def _json_value(raw: Any, fallback: Any) -> Any:
    if raw is None:
        return fallback
    try:
        return json.loads(str(raw))
    except (TypeError, ValueError, json.JSONDecodeError):
        return fallback


def _business_evidence(repository: Repository, case_id: str) -> list[dict[str, Any]]:
    return [
        item
        for item in repository.list_evidence(case_id)
        if str(item.get("source_role") or "") not in _NON_DOMAIN_SOURCE_ROLES
        and not str(item.get("source_role") or "").startswith("capability_")
    ]


def has_recallable_case_history(
    repository: Repository,
    case_id: str,
    *,
    exclude_run_id: str | None = None,
) -> bool:
    evidence_run_ids = {str(item["run_id"]) for item in _business_evidence(repository, case_id)}
    return any(run_id != exclude_run_id for run_id in evidence_run_ids)


def case_history_index(
    repository: Repository,
    case_id: str,
    *,
    exclude_run_id: str | None = None,
    limit: int = 8,
) -> str:
    """Return a compact address map, not the historical facts themselves."""

    evidence_counts: dict[str, int] = {}
    for item in _business_evidence(repository, case_id):
        run_id = str(item["run_id"])
        evidence_counts[run_id] = evidence_counts.get(run_id, 0) + 1
    runs = [
        run
        for run in repository.list_runs(case_id)
        if run["id"] != exclude_run_id and run.get("status") != "running" and run["id"] in evidence_counts
    ][-limit:]
    if not runs:
        return ""
    lines = [
        "[case history index]",
        "下列既往 Run、答复和 Evidence 已持久化。Runtime 只会自动投影与当前请求或对象"
        "明确相关的类型化既往事实；完整正文和其余证据不会自动塞入当前上下文。",
        f"用户追问既往结论、证据链或要求继续时，先调用 `{CASE_RECALL_TOOL_NAME}`，"
        "不要重新执行领域取证来重建已存在的结果。",
    ]
    for run in runs:
        reply = repository.reply_for_run(run["id"])
        lines.append(
            f"- run_id={run['id']} status={run.get('status') or 'unknown'} "
            f"stop_reason={run.get('stop_reason') or 'unknown'} "
            f"evidence={evidence_counts.get(str(run['id']), 0)} "
            f"reply={'yes' if reply else 'no'}"
        )
    return "\n".join(lines)


def _project_evidence(
    rows: list[dict[str, Any]],
    tool_names: dict[str, str],
) -> list[dict[str, Any]]:
    projected: list[dict[str, Any]] = []
    for row in rows:
        projected.append(
            {
                "evidence_id": row["id"],
                "tool_call_id": row.get("tool_call_id"),
                "tool_name": tool_names.get(str(row.get("tool_call_id") or "")),
                "state": row.get("state"),
                "coverage_state": row.get("coverage_state"),
                "truncation_state": row.get("truncation_state"),
                "source_ref": row.get("source_ref"),
                "source_role": row.get("source_role"),
                "summary": row.get("summary"),
                "data": _json_value(row.get("data_json"), {}),
                "limitations": _json_value(row.get("limitations_json"), []),
                "safe_statements": _json_value(row.get("safe_statements_json"), []),
                "continuation": _json_value(row.get("continuation_json"), None),
                "observed_at": row.get("observed_at"),
            }
        )
    return projected


def _reply_identifiers_grounded_by_evidence(
    reply: dict[str, Any] | None,
    rows: list[dict[str, Any]],
) -> tuple[str, ...]:
    """Keep only prior-reply identifiers that the recalled Evidence also contains.

    A prior assistant reply remains useful Case context, but it is not itself an
    Evidence source.  Intersecting its opaque identifiers with the selected
    historical Evidence lets a later Run reuse supported identifiers after Tool
    context compaction without turning old assistant text into authority.
    """

    if not reply or not rows:
        return ()
    evidence_identifiers: set[str] = set()
    for row in rows:
        corpus = "\n".join(
            str(row.get(field) or "")
            for field in (
                "summary",
                "data_json",
                "safe_statements_json",
                "source_ref",
            )
        )
        evidence_identifiers.update(
            match.group(0).casefold() for match in _OPAQUE_HEX_IDENTIFIER.finditer(corpus)
        )

    grounded: list[str] = []
    seen: set[str] = set()
    for match in _OPAQUE_HEX_IDENTIFIER.finditer(str(reply.get("content") or "")):
        identifier = match.group(0)
        normalized = identifier.casefold()
        if normalized in evidence_identifiers and normalized not in seen:
            grounded.append(identifier)
            seen.add(normalized)
        if len(grounded) >= _MAX_RECALLED_REPLY_IDENTIFIERS:
            break
    return tuple(grounded)


def _run_projection(
    repository: Repository,
    case_id: str,
    run: dict[str, Any],
    *,
    offset: int,
    limit: int,
) -> EvidenceEnvelope:
    rows = [item for item in _business_evidence(repository, case_id) if item["run_id"] == run["id"]]
    selected = rows[offset : offset + limit]
    next_offset = offset + len(selected)
    partial = next_offset < len(rows)
    reply = repository.reply_for_run(run["id"])
    reply_grounded_identifiers = _reply_identifiers_grounded_by_evidence(reply, selected)
    tool_names = {
        str(item["id"]): str(item["tool_name"]) for item in repository.list_run_tool_calls(run["id"])
    }
    if not selected and reply is None:
        return EvidenceEnvelope(
            state=EvidenceState.ZERO_MATCHES,
            summary="该既往 Run 没有可召回的领域 Evidence 或最终答复。",
            data={"run_id": run["id"], "evidence": []},
            coverage_state="proven_total",
            source_ref=f"case:{case_id}:run:{run['id']}",
            source_role="case_history_recall",
            safe_statements=("未重新执行任何领域工具",),
        )
    continuation = (
        {
            "operation": "run",
            "run_id": run["id"],
            "offset": next_offset,
            "limit": limit,
        }
        if partial
        else None
    )
    return EvidenceEnvelope(
        state=EvidenceState.TRUNCATED if partial else EvidenceState.OBSERVED,
        summary=(f"已召回既往 Run {run['id']} 的 {len(selected)} 项领域 Evidence；没有重新执行领域工具。"),
        data={
            "run": {
                "run_id": run["id"],
                "status": run.get("status"),
                "stop_reason": run.get("stop_reason"),
                "started_at": run.get("started_at"),
                "finished_at": run.get("finished_at"),
            },
            "reply": ({"message_id": reply["id"], "content": reply["content"]} if reply else None),
            "evidence": _project_evidence(selected, tool_names),
            "reply_grounded_identifiers": list(reply_grounded_identifiers),
            "offset": offset,
            "returned": len(selected),
            "total": len(rows),
        },
        coverage_state="bounded" if partial else "proven_total",
        truncation_state="partial" if partial else "complete",
        source_ref=f"case:{case_id}:run:{run['id']}",
        source_role="case_history_recall",
        limitations=("case_history_continuation_required",) if partial else (),
        safe_statements=(
            "内容只来自当前 Case 已持久化的模型可见 Evidence 与最终答复",
            "未重新执行任何领域工具",
            *(
                (
                    "既往最终答复中的以下不透明标识逐字符存在于已召回 Evidence："
                    + "、".join(reply_grounded_identifiers),
                )
                if reply_grounded_identifiers
                else ()
            ),
        ),
        continuation=continuation,
    )


def register_case_recall_tool(repository: Repository, registry: ToolRegistry) -> None:
    """Register a Case-bound recall tool; the case id is injected by Runtime."""

    def recall(arguments: dict[str, Any]) -> EvidenceEnvelope:
        runtime_context = arguments.get("_runtime_context")
        if not isinstance(runtime_context, dict):
            raise ValueError("case recall requires Runtime context")
        case_id = str(runtime_context.get("case_id") or "")
        current_run_id = str(runtime_context.get("run_id") or "")
        if not case_id or not current_run_id:
            raise ValueError("case recall requires current Case and Run")
        runs = [
            run
            for run in repository.list_runs(case_id)
            if run["id"] != current_run_id and run.get("status") != "running"
        ]
        operation = str(arguments["operation"])
        limit = int(arguments.get("limit", 12))
        offset = int(arguments.get("offset", 0))

        if operation == "search":
            query = str(arguments.get("query") or "").strip().lower()
            if not query:
                raise ValueError("history search requires query")
            matches: list[dict[str, Any]] = []
            replies = {run["id"]: repository.reply_for_run(run["id"]) for run in runs}
            for row in _business_evidence(repository, case_id):
                if row["run_id"] == current_run_id:
                    continue
                corpus = " ".join(
                    str(row.get(key) or "") for key in ("summary", "source_ref", "state")
                ).lower()
                if query in corpus:
                    matches.append(
                        {
                            "run_id": row["run_id"],
                            "evidence_id": row["id"],
                            "state": row.get("state"),
                            "summary": row.get("summary"),
                            "source_ref": row.get("source_ref"),
                        }
                    )
            for run_id, reply in replies.items():
                if reply and query in str(reply.get("content") or "").lower():
                    matches.append(
                        {
                            "run_id": run_id,
                            "message_id": reply["id"],
                            "kind": "assistant_reply",
                        }
                    )
            selected = matches[offset : offset + limit]
            partial = offset + len(selected) < len(matches)
            return EvidenceEnvelope(
                state=(
                    EvidenceState.TRUNCATED
                    if partial
                    else EvidenceState.OBSERVED
                    if selected
                    else EvidenceState.ZERO_MATCHES
                ),
                summary=f"案件历史搜索命中 {len(selected)} 个可召回地址。",
                data={"query": query, "matches": selected, "total": len(matches)},
                coverage_state="bounded" if partial else "proven_total",
                truncation_state="partial" if partial else "complete",
                source_ref=f"case:{case_id}:history-search",
                source_role="case_history_recall",
                limitations=("case_history_continuation_required",) if partial else (),
                safe_statements=("搜索只返回当前 Case 已持久化记录的地址和摘要",),
                continuation=(
                    {
                        "operation": "search",
                        "query": query,
                        "offset": offset + len(selected),
                        "limit": limit,
                    }
                    if partial
                    else None
                ),
            )

        if operation == "latest":
            evidence_run_ids = {str(item["run_id"]) for item in _business_evidence(repository, case_id)}
            target = next(
                (run for run in reversed(runs) if run["id"] in evidence_run_ids),
                runs[-1] if runs else None,
            )
        else:
            requested_run_id = str(arguments.get("run_id") or "")
            target = next((run for run in runs if run["id"] == requested_run_id), None)
        if target is None:
            return EvidenceEnvelope(
                state=EvidenceState.ZERO_MATCHES,
                summary="当前 Case 没有符合条件的既往 Run。",
                data={"evidence": []},
                coverage_state="proven_total",
                source_ref=f"case:{case_id}:history",
                source_role="case_history_recall",
                safe_statements=("未读取其他 Case", "未重新执行领域工具"),
            )
        return _run_projection(repository, case_id, target, offset=offset, limit=limit)

    registry.register(case_recall_tool_definition(), recall)


def case_recall_tool_definition() -> ToolDefinition:
    """Return the canonical Case recall contract without reading the repository."""

    return ToolDefinition(
        name=CASE_RECALL_TOOL_NAME,
        description=(
            "按需召回当前 Case 已持久化的既往 Run、最终答复和领域 Evidence。"
            "当用户追问上轮证据链、要求继续或引用既往结论时，优先使用 operation=latest；"
            "已知稳定 Run ID 时使用 operation=run；需要定位更早记录时使用 operation=search。"
            "本工具只读历史，不重新执行任何领域工具。"
        ),
        input_schema={
            "type": "object",
            "properties": {
                "operation": {"type": "string", "enum": ["latest", "run", "search"]},
                "run_id": {"type": "string", "minLength": 1, "maxLength": 128},
                "query": {"type": "string", "minLength": 1, "maxLength": 200},
                "offset": {"type": "integer", "minimum": 0, "maximum": 10_000},
                "limit": {"type": "integer", "minimum": 1, "maximum": 20},
            },
            "required": ["operation"],
            "oneOf": [
                {
                    "properties": {"operation": {"const": "latest"}},
                    "required": ["operation"],
                },
                {
                    "properties": {
                        "operation": {"const": "run"},
                        "run_id": {"type": "string", "minLength": 1, "maxLength": 128},
                    },
                    "required": ["operation", "run_id"],
                },
                {
                    "properties": {
                        "operation": {"const": "search"},
                        "query": {"type": "string", "minLength": 1, "maxLength": 200},
                    },
                    "required": ["operation", "query"],
                },
            ],
            "additionalProperties": False,
        },
        risk=ToolRisk.READ_ONLY,
        provider_id="runtime-core",
    )
