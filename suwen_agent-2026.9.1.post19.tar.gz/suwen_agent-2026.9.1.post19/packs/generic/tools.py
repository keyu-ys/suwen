from suwen.tools import ToolRegistry
from suwen.types import EvidenceEnvelope, EvidenceState, ToolDefinition, ToolRisk


def register_tools(registry: ToolRegistry) -> None:
    def inspect_claim(arguments):
        claim = str(arguments.get("claim", "")).strip()
        if not claim:
            return EvidenceEnvelope(
                state=EvidenceState.ZERO_MATCHES,
                summary="没有提供可检查的主张。",
                coverage_state="proven_total",
            )
        return EvidenceEnvelope(
            state=EvidenceState.OBSERVED,
            summary=f"已记录待核验主张：{claim}",
            data={"claim": claim, "kind": "user_statement"},
            coverage_state="bounded",
            source_ref="generic:inspect_claim",
        )

    registry.register(
        ToolDefinition(
            name="inspect_claim",
            description="Record one bounded claim as a user statement for further diagnosis.",
            input_schema={
                "type": "object",
                "properties": {"claim": {"type": "string"}},
                "required": ["claim"],
                "additionalProperties": False,
            },
            risk=ToolRisk.READ_ONLY,
            provider_id="builtin-generic",
        ),
        inspect_claim,
    )
