const state = {
  adminTab: "overview",
  releaseVersion: "",
  activeAgentId: "",
  agentSettingsTab: "general",
  agentUsage: null,
  session: { role: "viewer", permissions: { view: true, operate: false, review: false, administer: false } },
  agents: [],
  agentCatalog: [],
  personas: [],
  agentPage: { total: 0, limit: 20, offset: 0, has_previous: false, has_next: false },
  agentProfiles: [],
  nativeReleases: { artifacts: [], installations: [], external_bindings: [] },
  domainExperts: [],
  profiles: [],
  profileCatalog: [],
  profilePage: { total: 0, limit: 20, offset: 0, has_previous: false, has_next: false },
  providers: [],
  providerCatalog: [],
  providerPage: { total: 0, limit: 20, offset: 0, has_previous: false, has_next: false },
  modelProviderQuery: "",
  secrets: [],
  packs: [],
  packDiscoveries: [],
  prompts: [],
  nativeReadiness: null,
  deliveryPreflight: null,
  toolProviders: [],
  tools: [],
  channels: [],
  agentChannels: [],
  outbox: [],
  reviewEngines: [],
  reviews: [],
  reviewPage: { total: 0, limit: 50, offset: 0, has_previous: false, has_next: false },
  reviewFilters: {
    status: "",
    agent_id: "",
    model_profile_version_id: "",
    capability_gap: "",
    created_from: "",
    created_to: "",
  },
  researchDigests: [],
  researchPage: { total: 0, limit: 20, offset: 0, has_previous: false, has_next: false },
  candidatePreflight: null,
  candidateAttempts: [],
  candidatePage: { total: 0, limit: 20, offset: 0, has_previous: false, has_next: false },
  overview: null,
  adminCases: [],
  casePage: { total: 0, limit: 50, offset: 0, has_previous: false, has_next: false },
  selectedCaseId: "",
  selectedConversationItemId: "",
  caseConversation: null,
  expandedExecutionGroups: {},
  jobs: [],
  jobPage: { total: 0, limit: 50, offset: 0, has_previous: false, has_next: false },
  outboxPage: { total: 0, limit: 50, offset: 0, has_previous: false, has_next: false },
  audit: [],
  auditPage: { total: 0, limit: 20, offset: 0, has_previous: false, has_next: false },
  auditFilters: { actor_ref: "", target_type: "", action: "", result: "", created_from: "", created_to: "" },
  system: null,
  glossaryLoaded: false,
};

const ADMIN_TAB_META = Object.freeze({
  overview: ["总览", "健康总览", "", "实例"],
  agents: ["智能体", "智能体设置", "", "智能体配置"],
  models: ["模型资源", "提供商", "", "实例配置"],
  connectors: ["连接器", "连接器", "", "实例配置"],
  tools: ["工具", "工具", "", "实例配置"],
  experts: ["领域专家", "领域专家", "", "实例配置"],
  channels: ["频道", "频道", "", "智能体配置"],
  cases: ["案件", "案件管理", "", "实例运行"],
  runs: ["诊断记录", "诊断记录", "", "实例运行"],
  audit: ["变更审计", "变更审计", "", "系统管理"],
  glossary: ["词汇表", "调查诊断领域概念与统一语言", "查看 Suwen 对调查对象、Evidence、假设和结论的标准定义。", "实例参考"],
  system: ["系统", "系统", "", "实例配置"],
});

const AGENT_SCOPED_TABS = new Set(["agents", "channels"]);

const ACTIVE_AGENT_KEY = "suwen-active-workspace";

const MANAGEMENT_FORM_ACTIONS = Object.freeze({
  "agent-create-form": { section: "agents", label: "添加 Agent" },
  "prompt-create-form": { section: "experts", label: "新建 Prompt Bundle", secondary: true },
  "tool-provider-create-form": { section: "connectors", label: "添加连接器" },
  "channel-create-form": { section: "channels", label: "连接飞书" },
  "channel-access-form": { section: "channels", label: "访问控制", actionRoot: "channel-access-action-root" },
  "review-engine-version-form": { section: "reviews", label: "新建复盘规则", actionRoot: "review-advanced-actions" },
  "research-generate-form": { section: "reviews", label: "生成研究摘要", actionRoot: "review-advanced-actions" },
});

let activeDrawerFormId = "";
let drawerReturnFocus = null;
let drawerContentOrigin = null;
let drawerContentNode = null;
let adminNoticeTimer = null;
let modelModalReturnFocus = null;

const CLIENT_TIME_ZONE = Intl.DateTimeFormat().resolvedOptions().timeZone || "本地时区";

const FORM_FIELD_LABELS = Object.freeze({
  id: "稳定 ID",
  name: "名称",
  description: "说明",
  content: "消息内容",
  env_name: "环境变量名",
  protocol: "协议",
  endpoint: "服务地址",
  endpoint_ref: "服务地址",
  api_key: "API Key",
  secret_ref_id: "API Key",
  provider_id: "模型连接",
  provider_version_id: "连接版本",
  model_profile_id: "模型资源",
  persona_id: "交流角色",
  model_id: "模型 ID",
  max_input_length: "上下文上限（tokens）",
  max_output_tokens: "最大输出（tokens）",
  temperature: "生成温度",
  reasoning_effort: "思考级别",
  timeout_seconds: "请求超时",
  capabilities: "模型能力",
  routing: "模型路由",
  language: "主要语言",
  model_profile_version_id: "模型配置版本",
  prompt_bundle_version_id: "提示词版本",
  pack_version_ids: "能力包版本",
  config: "配置",
  status: "状态",
  note: "说明",
});

const VALIDATION_LABELS = Object.freeze({
  missing: "此项必填",
  extra_forbidden: "不支持此字段",
  string_too_short: "内容过短",
  string_too_long: "内容过长",
  string_type: "必须填写文本",
  int_type: "必须填写整数",
  int_parsing: "必须填写整数",
  float_type: "必须填写数字",
  float_parsing: "必须填写数字",
  bool_type: "必须选择是或否",
  list_type: "必须是列表",
  dict_type: "必须是结构化对象",
  greater_than_equal: "低于允许的最小值",
  less_than_equal: "超过允许的最大值",
});

function validationField(loc) {
  const parts = (loc || []).filter((item) => !["body", "query", "path"].includes(item));
  return parts.map((item) => {
    if (typeof item === "number") return `第 ${item + 1} 项`;
    return FORM_FIELD_LABELS[item] || item;
  }).join(" → ");
}

function formatApiError(detail, status) {
  if (Array.isArray(detail)) {
    return detail.map((issue) => {
      const field = validationField(issue.loc);
      const message = VALIDATION_LABELS[issue.type] || "内容不符合要求";
      return field ? `${field}：${message}` : message;
    }).join("；");
  }
  if (typeof detail === "string" && detail.trim()) return detail;
  if (detail && typeof detail.message === "string" && detail.message.trim()) {
    return detail.message;
  }
  return `请求失败（HTTP ${status}）`;
}

function can(permission) {
  return Boolean(state.session?.permissions?.[permission]);
}

function applyRoleVisibility() {
  document.querySelectorAll("[data-permission]").forEach((element) => {
    element.classList.toggle("hidden", !can(element.dataset.permission));
  });
  const label = document.getElementById("management-role");
  if (label) {
    const names = { admin: "管理员", operator: "运维者", reviewer: "审核者", viewer: "只读查看者" };
    label.textContent = names[state.session.role] || state.session.role;
    label.classList.toggle("hidden", state.session.role === "admin");
  }
}

async function api(path, options = {}) {
  const { headers = {}, ...requestOptions } = options;
  const response = await fetch(path, {
    credentials: "same-origin",
    ...requestOptions,
    headers: {
      "Content-Type": "application/json",
      ...headers,
    },
  });
  if (!response.ok) {
    let body = {};
    try {
      body = await response.json();
    } catch (_error) {
      // 安全错误页可能没有 JSON 正文；只显示状态码，不显示服务端内部内容。
    }
    const error = new Error(formatApiError(body.detail, response.status));
    error.status = response.status;
    error.detail = body.detail;
    throw error;
  }
  if (response.status === 204) return null;
  return response.json();
}

const STATUS_LABELS = Object.freeze({
  active: "已启用",
  admitted: "已接收",
  approved: "已批准",
  archived: "已归档",
  bounded: "有界覆盖",
  proven_total: "完整覆盖",
  sample_only: "抽样覆盖",
  internal_state: "内部状态",
  closed: "已关闭",
  completed: "已完成",
  captured: "已捕获",
  complete: "完整",
  completed_pending_human_review: "待人工复核",
  contract_failed: "契约未通过",
  configured: "已配置",
  connecting: "连接中",
  connected: "已连接",
  credential_verified: "App 已验证",
  credential_rejected: "App 验证失败",
  disconnected: "连接已断开",
  controlled_action: "受控动作",
  degraded: "降级",
  disabled: "已禁用",
  draft: "草稿",
  failed: "失败",
  fixture_contract_verified: "隔离契约已验证",
  fixture_ready: "隔离环境就绪",
  investigating: "调查中",
  installed: "已安装",
  missing: "缺失",
  misconfigured: "配置错误",
  not_observed: "未观测",
  not_observable: "不可观察",
  not_recorded: "未留存",
  observed: "已观测",
  zero_matches: "零命中",
  query_failed: "查询失败",
  input_rejected: "输入被拒绝",
  conflict: "证据冲突",
  declared_not_observed: "已声明但未由宿主证实",
  not_run: "未运行",
  ok: "通过",
  open: "进行中",
  outcome_unknown: "结果未知",
  outcome_reviewed: "结果复核通过",
  passed: "通过",
  pending: "待处理",
  partial: "部分覆盖",
  preflight_blocked: "预检阻塞",
  published: "已发布",
  read_only: "只读",
  ready: "就绪",
  rejected: "已驳回",
  review_rejected: "候选复核未通过",
  retired: "已退役",
  running: "运行中",
  sent: "已发送",
  source_gated: "来源受限",
  managed_instances: "按渠道实例",
  not_authorized: "尚未授权",
  source_observed: "来源已观测",
  not_observed: "未观测",
  schema_mismatch: "结构不兼容",
  stopped: "已停止",
  interrupted: "已中断",
  cancelled: "已取消",
  timed_out: "已超时",
  truncated: "已截断",
  stale: "证据已失效",
  publish: "发布",
  rollback: "回滚",
  succeeded: "成功",
  model_stop: "模型正常停止",
  model_timeout: "模型调用超时",
  model_protocol_error: "模型接口协议错误",
  model_or_tool_failure: "模型或工具不可用",
  run_timeout: "整次运行超时",
  max_tool_calls: "工具调用预算用尽",
  max_tool_waves: "检查波次预算用尽",
  investigation_convergence: "调查已收口",
  process_shutdown: "进程交接",
  inbound_execution_failure: "执行异常",
  context_limit_exceeded: "上下文超过模型上限",
  empty_response_recovery_exhausted: "模型空答复恢复已用尽",
  no_new_evidence: "没有新增证据",
  capture: "捕获",
  none: "无",
  trusted_local: "本地可信",
  standard: "标准任务",
  heavy_media: "媒体重任务",
  unknown: "未知",
  validated: "已校验",
  unverified: "未验证",
  unavailable: "不可用",
  model_configuration_required: "需要配置模型",
  model_probe_required: "需要运行模型探针",
  agent_publish_required: "需要发布智能体",
  ready_for_candidate: "可以运行候选",
  candidate_loaded: "候选已加载",
  influence_observed: "能力影响已观测",
  delivery_blocked: "交付准出未满足",
  delivery_complete: "本地交付准出通过",
});

function statusLabel(value) {
  const normalized = value ?? "unknown";
  return STATUS_LABELS[normalized] || normalized;
}

const SYSTEM_NAMES = Object.freeze({
  suwen: "素问",
  "suwen": "素问",
  "builtin-generic": "内置通用工具",
  "runtime-core": "运行时核心工具",
  "test-fixture-agent": "隔离测试智能体",
  "test-fixture-stub": "合成确定性测试模型",
  local: "本地模型服务",
  "secret-local-model-api-key": "本地模型接口密钥",
  "secret-local-model-endpoint": "本地模型服务地址",
  "api-local": "本地接口渠道",
  "console-capture": "隔离控制台捕获",
  "app-fixture": "飞书隔离捕获",
  "web-local": "网页历史入口（已停用）",
  "test-fixture-prompt": "合成测试提示词",
  "deterministic-review": "确定性有界复盘",
  "Legacy Prototype": "历史原型标识（不导入）",
  "Migrated single-Agent prototype": "历史结构记录（无数据导入）",
  "Trace Agent：证据驱动的故障调查智能体": "素问：证据驱动的故障调查智能体",
  "Legacy deterministic provider": "历史测试模型服务标识",
  "Legacy deterministic model": "历史测试模型标识",
  "Local model API key": "本地模型接口密钥",
  "Local model endpoint": "本地模型服务地址",
  "Local API": "本地接口渠道",
  "Isolated Console Capture": "隔离控制台捕获",
  "Feishu Fixture Capture": "飞书隔离捕获",
  "Local Web": "网页历史入口（已停用）",
  "Legacy generic prompt": "历史测试提示词标识",
  "Deterministic bounded Review v1": "确定性有界复盘 v1",
});

function displayName(id, fallback) {
  return SYSTEM_NAMES[id] || SYSTEM_NAMES[fallback] || fallback;
}

function channelTypeLabel(value) {
  return { feishu: "飞书", console: "隔离控制台", capture: "捕获通道", api: "运行接口", web: "网页历史入口" }[value] || value;
}

function isInternalChannel(channel) {
  if (typeof channel?.user_configurable === "boolean") return !channel.user_configurable;
  return ["api", "console", "capture"].includes(channel?.channel_type) || channel?.id === "app-fixture";
}

function isDevelopmentWorkspace() {
  return state.system?.runtime_mode === "development";
}

function toolProviderTypeLabel(value) {
  return {
    fixture: "隔离测试",
    trusted_local: "受信任本地",
    mcp_stdio: "stdio",
    mcp_http: "Streamable HTTP",
  }[value] || value;
}

function modelProtocolLabel(value) {
  return {
    "openai-compatible": "OpenAI-compatible 协议",
    stub: "隔离测试协议",
  }[value] || value;
}

const REVIEW_RULE_LABELS = Object.freeze({
  evidence_gap: "无证据提示",
  run_reliability: "运行可靠性",
  unresolved_case: "未解决状态",
  reply_persistence_gap: "答复缺失",
  evidence_boundary: "证据边界",
  action_uncertainty: "动作不确定性",
  evidence_provider_candidate: "证据入口候选",
  runtime_reliability_candidate: "运行缺口候选",
  source_coverage_candidate: "来源覆盖候选",
});

const TOOL_LABELS = Object.freeze({
  inspect_claim: ["记录待核查主张", "把一条有边界的用户陈述登记为待进一步核查的线索。"],
  read_artifact_chunk: ["续读运行产物", "续读当前运行产生且尚未过期的有界文本片段。"],
  render_explanation_diagram: ["绘制解释图示", "把模型已经组织好的通用节点与关系渲染为当前运行可引用的流程图或实体关系图。"],
});

function toolLabel(name) {
  const mapped = TOOL_LABELS[name]?.[0];
  if (mapped) return mapped;
  const tool = state.tools.find((item) => item.name === name);
  const firstSentence = String(tool?.description || "").split(/[。；\n]/)[0].trim();
  return /[\u3400-\u9fff]/u.test(firstSentence) ? firstSentence : name;
}

function toolNameMarkup(name) {
  return escapeHtml(String(name || "未记录")).replaceAll("_", "_<wbr>");
}

function toolIdentity(name) {
  const technicalName = String(name || "未记录");
  const label = String(toolLabel(technicalName) || technicalName);
  return {
    label,
    technicalName,
    hasDistinctLabel: label.trim().toLocaleLowerCase() !== technicalName.trim().toLocaleLowerCase(),
  };
}

function toolIdentityMarkup(name) {
  const identity = toolIdentity(name);
  return `<span class="tool-identity"><strong>${escapeHtml(identity.label)}</strong>${identity.hasDistinctLabel ? `<small>${toolNameMarkup(identity.technicalName)}</small>` : ""}</span>`;
}

function toolDescription(tool) {
  return TOOL_LABELS[tool.name]?.[1] || tool.description;
}

function isUserSelectableTool(tool) {
  if (typeof tool?.user_selectable === "boolean") return tool.user_selectable;
  return ![
    "inspect_claim",
    "read_artifact_chunk",
    "find_artifact_text",
    "render_explanation_diagram",
    "recall_case_history",
    "read_skill",
    "list_skill_references",
    "search_skill_references",
    "read_skill_reference",
  ].includes(tool?.name);
}

function userSelectableTools() {
  return state.tools.filter(isUserSelectableTool);
}

const TECHNICAL_LABELS = Object.freeze({
  diagnostic_progress: "诊断是否取得进展",
  actionable_guidance: "建议是否可执行",
  continuity_and_evidence_update: "连续性与证据更新",
  evidence_boundary: "证据边界",
  closure_or_next_hook: "闭环或下一检查点",
  investigation_efficiency: "调查效率",
  review_case: "案件复盘",
  outbox_dispatch: "发件箱投递",
  lifecycle_close: "案件生命周期关闭",
  system: "系统",
  database: "数据库",
  admin: "管理员",
  api: "接口",
  success: "成功",
  configuration_invalid: "配置不完整",
  agent_not_published: "智能体尚未发布",
  agent_active_version_missing: "智能体活动版本缺失",
  tool_schema_digest_missing: "工具结构摘要缺失",
  model_api_key_unresolved: "模型接口密钥未配置",
  model_probe_not_passed: "模型固定探针尚未通过",
  model_probe_stale: "模型固定探针已过期",
  model_tool_calling_not_observed: "模型工具调用能力尚未观测",
  model_structured_output_not_observed: "模型结构化输出能力尚未观测",
  model_vision_not_observed: "模型图片输入能力尚未观测",
  api_key_ref_unresolved: "模型接口密钥未配置",
  model_endpoint_unresolved: "模型服务地址未配置",
  sj_baseline_attestation_missing: "能力基线内容证明缺失",
  capability_pack_baseline_attestation_missing: "能力包缺少基线内容证明",
  prompt_bundle_baseline_attestation_missing: "常驻职责缺少基线内容证明",
  prompt_bundle_not_active: "提示词包尚未启用",
  sj_prompt_baseline_attestation_missing: "素问常驻职责基线证明缺失",
  bind_attested_sj_prompt_bundle: "绑定完整且已证明的素问常驻职责",
  endpoint_ref_unresolved: "模型服务地址未配置",
  validate_and_publish_agent: "完成模型配置后校验并发布智能体",
  restore_active_agent_version: "恢复智能体活动版本",
  enable_model_profile: "启用模型配置",
  enable_model_provider: "启用模型连接",
  republish_agent_version: "重新校验并发布智能体版本",
  restore_candidate_runtime_budget: "恢复 24/24/6 候选运行预算",
  bind_local_keyu_mtp: "绑定缺省 local/keyu-mtp 模型",
  configure_model_endpoint: "在模型页填写本项目服务地址",
  configure_model_api_key: "在模型页填写本项目接口密钥",
  run_model_probe: "在模型页运行连接与工具调用探针",
  rerun_model_probe: "在模型页重新运行固定探针",
  rerun_model_tool_calling_probe: "重新运行合成工具调用探针",
  run_timeout_seconds_outside_limit: "整次运行超时必须在 0.1 到 1800 秒之间",
  max_tool_risk_invalid: "工具风险上限无效",
  agent_tool_risk_exceeds_limit: "工具白名单包含超过风险上限的工具",
  channel_reply_enabled_must_be_boolean: "渠道回复开关无效",
  feishu_scope_missing: "请填写允许接收消息的用户 Open ID 或会话 ID",
  feishu_app_id_missing: "缺少飞书 App ID",
  feishu_app_secret_missing: "缺少飞书 App Secret",
  feishu_credentials_rejected: "飞书 App ID 或 App Secret 不正确",
  feishu_connectivity_failed: "无法连接飞书开放平台",
  review_delay_seconds_outside_limit: "复盘延迟必须在 0 到 604800 秒之间",
  reply_footer_invalid: "答复页脚超过限制或格式无效",
  immutable_presentation_boundary_disabled: "密钥脱敏和本机路径移除不能关闭",
  agent_tags_invalid: "智能体标签格式无效",
  select_tool_capable_model: "选择声明支持工具调用的模型",
  inspect_model_configuration: "检查模型配置",
  initialize_native_suwen: "使用全新运行库初始化原生素问",
  repair_database: "检查并修复本项目数据库",
  repair_capability_contract: "恢复七项技能与十四项工具契约",
  inspect_candidate_preflight: "检查候选预检结果",
  run_frozen_candidate: "运行一次冻结候选",
  complete_candidate_review: "完成十类场景六维人工复核",
  create_managed_backup: "创建本项目受管备份",
  start_suwen_service: "启动素问服务与调度器",
  restore_capture_sender: "恢复捕获发送器",
  select_persistent_manager: "选择并授权持久进程宿主",
  perform_release_rollback_drill: "完成一次发布与回滚演练",
  observe_interval_health: "对同一进程执行两次间隔健康观测",
  run_management_e2e: "执行管理端真实操作验收",
  authorize_read_only_source: "授权最小真实只读来源",
  authorize_test_channel: "授权专用测试渠道",
  authorize_git_and_deployment: "授权 Git 与部署动作",
  "multi-agent-configuration-foundation": "多智能体配置基础",
  "observation-and-private-presentation-boundary": "观测与私密呈现边界",
  "controlled-action-governance": "受控动作治理",
  "channel-control-plane": "渠道控制面",
  "review-research-control-plane": "复盘与研究控制面",
  "candidate-scorecards": "候选验收评分卡",
  "suwen-brand-and-management-web-boundary": "素问命名与管理端边界",
  "runtime-observability": "运行可观测性",
  "capability-pack-lifecycle": "能力包生命周期",
  "controlled-action-agent-version": "受控动作智能体版本冻结",
  "audit-request-and-authorization-context": "审计请求与授权上下文",
  agent_version: "智能体版本",
  model_probe: "模型探针",
  default_agent_id: "缺省智能体",
  test_fixture_agent_id: "合成测试智能体",
  system_internal: "系统内部",
  local_cli: "本地命令行",
  local_management_without_token: "仅限本机的免令牌管理",
  management_actor: "管理角色",
  runtime_api: "运行接口",
  channel_adapter: "渠道适配器",
  capture: "捕获",
  agent: "智能体",
  model_profile: "模型配置",
  model_provider: "模型连接",
  secret_ref: "密钥引用",
  capability_pack: "能力包",
  tool_provider: "MCP Connector",
  channel_instance: "渠道实例",
  agent_channel_binding: "智能体渠道绑定",
  candidate: "候选验收",
  review: "复盘",
  research: "研究摘要",
  research_candidate: "研究候选",
  controlled_action: "受控动作",
  capability: "能力资源",
  "database.migrated": "数据库结构已升级",
  "database.initialized": "数据库已初始化",
  "system.backup_created": "本地数据库备份已创建",
  database_backup: "数据库备份",
  "agent.created": "智能体草稿已创建",
  "agent.current_model_changed": "当前模型已切换",
  "agent.current_persona_changed": "当前交流角色已切换",
  "agent.default_changed": "缺省智能体已变更",
  "agent.draft_updated": "智能体草稿已更新",
  "agent.draft_validated": "智能体草稿已校验",
  "agent.enabled": "智能体已启用",
  "agent.publish_failed": "智能体发布失败",
  "agent.published": "智能体已发布",
  "agent.rollback_failed": "智能体回滚失败",
  "agent.rolled_back": "智能体已回滚",
  "model_profile.created": "模型配置已创建",
  "model_profile.probed": "模型固定探针已运行",
  "model_profile.status_changed": "模型配置状态已变更",
  "model_profile.version_created": "模型配置版本已创建",
  "model_provider.created": "模型连接已创建",
  "model_provider.models_discovered": "模型目录已发现",
  "model_provider.status_changed": "模型连接状态已变更",
  "model_provider.version_created": "模型连接版本已创建",
  "secret_ref.created": "密钥引用已创建",
  "secret_ref.private_value_rotated": "私密值已轮换",
  "secret_ref.private_value_stored": "私密值已保存",
  "capability_pack.status_changed": "能力包状态已变更",
  "capability_pack.validated": "能力包已校验",
  "capability_pack.version_registered": "能力包版本已登记",
  "capability_pack.version_installed": "能力包版本已安装",
  "prompt_bundle.created": "提示词草稿已创建",
  "prompt_bundle.version_installed": "提示词版本已安装",
  "prompt_bundle.version_created": "提示词版本已创建",
  "prompt_bundle.status_changed": "提示词状态已变更",
  "tool_provider.created": "Connector 已创建",
  "tool_provider.configured": "Connector 连接已配置",
  "tool_provider.connected": "Connector 已连接",
  "tool_provider.connect_failed": "Connector 连接失败",
  "tool_provider.probed": "Connector 已探测",
  "tool_provider.schema_version_created": "工具结构版本已创建",
  "tool_provider.status_changed": "Connector 状态已变更",
  "channel_instance.created": "渠道实例已创建",
  "channel_instance.renamed": "渠道名称已更新",
  "channel_instance.status_changed": "渠道实例状态已变更",
  "channel_instance.validated": "渠道实例已校验",
  "channel_instance.version_created": "渠道实例版本已创建",
  "agent_channel_binding.enabled": "智能体渠道绑定已启用",
  "agent_channel_binding.disabled": "智能体渠道绑定已停用",
  "candidate.reserved": "候选验收机会已冻结",
  "candidate.human_reviewed": "候选验收已人工复核",
  "review.created": "复盘已创建",
  "review.decided": "复盘已决策",
  "research.generated": "研究摘要已生成",
  "research.decided": "研究摘要已决策",
  "research_candidate.decided": "研究候选已决策",
  "action.prepared": "受控动作已准备",
  "action.confirmed": "受控动作已确认",
  "action.confirmation_rejected": "受控动作确认已拒绝",
  "action.expired": "受控动作已过期",
  "action.terminal": "受控动作已结束",
});

function technicalLabel(value) {
  return TECHNICAL_LABELS[value] || statusLabel(value);
}

function auditResultClass(result) {
  if (["succeeded", "passed", "success"].includes(result)) return "success";
  if (["failed", "rejected"].includes(result)) return "danger";
  return "attention";
}

function auditTechnicalDetails(event) {
  const rows = [
    ["审计事件 ID", event.id],
    ["请求 ID", event.request_id],
    ["对象版本", event.target_version],
    ["变更前摘要", event.before_digest],
    ["变更后摘要", event.after_digest],
    ["失败分类", event.failure_class],
  ].filter(([, value]) => value !== null && value !== undefined && String(value).trim());
  const metadata = event.metadata && Object.keys(event.metadata).length
    ? `<div class="audit-technical-metadata"><dt>附加信息</dt><dd><pre>${escapeHtml(JSON.stringify(event.metadata, null, 2))}</pre></dd></div>`
    : "";
  if (!rows.length && !metadata) return "";
  return `<details class="audit-technical-details"><summary>技术记录</summary><dl>${rows.map(([label, value]) =>
    `<div><dt>${escapeHtml(label)}</dt><dd class="mono">${escapeHtml(String(value))}</dd></div>`
  ).join("")}${metadata}</dl></details>`;
}

const NATIVE_STAGE_LABELS = Object.freeze({
  P0: "能力清单对齐",
  P1: "仓库与运行契约验证",
  P2: "候选实际加载",
  P3: "模型影响已观测",
  P4: "真实只读来源已观测",
  P5: "结果已人工复核",
  P6: "交付完成",
});

function nativeStageLabel(id) {
  return NATIVE_STAGE_LABELS[id] || id;
}

function findingLabel(item) {
  const code = typeof item === "string" ? item : item?.code;
  const label = technicalLabel(code || "unknown");
  return item?.next_action
    ? `${label}；下一步：${technicalLabel(item.next_action)}`
    : label;
}

function agentDraftValidationFindings(error) {
  return Array.isArray(error?.detail?.findings) ? error.detail.findings : [];
}

function agentDraftBlockedMessage(label, findings, fallbackMessage) {
  const reason = findings.length
    ? findings.map(findingLabel).join("；")
    : fallbackMessage;
  return `${label}已保存为草稿，当前运行配置未更新：${reason}`;
}

async function publishSavedAgentDraft(agent, note, result) {
  const publish = () => api(`/api/v1/admin/agents/${agent.id}/publish`, {
    method: "POST",
    body: JSON.stringify({ note }),
  });
  try {
    await publish();
    return { published: true, findings: [] };
  } catch (error) {
    const findings = agentDraftValidationFindings(error);
    const probeFindingCodes = new Set(["model_probe_not_passed", "model_probe_stale"]);
    const canRecoverWithProbe = Boolean(agent.current_model?.model_profile_version_id) &&
      findings.length > 0 &&
      findings.every((item) => probeFindingCodes.has(item?.code));
    if (!canRecoverWithProbe) {
      return { published: false, findings, message: error.message };
    }
    const confirmed = confirm(
      "设置已经保存。当前模型需要先通过固定合成测试，才能用于下一次运行。" +
      "现在测试并继续启用吗？测试不包含案件或真实会话，也不会执行工具。"
    );
    if (!confirmed) {
      return { published: false, findings, message: error.message };
    }
    result.className = "agent-result";
    result.textContent = "设置已保存，正在测试当前模型并继续启用…";
    const observed = await api(
      `/api/v1/admin/model-profile-versions/${agent.current_model.model_profile_version_id}/probe`,
      { method: "POST" }
    );
    if (observed.status !== "passed") {
      return {
        published: false,
        findings: Array.isArray(observed.findings) ? observed.findings : [],
        message: "模型固定探针未通过",
      };
    }
    try {
      await publish();
      return { published: true, findings: [] };
    } catch (retryError) {
      return {
        published: false,
        findings: agentDraftValidationFindings(retryError),
        message: retryError.message,
      };
    }
  }
}

function formatTime(value, includeSource = false) {
  if (!value || value === "-") return "-";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return String(value);
  const local = parsed.toLocaleString("zh-CN", {
    timeZone: CLIENT_TIME_ZONE,
    hour12: false,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  return includeSource ? `${local}（${CLIENT_TIME_ZONE}；源值 ${value}）` : local;
}

function timeHtml(value) {
  if (!value) return "-";
  return `<time datetime="${escapeHtml(value)}" title="UTC 源值：${escapeHtml(value)}">${escapeHtml(formatTime(value))}</time>`;
}

function conciseCaseTitle(item) {
  const raw = String(item?.title || "").replace(/\s+/g, " ").trim();
  if (!raw || /^\d{1,4}$/.test(raw) || raw.length < 2) return "未命名案件";
  if (/^\/(new|clear|stop)$/i.test(raw)) return `历史控制指令 ${raw}`;
  return raw.length > 52 ? `${raw.slice(0, 52).trim()}…` : raw;
}

function runHeading(status) {
  if (status === "completed") return "运行完成";
  if (["failed", "cancelled", "timed_out"].includes(status)) return "运行异常";
  if (["pending", "running"].includes(status)) return "运行中";
  return statusLabel(status || "unknown");
}

function durationBetween(startedAt, finishedAt) {
  if (!startedAt || !finishedAt) return null;
  const milliseconds = new Date(finishedAt).getTime() - new Date(startedAt).getTime();
  return Number.isFinite(milliseconds) ? Math.max(0, milliseconds) : null;
}

function formatDuration(milliseconds) {
  if (!Number.isFinite(milliseconds)) return "进行中";
  if (milliseconds < 1000) return `${Math.round(milliseconds)} 毫秒`;
  if (milliseconds < 60_000) return `${(milliseconds / 1000).toFixed(milliseconds < 10_000 ? 2 : 1)} 秒`;
  const minutes = Math.floor(milliseconds / 60_000);
  const seconds = Math.round((milliseconds % 60_000) / 1000);
  return `${minutes} 分 ${seconds} 秒`;
}

async function loadHealth() {
  const health = await api("/health");
  state.releaseVersion = health.release_version || health.package_version || "";
  const release = document.getElementById("instance-release-meta");
  if (release) {
    release.textContent = state.releaseVersion || "实例版本未知";
    release.title = `Suwen 实例发布版本：${state.releaseVersion || "未知"}`;
  }
  const status = document.getElementById("health");
  const ready = health.status === "ready" && health.database === "ready" && health.scheduler === "running";
  status.textContent = ready ? "服务正常" : "服务需检查";
  status.title = `版本：${state.releaseVersion || "未知"}；服务：${statusLabel(health.status)}；数据库：${statusLabel(health.database)}；调度器：${statusLabel(health.scheduler)}`;
}

function setAdminNotice(message, kind = "") {
  const notice = document.getElementById("admin-notice");
  if (adminNoticeTimer) clearTimeout(adminNoticeTimer);
  notice.textContent = message;
  notice.className = `admin-notice ${kind}`;
  if (kind === "admin-success") {
    adminNoticeTimer = window.setTimeout(() => notice.classList.add("hidden"), 4200);
  }
}

function clearAdminNotice() {
  const notice = document.getElementById("admin-notice");
  if (adminNoticeTimer) clearTimeout(adminNoticeTimer);
  adminNoticeTimer = null;
  notice.textContent = "";
  notice.className = "admin-notice hidden";
}

async function copyTextToClipboard(value) {
  const text = String(value || "");
  if (!text) throw new Error("没有可复制的 ID");
  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return;
    } catch (_error) {
      // Fall through for browsers that expose Clipboard API but deny this call.
    }
  }
  const input = document.createElement("textarea");
  input.value = text;
  input.setAttribute("readonly", "");
  input.style.position = "fixed";
  input.style.inset = "0 auto auto -9999px";
  document.body.append(input);
  input.select();
  const copied = typeof document.execCommand === "function" && document.execCommand("copy");
  input.remove();
  if (!copied) throw new Error("浏览器未允许复制");
}

async function runBusy(button, busyLabel, operation) {
  if (button.dataset.busy === "true") return undefined;
  const previousLabel = button.textContent;
  const previousDisabled = button.disabled;
  button.dataset.busy = "true";
  button.disabled = true;
  button.textContent = busyLabel;
  try {
    return await operation();
  } finally {
    delete button.dataset.busy;
    if (button.isConnected) {
      button.disabled = previousDisabled;
      button.textContent = previousLabel;
    }
  }
}

function latestProfileVersions() {
  return state.profileCatalog.map((profile) => ({ profile, version: profile.versions[0] }));
}

function profileVersions() {
  return state.profileCatalog.flatMap((profile) =>
    profile.versions.map((version) => ({ profile, version }))
  );
}

function modelProbeObservation(version) {
  return version.last_probe?.findings?.find((item) => item.code === "probe_observed")?.observed || {};
}

function fillModelSelect(select, selectedId = "") {
  select.innerHTML = "";
  const resources = latestProfileVersions();
  const effectiveSelectedId = selectedId || resources[0]?.profile.id || "";
  resources.forEach(({ profile, version }) => {
    const provider = state.providerCatalog.find((item) => item.id === version.provider_id);
    const option = document.createElement("option");
    option.value = profile.id;
    option.textContent = `${displayName(profile.id, profile.name)} · ${displayName(provider?.id || "", provider?.name || version.provider_id)} / ${version.model_id}`;
    option.selected = profile.id === effectiveSelectedId;
    select.appendChild(option);
  });
  select.disabled = resources.length === 0;
}

function fillReviewFilterSelects() {
  const agentSelect = document.getElementById("review-filter-agent");
  const selectedAgent = state.reviewFilters.agent_id;
  agentSelect.innerHTML = '<option value="">全部</option>';
  state.agentCatalog.forEach((agent) => {
    const option = document.createElement("option");
    option.value = agent.id;
    option.textContent = `${displayName(agent.id, agent.name)}（${agent.id}）`;
    option.selected = agent.id === selectedAgent;
    agentSelect.appendChild(option);
  });

  const modelSelect = document.getElementById("review-filter-model");
  const selectedModel = state.reviewFilters.model_profile_version_id;
  modelSelect.innerHTML = '<option value="">全部</option>';
  profileVersions().forEach(({ profile, version }) => {
    const option = document.createElement("option");
    option.value = version.id;
    option.textContent = `${displayName(profile.id, profile.name)} · ${version.model_id} · v${version.version}`;
    option.selected = version.id === selectedModel;
    modelSelect.appendChild(option);
  });
}

function latestPackVersions() {
  return state.packs
    .filter((pack) => pack.status === "installed" && pack.versions.length)
    .map((pack) => ({ pack, version: pack.versions.find((version) => version.loaded) }))
    .filter(({ version }) => Boolean(version));
}

function selectablePackVersions() {
  return state.packs
    .filter((pack) => pack.status === "installed")
    .flatMap((pack) => pack.versions.filter((version) => version.loaded).map((version) => ({ pack, version })));
}

function fillPackSelect(select, selectedIds = []) {
  select.innerHTML = "";
  selectablePackVersions().forEach(({ pack, version }) => {
    const option = document.createElement("option");
    option.value = version.id;
    option.textContent = `${pack.name} · ${version.version} · ${statusLabel(pack.trust_level)}`;
    option.selected = selectedIds.includes(version.id);
    select.appendChild(option);
  });
}

function availableToolNames(packVersionIds) {
  const names = new Set(
    state.tools
      .filter((tool) => tool.provider_id === "runtime-core")
      .map((tool) => tool.name)
  );
  state.packs.forEach((pack) => {
    pack.versions.forEach((version) => {
      if (!packVersionIds.includes(version.id)) return;
      (version.manifest?.tools || []).forEach((name) => names.add(name));
      if (pack.id === "generic") names.add("inspect_claim");
    });
  });
  return Array.from(names)
    .filter((name) => {
      const tool = state.tools.find((item) => item.name === name);
      return tool ? isUserSelectableTool(tool) : false;
    })
    .sort();
}

function fillToolSelect(select, packVersionIds, selectedNames = []) {
  select.innerHTML = "";
  const available = availableToolNames(packVersionIds);
  const effectiveSelected = selectedNames.length ? selectedNames : available;
  available.forEach((name) => {
    const option = document.createElement("option");
    option.value = name;
    option.textContent = `${name} · ${toolLabel(name)}`;
    option.selected = effectiveSelected.includes(name);
    select.appendChild(option);
  });
}

function promptLines(value) {
  return String(value || "").split(/\r?\n/).map((item) => item.trim()).filter(Boolean);
}

function promptContentAsAgentsMarkdown(content) {
  if (!content || typeof content !== "object") return "";
  const sections = [];
  ["system_prompt", "soul", "rules", "output_rules"].forEach((key) => {
    const value = content[key];
    if (typeof value === "string" && value.trim()) {
      sections.push(value.trim());
    } else if (Array.isArray(value)) {
      value.forEach((item) => {
        if (typeof item === "string" && item.trim()) sections.push(item.trim());
      });
    }
  });
  return sections.join("\n\n");
}

function selectablePromptVersions(selectedId = "") {
  return state.prompts.flatMap((bundle) =>
    bundle.versions
      .filter((version) => bundle.status === "active" || version.id === selectedId)
      .map((version) => ({ bundle, version }))
  );
}

function fillPromptSelect(select, selectedId = "") {
  select.innerHTML = "";
  selectablePromptVersions(selectedId).forEach(({ bundle, version }) => {
    const option = document.createElement("option");
    option.value = version.id;
    option.textContent = `${displayName(bundle.id, bundle.name)} · v${version.version} · ${statusLabel(bundle.status)}`;
    option.selected = version.id === selectedId;
    select.appendChild(option);
  });
}

function fillAgentProfileSelect(select, selectedDigest = "") {
  const preserved = selectedDigest || select.value;
  select.innerHTML = '<option value="">自定义配置</option>';
  state.agentProfiles.forEach((profile) => {
    const option = document.createElement("option");
    option.value = profile.digest || "";
    option.textContent = `${profile.name} · v${profile.version} · ${profile.ready ? "就绪" : "未就绪"}`;
    option.selected = profile.digest === preserved;
    option.disabled = !profile.ready;
    select.appendChild(option);
  });
}

function selectedAgentProfile(select = document.getElementById("agent-create-profile")) {
  return state.agentProfiles.find((item) => item.digest === select?.value) || null;
}

function fillPersonaSelect(select, selectedId = "technical-peer") {
  if (!select) return;
  select.innerHTML = "";
  state.personas.forEach((persona) => {
    const option = document.createElement("option");
    option.value = persona.id;
    option.textContent = `${persona.name} · ${persona.description}`;
    option.selected = persona.id === selectedId;
    select.appendChild(option);
  });
}

function applyAgentCreateAssembly() {
  const profileSelect = document.getElementById("agent-create-profile");
  const promptSelect = document.getElementById("agent-create-prompt");
  const packSelect = document.getElementById("agent-create-packs");
  const toolSelect = document.getElementById("agent-create-tools");
  const status = document.getElementById("agent-create-profile-status");
  const profile = selectedAgentProfile(profileSelect);
  if (profile) {
    fillPromptSelect(promptSelect);
    fillPackSelect(packSelect, []);
    fillToolSelect(toolSelect, []);
    [promptSelect, packSelect, toolSelect].forEach((element) => { element.disabled = true; });
    status.textContent = `原生配置 ${profile.name} 已就绪；创建后会校验并启用这套配置。`;
    return;
  }
  const defaultGenericPack = state.packs
    .find((pack) => pack.id === "generic" && pack.status === "installed")
    ?.versions[0];
  fillPromptSelect(promptSelect);
  fillPackSelect(packSelect, defaultGenericPack ? [defaultGenericPack.id] : []);
  fillToolSelect(toolSelect, Array.from(packSelect.selectedOptions).map((item) => item.value));
  [promptSelect, packSelect, toolSelect].forEach((element) => { element.disabled = false; });
  status.textContent = "未选择原生配置；将使用下方逐项选择的模型、提示词和工具。";
}

function secretScopes(secret) {
  return new Set((secret.usages || []).map((usage) => usage.scope));
}

function secretsForScope(scope, selectedId = "") {
  return state.secrets.filter((secret) => {
    if (secret.id === selectedId) return true;
    const scopes = secretScopes(secret);
    return scopes.has(scope) || scopes.size === 0;
  });
}

function fillSecretSelect(select, allowEmpty = false, selectedId = "", scope = "model") {
  select.innerHTML = allowEmpty ? '<option value="">无</option>' : "";
  secretsForScope(scope, selectedId).forEach((secret) => {
    const option = document.createElement("option");
    option.value = secret.id;
    option.textContent = `${displayName(secret.id, secret.name)} · v${secret.version} · ${secret.configured ? "已配置" : "缺失"}`;
    option.selected = secret.id === selectedId;
    select.appendChild(option);
  });
}

function fillProviderSelect(select) {
  select.innerHTML = "";
  state.providerCatalog.forEach((provider) => {
    const option = document.createElement("option");
    option.value = provider.id;
    option.textContent = `${displayName(provider.id, provider.name)} · ${modelProtocolLabel(provider.protocol)} · ${statusLabel(provider.status)}`;
    select.appendChild(option);
  });
}

function agentReleaseLabel(version) {
  return version?.release_version || (version ? `v${version.version}` : "尚无版本");
}

function agentVersionLabel(agent, version) {
  if (!version) return "尚无版本";
  return `${agentReleaseLabel(version)} · ${agent.current_model?.model_id || "未选择模型"} · ${statusLabel(version.status)}`;
}

function activeAgent() {
  return state.agents.find((item) => item.id === state.activeAgentId) ||
    state.agents.find((item) => item.is_default) ||
    state.agents[0] ||
    null;
}

function activeAgentVersion(agent = activeAgent()) {
  if (!agent) return null;
  return agent.versions.find((item) => item.id === agent.active_version_id) ||
    agent.versions.find((item) => item.status === "draft") ||
    agent.versions[0] ||
    null;
}

function resolveActiveAgent() {
  const stored = sessionStorage.getItem(ACTIVE_AGENT_KEY);
  const selected = state.agents.find((item) => item.id === stored) ||
    state.agents.find((item) => item.is_default) ||
    state.agents[0];
  state.activeAgentId = selected?.id || "";
  if (state.activeAgentId) {
    sessionStorage.setItem(ACTIVE_AGENT_KEY, state.activeAgentId);
  }
}

function updateActiveAgentChrome() {
  const agentScoped = AGENT_SCOPED_TABS.has(state.adminTab);
  document.getElementById("agent-topbar-context")?.classList.toggle("hidden", !agentScoped);
}

function renderAgentContext() {
  const trigger = document.getElementById("agent-context-trigger");
  const menu = document.getElementById("agent-context-menu");
  const current = activeAgent();
  const agentCount = state.agentPage.total || state.agents.length;
  document.getElementById("agent-context-count").textContent = agentCount;
  document.getElementById("agent-context-name").textContent = current
    ? displayName(current.id, current.name)
    : "未配置智能体";
  document.getElementById("agent-context-status").className =
    `status-dot ${current?.status === "published" ? "status-dot-running" : ""}`;
  trigger.disabled = !current;
  trigger.setAttribute(
    "aria-label",
    current
      ? `切换当前 Agent，当前为${displayName(current.id, current.name)}`
      : "当前没有可切换的 Agent"
  );
  menu.innerHTML = `<div class="agent-context-menu-heading" role="presentation"><span>选择 Agent</span><span id="agent-context-count">${agentCount}</span></div>`;
  state.agents.forEach((agent) => {
    const option = document.createElement("button");
    option.type = "button";
    option.className = "agent-context-option";
    option.setAttribute("role", "option");
    option.setAttribute("aria-selected", String(agent.id === current?.id));
    option.innerHTML = `
      <span class="status-dot ${agent.status === "published" ? "status-dot-running" : ""}"></span>
      <span class="agent-context-option-copy">
        <strong>${escapeHtml(displayName(agent.id, agent.name))}</strong>
        <small>${escapeHtml(agent.current_model?.model_id || "未选择模型")} · ${agent.status === "published" ? "已启用" : "待完成配置"}</small>
      </span>`;
    option.onclick = async () => {
      if (state.activeAgentId === agent.id) {
        menu.classList.add("hidden");
        trigger.setAttribute("aria-expanded", "false");
        return;
      }
      state.activeAgentId = agent.id;
      sessionStorage.setItem(ACTIVE_AGENT_KEY, agent.id);
      menu.classList.add("hidden");
      trigger.setAttribute("aria-expanded", "false");
      try {
        await loadAdmin(false);
        setAdminNotice(`当前 Agent 已切换为“${displayName(agent.id, agent.name)}”。`, "admin-success");
      } catch (error) {
        setAdminNotice(`Agent 已切换，但数据刷新失败：${error.message}`, "admin-error");
      }
    };
    menu.appendChild(option);
  });
  trigger.onclick = () => {
    const open = trigger.getAttribute("aria-expanded") === "true";
    trigger.setAttribute("aria-expanded", String(!open));
    menu.classList.toggle("hidden", open);
    if (!open) menu.querySelector('[aria-selected="true"]')?.focus();
  };
  updateActiveAgentChrome();
}

function renderAgents() {
  const root = document.getElementById("agent-admin-list");
  root.innerHTML = "";
  [activeAgent()].filter(Boolean).forEach((agent) => {
    const active = agent.versions.find((item) => item.id === agent.active_version_id);
    const draft = agent.versions.find((item) => item.status === "draft");
    const base = draft || active || agent.versions[0];
    const activeModelResource = state.profileCatalog.find(
      (profile) => profile.id === agent.current_model?.model_profile_id
    );
    const activeModel = activeModelResource?.current_version || activeModelResource?.versions?.[0];
    const modelObserved = modelProbeObservation(activeModel || {});
    const modelReady = activeModel?.configuration?.status === "valid" &&
      activeModel?.last_probe?.status === "passed" &&
      modelObserved.tool_calling_observed;
    const nativeProfile = base?.config?.agent_profile_id
      ? {
          id: base.config.agent_profile_id,
          version: base.config.agent_profile_version,
          digest: base.config.agent_profile_digest,
        }
      : null;
    const agentReady = agent.status === "published" && modelReady;
    const card = document.createElement("article");
    card.className = "agent-settings-shell";
    card.innerHTML = `
      <header class="agent-settings-header">
        <div>
          <div class="agent-settings-title"><h3>${escapeHtml(displayName(agent.id, agent.name))}</h3><span class="status-badge ${agentReady ? "success" : "attention"}">${agentReady ? "运行就绪" : "需要处理"}</span></div>
          <p>${escapeHtml(agent.current_model?.model_profile_name || agent.current_model?.model_id || "未选择模型")} · ${escapeHtml(agent.current_persona?.name || "未选择交流角色")}${agent.is_default ? " · 缺省智能体" : ""}</p>
        </div>
      </header>
      <nav class="agent-settings-tabs" aria-label="智能体设置分区">
        <button type="button" class="secondary" data-agent-settings-tab="general">基础设置</button>
        <button type="button" class="secondary" data-agent-settings-tab="tools">工具</button>
        <button type="button" class="secondary" data-agent-settings-tab="prompts">AGENTS.md</button>
        <button type="button" class="secondary" data-agent-settings-tab="runtime">运行配置</button>
        <button type="button" class="secondary" data-agent-settings-tab="usage">使用统计</button>
      </nav>
      <section class="agent-settings-workspace">
        <div class="advanced-content agent-advanced-content">
          <div class="admin-actions"></div>
          <div class="agent-result"></div>
        </div>
      </section>`;
    const advancedContent = card.querySelector(".agent-advanced-content");
    const actions = card.querySelector(".admin-actions");
    actions.classList.add("agent-save-actions");
    const result = card.querySelector(".agent-result");
    const generalPanel = document.createElement("section");
    generalPanel.className = "agent-settings-panel";
    generalPanel.dataset.agentSettingsPanel = "general";
    const generalInfoBlock = document.createElement("section");
    generalInfoBlock.className = "agent-form-block agent-info-block";
    generalInfoBlock.innerHTML = "<header class=\"agent-form-block-head\"><h5>智能体信息</h5></header>";
    const generalGrid = document.createElement("div");
    generalGrid.className = "agent-policy-grid";
    generalInfoBlock.appendChild(generalGrid);
    generalPanel.appendChild(generalInfoBlock);
    const policyDetails = document.createElement("section");
    policyDetails.className = "agent-settings-panel";
    policyDetails.dataset.agentSettingsPanel = "runtime";
    const runtimeBlocks = document.createElement("div");
    runtimeBlocks.className = "agent-runtime-blocks";
    const labeled = (text, control) => {
      const label = document.createElement("label");
      label.textContent = text;
      label.appendChild(control);
      return label;
    };
    const settingsBlock = (title, className = "") => {
      const block = document.createElement("section");
      block.className = `agent-form-block ${className}`.trim();
      block.innerHTML = `<header class="agent-form-block-head"><h5>${escapeHtml(title)}</h5></header>`;
      const grid = document.createElement("div");
      grid.className = "agent-policy-grid";
      block.appendChild(grid);
      return { block, grid };
    };
    const nameInput = document.createElement("input");
    nameInput.value = agent.name;
    nameInput.maxLength = 200;
    const descriptionInput = document.createElement("textarea");
    descriptionInput.value = agent.description || "";
    descriptionInput.maxLength = 5000;
    const tagsInput = document.createElement("input");
    tagsInput.value = (base?.config?.tags || []).join("，");
    tagsInput.placeholder = "例如：故障调查，内部支持";
    const languageSelect = document.createElement("select");
    languageSelect.innerHTML = '<option value="zh-CN">中文（简体）</option><option value="en">英文</option>';
    languageSelect.value = agent.language || "zh-CN";
    const numberInput = (value, min, max, step = "1") => {
      const input = document.createElement("input");
      input.type = "number";
      input.min = String(min);
      input.max = String(max);
      input.step = step;
      input.value = String(value);
      return input;
    };
    const maxToolCalls = numberInput(base?.runtime_policy?.max_tool_calls ?? 12, 1, 24);
    const maxToolWaves = numberInput(base?.runtime_policy?.max_tool_waves ?? 8, 1, 24);
    const maxConcurrency = numberInput(base?.runtime_policy?.max_concurrency ?? 3, 1, 6);
    const toolTimeout = numberInput(base?.runtime_policy?.tool_timeout_seconds ?? 30, 0.1, 300, "0.1");
    const runTimeout = numberInput(base?.runtime_policy?.run_timeout_seconds ?? 600, 0.1, 1800, "0.1");
    const maxToolRisk = document.createElement("select");
    maxToolRisk.innerHTML = '<option value="read_only">仅只读</option><option value="controlled_action">允许受控动作</option>';
    maxToolRisk.value = base?.config?.max_tool_risk || "controlled_action";
    const messageLimit = numberInput(base?.context_policy?.message_limit ?? 80, 1, 500);
    const compactAfter = numberInput(base?.context_policy?.compact_after_messages ?? 50, 1, 500);
    const reviewEnabled = document.createElement("input");
    reviewEnabled.type = "checkbox";
    reviewEnabled.checked = base?.review_policy?.enabled !== false;
    reviewEnabled.className = "inline-checkbox";
    const reviewDelay = numberInput(base?.review_policy?.delay_seconds ?? 0, 0, 604800);
    const replyFooter = document.createElement("textarea");
    replyFooter.value = base?.presentation_policy?.reply_footer || "";
    replyFooter.maxLength = 500;
    replyFooter.placeholder = "可选；确定性附加到每次公开答复末尾";
    const descriptionField = labeled("说明", descriptionInput);
    descriptionField.classList.add("agent-field-wide");
    const tagsField = labeled("标签（逗号分隔，最多 20 个）", tagsInput);
    tagsField.classList.add("agent-field-wide");
    generalGrid.append(
      labeled("名称", nameInput),
      labeled("主要语言", languageSelect),
      descriptionField,
      tagsField
    );
    const investigationBlock = settingsBlock("调查运行", "agent-runtime-block");
    investigationBlock.grid.append(
      labeled("单次最多工具调用", maxToolCalls),
      labeled("单次最多检查轮次", maxToolWaves),
      labeled("只读工具最大并发", maxConcurrency),
      labeled("工具超时（秒）", toolTimeout),
      labeled("整次运行超时（秒）", runTimeout),
      labeled("工具风险上限", maxToolRisk)
    );
    const contextBlock = settingsBlock("上下文与复盘", "agent-runtime-block");
    const reviewField = labeled("运行后安排复盘", reviewEnabled);
    reviewField.classList.add("agent-toggle-field");
    const replyFooterField = labeled("公开答复页脚", replyFooter);
    replyFooterField.classList.add("agent-field-wide");
    contextBlock.grid.append(
      labeled("上下文消息上限", messageLimit),
      labeled("超过多少条后压缩", compactAfter),
      reviewField,
      labeled("复盘延迟（秒）", reviewDelay),
      replyFooterField
    );
    runtimeBlocks.append(investigationBlock.block, contextBlock.block);
    policyDetails.appendChild(runtimeBlocks);
    advancedContent.insertBefore(generalPanel, actions);
    advancedContent.insertBefore(policyDetails, actions);
    const modelSelect = document.createElement("select");
    fillModelSelect(modelSelect, agent.current_model?.model_profile_id || "");
    const currentPromptVersionId = base?.prompt_bundle_version_id || "";
    const profileManaged = Boolean(nativeProfile);
    const toolCheckboxes = [];
    const enforceToolRisk = () => {
      toolCheckboxes.forEach(({ checkbox, tool }) => {
        const blocked = maxToolRisk.value === "read_only" && tool.risk !== "read_only";
        checkbox.disabled = blocked;
        if (blocked) checkbox.checked = false;
      });
    };
    maxToolRisk.onchange = enforceToolRisk;
    if (can("administer")) {
      const modelSection = document.createElement("section");
      modelSection.className = "agent-form-block agent-model-block";
      modelSection.innerHTML = "<header class=\"agent-form-block-head\"><h5>当前模型</h5><span class=\"agent-scope-badge\">智能体级</span></header>";
      const selectionGrid = document.createElement("div");
      selectionGrid.className = "agent-policy-grid agent-current-model-row";
      const switchModel = document.createElement("button");
      switchModel.type = "button";
      switchModel.textContent = "切换当前模型";
      switchModel.disabled = modelSelect.value === agent.current_model?.model_profile_id;
      modelSelect.onchange = () => {
        switchModel.disabled = modelSelect.value === agent.current_model?.model_profile_id;
      };
      switchModel.onclick = async () => {
        try {
          await api(`/api/v1/admin/agents/${agent.id}/current-model`, {
            method: "PUT",
            body: JSON.stringify({ model_profile_id: modelSelect.value }),
          });
          setAdminNotice(`${agent.name} 的当前模型已切换；下一次运行生效。`, "admin-success");
          await loadAdmin(false);
        } catch (error) {
          result.className = "agent-result admin-error";
          result.textContent = error.message;
        }
      };
      selectionGrid.append(labeled("模型资源", modelSelect), switchModel);
      modelSection.appendChild(selectionGrid);
      generalPanel.insertBefore(modelSection, generalInfoBlock);
      const personaSection = document.createElement("section");
      personaSection.className = "agent-form-block agent-model-block";
      personaSection.innerHTML = "<header class=\"agent-form-block-head\"><h5>当前交流角色</h5><span class=\"agent-scope-badge\">新会话生效</span></header>";
      const personaGrid = document.createElement("div");
      personaGrid.className = "agent-policy-grid agent-current-model-row";
      const personaSelect = document.createElement("select");
      state.personas.forEach((persona) => {
        const option = document.createElement("option");
        option.value = persona.id;
        option.textContent = `${persona.name} · ${persona.description}`;
        personaSelect.appendChild(option);
      });
      personaSelect.value = agent.current_persona?.id || "technical-peer";
      const switchPersona = document.createElement("button");
      switchPersona.type = "button";
      switchPersona.textContent = "切换交流角色";
      switchPersona.disabled = personaSelect.value === agent.current_persona?.id;
      personaSelect.onchange = () => {
        switchPersona.disabled = personaSelect.value === agent.current_persona?.id;
      };
      switchPersona.onclick = async () => {
        try {
          await api(`/api/v1/admin/agents/${agent.id}/current-persona`, {
            method: "PUT",
            body: JSON.stringify({ persona_id: personaSelect.value }),
          });
          setAdminNotice(`${agent.name} 的交流角色已切换；新建会话生效，现有会话保持原角色。`, "admin-success");
          await loadAdmin(false);
        } catch (error) {
          result.className = "agent-result admin-error";
          result.textContent = error.message;
        }
      };
      personaGrid.append(labeled("交流角色", personaSelect), switchPersona);
      const personaNote = document.createElement("p");
      personaNote.className = "form-note";
      personaNote.textContent = "切换立即保存，不创建或发布智能体版本；每个会话在创建时冻结所选角色。";
      personaSection.append(personaGrid, personaNote);
      generalPanel.insertBefore(personaSection, generalInfoBlock);
      const toolsPanel = document.createElement("section");
      toolsPanel.className = "agent-settings-panel";
      toolsPanel.dataset.agentSettingsPanel = "tools";
      const toolChoiceGrid = document.createElement("div");
      toolChoiceGrid.className = "agent-tool-choice-grid";
      const selectedToolNames = new Set(base?.config?.tool_allowlist || []);
      const selectableTools = userSelectableTools();
      selectableTools.forEach((tool) => {
        const choice = document.createElement("label");
        choice.className = "agent-tool-choice";
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.className = "inline-checkbox";
        checkbox.checked = selectedToolNames.has(tool.name);
        const copy = document.createElement("span");
        copy.innerHTML = `<strong>${toolNameMarkup(tool.name)}</strong><small>${escapeHtml(toolLabel(tool.name))}</small><em>${escapeHtml(statusLabel(tool.risk))}</em>`;
        choice.append(checkbox, copy);
        toolCheckboxes.push({ checkbox, tool });
        toolChoiceGrid.appendChild(choice);
      });
      if (!selectableTools.length) {
        toolChoiceGrid.innerHTML = '<div class="manager-empty"><strong>暂无可选工具</strong><span>系统运行工具已自动启用，无需配置。</span></div>';
      }
      toolsPanel.appendChild(toolChoiceGrid);
      enforceToolRisk();
      advancedContent.insertBefore(toolsPanel, actions);

      const promptsPanel = document.createElement("section");
      promptsPanel.className = "agent-settings-panel";
      promptsPanel.dataset.agentSettingsPanel = "prompts";
      const promptDocument = document.createElement("section");
      promptDocument.className = "agent-prompt-document";
      const promptDocumentHeader = document.createElement("header");
      promptDocumentHeader.className = "agent-prompt-document-header";
      promptDocumentHeader.innerHTML = "<strong>AGENTS.md</strong><small>该智能体的常驻职责、调查与证据规则；交流方式由 Persona 单独选择</small>";
      const promptEditor = document.createElement("textarea");
      promptEditor.className = "agent-prompt-editor";
      promptEditor.spellcheck = false;
      promptEditor.required = true;
      promptEditor.maxLength = 190000;
      promptEditor.placeholder = "填写该智能体的 AGENTS.md";
      const currentPromptVersion = () => {
        for (const bundle of state.prompts) {
          const version = bundle.versions.find((item) => item.id === currentPromptVersionId);
          if (version) return { bundle, version };
        }
        return null;
      };
      const selectedPrompt = currentPromptVersion();
      promptEditor.value = promptContentAsAgentsMarkdown(selectedPrompt?.version?.content);
      promptDocument.append(promptDocumentHeader, promptEditor);
      promptsPanel.appendChild(promptDocument);
      const promptActions = document.createElement("div");
      promptActions.className = "admin-actions";
      const savePromptVersion = document.createElement("button");
      savePromptVersion.type = "button";
      savePromptVersion.textContent = "保存 AGENTS.md";
      savePromptVersion.onclick = async () => {
        if (!promptEditor.reportValidity()) return;
        const selected = currentPromptVersion();
        if (!selected) return;
        let draftSaved = false;
        try {
          const created = await api(`/api/v1/admin/prompt-bundles/${selected.bundle.id}/versions`, {
            method: "POST",
            body: JSON.stringify({
              content: { system_prompt: promptEditor.value.trim() },
              source_ref: "admin:agent-agents-md",
            }),
          });
          const version = created.versions[0];
          const payload = buildAgentSettingsPayload();
          payload.prompt_bundle_version_id = version.id;
          const savedAgent = await api(`/api/v1/admin/agents/${agent.id}/draft`, {
            method: "PATCH",
            body: JSON.stringify(payload),
          });
          draftSaved = true;
          const outcome = await publishSavedAgentDraft(
            savedAgent,
            "从智能体 AGENTS.md 保存",
            result
          );
          if (!outcome.published) {
            setAdminNotice(
              agentDraftBlockedMessage("AGENTS.md", outcome.findings, outcome.message),
              "admin-warning"
            );
            await loadAdmin(false);
            return;
          }
          setAdminNotice(`${agent.name} 的 AGENTS.md 已保存；下一次运行使用新配置。`, "admin-success");
          await loadAdmin(false);
        } catch (error) {
          result.className = "agent-result admin-error";
          result.textContent = draftSaved
            ? agentDraftBlockedMessage("AGENTS.md", agentDraftValidationFindings(error), error.message)
            : `保存失败，当前运行配置没有变化：${error.message}`;
        }
      };
      promptActions.appendChild(savePromptVersion);
      promptsPanel.appendChild(promptActions);
      advancedContent.insertBefore(promptsPanel, actions);

      const usagePanel = document.createElement("section");
      usagePanel.className = "agent-settings-panel";
      usagePanel.dataset.agentSettingsPanel = "usage";
      const usage = state.agentUsage;
      const totals = usage?.totals || {};
      const formatUsage = (value) => Number(value || 0).toLocaleString("zh-CN");
      const dailyRows = (usage?.daily || []).slice().reverse().map((item) => `
        <tr><td>${escapeHtml(item.date)}</td><td>${formatUsage(item.runs)}</td><td>${formatUsage(item.model_calls)}</td><td>${formatUsage(item.tool_calls)}</td><td>${formatUsage(item.total_tokens)}</td></tr>`).join("");
      usagePanel.innerHTML = `
        <div class="agent-usage-metrics">
          <div><span>总 Token</span><strong>${formatUsage(totals.total_tokens)}</strong></div>
          <div><span>输入 Token</span><strong>${formatUsage(totals.input_tokens)}</strong></div>
          <div><span>输出 Token</span><strong>${formatUsage(totals.output_tokens)}</strong></div>
          <div><span>Runs</span><strong>${formatUsage(totals.runs)}</strong></div>
          <div><span>模型回合</span><strong>${formatUsage(totals.model_calls)}</strong></div>
          <div><span>工具调用</span><strong>${formatUsage(totals.tool_calls)}</strong></div>
        </div>
        <div class="agent-usage-table-wrap"><table class="agent-usage-table"><thead><tr><th>日期</th><th>Runs</th><th>模型回合</th><th>工具调用</th><th>Token</th></tr></thead><tbody>${dailyRows || '<tr><td colspan="5">暂无使用记录</td></tr>'}</tbody></table></div>
        <p class="form-note">Token 可观测性：${escapeHtml(statusLabel(usage?.observability?.token_coverage || "not_observable"))} · 时区 ${escapeHtml(usage?.period?.time_zone || "UTC")}</p>`;
      advancedContent.insertBefore(usagePanel, actions);
    }

    const buildAgentSettingsPayload = () => {
      const tags = Array.from(new Set(
        tagsInput.value.split(/[,，]/).map((item) => item.trim()).filter(Boolean)
      ));
      const selectedTools = toolCheckboxes
        .filter(({ checkbox }) => checkbox.checked)
        .map(({ tool }) => tool.name);
      const packVersionIds = new Set((base?.packs || []).map((item) => item.pack_version_id));
      selectedTools.forEach((toolName) => {
        const tool = state.tools.find((item) => item.name === toolName);
        if (selectedToolNames.has(toolName)) return;
        const installedPack = (tool?.pack_usage || []).find((item) => item.status === "installed");
        if (installedPack?.pack_version_id) packVersionIds.add(installedPack.pack_version_id);
      });
      const config = {
        ...(base?.config || {}),
        tags,
        max_tool_risk: maxToolRisk.value,
        tool_allowlist: selectedTools,
        connector_bindings: connectorBindingsForSelectedTools(selectedTools),
      };
      if (profileManaged) {
        delete config.agent_profile_id;
        delete config.agent_profile_version;
        delete config.agent_profile_digest;
      }
      return {
        name: nameInput.value.trim(),
        description: descriptionInput.value.trim(),
        language: languageSelect.value,
        prompt_bundle_version_id: currentPromptVersionId,
        pack_version_ids: Array.from(packVersionIds),
        capability_bindings: capabilityBindingsForSelectedTools(
          selectedTools,
          base?.capabilities || []
        ),
        runtime_policy: {
          ...(base?.runtime_policy || {}),
          max_tool_calls: Number(maxToolCalls.value),
          max_tool_waves: Number(maxToolWaves.value),
          max_concurrency: Number(maxConcurrency.value),
          tool_timeout_seconds: Number(toolTimeout.value),
          run_timeout_seconds: Number(runTimeout.value),
        },
        context_policy: {
          ...(base?.context_policy || {}),
          message_limit: Number(messageLimit.value),
          compact_after_messages: Number(compactAfter.value),
        },
        channel_policy: { ...(base?.channel_policy || {}) },
        review_policy: {
          ...(base?.review_policy || {}),
          enabled: reviewEnabled.checked,
          delay_seconds: Number(reviewDelay.value),
        },
        presentation_policy: {
          ...(base?.presentation_policy || {}),
          reply_footer: replyFooter.value.trim(),
        },
        config,
      };
    };

    const saveSettings = document.createElement("button");
    saveSettings.textContent = "保存设置";
    saveSettings.onclick = async () => {
      result.textContent = "正在保存…";
      let draftSaved = false;
      try {
        const savedAgent = await api(`/api/v1/admin/agents/${agent.id}/draft`, {
          method: "PATCH",
          body: JSON.stringify(buildAgentSettingsPayload()),
        });
        draftSaved = true;
        const outcome = await publishSavedAgentDraft(savedAgent, "从智能体设置保存", result);
        if (!outcome.published) {
          setAdminNotice(
            agentDraftBlockedMessage("设置", outcome.findings, outcome.message),
            "admin-warning"
          );
          await loadAdmin(false);
          return;
        }
        setAdminNotice(`${agent.name} 的设置已保存；下一次运行使用新配置。`, "admin-success");
        await loadAdmin(false);
      } catch (error) {
        result.className = "agent-result admin-error";
        result.textContent = draftSaved
          ? agentDraftBlockedMessage("设置", agentDraftValidationFindings(error), error.message)
          : `保存失败，当前运行配置没有变化：${error.message}`;
      }
    };
    if (can("administer")) actions.appendChild(saveSettings);
    if (can("administer") && agent.status === "published" && !agent.is_default) {
      const makeDefault = document.createElement("button");
      makeDefault.className = "secondary";
      makeDefault.textContent = "设为缺省智能体";
      makeDefault.onclick = async () => {
        try {
          await api("/api/v1/admin/default-agent", {
            method: "POST",
            body: JSON.stringify({ agent_id: agent.id }),
          });
          await loadAdmin(false);
          setAdminNotice(`${agent.name} 已设为未明确绑定入口的缺省智能体。`, "admin-success");
        } catch (error) {
          result.className = "agent-result admin-error";
          result.textContent = error.message;
        }
      };
      actions.appendChild(makeDefault);
    }
    if (can("administer")) {
      const clone = document.createElement("button");
      clone.className = "secondary";
      clone.textContent = "克隆为新智能体";
      clone.onclick = async () => {
        const cloneId = prompt("新智能体稳定 ID（小写字母、数字或连字符）");
        if (!cloneId) return;
        const cloneName = prompt("新智能体名称", `${agent.name} 副本`);
        if (!cloneName) return;
        try {
          const cloned = await api(`/api/v1/admin/agents/${agent.id}/clone`, {
            method: "POST",
            body: JSON.stringify({ id: cloneId.trim(), name: cloneName.trim() }),
          });
          await api(`/api/v1/admin/agents/${cloned.id}/publish`, {
            method: "POST",
            body: JSON.stringify({ note: "从智能体设置克隆" }),
          });
          setAdminNotice(`${cloneName} 已创建并启用；渠道绑定和凭据未克隆。`, "admin-success");
          await loadAdmin(false);
        } catch (error) {
          result.className = "agent-result admin-error";
          result.textContent = error.message;
        }
      };
      actions.appendChild(clone);
      if (agent.status === "disabled") {
        const enable = document.createElement("button");
        enable.className = "secondary";
        enable.textContent = "重新启用智能体";
        enable.onclick = async () => {
          try {
            await api(`/api/v1/admin/agents/${agent.id}/status`, {
              method: "POST",
              body: JSON.stringify({ status: "enabled" }),
            });
            setAdminNotice(`${agent.name} 已恢复接收新运行；依赖已重新校验。`, "admin-success");
            await loadAdmin(false);
          } catch (error) {
            result.className = "agent-result admin-error";
            result.textContent = error.message;
          }
        };
        actions.appendChild(enable);
      }
      if (!["disabled", "archived"].includes(agent.status) && !agent.is_default) {
        const disable = document.createElement("button");
        disable.className = "danger";
        disable.textContent = "禁用智能体";
        disable.onclick = async () => {
          if (!confirm(`确认禁用“${agent.name}”？之后新运行将被拒绝。`)) return;
          await api(`/api/v1/admin/agents/${agent.id}/status`, {
            method: "POST",
            body: JSON.stringify({ status: "disabled" }),
          });
          await loadAdmin(false);
        };
        actions.appendChild(disable);
      }
      if (agent.status !== "archived" && !agent.is_default) {
        const archive = document.createElement("button");
        archive.className = "danger";
        archive.textContent = "归档智能体";
        archive.onclick = async () => {
          if (!confirm(`确认归档“${agent.name}”？该操作会解除渠道绑定，且不能恢复。`)) return;
          await api(`/api/v1/admin/agents/${agent.id}/status`, {
            method: "POST",
            body: JSON.stringify({ status: "archived" }),
          });
          await loadAdmin(false);
        };
        actions.appendChild(archive);
      }
    }

    advancedContent.append(actions, result);
    const settingTabs = Array.from(card.querySelectorAll("[data-agent-settings-tab]"));
    const settingPanels = Array.from(card.querySelectorAll("[data-agent-settings-panel]"));
    const activateSettingTab = (requested) => {
      const availableTabs = new Set(settingPanels.map((panel) => panel.dataset.agentSettingsPanel));
      const selected = settingPanels.some((panel) => panel.dataset.agentSettingsPanel === requested)
        ? requested
        : "general";
      state.agentSettingsTab = selected;
      settingTabs.forEach((button) => {
        button.classList.toggle("hidden", !availableTabs.has(button.dataset.agentSettingsTab));
        const activeTab = button.dataset.agentSettingsTab === selected;
        button.classList.toggle("secondary", !activeTab);
        button.setAttribute("aria-current", activeTab ? "page" : "false");
      });
      settingPanels.forEach((panel) => {
        panel.classList.toggle("hidden", panel.dataset.agentSettingsPanel !== selected);
      });
      actions.classList.toggle("hidden", selected === "usage");
    };
    settingTabs.forEach((button) => {
      button.onclick = () => activateSettingTab(button.dataset.agentSettingsTab);
    });
    activateSettingTab(state.agentSettingsTab);
    root.appendChild(card);
  });
  document.getElementById("agent-page-actions").innerHTML = "";
}

function modelLabeledControl(text, control, hint = "") {
  const label = document.createElement("label");
  label.className = "model-form-field";
  const heading = document.createElement("span");
  heading.className = "model-form-label";
  heading.textContent = text;
  label.append(heading, control);
  if (hint) {
    const help = document.createElement("small");
    help.textContent = hint;
    label.appendChild(help);
  }
  return label;
}

function openModelModal(title, eyebrow, trigger) {
  const backdrop = document.getElementById("model-modal-backdrop");
  const modal = document.getElementById("model-modal");
  modelModalReturnFocus = trigger || modelModalReturnFocus || document.activeElement;
  document.getElementById("model-modal-title").textContent = title;
  document.getElementById("model-modal-eyebrow").textContent = eyebrow;
  backdrop.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("model-modal-open");
}

function closeModelModal() {
  const backdrop = document.getElementById("model-modal-backdrop");
  const modal = document.getElementById("model-modal");
  document.getElementById("model-modal-body").replaceChildren();
  backdrop.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
  document.body.classList.remove("model-modal-open");
  if (modelModalReturnFocus?.isConnected) modelModalReturnFocus.focus();
  modelModalReturnFocus = null;
}

function modelModalMessage(message, error = false) {
  const body = document.getElementById("model-modal-body");
  const notice = document.createElement("p");
  notice.className = error ? "model-modal-message error" : "model-modal-message";
  notice.textContent = message;
  body.replaceChildren(notice);
}

function generatedStableResourceId(value, fallback) {
  let slug = value.toLowerCase().normalize("NFKD")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
  if (!slug || !/^[a-z]/.test(slug)) {
    slug = `${fallback}${slug ? `-${slug}` : ""}`.slice(0, 40);
  }
  const randomBytes = new Uint8Array(4);
  if (window.crypto?.getRandomValues) {
    window.crypto.getRandomValues(randomBytes);
  } else {
    const fallback = Math.floor((Date.now() + Math.random() * 0xffffffff) % 0x100000000);
    new DataView(randomBytes.buffer).setUint32(0, fallback);
  }
  const suffix = Array.from(randomBytes, (value) => value.toString(16).padStart(2, "0")).join("");
  return `${slug}-${suffix}`.slice(0, 64);
}

function generatedProviderId(name) {
  return generatedStableResourceId(name, "provider");
}

function generatedModelProfileId(name, modelId) {
  return generatedStableResourceId(modelId || name, "model");
}

function openProviderSettings(provider = null, trigger = null, focusApiKey = false) {
  const current = provider?.versions?.[0];
  openModelModal(provider ? "修改提供商" : "添加提供商", "实例级模型资源", trigger);
  const body = document.getElementById("model-modal-body");
  const form = document.createElement("form");
  form.className = "model-config-form";
  const grid = document.createElement("div");
  grid.className = "model-form-grid";
  const name = document.createElement("input");
  name.required = true;
  name.maxLength = 200;
  name.placeholder = "例如 本地模型服务";
  name.value = provider?.name || "";
  const protocol = document.createElement("select");
  protocol.innerHTML = '<option value="openai-compatible">OpenAI-compatible</option>';
  protocol.value = provider?.protocol || "openai-compatible";
  protocol.disabled = true;
  const endpoint = document.createElement("input");
  endpoint.type = "url";
  endpoint.required = true;
  endpoint.maxLength = 2000;
  endpoint.placeholder = "http://127.0.0.1:8080/v1";
  endpoint.value = current?.endpoint?.value || "";
  const apiKey = document.createElement("input");
  apiKey.type = "password";
  apiKey.maxLength = 65536;
  apiKey.autocomplete = "new-password";
  apiKey.placeholder = provider ? "留空以保持当前 API Key" : "可选";
  grid.append(
    modelLabeledControl("名称", name),
    modelLabeledControl("连接协议", protocol, "OpenAI-compatible 是连接协议，不是模型提供商"),
    modelLabeledControl("Endpoint", endpoint),
    modelLabeledControl("API Key", apiKey, provider ? "不回显；留空保持当前值" : "不需要密钥时可留空")
  );
  const note = document.createElement("p");
  note.className = "model-form-note";
  note.textContent = provider
    ? `保存会更新此提供商，并让其下 ${provider.profile_count || 0} 个模型从下一次运行使用新配置。`
    : "提供商属于整个 Suwen 实例；模型创建后由各个智能体分别选择。";
  const error = document.createElement("p");
  error.className = "model-form-error hidden";
  error.setAttribute("role", "alert");
  error.setAttribute("aria-live", "polite");
  error.tabIndex = -1;
  const actions = document.createElement("div");
  actions.className = "model-modal-actions";
  const cancel = document.createElement("button");
  cancel.type = "button";
  cancel.className = "secondary";
  cancel.textContent = "取消";
  cancel.onclick = closeModelModal;
  const save = document.createElement("button");
  save.type = "submit";
  save.textContent = provider ? "保存提供商" : "添加提供商";
  form.addEventListener("invalid", (event) => {
    const invalid = form.querySelector(":invalid");
    if (event.target !== invalid) return;
    if (invalid === name) {
      error.textContent = "请填写提供商名称。";
    } else if (endpoint.validity.valueMissing) {
      error.textContent = "请填写 Endpoint。";
    } else {
      error.textContent = "请输入完整有效的 Endpoint，例如 http://127.0.0.1:8080/v1。";
    }
    error.className = "model-form-error";
  }, true);
  actions.append(cancel, save);
  form.append(grid, note, error, actions);
  form.onsubmit = async (event) => {
    event.preventDefault();
    error.textContent = "";
    error.className = "model-form-error hidden";
    await runBusy(save, "保存中…", async () => {
      try {
        const payload = {
          name: name.value.trim(),
          protocol: protocol.value,
          endpoint: endpoint.value.trim(),
        };
        if (!provider) payload.id = generatedProviderId(payload.name);
        if (apiKey.value) payload.api_key = apiKey.value;
        await api(provider ? `/api/v1/admin/model-providers/${provider.id}` : "/api/v1/admin/model-providers", {
          method: provider ? "PUT" : "POST",
          body: JSON.stringify(payload),
        });
        closeModelModal();
        setAdminNotice(`${payload.name} 已保存。`, "admin-success");
        await loadAdmin(false);
      } catch (caught) {
        error.textContent = caught.message;
        error.className = "model-form-error";
        error.focus();
      }
    });
  };
  [name, endpoint, apiKey].forEach((control) => {
    control.addEventListener("input", () => {
      if (!error.classList.contains("hidden")) {
        error.textContent = "";
        error.className = "model-form-error hidden";
      }
    });
  });
  body.replaceChildren(form);
  requestAnimationFrame(() => (focusApiKey ? apiKey : name).focus());
}

function modelCapabilityToggle(text, checked) {
  const label = document.createElement("label");
  label.className = "model-capability-toggle";
  const input = document.createElement("input");
  input.type = "checkbox";
  input.checked = checked;
  const copy = document.createElement("span");
  copy.textContent = text;
  label.append(copy, input);
  return { label, input };
}

function buildModelEditor(provider, profile = null, onCancel = null, availableModelIds = [], catalogTruncated = false) {
  const version = profile?.versions?.[0];
  const form = document.createElement("form");
  form.className = "provider-model-editor";
  const grid = document.createElement("div");
  grid.className = "model-form-grid";
  const name = document.createElement("input");
  name.required = true;
  name.maxLength = 200;
  name.value = profile?.name || "";
  name.placeholder = "例如 keyu-mtp (130K)";
  const modelId = document.createElement(profile ? "input" : "select");
  modelId.required = true;
  if (profile) {
    modelId.maxLength = 200;
    modelId.value = version?.model_id || "";
    modelId.placeholder = "模型服务中的 model id";
  } else {
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "请选择连接支持的模型";
    placeholder.disabled = true;
    placeholder.selected = true;
    modelId.appendChild(placeholder);
    availableModelIds.forEach((availableModelId) => {
      const option = document.createElement("option");
      option.value = availableModelId;
      option.textContent = availableModelId;
      modelId.appendChild(option);
    });
    let nameEdited = false;
    name.addEventListener("input", () => {
      nameEdited = Boolean(name.value.trim());
    });
    modelId.addEventListener("change", () => {
      if (!nameEdited) name.value = modelId.value;
    });
  }
  const context = document.createElement("input");
  context.type = "number";
  context.min = "1024";
  context.required = true;
  context.value = version?.max_input_length || 70000;
  const output = document.createElement("input");
  output.type = "number";
  output.min = "1";
  output.required = true;
  output.value = version?.max_output_tokens || 4096;
  const temperature = document.createElement("input");
  temperature.type = "number";
  temperature.min = "0";
  temperature.max = "2";
  temperature.step = "0.1";
  temperature.required = true;
  temperature.value = version?.temperature ?? 0.2;
  const reasoningEffort = document.createElement("select");
  [
    ["none", "关闭（none）"],
    ["low", "低（low）"],
    ["medium", "中（medium）"],
    ["high", "高（high，默认）"],
    ["xhigh", "更高（xhigh）"],
    ["max", "最高（max）"],
  ].forEach(([value, label]) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = label;
    reasoningEffort.appendChild(option);
  });
  reasoningEffort.value = version?.reasoning_effort ?? "high";
  const timeout = document.createElement("input");
  timeout.type = "number";
  timeout.min = "0.1";
  timeout.max = "600";
  timeout.step = "0.1";
  timeout.required = true;
  timeout.value = version?.timeout_seconds || 60;
  grid.append(
    modelLabeledControl("模型名称", name),
    modelLabeledControl("模型 ID", modelId),
    modelLabeledControl("上下文长度", context, "tokens"),
    modelLabeledControl("最大输出", output, "tokens"),
    modelLabeledControl("生成温度", temperature),
    modelLabeledControl("思考级别", reasoningEffort),
    modelLabeledControl("请求超时", timeout, "秒")
  );
  const capabilities = document.createElement("div");
  capabilities.className = "model-capability-grid";
  const toolCalling = modelCapabilityToggle("工具调用", version?.capabilities?.tool_calling ?? true);
  const vision = modelCapabilityToggle("图片输入", version?.capabilities?.vision ?? false);
  const structured = modelCapabilityToggle("结构化输出", version?.capabilities?.structured_output ?? false);
  const local = modelCapabilityToggle("本地模型", version?.capabilities?.local ?? provider.id === "local");
  capabilities.append(toolCalling.label, vision.label, structured.label, local.label);
  const note = document.createElement("p");
  note.className = "model-form-note";
  const usageCount = profile?.usage?.agents?.length || 0;
  note.textContent = profile
    ? `当前有 ${usageCount} 个智能体选择此模型。保存只影响后续运行；思考级别按供应商支持情况发送，图片输入和结构化输出还必须通过对应合成探针。`
    : `Model ID 来自此连接的协议目录${catalogTruncated ? "（目录过大，当前仅显示前 1000 项）" : ""}；思考级别默认 high，图片输入和结构化输出需声明后通过合成探针。`;
  const error = document.createElement("p");
  error.className = "model-form-error hidden";
  error.setAttribute("role", "alert");
  error.setAttribute("aria-live", "polite");
  error.tabIndex = -1;
  const actions = document.createElement("div");
  actions.className = "model-editor-actions";
  const cancel = document.createElement("button");
  cancel.type = "button";
  cancel.className = "secondary";
  cancel.textContent = "取消";
  cancel.onclick = () => onCancel?.();
  const save = document.createElement("button");
  save.type = "submit";
  save.textContent = "保存模型";
  actions.appendChild(cancel);
  if (profile && version) {
    const probe = document.createElement("button");
    probe.type = "button";
    probe.className = "secondary";
    probe.textContent = version.last_probe?.status === "passed" ? "重新测试" : "测试连接";
    probe.onclick = async () => {
      if (!confirm("将向该模型发送固定合成请求验证文本、工具调用及已声明的图片/结构化能力；不包含案件或真实会话，也不执行工具。继续吗？")) return;
      await runBusy(probe, "正在测试…", async () => {
        try {
          const observed = await api(`/api/v1/admin/model-profile-versions/${version.id}/probe`, { method: "POST" });
          error.textContent = observed.status === "passed"
            ? "连接、工具调用及已声明能力测试通过。"
            : observed.findings.map(findingLabel).join(" · ");
          error.className = observed.status === "passed" ? "model-form-success" : "model-form-error";
        } catch (caught) {
          error.textContent = caught.message;
          error.className = "model-form-error";
        }
      });
    };
    actions.appendChild(probe);
  }
  actions.appendChild(save);
  form.append(grid, capabilities, note, error, actions);
  form.addEventListener("invalid", (event) => {
    const invalid = form.querySelector(":invalid");
    if (event.target !== invalid) return;
    error.textContent = invalid === name
      ? "请填写模型名称。"
      : invalid === modelId
        ? "请填写模型 ID。"
        : "请检查数值范围后再保存。";
    error.className = "model-form-error";
  }, true);
  form.onsubmit = async (event) => {
    event.preventDefault();
    error.textContent = "";
    error.className = "model-form-error hidden";
    await runBusy(save, "保存中…", async () => {
      try {
        const payload = {
          provider_id: provider.id,
          provider_version_id: provider.versions?.[0]?.id,
          name: name.value.trim(),
          model_id: modelId.value.trim(),
          max_input_length: Number(context.value),
          max_output_tokens: Number(output.value),
          temperature: Number(temperature.value),
          reasoning_effort: reasoningEffort.value,
          timeout_seconds: Number(timeout.value),
          capabilities: {
            tool_calling: toolCalling.input.checked,
            vision: vision.input.checked,
            structured_output: structured.input.checked,
            local: local.input.checked,
          },
          routing: { fallback: false },
        };
        if (!profile) payload.id = generatedModelProfileId(payload.name, payload.model_id);
        await api(profile ? `/api/v1/admin/model-profiles/${profile.id}` : "/api/v1/admin/model-profiles", {
          method: profile ? "PUT" : "POST",
          body: JSON.stringify(payload),
        });
        setAdminNotice(`${payload.name} 已保存。`, "admin-success");
        await loadAdmin(false);
        await showProviderModels(provider.id);
      } catch (caught) {
        error.textContent = caught.message;
        error.className = "model-form-error";
        error.focus();
      }
    });
  };
  [name, modelId, context, output, temperature, reasoningEffort, timeout].forEach((control) => {
    control.addEventListener("input", () => {
      if (!error.classList.contains("hidden")) {
        error.textContent = "";
        error.className = "model-form-error hidden";
      }
    });
  });
  return form;
}

function renderModelCatalogNotice(provider, profiles, title, detail, retryable) {
  const body = document.getElementById("model-modal-body");
  const panel = document.createElement("div");
  panel.className = "model-modal-empty";
  const heading = document.createElement("strong");
  heading.textContent = title;
  const copy = document.createElement("span");
  copy.textContent = detail;
  const actions = document.createElement("div");
  actions.className = "model-modal-actions";
  const back = document.createElement("button");
  back.type = "button";
  back.className = "secondary";
  back.textContent = "返回";
  back.onclick = () => showProviderModels(provider.id);
  actions.appendChild(back);
  if (retryable) {
    const retry = document.createElement("button");
    retry.type = "button";
    retry.textContent = "重新读取";
    retry.onclick = () => openProviderModelCreate(provider, profiles);
    actions.appendChild(retry);
  }
  panel.append(heading, copy, actions);
  body.replaceChildren(panel);
}

async function openProviderModelCreate(provider, profiles) {
  document.getElementById("model-modal-title").textContent = "添加模型";
  modelModalMessage("正在从模型连接读取支持的模型…");
  try {
    const catalog = await api(`/api/v1/admin/model-providers/${provider.id}/model-catalog`);
    const existingModelIds = new Set(
      profiles.map((profile) => profile.versions?.[0]?.model_id).filter(Boolean)
    );
    const availableModelIds = catalog.items
      .map((item) => item.id)
      .filter((modelId) => !existingModelIds.has(modelId));
    if (!availableModelIds.length) {
      const title = catalog.items.length ? "目录中的模型都已添加" : "连接没有返回可用模型";
      const detail = catalog.items.length
        ? "返回模型列表后可继续管理已有资源。"
        : "请检查该 Endpoint 是否实现 OpenAI-compatible GET /models。";
      renderModelCatalogNotice(provider, profiles, title, detail, false);
      return;
    }
    const editor = buildModelEditor(
      provider,
      null,
      () => showProviderModels(provider.id),
      availableModelIds,
      catalog.truncated
    );
    document.getElementById("model-modal-body").replaceChildren(editor);
    requestAnimationFrame(() => editor.querySelector("select")?.focus());
  } catch (caught) {
    renderModelCatalogNotice(provider, profiles, "模型目录读取失败", caught.message, true);
  }
}

function renderProviderModelList(provider, profiles) {
  const body = document.getElementById("model-modal-body");
  const toolbar = document.createElement("div");
  toolbar.className = "provider-model-toolbar";
  const search = document.createElement("input");
  search.type = "search";
  search.placeholder = "搜索模型…";
  search.setAttribute("aria-label", "搜索模型");
  const add = document.createElement("button");
  add.type = "button";
  add.textContent = "添加模型";
  add.classList.toggle("hidden", !can("administer"));
  add.onclick = () => openProviderModelCreate(provider, profiles);
  toolbar.append(search, add);
  const list = document.createElement("div");
  list.className = "provider-model-list";
  const draw = () => {
    list.replaceChildren();
    const query = search.value.trim().toLowerCase();
    const visible = profiles.filter((profile) => {
      const version = profile.versions?.[0];
      return `${profile.name} ${version?.model_id || ""}`.toLowerCase().includes(query);
    });
    visible.forEach((profile) => {
      const version = profile.versions?.[0];
      if (!version) return;
      const usage = profile.usage || { agents: [], deletable: false, delete_blockers: [] };
      const row = document.createElement("article");
      row.className = "provider-model-row";
      const summary = document.createElement("div");
      summary.className = "provider-model-row-summary";
      summary.innerHTML = `<div><h3>${escapeHtml(profile.name)}</h3><code>${escapeHtml(version.model_id)}</code></div>`;
      const controls = document.createElement("div");
      controls.className = "provider-model-row-controls";
      const usageLabel = document.createElement("span");
      usageLabel.className = "provider-model-usage";
      usageLabel.textContent = usage.agents.length ? `${usage.agents.length} 个智能体使用` : "未使用";
      const actions = document.createElement("div");
      actions.className = "provider-model-row-actions";
      let settings = null;
      const editor = buildModelEditor(provider, profile, () => {
        editor.classList.add("hidden");
        if (settings) settings.textContent = "设置";
      });
      editor.classList.add("hidden");
      if (can("administer")) {
        settings = document.createElement("button");
        settings.type = "button";
        settings.className = "secondary";
        settings.textContent = "设置";
        settings.onclick = () => {
          const willOpen = editor.classList.contains("hidden");
          editor.classList.toggle("hidden", !willOpen);
          settings.textContent = willOpen ? "收起" : "设置";
          if (willOpen) requestAnimationFrame(() => editor.querySelector("input")?.focus());
        };
        actions.appendChild(settings);
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "danger";
        remove.textContent = "删除";
        remove.disabled = !usage.deletable;
        remove.title = usage.deletable ? "删除未被智能体使用的模型" : `不能删除：${usage.delete_blockers.join("、")}`;
        remove.onclick = async () => {
          if (!confirm(`确认删除“${profile.name}”？该模型当前没有应用，删除后不能恢复。`)) return;
          try {
            await api(`/api/v1/admin/model-profiles/${profile.id}`, { method: "DELETE" });
            setAdminNotice(`${profile.name} 已删除。`, "admin-success");
            await loadAdmin(false);
            await showProviderModels(provider.id);
          } catch (caught) {
            setAdminNotice(`删除失败：${caught.message}`, "admin-error");
          }
        };
        actions.appendChild(remove);
      }
      controls.append(usageLabel, actions);
      summary.appendChild(controls);
      row.appendChild(summary);
      if (can("administer")) row.appendChild(editor);
      list.appendChild(row);
    });
    if (!visible.length) {
      const emptyTitle = profiles.length ? "没有匹配的模型" : "此连接还没有模型";
      const emptyDetail = profiles.length
        ? "清空搜索词，或从连接目录添加一个新模型。"
        : "点击“添加模型”，从此连接按协议返回的模型目录中选择。";
      list.innerHTML = `<div class="model-modal-empty"><strong>${emptyTitle}</strong><span>${emptyDetail}</span></div>`;
    }
  };
  search.oninput = draw;
  draw();
  body.replaceChildren(toolbar, list);
}

async function showProviderModels(providerId, trigger = null) {
  const provider = state.providers.find((item) => item.id === providerId)
    || state.providerCatalog.find((item) => item.id === providerId);
  if (!provider) return;
  openModelModal("模型", displayName(provider.id, provider.name), trigger);
  modelModalMessage("正在加载模型…");
  try {
    const params = new URLSearchParams({ limit: "500", offset: "0", provider_id: provider.id });
    const response = await api(`/api/v1/admin/model-profiles?${params.toString()}`);
    renderProviderModelList(provider, response.items);
  } catch (caught) {
    modelModalMessage(`模型加载失败：${caught.message}`, true);
  }
}

function renderModels() {
  const providerRoot = document.getElementById("model-provider-list");
  const summary = document.getElementById("model-summary");
  const providerCount = state.providers.length;
  const profileCount = state.profiles.length;
  const query = state.modelProviderQuery.trim().toLowerCase();
  const providers = state.providers.filter((provider) =>
    `${provider.name} ${provider.id}`.toLowerCase().includes(query)
  );
  providerRoot.replaceChildren();
  document.getElementById("model-provider-tab-count").textContent = providerCount;
  summary.innerHTML = `<span class="provider-summary-dot" aria-hidden="true"></span><strong>实例共享资源</strong><span>${providerCount} 个提供商 · ${profileCount} 个模型</span>`;
  providers.forEach((provider) => {
    const current = provider.versions?.[0];
    const endpoint = current?.endpoint?.value || "未配置";
    const live = provider.status === "active"
      && current?.endpoint?.configured
      && (!current?.secret || current.secret.configured);
    const keyStatus = current?.secret
      ? (current.secret.configured ? "••••••••" : "未配置")
      : "无需配置";
    const card = document.createElement("article");
    card.className = "model-provider-card";
    card.innerHTML = `
      <header class="model-provider-card-header">
        <div class="model-provider-identity">
          <span class="model-provider-avatar" aria-hidden="true">${escapeHtml((provider.id === "local" ? "L" : provider.name.slice(0, 1)).toUpperCase())}</span>
          <div><h3>${escapeHtml(displayName(provider.id, provider.name))}</h3><span class="model-provider-kind">自定义</span></div>
        </div>
        <span class="model-provider-live ${live ? "online" : ""}"><i aria-hidden="true"></i>${live ? "Live" : "未启用"}</span>
      </header>
      <div class="model-provider-fields">
        <div class="model-provider-field"><span>ENDPOINT</span><code title="${escapeHtml(endpoint)}">${escapeHtml(endpoint)}</code></div>
        <div class="model-provider-field model-provider-key"><span>API KEY</span><div><code>${keyStatus}</code></div></div>
        <div class="model-provider-field"><span>MODELS</span><strong>${provider.profile_count || 0} 个模型</strong></div>
      </div>
      <footer class="model-provider-actions"></footer>`;
    const keyField = card.querySelector(".model-provider-key > div");
    const actions = card.querySelector(".model-provider-actions");
    if (can("administer") && provider.protocol !== "stub") {
      const changeKey = document.createElement("button");
      changeKey.type = "button";
      changeKey.className = "model-inline-action";
      changeKey.textContent = "修改";
      changeKey.onclick = (event) => openProviderSettings(provider, event.currentTarget, true);
      keyField.appendChild(changeKey);
    }
    const models = document.createElement("button");
    models.type = "button";
    models.className = "secondary";
    models.textContent = "模型";
    models.onclick = (event) => showProviderModels(provider.id, event.currentTarget);
    actions.appendChild(models);
    if (can("administer") && provider.protocol !== "stub") {
      const settings = document.createElement("button");
      settings.type = "button";
      settings.className = "secondary";
      settings.textContent = "设置";
      settings.onclick = (event) => openProviderSettings(provider, event.currentTarget);
      actions.appendChild(settings);
      if (provider.status !== "active") {
        const enable = document.createElement("button");
        enable.type = "button";
        enable.className = "secondary";
        enable.textContent = "启用";
        enable.onclick = async () => {
          try {
            await api(`/api/v1/admin/model-providers/${provider.id}/status`, {
              method: "POST",
              body: JSON.stringify({ status: "active" }),
            });
            await loadAdmin(false);
          } catch (caught) {
            setAdminNotice(`启用失败：${caught.message}`, "admin-error");
          }
        };
        actions.appendChild(enable);
      }
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "danger";
      remove.textContent = "删除";
      remove.disabled = Boolean(provider.profile_count);
      remove.title = provider.profile_count ? `仍有 ${provider.profile_count} 个模型，不能删除` : "删除未被应用的提供商";
      remove.onclick = async () => {
        if (!confirm(`确认删除“${provider.name}”？`)) return;
        try {
          await api(`/api/v1/admin/model-providers/${provider.id}`, { method: "DELETE" });
          setAdminNotice(`${provider.name} 已删除。`, "admin-success");
          await loadAdmin(false);
        } catch (caught) {
          setAdminNotice(`删除失败：${caught.message}`, "admin-error");
        }
      };
      actions.appendChild(remove);
    }
    providerRoot.appendChild(card);
  });
  if (!providers.length) {
    providerRoot.innerHTML = query
      ? '<div class="model-provider-empty"><strong>没有匹配的提供商</strong><span>清空搜索词后再试。</span></div>'
      : '<div class="model-provider-empty"><strong>还没有提供商</strong><span>点击右上角“添加提供商”完成第一条模型服务配置。</span></div>';
  }
}

function prepareFeishuChannelForm(channel = null) {
  const form = document.getElementById("channel-create-form");
  form.dataset.instanceId = channel?.id || "";
  form.querySelector("h3").textContent = channel ? "飞书设置" : "连接飞书";
  document.getElementById("channel-create-id").value = channel?.id || "";
  document.getElementById("channel-create-name").value = channel?.name || "素问飞书";
  document.getElementById("channel-create-enabled").checked = channel?.status === "active";
  document.getElementById("channel-create-domain").value = channel?.config.domain || "feishu";
  document.getElementById("channel-create-agent").value = activeAgent()?.id || "";
  document.getElementById("channel-create-app-id").value = channel?.config.external_instance_ref || "";
  const appSecret = document.getElementById("channel-create-app-secret");
  appSecret.value = "";
  appSecret.required = !channel;
  appSecret.placeholder = channel ? "留空则保持当前密钥" : "App Secret";
  document.getElementById("channel-create-encrypt-value").value = "";
  document.getElementById("channel-create-verification-value").value = "";
  form.querySelector('button[type="submit"]').textContent = "保存";
}

function openFeishuChannelForm(channel, trigger) {
  prepareFeishuChannelForm(channel);
  openManagementDrawer("channel-create-form", trigger);
}

function prepareFeishuAccessForm(channel) {
  const form = document.getElementById("channel-access-form");
  form.dataset.instanceId = channel.id;
  document.getElementById("channel-access-id").value = channel.id;
  document.getElementById("channel-access-actors").value = channel.config.allowed_actor_refs || "";
  document.getElementById("channel-access-chats").value = channel.config.allowed_chat_refs || "";
  document.getElementById("channel-access-require-mention").checked =
    channel.config.require_mention_in_group !== false;
}

function openFeishuAccessForm(channel, trigger) {
  prepareFeishuAccessForm(channel);
  openManagementDrawer("channel-access-form", trigger);
}

function currentAgentChannel(channelType = "feishu") {
  return state.agentChannels.find(
    (item) => item.channel_type === channelType && !isInternalChannel(item)
  ) || null;
}

function createFeishuChannelCard(channel = null) {
  const active = channel?.status === "active";
  const card = document.createElement("article");
  card.className = "channel-setting-row";
  card.innerHTML = `
    <div class="channel-setting-identity">
      <span class="channel-setting-icon" aria-hidden="true">飞</span>
      <div><h3>飞书</h3><p>长连接</p></div>
    </div>
    <span class="channel-option-status ${active ? "success" : ""}">${active ? "已启用" : "未启用"}</span>
    <div class="channel-option-actions"></div>`;
  const actions = card.querySelector(".channel-option-actions");
  if (can("administer")) {
    const settings = document.createElement("button");
    settings.type = "button";
    settings.className = "secondary";
    settings.textContent = channel ? "设置" : "配置";
    settings.onclick = () => openFeishuChannelForm(channel, settings);
    actions.appendChild(settings);
    if (channel) {
      const access = document.createElement("button");
      access.type = "button";
      access.className = "secondary";
      access.textContent = "访问范围";
      access.onclick = () => openFeishuAccessForm(channel, access);
      actions.appendChild(access);
    }
  }
  return card;
}

function createHttpRouteCard(channel) {
  const card = document.createElement("article");
  card.className = "channel-setting-row http-route-card";
  const ready = channel?.status === "active";
  card.innerHTML = `
    <div class="channel-setting-identity">
      <span class="channel-setting-icon" aria-hidden="true">API</span>
      <div><h3>本地 HTTP API</h3><p>开发入口</p></div>
    </div>
    <span class="channel-option-status ${ready ? "success" : ""}">${ready ? "已启用" : "未启用"}</span>`;
  return card;
}

function renderChannels() {
  const enabledRoot = document.getElementById("channel-enabled-list");
  const developmentWorkspace = isDevelopmentWorkspace();
  const httpChannels = state.agentChannels.filter((item) => item.channel_type === "api");
  const userChannel = currentAgentChannel();
  enabledRoot.innerHTML = "";
  if (developmentWorkspace) {
    httpChannels.forEach((channel) => enabledRoot.appendChild(createHttpRouteCard(channel)));
    if (!httpChannels.length) enabledRoot.innerHTML = '<p class="channel-empty">HTTP API 未启用</p>';
  } else {
    enabledRoot.appendChild(createFeishuChannelCard(userChannel));
  }
}

function renderDomainSkillDetails(expert, skill, focusReferenceId = "") {
  const body = document.getElementById("management-drawer-body");
  if (!body) return;
  const version = expert.current_version?.version || skill.version || "-";
  const canDelete = can("administer");
  document.getElementById("management-drawer-eyebrow").textContent = `${expert.name} · v${version}`;
  document.getElementById("management-drawer-title").textContent = skill.name || skill.id;
  const references = skill.references || [];
  body.innerHTML = `
    <div class="domain-skill-detail${canDelete ? " has-actions" : ""}">
      <p class="domain-skill-lead">${escapeHtml(skill.description || "未提供说明")}</p>
      <dl class="domain-skill-facts">
        <div><dt>适用范围</dt><dd>${escapeHtml(skill.applicability || skill.description || "未声明")}</dd></div>
        <div><dt>类型</dt><dd>${skill.fallback ? "通用回退" : "领域 Skill"}</dd></div>
      </dl>
      <section class="domain-skill-instructions">
        <h3>Skill 内容</h3>
        <div class="human-rich-text">${humanTextMarkup(skill.instructions)}</div>
      </section>
      ${references.length ? `<section class="domain-skill-references"><h3>引用文件</h3><div>${references.map((reference) => `
        <button type="button" class="domain-reference-row" data-domain-reference-id="${escapeHtml(reference.id)}" aria-label="预览引用文件：${escapeHtml(reference.title || reference.id)}">
          <span class="domain-reference-copy"><strong>${escapeHtml(reference.title || reference.id)}</strong>${reference.description ? `<span>${escapeHtml(reference.description)}</span>` : ""}</span>
          <span class="domain-reference-action" aria-hidden="true">预览</span>
        </button>`).join("")}</div></section>` : ""}
      ${canDelete ? '<div class="drawer-actions domain-skill-actions"><button type="button" class="danger" data-delete-domain-expert>删除</button></div>' : ""}
    </div>`;
  activeDrawerFormId = `skill:${expert.id}:${skill.id}`;
  const remove = body.querySelector("[data-delete-domain-expert]");
  if (remove) {
    remove.title = "删除当前未被智能体使用的领域能力";
    remove.onclick = async () => {
      if (!confirm(`确认删除“${expert.name}”？删除后不会再展示或加载，历史诊断记录仍会保留。`)) return;
      try {
        await api(`/api/v1/admin/domain-experts/${encodeURIComponent(expert.id)}`, {
          method: "DELETE",
        });
        closeManagementDrawer();
        setAdminNotice(`${expert.name} 已删除。`, "admin-success");
        await loadAdmin(false);
      } catch (caught) {
        setAdminNotice(`删除失败：${caught.message}`, "admin-error");
      }
    };
  }
  body.querySelectorAll("[data-domain-reference-id]").forEach((button) => {
    const reference = references.find((item) => item.id === button.dataset.domainReferenceId);
    if (reference) button.onclick = () => void openDomainReferencePreview(expert, skill, reference);
  });
  if (focusReferenceId) {
    requestAnimationFrame(() => {
      Array.from(body.querySelectorAll("[data-domain-reference-id]"))
        .find((button) => button.dataset.domainReferenceId === focusReferenceId)
        ?.focus();
    });
  }
}

async function openDomainReferencePreview(expert, skill, reference) {
  const body = document.getElementById("management-drawer-body");
  const versionId = expert.current_version?.id;
  if (!body) return;
  const previewId = `reference:${expert.id}:${versionId || "missing"}:${skill.id}:${reference.id}`;
  activeDrawerFormId = previewId;
  document.getElementById("management-drawer-eyebrow").textContent = skill.name || skill.id;
  document.getElementById("management-drawer-title").textContent = reference.title || reference.id;
  body.innerHTML = `
    <div class="domain-reference-preview">
      <button type="button" class="secondary domain-reference-back">返回 Skill</button>
      ${reference.description ? `<p class="domain-reference-lead">${escapeHtml(reference.description)}</p>` : ""}
      <div class="markdown-preview domain-reference-markdown" aria-live="polite">
        <p class="domain-reference-status">正在读取引用文件…</p>
      </div>
    </div>`;
  body.querySelector(".domain-reference-back").onclick = () => {
    renderDomainSkillDetails(expert, skill, reference.id);
  };
  requestAnimationFrame(() => body.querySelector(".domain-reference-back")?.focus());
  const contentRoot = body.querySelector(".domain-reference-markdown");
  if (!versionId) {
    contentRoot.innerHTML = '<p class="admin-error">当前领域专家没有可读取的已安装版本。</p>';
    contentRoot.setAttribute("role", "alert");
    return;
  }
  try {
    const payload = await api(
      `/api/v1/admin/domain-experts/${encodeURIComponent(expert.id)}` +
      `/versions/${encodeURIComponent(versionId)}` +
      `/skills/${encodeURIComponent(skill.id)}` +
      `/references/${encodeURIComponent(reference.id)}`
    );
    if (activeDrawerFormId !== previewId) return;
    const loadedReference = payload?.reference;
    if (!loadedReference || typeof loadedReference.content !== "string") {
      throw new Error("引用文件正文无效");
    }
    if (typeof window.renderMarkdownPreview !== "function") {
      throw new Error("Markdown 预览组件未加载");
    }
    document.getElementById("management-drawer-title").textContent =
      loadedReference.title || reference.title || reference.id;
    contentRoot.removeAttribute("aria-live");
    window.renderMarkdownPreview(contentRoot, loadedReference.content);
  } catch (error) {
    if (activeDrawerFormId !== previewId) return;
    contentRoot.replaceChildren();
    const message = document.createElement("p");
    message.className = "admin-error";
    message.textContent = `引用文件读取失败：${error.message}`;
    contentRoot.setAttribute("role", "alert");
    contentRoot.append(message);
  }
}

function openDomainSkillDetails(expert, skill, trigger) {
  const drawer = document.getElementById("management-drawer");
  const backdrop = document.getElementById("management-drawer-backdrop");
  const body = document.getElementById("management-drawer-body");
  if (!drawer || !backdrop || !body) return;
  closeManagementDrawer();
  drawerReturnFocus = trigger || document.activeElement;
  renderDomainSkillDetails(expert, skill);
  drawer.classList.add("open", "agent-settings-mode");
  drawer.setAttribute("aria-hidden", "false");
  backdrop.classList.remove("hidden");
  document.body.classList.add("drawer-open");
  requestAnimationFrame(() => document.getElementById("management-drawer-close")?.focus());
}

function capabilityFamilyId(capabilityId) {
  const source = String(capabilityId || "unknown");
  return source.replace(/-(?:tools|domain|mcp)$/, "") || source;
}

function capabilityPackageHeader(meta, itemCount, unit) {
  const version = meta.version && meta.version !== "-" ? ` · v${escapeHtml(meta.version)}` : "";
  return `<header class="capability-package-header">
    <div><h3>${escapeHtml(meta.family)}</h3><p>${escapeHtml(meta.sourceId)}${version}</p></div>
    <span>${itemCount} ${escapeHtml(unit)}</span>
  </header>`;
}

function renderCapabilities() {
  const summary = document.getElementById("domain-expert-summary");
  const root = document.getElementById("domain-expert-list");
  if (!summary || !root) return;
  const experts = state.domainExperts || [];
  const availableExperts = experts.filter((item) => item.load_state === "available");
  const skills = availableExperts.flatMap((expert) =>
    (expert.skills || []).map((skill) => ({ expert, skill }))
  );
  const referenceCount = skills.reduce(
    (total, item) => total + Number(item.skill.reference_count || 0),
    0
  );
  summary.innerHTML =
    `<span class="pill">${availableExperts.length} 个领域专家</span>` +
    `<span class="pill">${skills.length} 个 Skills</span>` +
    `<span class="pill">${referenceCount} 个引用文件</span>`;

  root.innerHTML = "";
  experts.forEach((expert) => {
    const expertSkills = expert.load_state === "available" ? (expert.skills || []) : [];
    const version = expert.current_version?.version || "-";
    const group = document.createElement("section");
    group.className = "capability-package-group";
    group.innerHTML = `<header class="capability-package-header">
      <div><h3>${escapeHtml(capabilityFamilyId(expert.id))}</h3></div>
    </header><div class="domain-expert-grid"></div>`;
    const grid = group.querySelector(".domain-expert-grid");
    expertSkills.forEach((skill) => {
      const card = document.createElement("button");
      card.type = "button";
      card.className = "admin-card domain-skill-card";
      card.setAttribute("aria-haspopup", "dialog");
      card.setAttribute("aria-controls", "management-drawer");
      card.innerHTML = `
        <span class="admin-card-head">
          <div>
            <h3>${escapeHtml(skill.name || skill.id)}</h3>
            <p class="tool-card-source">${escapeHtml(skill.id)}${version !== "-" ? ` · v${escapeHtml(version)}` : ""}</p>
          </div>
          <span class="domain-skill-open" aria-hidden="true">›</span>
        </span>
        <p class="domain-skill-description">${escapeHtml(skill.description || "未提供说明")}</p>
        <span class="tool-card-footer">
          <span>${skill.fallback ? "通用回退" : "领域 Skill"}</span>
          <span>引用文件 ${Number(skill.reference_count || 0)}</span>
        </span>`;
      card.onclick = (event) => openDomainSkillDetails(expert, skill, event.currentTarget);
      grid.appendChild(card);
    });
    if (expert.load_state !== "available") {
      const card = document.createElement("article");
      card.className = "admin-card domain-skill-card";
      card.innerHTML = `
        <div class="admin-card-head">
          <div><h3>${escapeHtml(expert.name)}</h3><p class="tool-card-source">${escapeHtml(expert.id)}</p></div>
          <span class="status-badge attention">${expert.load_state === "not_installed" ? "未安装" : "不可用"}</span>
        </div>
        <p class="domain-skill-description">${escapeHtml(expert.description || "未提供说明")}</p>
        <div class="tool-card-footer"><span>Skills 0</span><span>等待实例就绪</span></div>`;
      grid.appendChild(card);
    }
    root.appendChild(group);
  });

  if (!experts.length) {
    root.innerHTML = '<article class="manager-empty"><strong>暂无领域专家</strong></article>';
  }
}

function toolProviderDisplayName(providerId) {
  const provider = state.toolProviders.find((item) => item.id === providerId);
  return displayName(providerId, provider?.name || providerId);
}

function toolSourceDisplayName(tool) {
  const capability = (tool?.capability_usage || []).find((item) => item.status === "installed");
  if (capability) return `${capability.capability_id} · v${capability.version}`;
  return toolProviderDisplayName(tool?.provider_id || "unknown");
}

function toolPackageMeta(tool) {
  const capability = (tool?.capability_usage || []).find((item) => item.status === "installed");
  const sourceId = capability?.capability_id || tool?.provider_id || "unknown";
  return {
    key: sourceId,
    family: capabilityFamilyId(sourceId),
    sourceId,
    version: capability?.version || "-",
  };
}

function capabilityBindingsForSelectedTools(toolNames, existingBindings = []) {
  const selected = new Set(toolNames);
  const catalogCapabilityIds = new Set();
  const selectedCapabilities = new Map();
  state.tools.forEach((tool) => {
    (tool.capability_usage || []).forEach((usage) => {
      if (usage.status !== "installed" || usage.role !== "tools") return;
      catalogCapabilityIds.add(usage.capability_id);
      if (selected.has(tool.name)) selectedCapabilities.set(usage.capability_id, usage);
    });
  });
  const preserved = existingBindings.filter((binding) => {
    const role = binding.role || binding.kind;
    return role !== "tools" || !catalogCapabilityIds.has(binding.capability_id);
  });
  const combined = [
    ...preserved.map((binding) => ({
      capability_version_id: binding.capability_version_id,
      role: binding.role || binding.kind,
    })),
    ...Array.from(selectedCapabilities.values())
      .sort((left, right) => left.capability_id.localeCompare(right.capability_id))
      .map((usage) => ({
        capability_version_id: usage.capability_version_id,
        role: "tools",
      })),
  ];
  return combined.map((binding, position) => ({ ...binding, position }));
}

function connectorBindingsForSelectedTools(toolNames) {
  const selected = new Set(toolNames);
  const providerIds = new Set(
    state.tools
      .filter((tool) => selected.has(tool.name))
      .map((tool) => tool.provider_id)
      .filter((providerId) => {
        const provider = state.toolProviders.find((item) => item.id === providerId);
        return provider && ["mcp_http", "mcp_stdio"].includes(provider.provider_type);
      })
  );
  return Array.from(providerIds).sort().map((providerId) => ({
    provider_id: providerId,
    selection: "all_read_only",
  }));
}

function schemaTypeLabel(definition = {}) {
  const labels = {
    string: "文本",
    integer: "整数",
    number: "数值",
    boolean: "是/否",
    array: "列表",
    object: "对象",
    null: "空值",
  };
  if (Array.isArray(definition.type)) {
    return definition.type.map((item) => labels[item] || item).join(" / ");
  }
  if (definition.type) return labels[definition.type] || definition.type;
  const variants = (definition.anyOf || [])
    .map((item) => labels[item.type] || item.type)
    .filter(Boolean);
  return variants.length ? [...new Set(variants)].join(" / ") : "任意值";
}

function schemaConstraintSummary(definition = {}) {
  const constraints = [];
  if (Array.isArray(definition.enum)) constraints.push(`可选：${definition.enum.join("、")}`);
  if (definition.minLength !== undefined) constraints.push(`至少 ${definition.minLength} 字符`);
  if (definition.maxLength !== undefined) constraints.push(`最多 ${definition.maxLength} 字符`);
  if (definition.minimum !== undefined) constraints.push(`最小 ${definition.minimum}`);
  if (definition.maximum !== undefined) constraints.push(`最大 ${definition.maximum}`);
  if (definition.minItems !== undefined) constraints.push(`至少 ${definition.minItems} 项`);
  if (definition.maxItems !== undefined) constraints.push(`最多 ${definition.maxItems} 项`);
  return constraints.join(" · ");
}

function renderToolParameters(tool) {
  const schema = tool.input_schema || {};
  const properties = Object.entries(schema.properties || {});
  const required = new Set(schema.required || []);
  if (!properties.length) return '<p class="drawer-empty-note">这个工具不需要输入参数。</p>';
  return `<div class="tool-parameter-list">${properties.map(([name, definition]) => {
    const description = definition.description || schemaConstraintSummary(definition);
    return `
      <div class="tool-parameter-row">
        <div>
          <code>${escapeHtml(name)}</code>
          <span>${required.has(name) ? "必填" : "可选"} · ${escapeHtml(schemaTypeLabel(definition))}</span>
        </div>
        ${description ? `<p>${escapeHtml(description)}</p>` : ""}
      </div>`;
  }).join("")}</div>`;
}

function renderToolAgentUsage(tool) {
  const agents = new Map();
  (tool.agent_usage || []).forEach((item) => {
    const agentId = String(item.agent_id || "").trim();
    if (!agentId || agents.has(agentId)) return;
    const agent = state.agents.find((candidate) => candidate.id === agentId);
    agents.set(agentId, item.agent_name || agent?.name || displayName(agentId, agentId));
  });
  const names = Array.from(agents.values()).sort((left, right) => left.localeCompare(right, "zh-CN"));
  return `
    <section class="tool-detail-section tool-agent-usage">
      <h3>使用智能体</h3>
      <p>${names.length ? escapeHtml(names.join("、")) : "暂无"}</p>
    </section>`;
}

function openToolDetailsDrawer(tool, trigger) {
  const drawer = document.getElementById("management-drawer");
  const backdrop = document.getElementById("management-drawer-backdrop");
  const body = document.getElementById("management-drawer-body");
  if (!drawer || !backdrop || !body) return;
  closeManagementDrawer();
  drawerReturnFocus = trigger || document.activeElement;
  document.getElementById("management-drawer-eyebrow").textContent = "工具详情";
  document.getElementById("management-drawer-title").textContent = tool.name;
  const providerName = toolSourceDisplayName(tool);
  body.innerHTML = `
    <div class="tool-detail-view">
      <section class="tool-detail-summary">
        <strong class="tool-detail-display-name">${escapeHtml(toolLabel(tool.name))}</strong>
        <p>${escapeHtml(toolDescription(tool))}</p>
        <dl class="tool-detail-facts">
          <div><dt>工具来源</dt><dd>${escapeHtml(providerName)}</dd></div>
          <div><dt>来源状态</dt><dd>${escapeHtml(statusLabel(tool.provider_status))}</dd></div>
          <div><dt>权限边界</dt><dd>${escapeHtml(statusLabel(tool.risk))}</dd></div>
          <div><dt>执行限制</dt><dd>${escapeHtml(statusLabel(tool.resource_class || "default"))} · ${escapeHtml(tool.timeout_seconds || "-")} 秒</dd></div>
        </dl>
      </section>
      <section class="tool-detail-section">
        <h3>输入参数</h3>
        ${renderToolParameters(tool)}
      </section>
      ${renderToolAgentUsage(tool)}
      <dl class="tool-technical-facts">
        <div><dt>工具 ID</dt><dd><code>${escapeHtml(tool.name)}</code></dd></div>
        <div><dt>来源 ID</dt><dd><code>${escapeHtml(tool.provider_id)}</code></dd></div>
        <div><dt>结果契约</dt><dd><code>${escapeHtml(tool.result_contract || "-")}</code></dd></div>
      </dl>
    </div>`;
  activeDrawerFormId = `tool:${tool.name}`;
  drawer.classList.add("tool-detail-mode", "open");
  drawer.setAttribute("aria-hidden", "false");
  backdrop.classList.remove("hidden");
  document.body.classList.add("drawer-open");
  requestAnimationFrame(() => document.getElementById("management-drawer-close")?.focus());
}

function renderToolsAndConnectors() {
  const globalTools = userSelectableTools();
  const configurableProviders = state.toolProviders.filter((provider) =>
    ["mcp_http", "mcp_stdio"].includes(provider.provider_type)
  );
  const queryInput = document.getElementById("tool-filter-query");
  const riskFilter = document.getElementById("tool-filter-risk");
  const providerFilter = document.getElementById("tool-filter-provider");
  const selectedProvider = providerFilter.value;
  providerFilter.innerHTML = '<option value="">全部来源</option>';
  Array.from(new Set(globalTools.map((tool) => tool.provider_id))).sort().forEach((providerId) => {
    const option = document.createElement("option");
    option.value = providerId;
    option.textContent = toolProviderDisplayName(providerId);
    providerFilter.appendChild(option);
  });
  providerFilter.value = selectedProvider;
  const query = queryInput.value.trim().toLocaleLowerCase("zh-CN");
  const visibleTools = globalTools.filter((tool) => {
    const searchText = `${tool.name} ${toolLabel(tool.name)} ${toolDescription(tool)} ${tool.provider_id}`.toLocaleLowerCase("zh-CN");
    return (!query || searchText.includes(query)) &&
      (!riskFilter.value || tool.risk === riskFilter.value) &&
      (!providerFilter.value || tool.provider_id === providerFilter.value);
  });
  const observedToolCount = configurableProviders.reduce(
    (total, provider) => total + (provider.schema_versions[0]?.schema?.length || 0),
    0,
  );
  document.getElementById("tool-summary").innerHTML = `<span class="pill">${globalTools.length} 个工具</span>`;
  document.getElementById("connector-summary").innerHTML =
    `<span class="pill">${configurableProviders.length} 个连接器</span>` +
    `<span class="pill">${observedToolCount} 个已观测工具</span>`;
  document.getElementById("tool-list-heading").textContent = `工具目录 · ${globalTools.length}`;
  document.getElementById("tool-filter-count").textContent = `显示 ${visibleTools.length} / ${globalTools.length}`;
  const providerRoot = document.getElementById("connector-list");
  providerRoot.innerHTML = "";
  configurableProviders.forEach((provider) => {
    const latest = provider.schema_versions[0];
    const referencedPackCount = new Set(
      (provider.pack_usage || []).map((item) => item.pack_id).filter(Boolean)
    ).size;
    const card = document.createElement("article");
    card.className = "admin-card provider-card";
    card.innerHTML = `
      <div class="admin-card-head">
        <div><h3>${escapeHtml(displayName(provider.id, provider.name))}</h3><p>${escapeHtml(toolProviderTypeLabel(provider.provider_type))}</p></div>
        <span class="status-badge ${provider.status === "connected" || provider.status === "enabled" ? "success" : "attention"}">${escapeHtml(statusLabel(provider.status))}</span>
      </div>
      <p>${latest?.schema?.length || 0} 个工具 · ${provider.connection_configured ? "连接已配置" : "连接未配置"}</p>
      <div class="admin-actions provider-primary-actions"></div>
      <div class="agent-result"></div>
      <details class="technical-details provider-facts">
        <summary>连接状态与引用</summary>
        <dl class="readiness-list">
          <div class="readiness-row"><dt>健康</dt><dd>${escapeHtml(statusLabel(provider.health))}</dd></div>
          <div class="readiness-row"><dt>连接配置</dt><dd>${provider.connection_configured ? "已配置" : "未配置"}</dd></div>
          <div class="readiness-row"><dt>绑定代次</dt><dd>${provider.binding_generation || 0}</dd></div>
          <div class="readiness-row"><dt>结构版本</dt><dd>v${latest?.version || "-"} · ${latest?.observed_at ? "已有观测" : "尚未观测"}</dd></div>
          <div class="readiness-row"><dt>引用</dt><dd>${referencedPackCount} 个能力包 · ${(provider.agent_usage || []).length} 个智能体</dd></div>
          <div class="readiness-row"><dt>密钥</dt><dd>${provider.secret ? `${escapeHtml(provider.secret.id)} · ${provider.secret.configured ? "已配置" : "缺失"}` : "无需密钥"}</dd></div>
        </dl>
      </details>`;
    const primaryActions = card.querySelector(".provider-primary-actions");
    const result = card.querySelector(".agent-result");
    let connectActions = null;
    let configurationActions = null;
    if (["mcp_stdio", "mcp_http"].includes(provider.provider_type) && (can("operate") || can("administer"))) {
      const configuration = document.createElement("details");
      configuration.className = "provider-configuration";
      configuration.innerHTML = `
        <summary>连接与配置</summary>
        <div class="provider-configuration-body">
          <div class="provider-connect-actions"></div>
          <div class="provider-connector-fields"></div>
        </div>`;
      card.appendChild(configuration);
      connectActions = configuration.querySelector(".provider-connect-actions");
      configurationActions = configuration.querySelector(".provider-connector-fields");
    }
    const probe = document.createElement("button");
    probe.className = "secondary";
    probe.textContent = "安全探测";
    probe.disabled = provider.status === "disabled";
    probe.onclick = async () => {
      const result = card.querySelector(".agent-result");
      await runBusy(probe, "正在安全探测…", async () => {
        try {
          const observed = await api(`/api/v1/admin/tool-providers/${provider.id}/probe`, { method: "POST" });
          result.className = `agent-result ${observed.status === "passed" ? "admin-success" : "admin-error"}`;
          result.textContent = observed.status === "passed"
            ? `Connector 探测通过，目录读取 ${observed.external_calls || 0} 次。`
            : observed.findings.map(findingLabel).join("\n");
          await loadAdmin(false);
        } catch (error) {
          result.className = "agent-result admin-error";
          result.textContent = error.message;
        }
      });
    };
    if (can("operate")) primaryActions.appendChild(probe);
    if (provider.provider_type === "mcp_stdio" && can("operate")) {
      const connect = document.createElement("button");
      connect.className = "secondary";
      connect.textContent = "连接并核对工具目录";
      connect.disabled = provider.status === "disabled" || !provider.connection_configured;
      connect.onclick = async () => {
        const result = card.querySelector(".agent-result");
        await runBusy(connect, "正在连接并核对…", async () => {
          try {
            await api(`/api/v1/admin/tool-providers/${provider.id}/connect`, {
              method: "POST",
              body: JSON.stringify({}),
            });
            setAdminNotice(`${displayName(provider.id, provider.name)} 已连接，工具目录与冻结契约一致。`, "admin-success");
            await loadAdmin(false);
          } catch (error) {
            result.className = "agent-result admin-error";
            result.textContent = error.message;
          }
        });
      };
      connectActions.append(connect);
    }
    if (can("administer")) {
      if (provider.provider_type === "mcp_http") {
        const endpoint = document.createElement("input");
        endpoint.placeholder = "Streamable HTTP 地址，例如 http://127.0.0.1:8765/mcp";
        endpoint.value = provider.connection?.endpoint || "";
        const configure = document.createElement("button");
        configure.className = "secondary";
        configure.textContent = "保存并连接";
        configure.onclick = async () => {
          const result = card.querySelector(".agent-result");
          await runBusy(configure, "正在保存并连接…", async () => {
            try {
              await api(`/api/v1/admin/tool-providers/${provider.id}/http-config`, {
                method: "PUT",
                body: JSON.stringify({
                  endpoint: endpoint.value.trim(),
                  timeout_seconds: 30,
                  max_response_bytes: 2097152,
                }),
              });
              endpoint.value = "";
              setAdminNotice(`${displayName(provider.id, provider.name)} 已保存、连接并加载工具目录。`, "admin-success");
              await loadAdmin(false);
            } catch (error) {
              result.className = "agent-result admin-error";
              result.textContent = error.message;
            }
          });
        };
        configurationActions.append(endpoint, configure);
      }
      if (provider.provider_type === "mcp_stdio") {
        const command = document.createElement("textarea");
        command.placeholder = "启动命令：每行一个参数，首行必须是可执行文件绝对路径";
        const cwd = document.createElement("input");
        cwd.placeholder = "工作目录绝对路径";
        const environment = document.createElement("textarea");
        environment.placeholder = "非敏感环境变量 JSON，例如 {\"NODE_ENV\":\"production\"}";
        environment.value = "{}";
        const secretEnv = document.createElement("input");
        secretEnv.placeholder = "密钥注入变量名（没有则留空）";
        const secretRef = document.createElement("select");
        fillSecretSelect(secretRef, true, provider.secret?.id || "", "tool");
        const configure = document.createElement("button");
        configure.className = "secondary";
        configure.textContent = "保存标准输入输出连接";
        configure.onclick = async () => {
          const result = card.querySelector(".agent-result");
          try {
            await api(`/api/v1/admin/tool-providers/${provider.id}/stdio-config`, {
              method: "PUT",
              body: JSON.stringify({
                command: command.value.split("\n").map((item) => item.trim()).filter(Boolean),
                cwd: cwd.value.trim(),
                environment: JSON.parse(environment.value || "{}"),
                secret_env: secretEnv.value.trim() || null,
                secret_ref_id: secretRef.value || null,
                timeout_seconds: 30,
              }),
            });
            command.value = "";
            cwd.value = "";
            secretEnv.value = "";
            setAdminNotice(`${displayName(provider.id, provider.name)} 的连接已保存；尚未连接或访问来源。`, "admin-success");
            await loadAdmin(false);
          } catch (error) {
            result.className = "agent-result admin-error";
            result.textContent = error.message;
          }
        };
        configurationActions.append(
          command,
          cwd,
          environment,
          secretEnv,
          secretRef,
          configure,
        );
      }
      const status = document.createElement("button");
      status.className = provider.status === "disabled" ? "secondary" : "danger";
      status.textContent = provider.status === "disabled" ? "启用 Connector" : "停用 Connector";
      status.disabled = provider.status === "disabled" && provider.schema_versions.length === 0;
      status.onclick = async () => {
        const next = provider.status === "disabled" ? "enabled" : "disabled";
        if (next === "disabled" && !confirm(`确认停用“${displayName(provider.id, provider.name)}”？被当前已发布智能体使用时系统会拒绝。`)) return;
        try {
          await api(`/api/v1/admin/tool-providers/${provider.id}/status`, {
            method: "POST",
            body: JSON.stringify({ status: next }),
          });
          await loadAdmin(false);
        } catch (error) {
          result.className = "agent-result admin-error";
          result.textContent = error.message;
        }
      };
      const statusManagement = document.createElement("details");
      statusManagement.className = "technical-details";
      statusManagement.innerHTML = "<summary>状态管理</summary>";
      statusManagement.appendChild(status);
      card.appendChild(statusManagement);
    }
    providerRoot.appendChild(card);
  });
  if (!configurableProviders.length) {
    providerRoot.innerHTML = '<article class="manager-empty"><strong>暂无连接器</strong></article>';
  }

  const toolRoot = document.getElementById("tool-admin-list");
  toolRoot.innerHTML = "";
  const appendToolGroup = (meta, tools) => {
    if (!tools.length) return;
    const group = document.createElement("section");
    group.className = "capability-package-group tool-source-group";
    group.innerHTML = `${capabilityPackageHeader(meta, tools.length, "Tools")}<div class="tool-card-grid"></div>`;
    const grid = group.querySelector(".tool-card-grid");
    tools.forEach((tool) => {
      const card = document.createElement("article");
      card.className = "admin-card tool-card";
      const providerReady = ["connected", "enabled", "ready", "installed"].includes(tool.provider_status);
      card.innerHTML = `
        <div class="admin-card-head">
          <div><h3>${toolNameMarkup(tool.name)}</h3><p class="tool-card-source">${escapeHtml(toolLabel(tool.name))}</p></div>
          <span class="status-badge ${providerReady ? "success" : "attention"}">${escapeHtml(statusLabel(tool.provider_status))}</span>
        </div>
        <p class="tool-card-description">${escapeHtml(toolDescription(tool))}</p>
        <div class="tool-card-footer">
          <span>${escapeHtml(statusLabel(tool.risk))}</span>
          <button type="button" class="secondary tool-detail-button" aria-haspopup="dialog" aria-controls="management-drawer">查看详情</button>
        </div>`;
      card.querySelector(".tool-detail-button").onclick = (event) => openToolDetailsDrawer(tool, event.currentTarget);
      grid.appendChild(card);
    });
    toolRoot.appendChild(group);
  };
  const packageGroups = new Map();
  visibleTools.forEach((tool) => {
    const meta = toolPackageMeta(tool);
    if (!packageGroups.has(meta.key)) packageGroups.set(meta.key, { meta, tools: [] });
    packageGroups.get(meta.key).tools.push(tool);
  });
  Array.from(packageGroups.values())
    .sort((left, right) => left.meta.family.localeCompare(right.meta.family))
    .forEach((group) => appendToolGroup(group.meta, group.tools));
  if (!visibleTools.length) {
    toolRoot.innerHTML = globalTools.length
      ? '<article class="manager-empty"><strong>没有符合条件的工具</strong></article>'
      : '<article class="manager-empty"><strong>暂无工具</strong></article>';
  }
}

function renderReviewsResearch() {
  const summary = document.getElementById("review-engine-summary");
  const reviewRoot = document.getElementById("admin-review-list");
  const engineRoot = document.getElementById("review-engine-list");
  const digestRoot = document.getElementById("research-digest-list");
  const workspaceReviews = [...state.reviews]
    .sort((left, right) => Number(right.status === "pending") - Number(left.status === "pending"));
  const workspaceDigests = state.researchDigests;
  const workspaceAttempts = state.candidateAttempts;
  const latestAttempt = workspaceAttempts[0];
  const totals = latestAttempt?.scorecard?.totals || {};
  const candidateApproved = latestAttempt?.status === "outcome_reviewed";
  const deterministicPassed = latestAttempt?.scorecard?.deterministic_contract_passed === true;
  const stopReason = latestAttempt?.scorecard?.stop_reason;
  const acceptanceMessage = candidateApproved
    ? "固定保留集与人工六维复核均已通过。"
    : stopReason === "infrastructure_failure"
      ? "最近运行在第一个模型回合遇到连接失败并安全停止；模型主配置仍为已探测通过，下一步是修正候选执行环境预检。"
      : latestAttempt?.status === "contract_failed"
        ? "最近运行已完成，但仍有确定性场景契约未通过，不能进入人工批准。"
        : "尚未完成真实模型候选运行。";
  summary.innerHTML = `<span class="pill">候选验收 ${candidateApproved ? "已通过" : "待完成"}</span>` +
    `<span class="pill">最近场景 ${totals.completed_episodes ?? 0}/10</span>` +
    `<span class="pill">确定性契约 ${deterministicPassed ? "通过" : "未通过"}</span>` +
    `<span class="pill">外部写入 ${latestAttempt?.external_writes ?? 0}</span>` +
    `<span class="pill">待审核案件复盘 ${workspaceReviews.filter((item) => item.status === "pending").length}</span>`;
  const acceptancePrimary = document.getElementById("acceptance-primary");
  acceptancePrimary.innerHTML = `
    <article class="scenario-card primary ${candidateApproved ? "success" : "attention"}">
      <div class="scenario-card-head">
        <div><p class="scenario-kicker">实例候选准出</p><h3>${candidateApproved ? "候选验收已经完成" : "候选验收还没有通过"}</h3></div>
        <span class="status-badge ${candidateApproved ? "success" : "attention"}">${candidateApproved ? "已通过" : "待处理"}</span>
      </div>
      <p>${escapeHtml(acceptanceMessage)}</p>
      <dl class="readiness-list">
        <div class="readiness-row"><dt>最近候选</dt><dd>${latestAttempt ? `${totals.completed_episodes ?? 0}/10 个场景完成 · ${escapeHtml(statusLabel(latestAttempt.status))}` : "尚未运行"}</dd></div>
        <div class="readiness-row"><dt>模型调用</dt><dd>${latestAttempt?.model_calls ?? 0} 回合；来源调用 ${latestAttempt?.source_calls ?? 0}；外部写入 ${latestAttempt?.external_writes ?? 0}</dd></div>
        <div class="readiness-row"><dt>批准条件</dt><dd>10 个场景确定性通过后，再逐场景完成人工六维复核</dd></div>
      </dl>
    </article>`;

  reviewRoot.innerHTML = "";
  workspaceReviews.forEach((review) => {
    const card = document.createElement("article");
    card.className = "admin-card resource-row";
    card.innerHTML = `
      <div class="admin-card-head">
        <div><h3>复盘 · ${escapeHtml(review.case_id)}</h3><p class="mono">${escapeHtml(review.id)}</p></div>
        <span class="pill">${escapeHtml(statusLabel(review.status))}</span>
      </div>
      <div class="admin-meta">
        <span class="pill">${escapeHtml(review.confidence === "bounded: evidence and explicit feedback only" ? "有界：仅依据证据与明确反馈" : review.confidence)}</span>
        <span class="pill">智能体 ${escapeHtml(review.agent_id || "未知")}</span>
        <span class="pill">引擎 ${escapeHtml(review.review_engine_version_id)}</span>
      </div>
      <p>${escapeHtml(review.summary)}</p>
      <p class="mono">输入快照 ${escapeHtml(review.input_snapshot_hash || "未记录")}</p>
      <div class="admin-actions"></div><div class="agent-result"></div>`;
    if (review.status === "pending" && can("review")) {
      const note = document.createElement("input");
      note.placeholder = "审核意见（可选）";
      const approve = document.createElement("button");
      approve.textContent = "批准复盘";
      const reject = document.createElement("button");
      reject.className = "danger";
      reject.textContent = "驳回复盘";
      const decide = async (decision) => {
        const result = card.querySelector(".agent-result");
        try {
          await api(`/api/v1/reviews/${review.id}/decision`, {
            method: "POST",
            body: JSON.stringify({ decision, note: note.value.trim() }),
          });
          setAdminNotice(`复盘 ${review.id} 已${decision === "approved" ? "批准" : "驳回"}；不会自动修改智能体。`, "admin-success");
          await loadAdmin(false);
        } catch (error) {
          result.className = "agent-result admin-error";
          result.textContent = error.message;
        }
      };
      approve.onclick = () => decide("approved");
      reject.onclick = () => decide("rejected");
      card.querySelector(".admin-actions").append(note, reject, approve);
    }
    reviewRoot.appendChild(card);
  });
  if (!workspaceReviews.length) {
    reviewRoot.innerHTML = '<article class="manager-empty"><strong>没有案件复盘</strong><span>完成案件后，符合规则的结构化复盘会出现在这里。</span></article>';
  }

  engineRoot.innerHTML = "";
  state.reviewEngines.forEach((profile) => {
    profile.versions.forEach((version) => {
      const enabledRules = Object.entries(version.config.rules || {})
        .filter(([, enabled]) => enabled)
        .map(([name]) => REVIEW_RULE_LABELS[name] || name);
      const card = document.createElement("article");
      card.className = "admin-card";
      card.innerHTML = `
        <div class="admin-card-head">
          <div><h3>${escapeHtml(displayName(profile.id, profile.name))} v${version.version}</h3><p class="mono">${escapeHtml(version.id)}</p></div>
          <span class="pill">${escapeHtml(statusLabel(version.status))}</span>
        </div>
        <div class="admin-meta">
          <span class="pill">${escapeHtml(version.engine_kind)}</span>
          <span class="pill">${escapeHtml(version.algorithm_version)}</span>
          <span class="pill">规则 ${enabledRules.length}/${Object.keys(REVIEW_RULE_LABELS).length}</span>
          <span class="pill">模型调用 0</span>
          <span class="pill">外部调用 0</span>
        </div>
        <p>已启用：${escapeHtml(enabledRules.join("、") || "无")}</p>
        <p>确定性有界复盘；不修改智能体、不自动发布。</p>
        <div class="admin-actions"></div>`;
      if (version.status === "draft" && can("administer")) {
        const activate = document.createElement("button");
        activate.className = "secondary";
        activate.textContent = "启用引擎版本";
        activate.onclick = async () => {
          try {
            await api(`/api/v1/admin/review-engine-profiles/${profile.id}/versions/${version.id}/activate`, { method: "POST" });
            setAdminNotice(`复盘引擎 v${version.version} 已启用；既有复盘仍记录执行时使用的引擎版本。`, "admin-success");
            await loadAdmin(false);
          } catch (error) {
            setAdminNotice(`复盘引擎启用失败：${error.message}`, "admin-error");
          }
        };
        card.querySelector(".admin-actions").appendChild(activate);
      }
      engineRoot.appendChild(card);
    });
  });

  const agentSelect = document.getElementById("research-agent");
  const previousAgent = agentSelect.value;
  agentSelect.innerHTML = "";
  state.agentCatalog.forEach((agent) => {
    const option = document.createElement("option");
    option.value = agent.id;
    option.textContent = `${displayName(agent.id, agent.name)} · ${statusLabel(agent.status)}`;
    option.selected = agent.id === previousAgent || (!previousAgent && agent.is_default);
    agentSelect.appendChild(option);
  });

  digestRoot.innerHTML = "";
  workspaceDigests.forEach((digest) => {
    const card = document.createElement("article");
    card.className = "admin-card";
    card.innerHTML = `
      <div class="admin-card-head">
        <div><h3>研究摘要</h3><p class="mono">${escapeHtml(digest.id)}</p></div>
        <span class="pill">${escapeHtml(statusLabel(digest.status))}</span>
      </div>
      <div class="admin-meta">
        <span class="pill">智能体 ${escapeHtml(digest.agent_id)}</span>
        <span class="pill">复盘 ${digest.review_refs.length}</span>
        <span class="pill">候选项 ${digest.candidates.length}</span>
        <span class="pill">自动发布 0</span>
      </div>
      <p>${escapeHtml(digest.summary)}</p>
      <div class="candidate-list"></div>
      <div class="admin-actions digest-actions"></div>`;
    const candidateRoot = card.querySelector(".candidate-list");
    digest.candidates.forEach((candidate) => {
      const item = document.createElement("div");
      item.className = "agent-result";
      item.innerHTML = `<strong>${escapeHtml(candidate.kind)}</strong> · ${escapeHtml(candidate.status)} · ` +
        `支持 ${candidate.supporting_review_count} / 反例 ${candidate.counterexample_count}<br>` +
        `${escapeHtml(candidate.summary)}<br>` +
        `确认门：${escapeHtml(candidate.validation.confirmation_gate)}`;
      if (candidate.status === "discovered" && can("review")) {
        const actions = document.createElement("div");
        actions.className = "admin-actions";
        ["confirmed", "rejected"].forEach((decision) => {
          const button = document.createElement("button");
          button.className = decision === "rejected" ? "danger" : "secondary";
          button.textContent = decision === "confirmed" ? "确认重复缺口" : "驳回候选";
          button.onclick = async () => {
            try {
              await api(`/api/v1/research/candidates/${candidate.id}/decision`, {
                method: "POST",
                body: JSON.stringify({ decision }),
              });
              setAdminNotice("候选状态已更新；未创建或发布智能体版本。", "admin-success");
              await loadAdmin(false);
            } catch (error) {
              setAdminNotice(`候选决策失败：${error.message}`, "admin-error");
            }
          };
          actions.appendChild(button);
        });
        item.appendChild(actions);
      }
      candidateRoot.appendChild(item);
    });
    if (digest.status === "pending" && can("review")) {
      ["approved", "rejected"].forEach((decision) => {
        const button = document.createElement("button");
        button.className = decision === "rejected" ? "danger" : "secondary";
        button.textContent = decision === "approved" ? "批准研究证据" : "驳回研究摘要";
        button.onclick = async () => {
          try {
            await api(`/api/v1/research/digests/${digest.id}/decision`, {
              method: "POST",
              body: JSON.stringify({ decision, note: "管理端人工复核" }),
            });
            setAdminNotice("研究摘要已决策；生产智能体未变化。", "admin-success");
            await loadAdmin(false);
          } catch (error) {
            setAdminNotice(`研究摘要决策失败：${error.message}`, "admin-error");
          }
        };
        card.querySelector(".digest-actions").appendChild(button);
      });
    }
    digestRoot.appendChild(card);
  });

  const attemptRoot = document.getElementById("candidate-attempt-list");
  attemptRoot.innerHTML = "";
  if (state.candidatePreflight) {
    const preflight = state.candidatePreflight;
    const card = document.createElement("article");
    card.className = "admin-card";
    const findings = preflight.findings || [];
    card.innerHTML = `
      <div class="admin-card-head">
        <div><h3>候选运行预检</h3><p class="mono">${escapeHtml(preflight.target.agent_id)} · ${escapeHtml(preflight.target.agent_version_id || "未发布")}</p></div>
        <span class="pill">${preflight.status === "ready" ? "可以启动" : "尚未就绪"}</span>
      </div>
      <div class="admin-meta">
        <span class="pill">不消耗候选机会</span>
        <span class="pill">模型调用 0</span>
        <span class="pill">来源调用 0</span>
        <span class="pill">外部写入 0</span>
      </div>
      <p>${findings.length ? findings.map(findingLabel).join("；") : "所有确定性前置条件已满足，可从本机命令行启动一次候选运行。"}</p>`;
    attemptRoot.appendChild(card);
  }
  const dimensions = [
    "diagnostic_progress",
    "actionable_guidance",
    "continuity_and_evidence_update",
    "evidence_boundary",
    "closure_or_next_hook",
    "investigation_efficiency",
  ];
  workspaceAttempts.forEach((attempt) => {
    const card = document.createElement("article");
    card.className = "admin-card";
    const totals = attempt.scorecard?.totals || {};
    const claims = attempt.scorecard?.claims || {};
    const episodes = (attempt.scorecard?.episodes || []).filter((episode) => episode.status === "completed");
    let candidateSummary = "未达到确定性准出；人工好评不能覆盖。";
    if (attempt.status === "fixture_contract_verified") {
      candidateSummary = "这里只验证隔离环境契约，未加载真实候选模型，因此不能进入人工批准。";
    } else if (attempt.scorecard?.deterministic_contract_passed && claims.candidate_loaded) {
      candidateSummary = "精确候选版本已加载；必须逐场景完成六维复核并确认能力指导影响。";
    }
    card.innerHTML = `
      <div class="admin-card-head">
        <div><h3>候选运行</h3><p class="mono">${escapeHtml(attempt.id)}</p></div>
        <span class="pill">${escapeHtml(statusLabel(attempt.status))}</span>
      </div>
      <div class="admin-meta">
        <span class="pill">场景 ${totals.completed_episodes ?? 0}/10</span>
        <span class="pill">模型轮次 ${attempt.model_calls}</span>
        <span class="pill">来源调用 ${attempt.source_calls}</span>
        <span class="pill">外部写入 ${attempt.external_writes}</span>
        <span class="pill">候选加载 ${claims.candidate_loaded ? "已证明" : "未证明"}</span>
        <span class="pill">技能影响 ${claims.skill_influence_observed ? "已观察" : "待观察"}</span>
        <span class="pill">工具影响 ${claims.tool_influence_observed ? "已观察" : "待观察"}</span>
      </div>
      <p class="mono">测试集摘要 sha256:${escapeHtml(attempt.suite_digest.slice(0, 16))} · 代码摘要 sha256:${escapeHtml(attempt.code_revision.slice(0, 16))} · 评分卡摘要 sha256:${escapeHtml((attempt.scorecard_digest || "未生成").slice(0, 16))}</p>
      <p>${candidateSummary}</p>
      <div class="candidate-review-form"></div>`;
    if (can("review") && attempt.status === "completed_pending_human_review") {
      const form = card.querySelector(".candidate-review-form");
      episodes.forEach((episode) => {
        const details = document.createElement("details");
        details.className = "candidate-episode-review";
        const summary = document.createElement("summary");
        summary.textContent = `${episode.category}（${episode.scenario_id}）`;
        details.appendChild(summary);
        const boundary = document.createElement("p");
        boundary.textContent = `复核边界：${episode.boundary_for_human_review}`;
        details.appendChild(boundary);
        const skillEvidence = document.createElement("p");
        skillEvidence.textContent = `预期技能：${episode.expected_skill || "未声明"}；运行上下文${episode.expected_skill_delivered ? "已送达" : "未送达"}`;
        details.appendChild(skillEvidence);
        const toolEvidence = document.createElement("p");
        const allowedTools = episode.allowed_tools?.length ? episode.allowed_tools.join("、") : "无";
        const actualTools = episode.actual_tools?.length ? episode.actual_tools.join("、") : "未调用";
        toolEvidence.textContent = `允许工具：${allowedTools}；实际调用：${actualTools}`;
        details.appendChild(toolEvidence);
        const runtimeEvidence = document.createElement("p");
        runtimeEvidence.textContent = `版本来源一致：${episode.provenance_passed ? "是" : "否"}；运行状态：${(episode.run_states || []).join("、") || "无"}；停止原因：${(episode.stop_reasons || []).filter(Boolean).join("、") || "无"}`;
        details.appendChild(runtimeEvidence);
        if (!episode.actual_tools?.length) {
          const warning = document.createElement("p");
          warning.textContent = "本场景没有实际工具调用，只能评估技能影响，不能声称已观察到工具执行影响。";
          details.appendChild(warning);
        }
        const answer = document.createElement("p");
        answer.textContent = `两轮答复摘录：${(episode.answer_excerpts || []).join(" / ")}`;
        details.appendChild(answer);
        const skillInfluenceLabel = document.createElement("label");
        skillInfluenceLabel.textContent = "预期技能是否对答复产生可辨识影响";
        const skillInfluenceSelect = document.createElement("select");
        skillInfluenceSelect.dataset.episodeSkillInfluence = episode.scenario_id;
        skillInfluenceSelect.innerHTML = '<option value="">请选择</option><option value="true">已观察</option><option value="false">未观察</option>';
        skillInfluenceLabel.appendChild(skillInfluenceSelect);
        details.appendChild(skillInfluenceLabel);
        const toolInfluenceLabel = document.createElement("label");
        toolInfluenceLabel.textContent = "实际工具调用是否影响了调查或答复";
        const toolInfluenceSelect = document.createElement("select");
        toolInfluenceSelect.dataset.episodeToolInfluence = episode.scenario_id;
        if (episode.actual_tools?.length) {
          toolInfluenceSelect.innerHTML = '<option value="">请选择</option><option value="true">已观察</option><option value="false">未观察</option>';
        } else {
          toolInfluenceSelect.innerHTML = '<option value="not_applicable">未调用，不适用</option>';
          toolInfluenceSelect.disabled = true;
        }
        toolInfluenceLabel.appendChild(toolInfluenceSelect);
        details.appendChild(toolInfluenceLabel);
        const influenceNote = document.createElement("textarea");
        influenceNote.dataset.episodeInfluenceNote = episode.scenario_id;
        influenceNote.placeholder = "说明哪段答复体现了技能影响；如有工具调用，同时说明工具结果如何被使用";
        details.appendChild(influenceNote);
        dimensions.forEach((dimension) => {
          const label = document.createElement("label");
          label.textContent = technicalLabel(dimension);
          const rubric = attempt.scorecard?.review_rubric?.[dimension];
          if (rubric) label.title = rubric;
          const select = document.createElement("select");
          select.dataset.episode = episode.scenario_id;
          select.dataset.dimension = dimension;
          select.innerHTML = '<option value="">请选择</option><option value="passed">通过</option><option value="failed">未通过</option>';
          label.appendChild(select);
          details.appendChild(label);
        });
        form.appendChild(details);
      });
      const note = document.createElement("textarea");
      note.placeholder = "整组人工复核意见（不得粘贴真实会话或密钥）";
      form.appendChild(note);
      const actions = document.createElement("div");
      actions.className = "admin-actions";
      ["approved", "rejected"].forEach((decision) => {
        const button = document.createElement("button");
        button.className = decision === "rejected" ? "danger" : "secondary";
        button.textContent = decision === "approved" ? "批准十类复核" : "驳回候选";
        button.onclick = async () => {
          try {
            const episodeDimensions = {};
            Array.from(form.querySelectorAll("select[data-episode]")).forEach((select) => {
              if (!select.value) throw new Error("每个场景的六个维度都必须选择");
              episodeDimensions[select.dataset.episode] ||= {};
              episodeDimensions[select.dataset.episode][select.dataset.dimension] = select.value;
            });
            const skillInfluenceObserved = {};
            Array.from(form.querySelectorAll("select[data-episode-skill-influence]")).forEach((select) => {
              if (!select.value) throw new Error("每个场景都必须记录技能影响是否可观察");
              skillInfluenceObserved[select.dataset.episodeSkillInfluence] = select.value === "true";
            });
            const toolInfluenceObserved = {};
            Array.from(form.querySelectorAll("select[data-episode-tool-influence]")).forEach((select) => {
              if (!select.value) throw new Error("有工具调用的场景必须记录工具影响");
              toolInfluenceObserved[select.dataset.episodeToolInfluence] = select.value === "not_applicable" ? null : select.value === "true";
            });
            const influenceNotes = {};
            Array.from(form.querySelectorAll("textarea[data-episode-influence-note]")).forEach((field) => {
              if (!field.value.trim()) throw new Error("每个场景都必须填写能力影响证据说明");
              influenceNotes[field.dataset.episodeInfluenceNote] = field.value.trim();
            });
            await api(`/api/v1/admin/candidate-attempts/${attempt.id}/human-review`, {
              method: "POST",
              body: JSON.stringify({
                decision,
                scorecard_digest: attempt.scorecard_digest,
                episode_dimensions: episodeDimensions,
                skill_influence_observed: skillInfluenceObserved,
                tool_influence_observed: toolInfluenceObserved,
                influence_notes: influenceNotes,
                note: note.value,
              }),
            });
            setAdminNotice("候选运行已完成一次性人工复核；不会自动重跑或发布。", "admin-success");
            await loadAdmin(false);
          } catch (error) {
            setAdminNotice(`候选运行复核失败：${error.message}`, "admin-error");
          }
        };
        actions.appendChild(button);
      });
      form.appendChild(actions);
    }
    attemptRoot.appendChild(card);
  });
  renderPager("review-page-actions", "reviewPage");
  renderPager("research-digest-page-actions", "researchPage");
  renderPager("candidate-attempt-page-actions", "candidatePage");
}

let caseConversationRequest = 0;
let caseConversationRefreshTimer = null;

function clearCaseConversationRefresh() {
  if (caseConversationRefreshTimer) window.clearTimeout(caseConversationRefreshTimer);
  caseConversationRefreshTimer = null;
}

function scheduleCaseConversationRefresh(caseId, delay = 2000) {
  clearCaseConversationRefresh();
  caseConversationRefreshTimer = window.setTimeout(() => {
    caseConversationRefreshTimer = null;
    if (state.adminTab !== "runs" || state.selectedCaseId !== caseId) return;
    void loadCaseConversation(caseId, { background: true });
  }, delay);
}

function traceStatusClass(status) {
  if (["completed", "observed", "passed", "sent", "captured", "ok"].includes(status)) return "success";
  if (["failed", "interrupted", "outcome_unknown", "timed_out", "rejected"].includes(status)) return "danger";
  return "attention";
}

function caseBrowserStatus(caseItem) {
  if (caseItem.latest_message_status === "pending") return { status: "pending", label: "等待执行" };
  if (caseItem.latest_message_status === "running" || caseItem.latest_run_status === "running") {
    return { status: "running", label: "排查中" };
  }
  if (caseItem.latest_message_error === "user_stop") return { status: "stopped", label: "已停止" };
  if (caseItem.latest_message_error && caseItem.latest_run_status !== "completed") {
    return { status: "failed", label: "已兜底结束" };
  }
  if (caseItem.latest_run_status === "completed") return { status: "completed", label: "已完成" };
  if (["failed", "interrupted", "timed_out"].includes(caseItem.latest_run_status)) {
    return { status: caseItem.latest_run_status, label: statusLabel(caseItem.latest_run_status) };
  }
  return { status: caseItem.lifecycle, label: statusLabel(caseItem.lifecycle) };
}

function traceNodeIcon(kind) {
  return {
    trigger_message: "入",
    context_assembly: "境",
    model_turn: "模",
    tool_call: "工",
    evidence: "证",
    assistant_reply: "答",
    outbox_delivery: "投",
    run_completion: "终",
  }[kind] || "·";
}

function traceKindLabel(kind) {
  return {
    trigger_message: "触发",
    context_assembly: "上下文",
    model_turn: "模型",
    tool_call: "工具",
    evidence: "证据",
    assistant_reply: "答复",
    outbox_delivery: "投递",
    run_completion: "运行",
  }[kind] || technicalLabel(kind);
}

function renderRunBrowser(workspaceCases) {
  const root = document.getElementById("admin-run-list");
  document.getElementById("run-browser-count").textContent = workspaceCases.length;
  root.innerHTML = "";
  workspaceCases.forEach((caseItem) => {
    const item = document.createElement("button");
    const displayStatus = caseBrowserStatus(caseItem);
    const statusClass = traceStatusClass(displayStatus.status);
    item.type = "button";
    item.className = `run-list-item secondary${caseItem.id === state.selectedCaseId ? " selected" : ""}`;
    item.setAttribute("role", "option");
    item.setAttribute("aria-selected", caseItem.id === state.selectedCaseId ? "true" : "false");
    item.tabIndex = caseItem.id === state.selectedCaseId ? 0 : -1;
    item.innerHTML = `
      <span class="run-list-item-head">
        <strong title="${escapeHtml(caseItem.title || "未命名会话")}">${escapeHtml(conciseCaseTitle(caseItem))}</strong>
        <span class="run-list-status ${statusClass}">${escapeHtml(displayStatus.label)}</span>
      </span>
      <p>${escapeHtml(displayName(caseItem.agent_id, caseItem.agent_name || "智能体"))} · ${escapeHtml(caseItem.persona?.name || "未知交流角色")} · ${caseItem.run_count} 次诊断 · ${caseItem.message_count} 条消息</p>
      <small>${timeHtml(caseItem.last_external_at || caseItem.updated_at || caseItem.created_at)}</small>`;
    item.onclick = () => selectCaseConversation(caseItem.id, workspaceCases);
    item.onkeydown = (event) => {
      const currentIndex = workspaceCases.findIndex((candidate) => candidate.id === caseItem.id);
      const targetIndex = event.key === "Home" ? 0
        : event.key === "End" ? workspaceCases.length - 1
          : event.key === "ArrowDown" ? Math.min(workspaceCases.length - 1, currentIndex + 1)
            : event.key === "ArrowUp" ? Math.max(0, currentIndex - 1)
              : -1;
      if (targetIndex < 0 || targetIndex === currentIndex) return;
      event.preventDefault();
      selectCaseConversation(workspaceCases[targetIndex].id, workspaceCases);
      requestAnimationFrame(() => root.querySelector('[aria-selected="true"]')?.focus());
    };
    root.appendChild(item);
  });
  if (!workspaceCases.length) {
    root.innerHTML = '<div class="trace-loading"><strong>当前还没有诊断会话</strong><span>案件触发智能体运行后，会按 Case 聚合显示在这里。</span></div>';
  }
}

function humanTextMarkup(value) {
  const text = String(value || "").trim();
  if (!text) return '<p class="human-empty">本回合没有记录可展示的文本。</p>';
  if (typeof window.markdownMarkup === "function") {
    const artifactBaseUrl = state.selectedCaseId
      ? `/api/v1/cases/${encodeURIComponent(state.selectedCaseId)}/artifacts`
      : "";
    return window.markdownMarkup(text, { artifactBaseUrl });
  }
  return `<p>${escapeHtml(text).replace(/\r?\n/g, "<br>")}</p>`;
}

function humanValueMarkup(value) {
  if (value === null || value === undefined || value === "") return '<span class="human-value-muted">未记录</span>';
  if (typeof value === "boolean") return escapeHtml(value ? "是" : "否");
  if (typeof value !== "object") return `<span>${escapeHtml(String(value))}</span>`;
  if (Array.isArray(value)) {
    if (!value.length) return '<span class="human-value-muted">空列表</span>';
    if (value.every((item) => typeof item !== "object" || item === null)) {
      return `<span>${value.map((item) => escapeHtml(String(item))).join("、")}</span>`;
    }
    return `<span class="human-value-muted">${value.length} 项结构化内容</span>`;
  }
  const keys = Object.keys(value);
  return `<span class="human-value-muted">${keys.length ? `包含 ${keys.slice(0, 3).map((key) => escapeHtml(technicalLabel(key))).join("、")}${keys.length > 3 ? " 等字段" : ""}` : "空对象"}</span>`;
}

function humanDataMarkup(value, emptyText = "没有记录") {
  if (value === null || value === undefined) return `<p class="human-empty">${escapeHtml(emptyText)}</p>`;
  if (typeof value !== "object" || Array.isArray(value)) return `<div class="human-data-value">${humanValueMarkup(value)}</div>`;
  const entries = Object.entries(value);
  if (!entries.length) return `<p class="human-empty">${escapeHtml(emptyText)}</p>`;
  return `<dl class="human-data-list">${entries.map(([key, item]) => `
    <div><dt>${escapeHtml(technicalLabel(key))}</dt><dd>${humanValueMarkup(item)}</dd></div>`).join("")}</dl>`;
}

function technicalRecordMarkup(value, emptyText = "没有留存") {
  if (value === null || value === undefined) return `<p class="human-empty">${escapeHtml(emptyText)}</p>`;
  const rendered = typeof value === "string" ? value : JSON.stringify(value, null, 2);
  return `<pre class="human-code model-record-code"><code>${escapeHtml(rendered)}</code></pre>`;
}

function modelRequestStats(round) {
  const request = round?.request;
  const messages = Array.isArray(request?.messages) ? request.messages : [];
  const tools = Array.isArray(request?.tools) ? request.tools : [];
  return { request, messages, tools };
}

function modelInputDisclosureMarkup(round) {
  const { request, messages, tools } = modelRequestStats(round);
  const summary = request && typeof request === "object"
    ? `${messages.length} 条消息 · ${tools.length} 个可用工具`
    : statusLabel(round.observability?.request_state || "not_recorded");
  return `
    <details class="inspector-disclosure">
      <summary><span><strong>模型看到的信息</strong><small>${escapeHtml(summary)}</small></span></summary>
      <div class="inspector-disclosure-body">
        ${technicalRecordMarkup(request, "该模型回合没有留存实际请求内容。")}
      </div>
    </details>`;
}

function modelTechnicalDisclosureMarkup(round) {
  const providerCallIds = (round.execution_group?.items || [])
    .map((item) => item.provider_call_id)
    .filter(Boolean);
  const record = {
    status: round.status,
    finish_reason: round.finish_reason,
    failure_class: round.failure_class,
    observability: round.observability,
    provider_call_ids: providerCallIds,
    normalized_response: round.response,
  };
  return `
    <details class="inspector-disclosure">
      <summary><span><strong>技术记录</strong><small>模型请求 · 规范化响应 · 调用标识</small></span></summary>
      <div class="inspector-disclosure-body">
        ${technicalRecordMarkup(record, "该模型回合没有留存技术记录。")}
      </div>
    </details>`;
}

function modelRoundPresentation(detail, round) {
  const executions = round.execution_group?.items || [];
  const projected = round.presentation && typeof round.presentation === "object"
    ? round.presentation
    : {};
  const responseText = String(round.response_text || "").trim();
  const replyText = String(detail.reply?.content || "").trim();
  const fallbackKind = executions.length
    ? "investigation"
    : responseText && replyText && responseText === replyText
      ? "public_answer"
      : responseText && replyText
        ? "candidate_answer"
        : responseText
          ? "model_response"
          : "model_event";
  let kind = projected.kind || fallbackKind;
  let title = projected.title || (kind === "public_answer" ? "对外答复" : executions.length ? `调查阶段 ${round.turn_index}` : `模型回合 ${round.turn_index}`);
  let summary = String(projected.summary || (kind === "candidate_answer" ? "模型生成了一版候选答复，随后经过准出检查；实际送达内容以“对外答复”为准。" : responseText)).trim();
  let summarySource = projected.summary_source || (round.response_text ? "model" : "runtime_projection");
  let reconstructionNote = "";

  if (kind === "investigation" && summarySource === "runtime_projection") {
    const labels = [...new Set(executions.map((item) => toolIdentity(item.tool_name).label))]
      .map((label) => String(label).slice(0, 42));
    summary = labels.length
      ? `正在进行：${labels.slice(0, 3).join("；")}${labels.length > 3 ? `等 ${labels.length} 项检查` : ""}。本轮用于取得会改变下一步判断的直接证据。`
      : summary;
    reconstructionNote = "该历史回合未留存模型阶段说明，以上按实际调用记录还原。";
  }
  if (!summary) {
    summary = round.observability?.response_state === "recorded"
      ? "本回合没有形成可读文本。"
      : "本回合返回正文未留存。";
    summarySource = "runtime_projection";
  }
  return {
    ...projected,
    kind,
    title,
    summary,
    summarySource,
    reconstructionNote,
  };
}

function roundSummaryMarkup(detail, round, { inspector = false } = {}) {
  const presentation = modelRoundPresentation(detail, round);
  const bodyClass = inspector ? "round-answer human-rich-text" : "assistant-message stage-summary human-rich-text";
  return `
    <div class="${bodyClass} ${escapeHtml(presentation.kind)}">
      ${humanTextMarkup(presentation.summary)}
      ${presentation.reconstructionNote ? `<p class="stage-reconstruction-note">${escapeHtml(presentation.reconstructionNote)}</p>` : ""}
    </div>`;
}

function roundDecisionMarkup(detail, round) {
  const presentation = modelRoundPresentation(detail, round);
  const failed = round.status === "failed" || Boolean(round.failure_class);
  return `
    <section class="inspector-primary-section round-presentation ${escapeHtml(presentation.kind)}${failed ? " danger" : ""}">
      <h4>${escapeHtml(presentation.kind === "investigation" ? "阶段说明" : presentation.title)}</h4>
      ${roundSummaryMarkup(detail, round, { inspector: true })}
    </section>`;
}

function evidenceStatementMarkup(statement) {
  const text = String(statement || "").trim();
  const match = text.match(/^([^：:]{1,18})[：:]\s*(.+)$/u);
  const label = match?.[1]?.trim() || "";
  if (match && /[A-Za-z\u3400-\u9fff]/u.test(label) && !/^https?$/i.test(label)) {
    return `<div><span>${escapeHtml(label)}</span><strong>${escapeHtml(match[2].trim())}</strong></div>`;
  }
  return `<div class="wide"><span>${escapeHtml(text)}</span></div>`;
}

const EVIDENCE_STATE_SUMMARIES = Object.freeze({
  observed: "本次检查已返回可用结果",
  zero_matches: "当前查询范围内未找到匹配结果",
  not_observable: "当前来源无法观察所需信息",
  query_failed: "本次来源查询失败",
  input_rejected: "本次查询条件未通过来源校验",
  conflict: "不同来源返回了相互冲突的结果",
  truncated: "本次检查返回了不完整结果",
});

const EVIDENCE_TEXT_TRANSLATIONS = Object.freeze({
  "Wiki results are documented business knowledge, not proof of current execution state.":
    "Wiki 返回的是已记录的业务知识，不能单独证明当前执行状态。",
  "One or more result snippets reached the per-page context limit.":
    "一个或多个结果摘要已达到单页上下文上限。",
  "The result covers only the repository-catalogued sources, identifier, and bounded time window shown here.":
    "结果只覆盖这里列出的已登记来源、标识符和有界时间范围。",
  "Source selection is a bounded source scope and does not prove which service handled an execution.":
    "来源选择仅代表本次查询范围，不能据此证明由哪个服务处理了该次执行。",
  "Zero matches applies only to the selected sources, identifier, and time window.":
    "零命中只适用于本次选定的来源、标识符和时间范围。",
  "continuation_unavailable:wiki_search_source_or_context_limit":
    "受来源或上下文上限限制，无法继续加载更多 Wiki 结果。",
  "continuation_unavailable:tool_pagination_not_implemented":
    "当前工具尚未提供分页续读能力。",
});

const EVIDENCE_FIELD_LABELS = Object.freeze({
  title: "标题",
  name: "名称",
  label: "名称",
  summary: "摘要",
  snippet: "内容摘要",
  content: "内容",
  text: "正文",
  message: "信息",
  description: "说明",
  query: "查询条件",
  count: "数量",
  total: "总数",
  total_count: "总数",
  returned_count: "返回数量",
  id: "标识",
  path: "路径",
  url: "链接",
  source: "来源",
  source_ref: "来源",
  created_at: "创建时间",
  updated_at: "更新时间",
  observed_at: "观测时间",
  timestamp: "时间",
});

const EVIDENCE_RESULT_KEYS = Object.freeze([
  "results", "matches", "items", "records", "entries", "rows", "documents", "logs", "events",
]);

function evidenceFieldLabel(key) {
  return EVIDENCE_FIELD_LABELS[key] || technicalLabel(key);
}

function evidenceLocalizedText(value) {
  const text = String(value || "").trim();
  if (!text) return "";
  if (EVIDENCE_TEXT_TRANSLATIONS[text]) return EVIDENCE_TEXT_TRANSLATIONS[text];
  const returned = text.match(/^[\w.:-]+ returned ([a-z_]+) evidence\.$/i);
  if (returned) return EVIDENCE_STATE_SUMMARIES[returned[1]] || "本次检查形成了结构化证据";
  return text;
}

function evidenceLimitationText(value) {
  const raw = String(value || "").trim();
  const localized = evidenceLocalizedText(raw);
  if (!localized || localized !== raw || /[\u3400-\u9fff]/u.test(localized)) return localized;
  if (/^continuation_unavailable:/i.test(raw)) return "当前来源无法继续加载更多结果，原始原因码已保留。";
  if (/^[a-z0-9_.:-]+$/i.test(raw)) return "来源返回了一项机器边界码，原值已保留在原始记录中。";
  return "来源返回了一条未本地化的边界说明，原文已保留在原始记录中。";
}

function evidenceResultList(value, depth = 0) {
  if (!value || typeof value !== "object" || Array.isArray(value) || depth > 2) return null;
  for (const key of EVIDENCE_RESULT_KEYS) {
    if (Array.isArray(value[key])) return { key, items: value[key] };
  }
  for (const [key, item] of Object.entries(value)) {
    if (Array.isArray(item) && item.some((entry) => entry && typeof entry === "object")) {
      return { key, items: item };
    }
  }
  for (const [key, item] of Object.entries(value)) {
    if (key.startsWith("_") || !item || typeof item !== "object" || Array.isArray(item)) continue;
    const nested = evidenceResultList(item, depth + 1);
    if (nested) return nested;
  }
  return null;
}

function evidenceScalarFields(value, limit = 8, prefix = "", depth = 0, output = []) {
  if (!value || typeof value !== "object" || Array.isArray(value) || depth > 2) return output;
  for (const [key, item] of Object.entries(value)) {
    if (output.length >= limit) break;
    if (key.startsWith("_") || EVIDENCE_RESULT_KEYS.includes(key)) continue;
    const label = prefix ? `${prefix} · ${evidenceFieldLabel(key)}` : evidenceFieldLabel(key);
    if (item === null || ["string", "number", "boolean"].includes(typeof item)) {
      const raw = item === null ? "未记录" : String(item);
      output.push({ label, value: raw.length > 700 ? `${raw.slice(0, 700)}…` : raw });
    } else if (Array.isArray(item) && item.every((entry) => entry === null || typeof entry !== "object")) {
      output.push({ label, value: item.map((entry) => String(entry ?? "未记录")).join("、") });
    } else if (item && typeof item === "object" && !Array.isArray(item)) {
      evidenceScalarFields(item, limit, label, depth + 1, output);
    }
  }
  return output;
}

function evidenceFieldListMarkup(fields, className = "evidence-preview-fields") {
  if (!fields.length) return "";
  return `<dl class="${className}">${fields.map((field) => `
    <div><dt>${escapeHtml(field.label)}</dt><dd>${escapeHtml(field.value)}</dd></div>`).join("")}</dl>`;
}

function evidenceResultItemMarkup(item, index) {
  if (item === null || typeof item !== "object") {
    return `<article class="evidence-result-item"><strong>结果 ${index + 1}</strong><p>${escapeHtml(String(item ?? "未记录"))}</p></article>`;
  }
  const fields = evidenceScalarFields(item, 10);
  const titleIndex = fields.findIndex((field) => ["标题", "名称", "标识"].includes(field.label));
  const title = titleIndex >= 0 ? fields.splice(titleIndex, 1)[0].value : `结果 ${index + 1}`;
  return `<article class="evidence-result-item"><strong>${escapeHtml(title)}</strong>${evidenceFieldListMarkup(fields, "evidence-result-fields")}</article>`;
}

function evidenceDataPreviewMarkup(data, maxItems = 5) {
  if (!data || typeof data !== "object" || Array.isArray(data) || !Object.keys(data).length) return "";
  const result = evidenceResultList(data);
  const contextFields = evidenceScalarFields(data, 6);
  if (!result && !contextFields.length) return "";
  const itemCount = result?.items.length ?? 0;
  return `
    <section class="evidence-data-preview">
      <div class="evidence-data-preview-heading"><strong>${result ? "查询结果" : "来源返回内容"}</strong><span>${result ? `${itemCount} 项` : `${contextFields.length} 个字段`}</span></div>
      ${evidenceFieldListMarkup(contextFields)}
      ${result ? (itemCount
        ? `<div class="evidence-result-list">${result.items.slice(0, maxItems).map(evidenceResultItemMarkup).join("")}</div>`
        : '<p class="evidence-preview-empty">当前查询范围内没有返回匹配项。</p>') : ""}
      ${result && itemCount > maxItems ? `<p class="evidence-preview-more">另有 ${itemCount - maxItems} 项，请在原始记录中查看。</p>` : ""}
    </section>`;
}

function evidenceSummaryText(item) {
  const raw = String(item?.summary || "").trim();
  const localized = evidenceLocalizedText(raw);
  if (localized && (localized !== raw || /[\u3400-\u9fff]/u.test(localized))) return localized;
  const chineseStatement = (item?.safe_statements || []).find((statement) => /[\u3400-\u9fff]/u.test(String(statement)));
  if (chineseStatement) return String(chineseStatement).slice(0, 120);
  const result = evidenceResultList(item?.data);
  if (item?.state === "observed" && result) return `本次检查返回 ${result.items.length} 项结构化结果`;
  return EVIDENCE_STATE_SUMMARIES[item?.state] || "本次检查形成了一条证据记录";
}

function groupedEvidenceMarkup(item, call) {
  const statements = Array.isArray(item.safe_statements) ? item.safe_statements.filter(Boolean) : [];
  const rawRecord = item.provider_observation ?? call?.result ?? item.data ?? null;
  const limitations = Array.isArray(item.limitations) ? item.limitations.filter(Boolean) : [];
  const dataPreview = evidenceDataPreviewMarkup(item.data);
  const readableLimitations = [...new Set(limitations.map(evidenceLimitationText).filter(Boolean))];
  return `
    <article class="grouped-evidence-card">
      <div class="grouped-evidence-heading">
        <span class="status-badge ${traceStatusClass(item.state)}">${escapeHtml(statusLabel(item.state))}</span>
        <strong>${escapeHtml(evidenceSummaryText(item))}</strong>
      </div>
      ${statements.length ? `<div class="evidence-fact-list">${statements.map(evidenceStatementMarkup).join("")}</div>` : (dataPreview ? '<p class="evidence-projection-note">来源未另行标注可直接引用的结论；以下展示本次结构化返回。</p>' : '<p class="human-empty">来源没有提供可直接展示的事实内容。</p>')}
      ${dataPreview}
      <div class="grouped-evidence-meta">
        <span>来源：${escapeHtml(String(item.source_ref || "未记录"))}</span>
        ${item.coverage_state && item.coverage_state !== "proven_total" ? `<span>覆盖：${escapeHtml(statusLabel(item.coverage_state))}</span>` : ""}
        ${item.truncation_state && item.truncation_state !== "complete" ? `<span>内容：${escapeHtml(statusLabel(item.truncation_state))}</span>` : ""}
      </div>
      ${readableLimitations.length ? `<details class="grouped-evidence-limitations"><summary>范围与限制 · ${readableLimitations.length} 项</summary><ul>${readableLimitations.map((limitation) => `<li>${escapeHtml(limitation)}</li>`).join("")}</ul></details>` : ""}
      <details class="evidence-raw-details">
        <summary>查看原始记录</summary>
        <div class="evidence-raw-body">
          <section><h6>原始观测</h6>${technicalRecordMarkup(rawRecord, "Provider 没有留存独立原始观测记录。")}</section>
          ${call ? `<section><h6>调用参数</h6>${technicalRecordMarkup(call.arguments, "没有记录调用参数。")}</section>` : ""}
        </div>
      </details>
    </article>`;
}

function checksAndEvidenceMarkup(detail, round) {
  const executions = round.execution_group?.items || [];
  const presentation = modelRoundPresentation(detail, round);
  if (presentation.kind === "internal_check") return "";
  if (!executions.length) {
    if (!detail.evidence?.length) return "";
    return `
      <section class="inspector-primary-section checks-evidence-section">
        <div class="inspector-section-heading"><span><h4>答复依据</h4><small>本轮未新增检查；答复可追溯到本次诊断此前累计的 ${detail.evidence.length} 条证据。</small></span></div>
        <details class="all-evidence-details"><summary>查看本次诊断全部 ${detail.evidence.length} 条证据</summary>${evidenceSummaryMarkup(detail.evidence)}</details>
      </section>`;
  }
  const executionCallIds = new Set(executions.map((execution) => execution.tool_call_id).filter(Boolean));
  const currentEvidence = (detail.evidence || []).filter((item) => executionCallIds.has(item.tool_call_id));
  const earlierEvidence = (detail.evidence || []).filter((item) => !executionCallIds.has(item.tool_call_id));
  return `
    <section class="inspector-primary-section checks-evidence-section">
      <div class="inspector-section-heading"><span><h4>本轮检查</h4><small>${executions.length} 项检查 · ${currentEvidence.length} 条证据</small></span></div>
      <div class="check-evidence-list">
        ${executions.map((execution) => {
          const call = (detail.tool_calls || []).find((item) => item.id === execution.tool_call_id);
          const evidence = (detail.evidence || []).filter((item) => item.tool_call_id === execution.tool_call_id);
          return `
            <article class="check-evidence-group">
              <header>
                ${toolIdentityMarkup(execution.tool_name)}
                <span class="run-list-status ${traceStatusClass(execution.status)}">${escapeHtml(statusLabel(execution.status))}</span>
              </header>
              <details class="check-evidence-details">
                <summary>${evidence.length ? `查看形成的 ${evidence.length} 条证据` : "本次检查未形成独立证据"}</summary>
                <div class="check-evidence-body">
                  ${evidence.length ? evidence.map((item) => groupedEvidenceMarkup(item, call)).join("") : '<p class="human-empty">本次检查没有形成独立 Evidence 记录。</p>'}
                </div>
              </details>
            </article>`;
        }).join("")}
      </div>
      ${earlierEvidence.length ? `<details class="all-evidence-details"><summary>查看此前累计的 ${earlierEvidence.length} 条证据</summary>${evidenceSummaryMarkup(earlierEvidence)}</details>` : ""}
    </section>`;
}

function findConversationRun(runId) {
  return state.caseConversation?.runs?.find((detail) => detail.run.id === runId) || null;
}

function findRoundContext(roundId) {
  for (const detail of state.caseConversation?.runs || []) {
    const round = (detail.model_rounds || []).find((item) => item.id === roundId);
    if (round) {
      const modelTurn = (detail.model_turns || []).find((item) => item.id === roundId);
      return {
        detail,
        round: {
          ...round,
          request: modelTurn?.request ?? null,
          response: modelTurn?.response ?? null,
        },
      };
    }
  }
  return null;
}

function findExecutionContext(toolCallId) {
  for (const detail of state.caseConversation?.runs || []) {
    const call = (detail.tool_calls || []).find((item) => item.id === toolCallId);
    if (!call) continue;
    const evidence = (detail.evidence || []).filter((item) => item.tool_call_id === toolCallId);
    const round = (detail.model_rounds || []).find((item) =>
      (item.execution_group?.items || []).some((execution) => execution.tool_call_id === toolCallId)
    );
    return { detail, round, call, evidence };
  }
  return null;
}

function evidenceSummaryMarkup(evidence) {
  if (!evidence.length) {
    return '<p class="human-empty">本次执行没有形成独立 Evidence 记录。</p>';
  }
  return `<div class="evidence-readable-list">${evidence.map((item) => `
    <article class="evidence-readable-card">
      <header><strong>${escapeHtml(evidenceSummaryText(item))}</strong><span class="status-badge ${traceStatusClass(item.state)}">${escapeHtml(statusLabel(item.state))}</span></header>
      <div class="evidence-readable-meta"><span>覆盖：${escapeHtml(statusLabel(item.coverage_state || "未记录"))}</span><span>来源：${escapeHtml(String(item.source_ref || "未记录"))}</span>${item.truncation_state && item.truncation_state !== "complete" ? `<span>内容：${escapeHtml(statusLabel(item.truncation_state))}</span>` : ""}</div>
      ${(item.safe_statements || []).length ? `<ul>${item.safe_statements.map((statement) => `<li>${escapeHtml(statement)}</li>`).join("")}</ul>` : ""}
      ${evidenceDataPreviewMarkup(item.data, 3)}
    </article>`).join("")}</div>`;
}

function deliveryMeaning(delivery) {
  const operation = delivery?.payload?.operation;
  const lifecycle = delivery?.payload?.lifecycle_state;
  if (operation === "card_start") return "处理中提示";
  if (operation === "card_finish") return lifecycle === "failed" ? "失败兜底" : "最终答复";
  if (lifecycle === "failed") return "失败兜底";
  return "最终答复";
}

function finalDeliveryState(detail) {
  const deliveries = (detail?.outbox_deliveries || []).filter(
    (delivery) => deliveryMeaning(delivery) !== "处理中提示",
  );
  if (!deliveries.length) return null;
  if (deliveries.some((delivery) => ["sent", "captured"].includes(delivery.status))) return "sent";
  if (deliveries.some((delivery) => ["failed", "outcome_unknown"].includes(delivery.status))) return "failed";
  return "pending";
}

function runFooterPresentation(detail) {
  const run = detail.run;
  const duration = formatDuration(durationBetween(
    run.started_at,
    run.finished_at || (run.status === "running" ? new Date().toISOString() : null),
  ));
  const delivery = finalDeliveryState(detail);
  const terminalFailure = ["failed", "interrupted", "timed_out", "budget_exhausted"].includes(run.status);
  const runTone = run.status === "completed" ? "success" : run.status === "running" ? "attention" : terminalFailure ? "danger" : "";
  let deliveryLabel = "";
  let deliveryTone = "";

  if (delivery === "sent") {
    deliveryLabel = terminalFailure ? "失败说明已送达" : "答复已送达";
    deliveryTone = "success";
  } else if (delivery === "failed") {
    deliveryLabel = "答复投递异常";
    deliveryTone = "danger";
  } else if (delivery === "pending") {
    deliveryLabel = "答复待送达";
    deliveryTone = "attention";
  } else if (run.status === "running") {
    deliveryLabel = "正在取得证据";
    deliveryTone = "attention";
  } else if (detail.reply?.content) {
    deliveryLabel = "答复已生成";
  }

  return {
    runLabel: statusLabel(run.status),
    runTone,
    runMark: run.status === "completed" ? "✓" : run.status === "running" ? "…" : terminalFailure ? "!" : "·",
    duration,
    deliveryLabel,
    deliveryTone,
  };
}

function conversationExecutionSummary(conversation) {
  const execution = conversation.messageExecutions?.at(-1) || null;
  const detail = conversation.runs?.at(-1) || null;
  const run = detail?.run || null;
  const live = execution?.status === "pending" || execution?.status === "running" || run?.status === "running";
  if (execution?.status === "pending") {
    return { status: "pending", label: "等待执行", detail: "消息已接收，等待 Worker 开始排查", live };
  }
  if (execution?.status === "running" || run?.status === "running") {
    const rounds = detail?.model_rounds?.length || 0;
    const tools = detail?.tool_calls?.length || 0;
    const startedAt = run?.started_at || execution?.created_at;
    const elapsed = startedAt ? formatDuration(durationBetween(startedAt, new Date().toISOString())) : "刚刚开始";
    return {
      status: "running",
      label: "排查中",
      detail: `${rounds} 个模型回合 · ${tools} 次工具调用 · 已运行 ${elapsed}`,
      live,
    };
  }
  if (execution?.terminal_reply_id) {
    const delivery = execution.terminal_delivery_status || finalDeliveryState(detail);
    const delivered = ["sent", "captured"].includes(delivery);
    const pending = [null, undefined, "pending", "sending"].includes(delivery);
    return {
      status: delivered ? "completed" : pending ? "pending" : "failed",
      label: delivered ? "异常已兜底" : pending ? "兜底待投递" : "兜底投递异常",
      detail: delivered
        ? "本轮未能完成诊断，但已结束处理中状态并投递失败说明"
        : pending
          ? "本轮已生成失败说明，正在等待投递"
          : "本轮已结束，但失败说明没有取得可靠投递回执",
      live: pending,
    };
  }
  if (run) {
    const delivery = finalDeliveryState(detail);
    if (run.status === "completed") {
      return {
        status: delivery === "failed" ? "failed" : delivery === "pending" ? "pending" : "completed",
        label: delivery === "sent" ? "已答复并投递" : delivery === "failed" ? "答复投递异常" : delivery === "pending" ? "答复待投递" : "诊断已完成",
        detail: `${detail.model_rounds?.length || 0} 个模型回合 · ${detail.tool_calls?.length || 0} 次工具调用${run.stop_reason === "investigation_convergence" ? " · 已按证据收口" : ""}`,
        live: delivery === "pending",
      };
    }
    if (["failed", "interrupted", "timed_out", "budget_exhausted"].includes(run.status)) {
      return {
        status: delivery === "pending" ? "pending" : delivery === "failed" ? "failed" : run.status,
        label: delivery === "sent" ? "失败已答复" : delivery === "pending" ? "失败答复待投递" : delivery === "failed" ? "失败答复投递异常" : statusLabel(run.status),
        detail: `${run.stop_reason ? statusLabel(run.stop_reason) : "运行已结束"}${delivery === "sent" ? " · 已结束处理中状态" : ""}`,
        live: delivery === "pending",
      };
    }
    return {
      status: run.status,
      label: run.status === "interrupted" && run.stop_reason === "process_shutdown" ? "等待进程接续" : statusLabel(run.status),
      detail: run.stop_reason ? statusLabel(run.stop_reason) : "运行已结束",
      live,
    };
  }
  return {
    status: execution?.status || conversation.case.lifecycle,
    label: execution ? statusLabel(execution.status) : statusLabel(conversation.case.lifecycle),
    detail: execution ? "消息执行状态已记录" : "当前没有运行记录",
    live,
  };
}

function renderTraceInspector() {
  const root = document.getElementById("run-node-inspector");
  const selectedId = state.selectedConversationItemId;
  const roundContext = findRoundContext(selectedId);
  const executionContext = findExecutionContext(selectedId.replace(/^unlinked:/, ""));
  if (!roundContext && !executionContext) {
    root.innerHTML = '<div class="trace-inspector-empty"><strong>选择一个调查阶段</strong><span>主视图先展示阶段说明；需要时再展开检查步骤与原始记录。</span></div>';
    return;
  }
  if (roundContext) {
    const { detail, round } = roundContext;
    const presentation = modelRoundPresentation(detail, round);
    root.innerHTML = `
      <header class="trace-inspector-header">
        <div class="trace-inspector-header-top">
          <div><h3>${escapeHtml(presentation.title)}</h3></div>
          <span class="status-badge ${traceStatusClass(round.status)}">${escapeHtml(statusLabel(round.status))}</span>
        </div>
        <div class="trace-inspector-meta-line"><span>模型回合 ${round.turn_index}</span><span aria-hidden="true">·</span><span>${escapeHtml(round.model?.model_id || "模型未记录")}</span><span aria-hidden="true">·</span><span>${escapeHtml(formatDuration(round.duration_ms))}</span><span aria-hidden="true">·</span><span>${escapeHtml(formatTime(round.started_at))}</span></div>
      </header>
      <div class="trace-inspector-body round-inspector-body">
        ${roundDecisionMarkup(detail, round)}
        ${checksAndEvidenceMarkup(detail, round)}
        <div class="inspector-secondary-records">
          ${modelInputDisclosureMarkup(round)}
          ${modelTechnicalDisclosureMarkup(round)}
        </div>
      </div>`;
    return;
  }
  const { detail, round, call, evidence } = executionContext;
  const callIdentity = toolIdentity(call.tool_name);
  const callRecordSections = `
    <section class="readable-section"><div class="readable-section-head"><h4>调用参数</h4></div>${humanDataMarkup(call.arguments, "没有记录参数")}</section>
    <section class="readable-section"><div class="readable-section-head"><h4>原始返回</h4></div>${humanDataMarkup(call.result, "没有记录工具返回")}</section>`;
  const callRecordMarkup = evidence.length
    ? `<details class="execution-record-details">
        <summary><span><strong>调用记录</strong><small>参数与原始返回</small></span></summary>
        <div class="execution-record-body">${callRecordSections}</div>
      </details>`
    : callRecordSections;
  root.innerHTML = `
    <header class="trace-inspector-header">
      <div class="trace-inspector-header-top"><div><h3>${escapeHtml(callIdentity.label)}</h3></div><span class="status-badge ${traceStatusClass(call.status)}">${escapeHtml(statusLabel(call.status))}</span></div>
      <div class="trace-inspector-meta-line">${callIdentity.hasDistinctLabel ? `<span class="trace-tool-technical-name">${toolNameMarkup(callIdentity.technicalName)}</span><span aria-hidden="true">·</span>` : ""}<span>${escapeHtml(formatDuration(durationBetween(call.created_at, call.finished_at)))}</span><span aria-hidden="true">·</span><span>${escapeHtml(formatTime(call.created_at))}</span></div>
    </header>
    <div class="trace-inspector-body execution-inspector-body">
      ${evidence.length ? `<section class="readable-section execution-evidence-section"><div class="readable-section-head"><h4>形成的证据</h4><span>${evidence.length} 条</span></div>${evidenceSummaryMarkup(evidence)}</section>` : ""}
      ${callRecordMarkup}
    </div>`;
}

function renderRunTrace() {
  const summary = document.getElementById("run-trace-summary");
  const root = document.getElementById("run-trace-list");
  const conversation = state.caseConversation;
  if (!conversation || conversation.case.id !== state.selectedCaseId) {
    summary.innerHTML = '<div><h3>正在读取诊断会话…</h3></div>';
    root.innerHTML = '<div class="trace-loading"><strong>正在读取诊断会话</strong></div>';
    renderTraceInspector();
    return;
  }
  const caseItem = conversation.case;
  const caseAgent = state.agents.find((agent) => agent.id === caseItem.agent_id);
  const caseAgentName = displayName(
    caseItem.agent_id || "",
    caseAgent?.name || caseItem.agent_name || "智能体",
  );
  const executionSummary = conversationExecutionSummary(conversation);
  summary.innerHTML = `
    <div class="trace-summary-copy"><h3>${escapeHtml(conciseCaseTitle(caseItem))}</h3><span class="trace-summary-meta"><span title="${escapeHtml(executionSummary.detail)}">${escapeHtml(caseItem.persona?.name || "未知交流角色")} · ${conversation.runs.length} 次诊断 · ${caseItem.message_count} 条消息 · ${caseItem.evidence_count} 条证据 · ${escapeHtml(executionSummary.detail)}</span><button type="button" class="trace-copy-id secondary" data-copy-case-id="${escapeHtml(caseItem.id)}" aria-label="复制 Case ID" title="复制完整 Case ID"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5.25 4.25V3.5A1.5 1.5 0 0 1 6.75 2h5.75A1.5 1.5 0 0 1 14 3.5v5.75a1.5 1.5 0 0 1-1.5 1.5h-.75M3.5 5.25h5.75a1.5 1.5 0 0 1 1.5 1.5v5.75A1.5 1.5 0 0 1 9.25 14H3.5A1.5 1.5 0 0 1 2 12.5V6.75a1.5 1.5 0 0 1 1.5-1.5Z"/></svg><span>复制 ID</span></button></span></div>
    <span class="status-badge ${traceStatusClass(executionSummary.status)}">${escapeHtml(executionSummary.label)}</span>`;
  const copyIdButton = summary.querySelector("[data-copy-case-id]");
  const copyCaseId = async () => {
    if (copyIdButton.dataset.busy === "true") return;
    const label = copyIdButton.querySelector("span");
    copyIdButton.dataset.busy = "true";
    copyIdButton.disabled = true;
    try {
      await copyTextToClipboard(copyIdButton.dataset.copyCaseId);
      label.textContent = "已复制";
      setAdminNotice("Case ID 已复制。", "admin-success");
      window.setTimeout(() => {
        if (copyIdButton.isConnected) label.textContent = "复制 ID";
      }, 1600);
    } catch (error) {
      setAdminNotice(`Case ID 复制失败：${error.message}`, "admin-error");
    } finally {
      delete copyIdButton.dataset.busy;
      if (copyIdButton.isConnected) copyIdButton.disabled = false;
    }
  };
  copyIdButton.onclick = copyCaseId;
  copyIdButton.onkeydown = (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    copyCaseId();
  };
  if (!conversation.runs.length) {
    root.innerHTML = executionSummary.live
      ? `<div class="trace-loading"><strong>${escapeHtml(executionSummary.label)}</strong><span>${escapeHtml(executionSummary.detail)}</span></div>`
      : '<div class="trace-loading"><strong>暂无诊断回合</strong><span>该消息尚未形成模型运行记录。</span></div>';
    renderTraceInspector();
    return;
  }
  root.innerHTML = `${conversation.limited ? '<div class="conversation-limitation">该 Case 的历史 Run 超过管理视图上限；这里只展示最近 100 次，未对缺失部分做推断。</div>' : ""}${conversation.runs.map((detail, runIndex) => {
    const run = detail.run;
    const trigger = detail.trigger_message;
    const rounds = detail.model_rounds || [];
    const renderedRoundTexts = new Set(rounds
      .filter((round) => modelRoundPresentation(detail, round).kind === "public_answer")
      .map((round) => String(round.response_text || "").trim())
      .filter(Boolean));
    const replyNeedsOwnMessage = detail.reply?.content && !renderedRoundTexts.has(String(detail.reply.content).trim());
    const footer = runFooterPresentation(detail);
    return `
      <section class="conversation-exchange" data-run-id="${escapeHtml(run.id)}">
        <article class="conversation-message user-message">
          <div class="message-meta"><strong>用户</strong><span>${escapeHtml(formatTime(trigger?.created_at || run.started_at))}</span></div>
          <div class="message-bubble human-rich-text">${humanTextMarkup(trigger?.content || "该历史 Run 没有留存触发消息正文。")}</div>
        </article>
        <section class="agent-conversation-turn">
          <div class="agent-turn-heading"><div><strong>${escapeHtml(caseAgentName)}</strong><span>${escapeHtml(run.model_id || "模型未记录")}</span></div><span>第 ${runIndex + 1} 次诊断</span></div>
          ${rounds.length ? rounds.map((round) => {
            const executions = round.execution_group?.items || [];
            const presentation = modelRoundPresentation(detail, round);
            const selected = state.selectedConversationItemId === round.id;
            return `<article class="model-round ${escapeHtml(presentation.kind)}${selected ? " selected" : ""}" data-round-card="${escapeHtml(round.id)}">
              <button type="button" class="model-round-select secondary" data-round-id="${escapeHtml(round.id)}">
                <span><strong>${escapeHtml(presentation.title)}</strong><small>模型回合 ${round.turn_index} · ${escapeHtml(round.model?.model_id || run.model_id || "模型未记录")} · ${escapeHtml(formatDuration(round.duration_ms))}</small></span>
                <span class="run-list-status ${traceStatusClass(round.status)}">${escapeHtml(statusLabel(round.status))}</span>
              </button>
              ${roundSummaryMarkup(detail, round)}
              ${executions.length ? `<details class="round-execution-group" data-execution-group-id="${escapeHtml(round.execution_group.id)}"${state.expandedExecutionGroups[round.execution_group.id] ? " open" : ""}>
                <summary><span>查看 ${executions.length} 个检查步骤 · ${round.execution_group.evidence_count || 0} 条证据</span><small>按需展开</small></summary>
                <div class="round-execution-list">${executions.map((execution, executionIndex) => `<button type="button" class="execution-row secondary${state.selectedConversationItemId === execution.tool_call_id ? " selected" : ""}" ${execution.tool_call_id ? `data-tool-id="${escapeHtml(execution.tool_call_id)}"` : "disabled"}><span class="execution-index">${executionIndex + 1}</span><span><strong>${escapeHtml(toolIdentity(execution.tool_name).label)}</strong><small>${execution.evidence_count} 条证据${execution.tool_call_id ? "" : execution.association_state === "ambiguous_model_round_reference" ? " · 回合关联不唯一" : " · 调用记录未落库"}</small></span><span class="run-list-status ${traceStatusClass(execution.status)}">${escapeHtml(statusLabel(execution.status))}</span></button>`).join("")}</div>
              </details>` : ""}
            </article>`;
          }).join("") : '<div class="conversation-observation-gap"><strong>模型回合不可观察</strong><span>该历史 Run 没有留存逐模型回合记录；不会用 Trace 时间线反向猜测。</span></div>'}
          ${replyNeedsOwnMessage ? `<article class="model-round public-reply"><div class="model-round-static"><span><strong>对外答复</strong><small>${escapeHtml(formatTime(detail.reply.created_at))}</small></span><span class="run-list-status success">已生成</span></div><div class="assistant-message human-rich-text">${humanTextMarkup(detail.reply.content)}</div></article>` : ""}
          ${(detail.unlinked_executions || []).length ? `<details class="round-execution-group unlinked-executions" data-execution-group-id="unlinked:${escapeHtml(run.id)}"${state.expandedExecutionGroups[`unlinked:${run.id}`] ? " open" : ""}><summary><span>未关联执行 ${detail.unlinked_executions.length} 条</span><small>收起</small></summary><div class="round-execution-list">${detail.unlinked_executions.map((execution, executionIndex) => `<button type="button" class="execution-row secondary${state.selectedConversationItemId === `unlinked:${execution.tool_call_id}` ? " selected" : ""}" data-unlinked-tool-id="${escapeHtml(execution.tool_call_id)}"><span class="execution-index">${executionIndex + 1}</span><span><strong>${escapeHtml(toolIdentity(execution.tool_name).label)}</strong><small>${execution.evidence_count} 条证据</small></span><span class="run-list-status ${traceStatusClass(execution.status)}">${escapeHtml(statusLabel(execution.status))}</span></button>`).join("")}</div></details>` : ""}
          <footer class="conversation-run-footer">
            <div class="conversation-run-summary ${footer.runTone}"><span class="conversation-run-mark" aria-hidden="true">${footer.runMark}</span><strong>${escapeHtml(footer.runLabel)}</strong><span aria-hidden="true">·</span><span>${escapeHtml(footer.duration)}</span></div>
            ${footer.deliveryLabel ? `<span class="conversation-delivery-state ${footer.deliveryTone}">${escapeHtml(footer.deliveryLabel)}</span>` : ""}
          </footer>
        </section>
      </section>`;
  }).join("")}`;
  root.querySelectorAll("[data-round-id]").forEach((button) => {
    button.onclick = () => selectConversationItem(button.dataset.roundId);
  });
  root.querySelectorAll("[data-tool-id]").forEach((button) => {
    button.onclick = () => selectConversationItem(button.dataset.toolId);
  });
  root.querySelectorAll("[data-unlinked-tool-id]").forEach((button) => {
    button.onclick = () => selectConversationItem(`unlinked:${button.dataset.unlinkedToolId}`);
  });
  root.querySelectorAll("[data-execution-group-id]").forEach((details) => {
    details.ontoggle = () => {
      state.expandedExecutionGroups[details.dataset.executionGroupId] = details.open;
    };
  });
  renderTraceInspector();
}

function conversationItemExists(itemId) {
  if (!itemId) return false;
  if (itemId.startsWith("unlinked:")) return Boolean(findExecutionContext(itemId.slice(9)));
  return Boolean(findRoundContext(itemId) || findExecutionContext(itemId));
}

function preferredConversationItem(detail) {
  const rounds = [...(detail?.model_rounds || [])].reverse();
  const publicAnswer = rounds.find((round) => modelRoundPresentation(detail, round).kind === "public_answer");
  const investigation = rounds.find((round) => modelRoundPresentation(detail, round).kind === "investigation");
  const readable = rounds.find((round) => !["internal_check", "candidate_answer"].includes(modelRoundPresentation(detail, round).kind));
  return publicAnswer?.id || investigation?.id || readable?.id || "";
}

function selectConversationItem(itemId) {
  state.selectedConversationItemId = itemId;
  renderRunTrace();
  if (window.innerWidth < 1180) {
    document.getElementById("run-node-inspector")?.scrollIntoView({ block: "start", behavior: "smooth" });
  }
}

async function loadCaseConversation(caseId, { background = false } = {}) {
  const requestId = ++caseConversationRequest;
  if (!background) {
    clearCaseConversationRefresh();
    state.caseConversation = null;
    renderRunTrace();
  }
  try {
    const caseDetail = await api(`/api/v1/admin/cases/${caseId}`);
    const runRefs = [...(caseDetail.runs || [])].sort((left, right) =>
      String(left.started_at || "").localeCompare(String(right.started_at || "")) || left.id.localeCompare(right.id)
    );
    const runDetails = await Promise.all(runRefs.map((run) => api(`/api/v1/admin/runs/${run.id}`)));
    if (requestId !== caseConversationRequest || state.selectedCaseId !== caseId) return;
    const runs = runDetails.filter((detail) => detail.run?.case_id === caseId);
    state.caseConversation = {
      case: caseDetail.case,
      runs,
      messageExecutions: caseDetail.message_executions || [],
      limited: Number(caseDetail.case?.run_count || 0) > runRefs.length,
    };
    if (!conversationItemExists(state.selectedConversationItemId)) {
      const lastRun = runs.at(-1);
      state.selectedConversationItemId = preferredConversationItem(lastRun)
        || (lastRun?.unlinked_executions?.at(-1)?.tool_call_id ? `unlinked:${lastRun.unlinked_executions.at(-1).tool_call_id}` : "");
    }
    renderRunTrace();
    if (conversationExecutionSummary(state.caseConversation).live) {
      scheduleCaseConversationRefresh(caseId);
    } else {
      clearCaseConversationRefresh();
    }
  } catch (error) {
    if (requestId !== caseConversationRequest) return;
    if (background && state.caseConversation?.case?.id === caseId) {
      scheduleCaseConversationRefresh(caseId, 5000);
      return;
    }
    document.getElementById("run-trace-list").innerHTML = '<div class="trace-loading"><strong>诊断会话读取失败</strong><span>请刷新后重试；页面不会用不完整数据推断回合。</span></div>';
    setAdminNotice(`诊断会话读取失败：${error.message}`, "admin-error");
  }
}

function selectCaseConversation(caseId, workspaceCases) {
  if (state.selectedCaseId === caseId && state.caseConversation?.case?.id === caseId) return;
  clearCaseConversationRefresh();
  state.selectedCaseId = caseId;
  state.selectedConversationItemId = "";
  state.expandedExecutionGroups = {};
  renderRunBrowser(workspaceCases);
  loadCaseConversation(caseId);
}

function renderRunExplorer(workspaceCases) {
  if (!workspaceCases.some((caseItem) => caseItem.id === state.selectedCaseId)) {
    state.selectedCaseId = workspaceCases[0]?.id || "";
    state.selectedConversationItemId = "";
    state.caseConversation = null;
  }
  renderRunBrowser(workspaceCases);
  renderPager("run-page-actions", "casePage");
  if (!state.selectedCaseId) {
    document.getElementById("run-trace-summary").innerHTML = '<div><h3>暂无诊断会话</h3></div>';
    document.getElementById("run-trace-list").innerHTML = '<div class="trace-loading"><strong>等待诊断记录</strong></div>';
    renderTraceInspector();
    return;
  }
  if (state.caseConversation?.case?.id === state.selectedCaseId) renderRunTrace();
  else if (state.adminTab === "runs") loadCaseConversation(state.selectedCaseId);
  else {
    document.getElementById("run-trace-list").innerHTML = '<div class="trace-loading"><strong>打开诊断记录查看会话</strong><span>进入该页面后再按需读取所选 Case 的管理记录。</span></div>';
    renderTraceInspector();
  }
}

function renderOperations() {
  const overview = state.overview || {};
  const currentModels = latestProfileVersions();
  const readyModels = currentModels.filter(({ version }) => {
    const observed = modelProbeObservation(version || {});
    return version?.configuration?.status === "valid" &&
      version?.last_probe?.status === "passed" &&
      observed.tool_calling_observed;
  });
  const developmentWorkspace = isDevelopmentWorkspace();
  const userChannels = developmentWorkspace
    ? state.channels.filter((item) => item.channel_type === "api")
    : state.channels.filter((item) => !isInternalChannel(item));
  const readyChannels = developmentWorkspace
    ? userChannels.filter((item) => item.status === "active")
    : userChannels.filter((item) => item.status === "active" && item.readiness?.reply_ready === true);
  const workspaceCases = state.adminCases;
  const readyAgentCount = state.agents.filter((item) => item.status === "published").length;
  const agentHealthTotal = readyAgentCount || state.agents.length;
  const agentReady = readyAgentCount > 0;
  const coreReady = agentReady && readyModels.length > 0;
  const systemReady = overview.process?.status === "ready" && overview.database?.ready;
  document.getElementById("overview-summary").innerHTML =
    `<div class="metric-grid health-metrics">` +
      `<button class="metric-card health-card" type="button" data-health-tab="agents"><span class="health-dot ${agentReady ? "success" : "attention"}"></span><p class="metric-value">${readyAgentCount}/${agentHealthTotal}</p><p class="metric-label">Agent 可用</p><p class="metric-hint">${state.agents.length ? "查看运行设置" : "尚未添加"}</p></button>` +
      `<button class="metric-card health-card" type="button" data-health-tab="models"><span class="health-dot ${readyModels.length ? "success" : "attention"}"></span><p class="metric-value">${readyModels.length}/${currentModels.length}</p><p class="metric-label">模型可用</p><p class="metric-hint">实例共享资源</p></button>` +
      `<button class="metric-card health-card" type="button" data-health-tab="channels"><span class="health-dot ${readyChannels.length ? "success" : "attention"}"></span><p class="metric-value">${readyChannels.length}</p><p class="metric-label">频道可用</p><p class="metric-hint">${userChannels.length ? `已添加 ${userChannels.length}` : "尚未添加"}</p></button>` +
      `<button class="metric-card health-card" type="button" data-health-tab="system"><span class="health-dot ${systemReady ? "success" : "danger"}"></span><p class="metric-value metric-text">${systemReady ? "正常" : "异常"}</p><p class="metric-label">系统</p><p class="metric-hint">服务与数据库</p></button>` +
    `</div>`;
  document.querySelectorAll("[data-health-tab]").forEach((button) => {
    button.onclick = () => activateAdminTab(button.dataset.healthTab);
  });
  const focusRoot = document.getElementById("overview-focus");
  focusRoot.innerHTML = `
    <article class="scenario-card health-overview ${coreReady && readyChannels.length && systemReady ? "success" : "attention"}">
      <div class="scenario-card-head">
        <div><p class="scenario-kicker">当前状态</p><h3>${coreReady && readyChannels.length && systemReady ? "所有核心服务正常" : "有项目需要处理"}</h3></div>
        <span class="status-badge ${coreReady && readyChannels.length && systemReady ? "success" : "attention"}">${coreReady && readyChannels.length && systemReady ? "健康" : "注意"}</span>
      </div>
      <div class="health-issue-list">
        ${!coreReady ? '<button type="button" data-go-tab="agents"><span>Agent 或模型尚未就绪</span><strong>处理</strong></button>' : ""}
        ${!readyChannels.length ? '<button type="button" data-go-tab="channels"><span>没有可用频道</span><strong>添加频道</strong></button>' : ""}
        ${!systemReady ? '<button type="button" data-go-tab="system"><span>系统服务需要检查</span><strong>查看</strong></button>' : ""}
        ${coreReady && readyChannels.length && systemReady ? '<p class="health-all-clear">当前没有需要处理的问题。</p>' : ""}
      </div>
    </article>`;
  focusRoot.querySelectorAll("[data-go-tab]").forEach((button) => {
    button.onclick = () => activateAdminTab(button.dataset.goTab);
  });
  const overviewRoot = document.getElementById("overview-grid");
  overviewRoot.innerHTML = "";
  const recentFailures = overview.recent_failures || [];
  overviewRoot.innerHTML = recentFailures.length
    ? `<article class="resource-section compact-attention"><header class="resource-section-head"><div><h3>最近异常</h3><p>仅显示需要管理员关注的诊断。</p></div><button type="button" class="secondary" data-go-tab="runs">查看全部</button></header>${recentFailures.slice(0, 5).map((item) => `<div class="resource-row"><strong>${escapeHtml(item.id)}</strong><span>${escapeHtml(statusLabel(item.status))}</span><small>${escapeHtml(item.failure_class || "未分类")}</small></div>`).join("")}</article>`
    : "";
  overviewRoot.querySelectorAll("[data-go-tab]").forEach((button) => {
    button.onclick = () => activateAdminTab(button.dataset.goTab);
  });

  const caseRoot = document.getElementById("admin-case-list");
  caseRoot.innerHTML = "";
  workspaceCases.forEach((item) => {
    const card = document.createElement("article");
    card.className = "admin-card case-card resource-row";
    card.innerHTML = `
      <div class="admin-card-head"><div><h3 class="clamped-title" title="${escapeHtml(item.title || "未命名案件")}">${escapeHtml(conciseCaseTitle(item))}</h3><p class="mono">${escapeHtml(item.id)}</p></div><span class="status-badge ${item.lifecycle === "closed" ? "success" : "attention"}">${escapeHtml(statusLabel(item.lifecycle))}</span></div>
      <div class="admin-meta"><span class="pill">${escapeHtml(statusLabel(item.disposition))}</span><span class="pill">Agent ${escapeHtml(displayName(item.agent_id, item.agent_name))}</span><span class="pill">消息 ${item.message_count}</span><span class="pill">Runs ${item.run_count}</span><span class="pill">Evidence ${item.evidence_count}</span><span class="pill">复盘 ${item.review_count}</span></div>
      <p>最近活动 ${timeHtml(item.last_external_at || item.updated_at || item.created_at)}</p>`;
    caseRoot.appendChild(card);
  });
  if (!workspaceCases.length) {
    caseRoot.innerHTML = '<article class="manager-empty"><strong>当前还没有案件</strong><span>接入真实渠道或通过案件 API 创建后，案件摘要会出现在这里。</span></article>';
  }

  renderRunExplorer(workspaceCases);

  document.getElementById("job-summary").innerHTML =
    `<span class="pill">任务 ${state.jobPage.total}</span>` +
    `<span class="pill">需关注 ${state.jobs.filter((item) => item.status !== "completed").length}</span>` +
    `<span class="pill">发件箱 ${state.outboxPage.total}</span>` +
    `<span class="pill">结果未知 ${state.outbox.filter((item) => item.status === "outcome_unknown").length}</span>`;
  const jobRoot = document.getElementById("admin-job-list");
  jobRoot.innerHTML = "";
  const attentionJobs = state.jobs.filter((item) => item.status !== "completed");
  const completedJobs = state.jobs.filter((item) => item.status === "completed");
  const renderJobCard = (job) => {
    const card = document.createElement("article");
    card.className = "admin-card resource-row";
    card.innerHTML = `
      <div class="admin-card-head"><div><h3>${escapeHtml(technicalLabel(job.kind))}</h3><p class="mono">${escapeHtml(job.id)}</p></div><span class="pill">${escapeHtml(statusLabel(job.status))}</span></div>
      <div class="admin-meta"><span class="pill">尝试 ${job.attempts}</span><span class="pill">失败分类 ${escapeHtml(technicalLabel(job.failure_class || "none"))}</span></div>
      <p>计划时间 ${timeHtml(job.due_at)} · 完成时间 ${timeHtml(job.finished_at)}</p>`;
    return card;
  };
  const attentionJobGrid = document.createElement("div");
  attentionJobGrid.className = "admin-grid exception-grid";
  if (attentionJobs.length) {
    attentionJobs.forEach((job) => attentionJobGrid.appendChild(renderJobCard(job)));
  } else {
    attentionJobGrid.innerHTML = '<article class="manager-empty"><strong>当前没有需要处理的后台任务</strong><span>失败、积压或运行中的任务会优先出现在这里。</span></article>';
  }
  jobRoot.appendChild(attentionJobGrid);
  if (completedJobs.length) {
    const history = document.createElement("details");
    history.className = "advanced-management compact-history";
    history.innerHTML = `<summary>查看已完成任务（${completedJobs.length}）</summary><div class="advanced-content admin-grid"></div>`;
    const historyGrid = history.querySelector(".admin-grid");
    completedJobs.forEach((job) => historyGrid.appendChild(renderJobCard(job)));
    jobRoot.appendChild(history);
  }
  const jobOutbox = document.getElementById("admin-job-outbox-list");
  jobOutbox.innerHTML = "";
  const attentionDeliveries = state.outbox.filter((item) => ["outcome_unknown", "failed"].includes(item.status));
  const completedDeliveries = state.outbox.filter((item) => !["outcome_unknown", "failed"].includes(item.status));
  const renderDeliveryCard = (delivery) => {
    const card = document.createElement("article");
    card.className = "admin-card resource-row";
    card.innerHTML = `
      <div class="admin-card-head"><div><h3>${escapeHtml(delivery.channel)}</h3><p class="mono">${escapeHtml(delivery.id)}</p></div><span class="pill">${escapeHtml(statusLabel(delivery.status))}</span></div>
      <div class="admin-meta"><span class="pill">尝试 ${delivery.attempts}</span><span class="pill">结果 ${escapeHtml(statusLabel(delivery.outcome_state || "unknown"))}</span></div>
      <p>${delivery.last_error ? `错误：${escapeHtml(delivery.last_error)}` : "没有记录投递错误"}<br>完成 ${timeHtml(delivery.finished_at || delivery.sent_at)}</p>
      <p class="mono">payload sha256:${escapeHtml(delivery.payload_digest.slice(0, 16))}</p>`;
    return card;
  };
  const attentionDeliveryGrid = document.createElement("div");
  attentionDeliveryGrid.className = "admin-grid exception-grid";
  if (attentionDeliveries.length) {
    attentionDeliveries.forEach((delivery) => attentionDeliveryGrid.appendChild(renderDeliveryCard(delivery)));
  } else {
    attentionDeliveryGrid.innerHTML = '<article class="manager-empty"><strong>当前没有投递异常</strong><span>结果未知和失败投递会出现在这里，且不会从网页自动重试。</span></article>';
  }
  jobOutbox.appendChild(attentionDeliveryGrid);
  if (completedDeliveries.length) {
    const history = document.createElement("details");
    history.className = "advanced-management compact-history";
    history.innerHTML = `<summary>查看已完成投递（${completedDeliveries.length}）</summary><div class="advanced-content admin-grid"></div>`;
    const historyGrid = history.querySelector(".admin-grid");
    completedDeliveries.forEach((delivery) => historyGrid.appendChild(renderDeliveryCard(delivery)));
    jobOutbox.appendChild(history);
  }
  renderPager("case-page-actions", "casePage");
  renderPager("run-page-actions", "casePage");
  renderPager("job-page-actions", "jobPage");
  renderPager("job-outbox-page-actions", "outboxPage");

  const auditRoot = document.getElementById("admin-audit-list");
  const auditSummary = document.getElementById("audit-page-summary");
  const auditStart = state.auditPage.total ? state.auditPage.offset + 1 : 0;
  const auditEnd = Math.min(state.auditPage.offset + state.audit.length, state.auditPage.total);
  const pageFailures = state.audit.filter((event) => ["failed", "rejected"].includes(event.result)).length;
  auditSummary.innerHTML = `<span class="pill">共 ${state.auditPage.total} 条</span>` +
    `<span class="pill">当前 ${auditStart}-${auditEnd}</span>` +
    (pageFailures ? `<span class="status-badge danger">本页异常 ${pageFailures}</span>` : "");
  auditRoot.innerHTML = "";
  state.audit.forEach((event) => {
    const card = document.createElement("article");
    card.className = "audit-event";
    card.setAttribute("role", "listitem");
    const targetType = technicalLabel(event.target_type || "unknown");
    const targetId = String(event.target_id || "未记录");
    card.innerHTML = `
      <div class="audit-event-time">${timeHtml(event.created_at)}</div>
      <span class="audit-event-marker ${escapeHtml(auditResultClass(event.result))}" aria-hidden="true"></span>
      <div class="audit-event-body">
        <div class="audit-event-title"><h3>${escapeHtml(technicalLabel(event.action))}</h3><span class="status-badge ${escapeHtml(auditResultClass(event.result))}">${escapeHtml(technicalLabel(event.result))}</span></div>
        <dl class="audit-event-facts">
          <div><dt>对象</dt><dd><span>${escapeHtml(targetType)}</span><code>${escapeHtml(targetId)}</code></dd></div>
          <div><dt>操作者</dt><dd>${escapeHtml(technicalLabel(event.actor_type || "unknown"))}${event.actor_ref ? `<code>${escapeHtml(String(event.actor_ref))}</code>` : ""}</dd></div>
          <div><dt>授权入口</dt><dd>${escapeHtml(technicalLabel(event.authorization_source || "unknown"))}</dd></div>
          ${event.failure_class ? `<div><dt>失败原因</dt><dd>${escapeHtml(technicalLabel(event.failure_class))}</dd></div>` : ""}
        </dl>
        ${auditTechnicalDetails(event)}
      </div>`;
    auditRoot.appendChild(card);
  });
  if (!state.audit.length) {
    auditRoot.innerHTML = '<article class="manager-empty"><strong>没有符合条件的事件</strong><span>调整筛选范围，或等待新的管理变更产生记录。</span></article>';
  }
  const auditActions = document.getElementById("audit-page-actions");
  auditActions.innerHTML = "";
  const previous = document.createElement("button");
  previous.className = "secondary";
  previous.textContent = "上一页";
  previous.disabled = !state.auditPage.has_previous;
  previous.onclick = async () => {
    state.auditPage.offset = Math.max(0, state.auditPage.offset - state.auditPage.limit);
    await loadAdmin(false);
  };
  const next = document.createElement("button");
  next.className = "secondary";
  next.textContent = "下一页";
  next.disabled = !state.auditPage.has_next;
  next.onclick = async () => {
    state.auditPage.offset += state.auditPage.limit;
    await loadAdmin(false);
  };
  auditActions.append(previous, next);

  const backups = state.system?.backups?.items || [];
  const restorableBackups = backups.filter((item) => item.restorable);
  const latestBackup = backups[0];
  document.getElementById("system-summary").innerHTML =
    `<span class="status-badge ${state.system?.database?.quick_check === "ok" ? "success" : "attention"}">数据库 ${escapeHtml(statusLabel(state.system?.database?.quick_check || "-"))}</span>` +
    `<span class="status-badge ${state.system?.scheduler?.running ? "success" : "attention"}">调度器 ${state.system?.scheduler?.running ? "运行中" : "已停止"}</span>` +
    `<span class="status-badge ${state.system?.process_manager?.status === "running" ? "success" : "attention"}">服务 ${escapeHtml(statusLabel(state.system?.process_manager?.status || "未知"))}</span>`;
  const systemRoot = document.getElementById("system-admin-list");
  systemRoot.innerHTML = `
    <article class="admin-card">
      <div class="admin-card-head"><h3>服务</h3><span class="status-badge ${state.system?.process_manager?.status === "running" ? "success" : "attention"}">${escapeHtml(statusLabel(state.system?.process_manager?.status || "未知"))}</span></div>
      <p>运行模式：${escapeHtml(state.system?.runtime_mode || "-")}</p>
      <p>调度器：${state.system?.scheduler?.running ? "运行中" : "已停止"}</p>
    </article>
    <article class="admin-card">
      <div class="admin-card-head"><h3>数据</h3><span class="status-badge ${state.system?.database?.quick_check === "ok" ? "success" : "attention"}">${escapeHtml(statusLabel(state.system?.database?.quick_check || "未知"))}</span></div>
      <p>数据库大小：${Number(state.system?.storage?.database_bytes || 0).toLocaleString("zh-CN")} 字节</p>
      <p>结构版本：${state.system?.database?.schema_version ?? "-"}</p>
    </article>
    <article class="admin-card">
      <div class="admin-card-head"><h3>备份</h3><span class="pill">${restorableBackups.length} 份可恢复</span></div>
      <p>${latestBackup ? `最近备份：${timeHtml(latestBackup.created_at)}` : "尚未创建备份。"}</p>
      <p>自动备份：${state.system?.backups?.automatic_backup_configured ? "已配置" : "未配置"}</p>
    </article>`;
  const backupButton = document.getElementById("system-create-backup");
  backupButton.onclick = async () => {
    if (!confirm("确认创建一次本地受管备份？备份不包含 Secret 值，不会停止服务或执行恢复。")) return;
    backupButton.disabled = true;
    try {
      const backup = await api("/api/v1/admin/backups", { method: "POST" });
      setAdminNotice(`本地备份已创建：${backup.id}`, "admin-success");
      await loadAdmin(false);
    } catch (error) {
      setAdminNotice(`本地备份失败：${error.message}`, "admin-error");
    } finally {
      backupButton.disabled = false;
    }
  };
  const latestValidation = state.system?.recent_validations?.[0];
  const runtimeMode = state.system?.runtime_mode === "production" ? "正式实例" : "开发实例";
  const systemFacts = [
    ["运行模式", runtimeMode],
    ["数据库结构", `v${state.system?.database?.schema_version ?? "-"}（期望 v${state.system?.database?.expected_schema_version ?? "-"}）`],
    ["外键检查", Number(state.system?.database?.foreign_key_violations || 0) === 0 ? "没有发现冲突" : `${state.system.database.foreign_key_violations} 项冲突`],
    ["配置项", `${state.system?.settings_metadata?.length || 0} 项受管设置`],
    ["最近配置校验", latestValidation ? `${statusLabel(latestValidation.status)} · ${formatTime(latestValidation.finished_at || latestValidation.created_at)}` : "尚无校验记录"],
    ["管理页面", state.system?.management_web?.asset_digest ? "资源已加载" : "资源状态未知"],
  ];
  document.getElementById("system-detail").innerHTML = systemFacts.map(([label, value]) =>
    `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`
  ).join("");
}

function renderPager(rootId, pageKey) {
  const root = document.getElementById(rootId);
  if (!root) return;
  const page = state[pageKey];
  const start = page.total ? page.offset + 1 : 0;
  const end = Math.min(page.offset + page.limit, page.total);
  root.innerHTML = `<span class="pill">共 ${page.total} 条 · 当前 ${start}-${end}</span>`;
  if (!page.has_previous && !page.has_next) return;
  const previous = document.createElement("button");
  previous.className = "secondary";
  previous.textContent = "上一页";
  previous.disabled = !page.has_previous;
  previous.onclick = async () => {
    page.offset = Math.max(0, page.offset - page.limit);
    await loadAdmin(false);
  };
  const next = document.createElement("button");
  next.className = "secondary";
  next.textContent = "下一页";
  next.disabled = !page.has_next;
  next.onclick = async () => {
    page.offset += page.limit;
    await loadAdmin(false);
  };
  root.append(previous, next);
}

async function loadAdmin() {
  const auditParams = new URLSearchParams({
    limit: String(state.auditPage.limit || 20),
    offset: String(state.auditPage.offset || 0),
  });
  Object.entries(state.auditFilters).forEach(([key, value]) => {
    if (value) auditParams.set(key, value);
  });
  const reviewParams = new URLSearchParams({
    limit: String(state.reviewPage.limit || 50),
    offset: String(state.reviewPage.offset || 0),
  });
  Object.entries(state.reviewFilters).forEach(([key, value]) => {
    if (value) reviewParams.set(key, value);
  });
  const pageQuery = (page) => new URLSearchParams({
    limit: String(page.limit || 50),
    offset: String(page.offset || 0),
  }).toString();
  const caseParams = new URLSearchParams({
    limit: String(state.casePage.limit || 50),
    offset: String(state.casePage.offset || 0),
  });
  const [
    session,
    agents,
    agentOptions,
    personas,
    agentProfiles,
    nativeReleases,
    domainExperts,
    profiles,
    providers,
    modelOptions,
    secrets,
    packs,
    prompts,
    deliveryPreflight,
    toolProviders,
    tools,
    channels,
    outbox,
    reviewEngines,
    reviews,
    researchDigests,
    candidateAttempts,
    overview,
    adminCases,
    jobs,
    audit,
    system,
  ] = await Promise.all([
    api("/api/v1/admin/session"),
    api("/api/v1/admin/agents?limit=500&offset=0"),
    api("/api/v1/admin/agent-options"),
    api("/api/v1/admin/personas"),
    api("/api/v1/admin/agent-profiles"),
    api("/api/v1/admin/native-releases"),
    api("/api/v1/admin/domain-experts"),
    api("/api/v1/admin/model-profiles?limit=500&offset=0"),
    api("/api/v1/admin/model-providers?limit=500&offset=0"),
    api("/api/v1/admin/model-options"),
    api("/api/v1/admin/secret-refs"),
    api("/api/v1/admin/capability-packs"),
    api("/api/v1/admin/prompt-bundles"),
    api("/api/v1/admin/delivery-preflight"),
    api("/api/v1/admin/tool-providers"),
    api("/api/v1/admin/tools"),
    api("/api/v1/admin/channel-instances"),
    api(`/api/v1/admin/outbox?${pageQuery(state.outboxPage)}`),
    api("/api/v1/admin/review-engine-profiles"),
    api(`/api/v1/reviews?${reviewParams.toString()}`),
    api(`/api/v1/research/digests?${pageQuery(state.researchPage)}`),
    api(`/api/v1/admin/candidate-attempts?${pageQuery(state.candidatePage)}`),
    api("/api/v1/admin/overview"),
    api(`/api/v1/admin/cases?${caseParams.toString()}`),
    api(`/api/v1/admin/jobs?${pageQuery(state.jobPage)}`),
    api(`/api/v1/admin/audit?${auditParams.toString()}`),
    api("/api/v1/admin/system"),
  ]);
  state.session = session;
  state.agents = agents.items;
  state.agentPage = agents.page;
  state.agentCatalog = agentOptions.items;
  state.personas = personas.items;
  resolveActiveAgent();
  const [agentUsage, agentChannels] = state.activeAgentId
    ? await Promise.all([
        api(`/api/v1/admin/agents/${state.activeAgentId}/usage?days=14`),
        api(`/api/v1/admin/channel-instances?agent_id=${encodeURIComponent(state.activeAgentId)}`),
      ])
    : [null, { items: [] }];
  state.agentUsage = agentUsage;
  state.agentChannels = agentChannels.items;
  state.agentProfiles = agentProfiles.items;
  state.nativeReleases = nativeReleases;
  state.domainExperts = domainExperts.items;
  state.profiles = profiles.items;
  state.profilePage = profiles.page;
  state.providers = providers.items;
  state.providerPage = providers.page;
  state.profileCatalog = modelOptions.profiles;
  state.providerCatalog = modelOptions.providers;
  state.secrets = secrets.items;
  state.packs = packs.items;
  state.packDiscoveries = packs.discoveries || [];
  state.prompts = prompts.items;
  state.deliveryPreflight = deliveryPreflight;
  state.nativeReadiness = deliveryPreflight.native_readiness;
  state.toolProviders = toolProviders.items;
  state.tools = tools.items;
  state.channels = channels.items;
  state.outbox = outbox.items;
  state.outboxPage = outbox.page;
  state.reviewEngines = reviewEngines.items;
  state.reviews = reviews.items;
  state.reviewPage = reviews.page;
  state.researchDigests = researchDigests.items;
  state.researchPage = researchDigests.page;
  state.candidatePreflight = deliveryPreflight.candidate_preflight;
  state.candidateAttempts = candidateAttempts.items;
  state.candidatePage = candidateAttempts.page;
  state.overview = overview;
  state.adminCases = adminCases.items;
  state.casePage = adminCases.page;
  if (state.adminTab === "runs") state.caseConversation = null;
  state.jobs = jobs.items;
  state.jobPage = jobs.page;
  state.audit = audit.items;
  state.auditPage = audit.page;
  document.getElementById("audit-action-options").innerHTML = Array.from(
    new Set(state.audit.map((event) => event.action))
  ).sort().map((action) => `<option value="${escapeHtml(action)}"></option>`).join("");
  state.system = system;
  const loadedAt = new Date().toISOString();
  const freshness = document.getElementById("admin-data-freshness");
  freshness.textContent = `更新于 ${formatTime(loadedAt).slice(11, 16)}`;
  freshness.title = `本页数据更新时间：${formatTime(loadedAt, true)}`;
  applyRoleVisibility();
  fillModelSelect(document.getElementById("agent-create-model"));
  fillPersonaSelect(document.getElementById("agent-create-persona"));
  const createProfileSelect = document.getElementById("agent-create-profile");
  fillAgentProfileSelect(createProfileSelect);
  createProfileSelect.onchange = applyAgentCreateAssembly;
  fillPromptSelect(document.getElementById("agent-create-prompt"));
  const createPackSelect = document.getElementById("agent-create-packs");
  const defaultGenericPack = state.packs
    .find((pack) => pack.id === "generic" && pack.status === "installed")
    ?.versions[0];
  fillPackSelect(createPackSelect, defaultGenericPack ? [defaultGenericPack.id] : []);
  const createToolSelect = document.getElementById("agent-create-tools");
  fillToolSelect(
    createToolSelect,
    Array.from(createPackSelect.selectedOptions).map((item) => item.value)
  );
  createPackSelect.onchange = () => {
    const selected = Array.from(createToolSelect.selectedOptions).map((item) => item.value);
    fillToolSelect(
      createToolSelect,
      Array.from(createPackSelect.selectedOptions).map((item) => item.value),
      selected
    );
  };
  applyAgentCreateAssembly();
  fillReviewFilterSelects();
  renderAgentContext();
  renderAgents();
  renderModels();
  renderCapabilities();
  renderToolsAndConnectors();
  renderChannels();
  renderReviewsResearch();
  renderOperations();
  renderActiveSectionActions();
}

function escapeHtml(value) {
  const div = document.createElement("div");
  div.textContent = value;
  return div.innerHTML;
}

document.getElementById("refresh-admin").onclick = (event) => runBusy(event.currentTarget, "刷新中…", async () => {
  try {
    await Promise.all([loadHealth(), loadAdmin()]);
    setAdminNotice("数据已更新。", "admin-success");
  } catch (error) {
    setAdminNotice(`刷新失败：${error.message}`, "admin-error");
  }
});
document.getElementById("audit-filter-form").onsubmit = async (event) => {
  event.preventDefault();
  const toIso = (value) => value ? new Date(value).toISOString() : "";
  state.auditFilters = {
    actor_ref: document.getElementById("audit-filter-actor").value.trim(),
    target_type: document.getElementById("audit-filter-target").value.trim(),
    action: document.getElementById("audit-filter-action").value.trim(),
    result: document.getElementById("audit-filter-result").value,
    created_from: toIso(document.getElementById("audit-filter-from").value),
    created_to: toIso(document.getElementById("audit-filter-to").value),
  };
  state.auditPage.offset = 0;
  try {
    await loadAdmin(false);
    setAdminNotice("审计筛选已应用。", "admin-success");
  } catch (error) {
    setAdminNotice(`审计筛选失败：${error.message}`, "admin-error");
  }
};
document.getElementById("audit-filter-clear").onclick = async () => {
  state.auditFilters = { actor_ref: "", target_type: "", action: "", result: "", created_from: "", created_to: "" };
  state.auditPage.offset = 0;
  document.getElementById("audit-filter-form").reset();
  try {
    await loadAdmin(false);
    setAdminNotice("审计筛选已清除。", "admin-success");
  } catch (error) {
    setAdminNotice(`审计筛选清除失败：${error.message}`, "admin-error");
  }
};
document.getElementById("review-filter-form").onsubmit = async (event) => {
  event.preventDefault();
  const toIso = (value) => value ? new Date(value).toISOString() : "";
  state.reviewFilters = {
    agent_id: document.getElementById("review-filter-agent").value,
    status: document.getElementById("review-filter-status").value,
    model_profile_version_id: document.getElementById("review-filter-model").value,
    capability_gap: document.getElementById("review-filter-gap").value,
    created_from: toIso(document.getElementById("review-filter-from").value),
    created_to: toIso(document.getElementById("review-filter-to").value),
  };
  state.reviewPage.offset = 0;
  try {
    await loadAdmin(false);
    setAdminNotice(`复盘筛选已应用：共 ${state.reviewPage.total} 条。`, "admin-success");
  } catch (error) {
    setAdminNotice(`复盘筛选失败：${error.message}`, "admin-error");
  }
};
document.getElementById("review-filter-clear").onclick = async () => {
  state.reviewFilters = {
    status: "",
    agent_id: "",
    model_profile_version_id: "",
    capability_gap: "",
    created_from: "",
    created_to: "",
  };
  state.reviewPage.offset = 0;
  document.getElementById("review-filter-form").reset();
  try {
    await loadAdmin(false);
    setAdminNotice("复盘筛选已清除。", "admin-success");
  } catch (error) {
    setAdminNotice(`复盘筛选清除失败：${error.message}`, "admin-error");
  }
};
function activateAdminTab(tab, updateHash = true) {
  const closedTab = ["jobs", "reviews"].includes(tab);
  if (closedTab) tab = "system";
  if (tab === "capabilities") tab = "tools";
  if (!ADMIN_TAB_META[tab]) tab = "overview";
  const tabChanged = state.adminTab !== tab;
  if (tabChanged) {
    closeManagementDrawer();
    clearAdminNotice();
    if (tab !== "runs") clearCaseConversationRefresh();
  }
  state.adminTab = tab;
  document.querySelectorAll(".admin-section").forEach((section) =>
    section.classList.toggle("hidden", section.id !== `admin-${tab}`)
  );
  document.getElementById("system-subnav")?.classList.toggle(
    "hidden",
    !["system", "audit"].includes(tab)
  );
  document.querySelectorAll("[data-admin-tab]").forEach((item) => {
    const active = item.dataset.adminTab === tab;
    item.classList.toggle("secondary", !active);
    item.setAttribute("aria-current", active ? "page" : "false");
  });
  const [label, heading, defaultDescription, category] = ADMIN_TAB_META[tab];
  const description = defaultDescription;
  document.getElementById("active-section-title").textContent = label;
  document.getElementById("active-section-eyebrow").textContent = category;
  document.getElementById("active-section-heading").textContent = heading;
  const descriptionRoot = document.getElementById("active-section-description");
  descriptionRoot.textContent = description;
  descriptionRoot.classList.toggle("hidden", !description);
  const staticReference = tab === "glossary";
  document.querySelector("#admin-view > .case-header")?.classList.toggle("hidden", staticReference);
  document.getElementById("admin-data-freshness").classList.toggle("hidden", staticReference);
  document.getElementById("refresh-admin").classList.toggle("hidden", staticReference);
  updateActiveAgentChrome();
  const agent = activeAgent();
  document.title = agent && AGENT_SCOPED_TABS.has(tab)
    ? `${label} · ${displayName(agent.id, agent.name)} · 素问管理台`
    : `${label} · 素问管理台`;
  renderActiveSectionActions();
  if (tabChanged) {
    const workspace = document.querySelector(".management-workspace");
    if (workspace) workspace.scrollTop = 0;
  }
  if (tab === "runs" && state.selectedCaseId && state.caseConversation?.case?.id !== state.selectedCaseId) {
    loadCaseConversation(state.selectedCaseId);
  }
  if (tab === "glossary") void loadGlossary();
  if ((updateHash || closedTab) && location.hash !== `#${tab}`) history.replaceState(null, "", `#${tab}`);
}

async function loadGlossary() {
  if (state.glossaryLoaded) return;
  const root = document.getElementById("glossary-content");
  try {
    const response = await fetch("/assets/investigation-concepts-and-glossary.md", {
      credentials: "same-origin",
      headers: { Accept: "text/markdown" },
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const markdown = await response.text();
    if (typeof window.renderMarkdownPreview !== "function") {
      throw new Error("Markdown 预览组件未加载");
    }
    window.renderMarkdownPreview(root, markdown);
    state.glossaryLoaded = true;
  } catch (error) {
    root.replaceChildren();
    const message = document.createElement("p");
    message.className = "admin-error markdown-loading";
    message.textContent = `词汇表加载失败：${error.message}`;
    root.append(message);
  }
}

function renderActiveSectionActions() {
  const root = document.getElementById("active-section-actions");
  if (!root) return;
  root.innerHTML = "";
  if (state.adminTab === "models") {
    const search = document.createElement("input");
    search.type = "search";
    search.className = "model-provider-search";
    search.placeholder = "搜索提供商…";
    search.setAttribute("aria-label", "搜索提供商");
    search.value = state.modelProviderQuery;
    search.oninput = () => {
      state.modelProviderQuery = search.value;
      renderModels();
    };
    const add = document.createElement("button");
    add.type = "button";
    add.textContent = "添加提供商";
    add.classList.toggle("hidden", !can("administer"));
    add.setAttribute("aria-controls", "model-modal");
    add.onclick = (event) => openProviderSettings(null, event.currentTarget);
    root.append(search, add);
    return;
  }
  Object.entries(MANAGEMENT_FORM_ACTIONS)
    .filter(([, config]) => config.section === state.adminTab && !config.actionRoot)
    .forEach(([formId, config], index) => {
      if (formId === "channel-create-form" && isDevelopmentWorkspace()) return;
      const form = document.getElementById(formId);
      if (!form) return;
      const button = document.createElement("button");
      button.type = "button";
      const existingFeishu = formId === "channel-create-form"
        ? currentAgentChannel()
        : null;
      button.textContent = existingFeishu ? "飞书设置" : config.label;
      button.className = config.secondary || index > 0 ? "secondary" : "";
      button.dataset.permission = form.dataset.permission;
      button.setAttribute("aria-controls", "management-drawer");
      button.classList.toggle("hidden", !can(form.dataset.permission));
      button.onclick = () => {
        if (formId === "channel-create-form") {
          const channel = currentAgentChannel();
          prepareFeishuChannelForm(channel || null);
        }
        openManagementDrawer(formId, button);
      };
      root.appendChild(button);
    });
}

function renderAdvancedFormActions() {
  const actionRoots = new Set(
    Object.values(MANAGEMENT_FORM_ACTIONS)
      .map((config) => config.actionRoot)
      .filter(Boolean)
  );
  actionRoots.forEach((rootId) => {
    const root = document.getElementById(rootId);
    if (root) root.innerHTML = "";
  });
  Object.entries(MANAGEMENT_FORM_ACTIONS)
    .filter(([, config]) => config.actionRoot)
    .forEach(([formId, config]) => {
      const root = document.getElementById(config.actionRoot);
      const form = document.getElementById(formId);
      if (!root || !form) return;
      const button = document.createElement("button");
      button.type = "button";
      button.className = "secondary";
      button.textContent = config.label;
      button.dataset.permission = form.dataset.permission;
      button.classList.toggle("hidden", !can(form.dataset.permission));
      button.onclick = () => openManagementDrawer(formId, button);
      root.appendChild(button);
    });
}

function closeManagementDrawer() {
  const drawer = document.getElementById("management-drawer");
  const backdrop = document.getElementById("management-drawer-backdrop");
  const body = document.getElementById("management-drawer-body");
  const store = document.getElementById("management-form-store");
  if (!drawer || !backdrop || !body || !store) return;
  const current = body.querySelector(".admin-form");
  if (current) {
    current.querySelector("h3")?.classList.remove("sr-only");
    store.appendChild(current);
  }
  if (drawerContentNode && drawerContentOrigin) {
    drawerContentOrigin.before(drawerContentNode);
    drawerContentOrigin.remove();
  }
  body.replaceChildren();
  drawer.classList.remove("open", "tool-detail-mode", "agent-settings-mode");
  drawer.setAttribute("aria-hidden", "true");
  backdrop.classList.add("hidden");
  document.body.classList.remove("drawer-open");
  activeDrawerFormId = "";
  drawerContentNode = null;
  drawerContentOrigin = null;
  if (drawerReturnFocus?.isConnected) drawerReturnFocus.focus();
  drawerReturnFocus = null;
}

function openContentDrawer(node, title, trigger, eyebrow = "管理配置") {
  const drawer = document.getElementById("management-drawer");
  const backdrop = document.getElementById("management-drawer-backdrop");
  const body = document.getElementById("management-drawer-body");
  if (!node || !drawer || !backdrop || !body) return;
  if (activeDrawerFormId || drawerContentNode) closeManagementDrawer();
  drawerReturnFocus = trigger || document.activeElement;
  drawerContentOrigin = document.createComment("drawer-content-origin");
  node.before(drawerContentOrigin);
  drawerContentNode = node;
  document.getElementById("management-drawer-eyebrow").textContent = eyebrow;
  document.getElementById("management-drawer-title").textContent = title;
  body.appendChild(node);
  backdrop.classList.remove("hidden");
  drawer.classList.add("open", "agent-settings-mode");
  drawer.setAttribute("aria-hidden", "false");
  document.body.classList.add("drawer-open");
  requestAnimationFrame(() => node.querySelector("input, select, textarea, button")?.focus());
}

function openManagementDrawer(formId, trigger) {
  const config = MANAGEMENT_FORM_ACTIONS[formId];
  const form = document.getElementById(formId);
  const drawer = document.getElementById("management-drawer");
  const backdrop = document.getElementById("management-drawer-backdrop");
  const body = document.getElementById("management-drawer-body");
  if (!config || !form || !drawer || !backdrop || !body) return;
  if ((activeDrawerFormId && activeDrawerFormId !== formId) || drawerContentNode) closeManagementDrawer();
  drawerReturnFocus = trigger || document.activeElement;
  document.getElementById("management-drawer-eyebrow").textContent = "管理配置";
  body.appendChild(form);
  const heading = form.querySelector("h3");
  document.getElementById("management-drawer-title").textContent = heading?.textContent || config.label;
  heading?.classList.add("sr-only");
  activeDrawerFormId = formId;
  backdrop.classList.remove("hidden");
  drawer.classList.add("open");
  drawer.setAttribute("aria-hidden", "false");
  document.body.classList.add("drawer-open");
  requestAnimationFrame(() => form.querySelector("input, select, textarea, button")?.focus());
}

function prepareManagementDrawers() {
  const store = document.getElementById("management-form-store");
  if (!store) return;
  Object.keys(MANAGEMENT_FORM_ACTIONS).forEach((formId) => {
    const form = document.getElementById(formId);
    if (form) store.appendChild(form);
  });
  document.getElementById("management-drawer-close").onclick = closeManagementDrawer;
  document.getElementById("management-drawer-backdrop").onclick = closeManagementDrawer;
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && activeDrawerFormId) closeManagementDrawer();
    if (event.key === "Tab" && activeDrawerFormId) {
      const drawer = document.getElementById("management-drawer");
      const focusable = Array.from(drawer.querySelectorAll(
        'button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])'
      )).filter((element) => element.offsetParent !== null);
      const first = focusable[0];
      const last = focusable.at(-1);
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first?.focus();
      }
    }
    if (event.key === "Escape") {
      const agentMenu = document.getElementById("agent-context-menu");
      const agentTrigger = document.getElementById("agent-context-trigger");
      if (agentMenu && !agentMenu.classList.contains("hidden")) {
        agentMenu.classList.add("hidden");
        agentTrigger?.setAttribute("aria-expanded", "false");
        agentTrigger?.focus();
      }
    }
  });
  document.addEventListener("click", (event) => {
    const context = document.querySelector(".agent-context");
    if (!context?.contains(event.target)) {
      document.getElementById("agent-context-menu")?.classList.add("hidden");
      document.getElementById("agent-context-trigger")?.setAttribute("aria-expanded", "false");
    }
  });
  renderActiveSectionActions();
  renderAdvancedFormActions();
}

function prepareModelModal() {
  const backdrop = document.getElementById("model-modal-backdrop");
  const modal = document.getElementById("model-modal");
  document.getElementById("model-modal-close").onclick = closeModelModal;
  backdrop.onclick = (event) => {
    if (event.target === backdrop) closeModelModal();
  };
  document.addEventListener("keydown", (event) => {
    if (backdrop.classList.contains("hidden")) return;
    if (event.key === "Escape") {
      event.preventDefault();
      closeModelModal();
      return;
    }
    if (event.key !== "Tab") return;
    const focusable = Array.from(modal.querySelectorAll(
      'button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])'
    )).filter((element) => element.offsetParent !== null);
    const first = focusable[0];
    const last = focusable.at(-1);
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last?.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first?.focus();
    }
  });
}

document.querySelectorAll("[data-admin-tab]").forEach((button) => {
  button.onclick = () => activateAdminTab(button.dataset.adminTab);
});
document.getElementById("agent-create-form").onsubmit = async (event) => {
  event.preventDefault();
  const id = document.getElementById("agent-create-id").value.trim();
  const name = document.getElementById("agent-create-name").value.trim();
  const profile = selectedAgentProfile();
  const modelProfileId = document.getElementById("agent-create-model").value;
  const personaId = document.getElementById("agent-create-persona").value;
  const promptBundleVersionId = document.getElementById("agent-create-prompt").value;
  const packVersionIds = Array.from(document.getElementById("agent-create-packs").selectedOptions)
    .map((item) => item.value);
  const toolAllowlist = Array.from(document.getElementById("agent-create-tools").selectedOptions)
    .map((item) => item.value);
  try {
    const payload = {
      id,
      name,
      model_profile_id: modelProfileId,
      persona_id: personaId,
    };
    if (profile) {
      payload.agent_profile = {
        id: profile.id,
        version: profile.version,
        digest: profile.digest,
      };
    } else {
      payload.prompt_bundle_version_id = promptBundleVersionId;
      payload.pack_version_ids = packVersionIds;
      payload.capability_bindings = capabilityBindingsForSelectedTools(toolAllowlist);
      payload.config = {
        schema: "suwen.agent-config.v1",
        tool_allowlist: toolAllowlist,
        connector_bindings: connectorBindingsForSelectedTools(toolAllowlist),
      };
    }
    await api("/api/v1/admin/agents", {
      method: "POST",
      body: JSON.stringify(payload),
    });
    await api(`/api/v1/admin/agents/${id}/publish`, {
      method: "POST",
      body: JSON.stringify({ note: "从新建智能体表单启用" }),
    });
    event.target.reset();
    setAdminNotice(`${name} 已创建并启用。`, "admin-success");
    await loadAdmin(false);
  } catch (error) {
    setAdminNotice(`创建失败：${error.message}`, "admin-error");
  }
};
document.getElementById("prompt-create-form").onsubmit = async (event) => {
  event.preventDefault();
  const id = document.getElementById("prompt-create-id").value.trim();
  const name = document.getElementById("prompt-create-name").value.trim();
  const systemPrompt = document.getElementById("prompt-create-system").value.trim();
  try {
    await api("/api/v1/admin/prompt-bundles", {
      method: "POST",
      body: JSON.stringify({
        id,
        name,
        description: document.getElementById("prompt-create-description").value.trim(),
        content: {
          system_prompt: systemPrompt,
          soul: document.getElementById("prompt-create-soul").value.trim(),
          rules: promptLines(document.getElementById("prompt-create-rules").value),
          output_rules: promptLines(document.getElementById("prompt-create-output-rules").value),
        },
        source_ref: "admin:web",
      }),
    });
    event.target.reset();
    setAdminNotice(`${name} 提示词草稿已创建。`, "admin-success");
    await loadAdmin(false);
  } catch (error) {
    setAdminNotice(`提示词创建失败：${error.message}`, "admin-error");
  }
};
document.getElementById("tool-provider-create-form").onsubmit = async (event) => {
  event.preventDefault();
  const id = document.getElementById("tool-provider-create-id").value.trim();
  const name = document.getElementById("tool-provider-create-name").value.trim();
  try {
    await api("/api/v1/admin/tool-providers", {
      method: "POST",
      body: JSON.stringify({
        id,
        name,
        provider_type: document.getElementById("tool-provider-create-type").value,
        connection_ref: "",
        secret_ref_id: null,
      }),
    });
    event.target.reset();
    closeManagementDrawer();
    setAdminNotice(`${name} 连接器已添加，可继续配置连接。`, "admin-success");
    await loadAdmin(false);
  } catch (error) {
    setAdminNotice(`连接器添加失败：${error.message}`, "admin-error");
  }
};
function generatedFeishuChannelId(appId) {
  const normalized = appId.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  return `feishu-${normalized || "app"}`.slice(0, 64);
}

document.getElementById("channel-create-form").onsubmit = async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const instanceId = form.dataset.instanceId || "";
  const appId = document.getElementById("channel-create-app-id").value.trim();
  const id = instanceId || generatedFeishuChannelId(appId);
  const name = document.getElementById("channel-create-name").value.trim();
  const enabled = document.getElementById("channel-create-enabled").checked;
  const domain = document.getElementById("channel-create-domain").value;
  const selectedAgentId = activeAgent()?.id || "";
  const selectedAgent = state.agents.find((item) => item.id === selectedAgentId);
  const current = state.agentChannels.find((item) => item.id === instanceId);
  try {
    const result = await api(`/api/v1/admin/channel-instances/${id}/feishu-configuration`, {
      method: "PUT",
      body: JSON.stringify({
        name,
        agent_id: selectedAgentId,
        enabled,
        domain,
        app_id: appId,
        app_secret: document.getElementById("channel-create-app-secret").value || null,
        encrypt_key: document.getElementById("channel-create-encrypt-value").value || null,
        verification_token: document.getElementById("channel-create-verification-value").value || null,
        require_mention_in_group: current?.config.require_mention_in_group !== false,
        allowed_actor_refs: current?.config.allowed_actor_refs || "",
        allowed_chat_refs: current?.config.allowed_chat_refs || "",
      }),
    });
    if (result.status === "ready") {
      setAdminNotice(`飞书已连接；新消息将交给${displayName(selectedAgentId, selectedAgent?.name || selectedAgentId)}处理并直接回复。`, "admin-success");
    } else {
      setAdminNotice("飞书配置已保存且应用身份验证通过；渠道当前未启用。", "admin-success");
    }
    form.reset();
    form.dataset.instanceId = "";
    closeManagementDrawer();
    await loadAdmin(false);
  } catch (error) {
    setAdminNotice(`飞书配置失败：${error.message}`, "admin-error");
  }
};

document.getElementById("channel-access-form").onsubmit = async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const id = form.dataset.instanceId;
  const current = state.agentChannels.find((item) => item.id === id);
  if (!current) {
    setAdminNotice("未找到要配置的飞书渠道。", "admin-error");
    return;
  }
  const wasActive = current.status === "active";
  const boundAgentId = (current.agent_bindings || []).find((binding) => binding.active)?.agent_id
    || activeAgent()?.id
    || "";
  try {
    await api(`/api/v1/admin/channel-instances/${id}/feishu-configuration`, {
      method: "PUT",
      body: JSON.stringify({
        name: current.name,
        agent_id: boundAgentId,
        enabled: wasActive,
        domain: current.config.domain || "feishu",
        app_id: current.config.external_instance_ref,
        app_secret: null,
        verification_token: null,
        encrypt_key: null,
        require_mention_in_group: document.getElementById("channel-access-require-mention").checked,
        allowed_actor_refs: document.getElementById("channel-access-actors").value.trim(),
        allowed_chat_refs: document.getElementById("channel-access-chats").value.trim(),
      }),
    });
    closeManagementDrawer();
    setAdminNotice(
      wasActive ? "访问控制已保存，飞书渠道保持可用。" : "访问控制已保存；在飞书设置中开启渠道即可启动。",
      "admin-success",
    );
    await loadAdmin(false);
  } catch (error) {
    setAdminNotice(`访问控制保存失败：${error.message}`, "admin-error");
  }
};
document.getElementById("review-engine-version-form").onsubmit = async (event) => {
  event.preventDefault();
  const profile = state.reviewEngines[0];
  if (!profile) return;
  try {
    await api(`/api/v1/admin/review-engine-profiles/${profile.id}/versions`, {
      method: "POST",
      body: JSON.stringify({
        config: {
          rules: {
            evidence_gap: document.getElementById("review-rule-evidence-gap").checked,
            run_reliability: document.getElementById("review-rule-run-reliability").checked,
            unresolved_case: document.getElementById("review-rule-unresolved-case").checked,
            reply_persistence_gap: document.getElementById("review-rule-reply-gap").checked,
            evidence_boundary: document.getElementById("review-rule-evidence-boundary").checked,
            action_uncertainty: document.getElementById("review-rule-action-uncertainty").checked,
            evidence_provider_candidate: document.getElementById("review-rule-evidence-candidate").checked,
            runtime_reliability_candidate: document.getElementById("review-rule-runtime-candidate").checked,
            source_coverage_candidate: document.getElementById("review-rule-coverage-candidate").checked,
          },
        },
      }),
    });
    setAdminNotice("复盘引擎草稿版本已创建；启用前不影响新复盘。", "admin-success");
    await loadAdmin(false);
  } catch (error) {
    setAdminNotice(`引擎版本创建失败：${error.message}`, "admin-error");
  }
};
document.getElementById("research-generate-form").onsubmit = async (event) => {
  event.preventDefault();
  const agentId = document.getElementById("research-agent").value;
  if (!agentId) return;
  try {
    await api("/api/v1/research/digests", {
      method: "POST",
      body: JSON.stringify({ agent_id: agentId }),
    });
    setAdminNotice("研究摘要已生成；只含结构化复盘引用，未改变智能体。", "admin-success");
    await loadAdmin(false);
  } catch (error) {
    setAdminNotice(`研究摘要生成失败：${error.message}`, "admin-error");
  }
};
async function ensureManagementSession() {
  try {
    await api("/api/v1/admin/session");
    return true;
  } catch (error) {
    if (error.status !== 401) throw error;
  }
  document.getElementById("management-role").textContent = "未登录";
  const authenticated = await requestManagementLogin();
  if (!authenticated) {
    setAdminNotice("尚未登录；刷新或重新打开页面可再次登录。", "admin-error");
    return false;
  }
  return true;
}

function requestManagementLogin() {
  const backdrop = document.getElementById("management-login-backdrop");
  const modal = document.getElementById("management-login-modal");
  const form = document.getElementById("management-login-form");
  const token = document.getElementById("management-login-token");
  const error = document.getElementById("management-login-error");
  const submit = document.getElementById("management-login-submit");
  const close = document.getElementById("management-login-close");
  const cancel = document.getElementById("management-login-cancel");
  backdrop.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("model-modal-open");
  token.value = "";
  error.textContent = "";
  submit.disabled = false;
  requestAnimationFrame(() => token.focus());

  return new Promise((resolve) => {
    let settled = false;
    const finish = (authenticated) => {
      if (settled) return;
      settled = true;
      token.value = "";
      backdrop.classList.add("hidden");
      modal.setAttribute("aria-hidden", "true");
      document.body.classList.remove("model-modal-open");
      form.onsubmit = null;
      backdrop.onclick = null;
      backdrop.onkeydown = null;
      close.onclick = null;
      cancel.onclick = null;
      resolve(authenticated);
    };
    const dismiss = () => finish(false);
    close.onclick = dismiss;
    cancel.onclick = dismiss;
    backdrop.onclick = (event) => {
      if (event.target === backdrop) dismiss();
    };
    backdrop.onkeydown = (event) => {
      if (event.key === "Escape") dismiss();
    };
    form.onsubmit = async (event) => {
      event.preventDefault();
      const supplied = token.value.trim();
      if (!supplied) {
        error.textContent = "请输入管理访问令牌。";
        token.focus();
        return;
      }
      submit.disabled = true;
      error.textContent = "";
      try {
        await api("/api/v1/admin/session", {
          method: "POST",
          headers: { Authorization: `Bearer ${supplied}` },
        });
        finish(true);
      } catch (loginError) {
        error.textContent = `登录失败：${loginError.message}`;
        submit.disabled = false;
        token.select();
      }
    };
  });
}
["tool-filter-query", "tool-filter-risk", "tool-filter-provider"].forEach((id) => {
  const control = document.getElementById(id);
  control.addEventListener(id === "tool-filter-query" ? "input" : "change", () => renderToolsAndConnectors());
});
prepareManagementDrawers();
prepareModelModal();
activateAdminTab(location.hash.slice(1) || "overview", false);
window.addEventListener("hashchange", () => activateAdminTab(location.hash.slice(1) || "overview", false));
async function initializeManagementApp() {
  try {
    await loadHealth();
  } catch (error) {
    document.getElementById("health").textContent = `服务不可用：${error.message}`;
  }
  try {
    if (!await ensureManagementSession()) return;
    await loadAdmin();
  } catch (error) {
    setAdminNotice(`管理配置不可用：${error.message}`, "admin-error");
  }
}
initializeManagementApp();
