(() => {
  "use strict";

  const ARTIFACT_ID = /^artifact_[A-Za-z0-9]+$/;

  function resolvedTarget(source, options = {}) {
    const value = String(source || "").trim();
    if (value.startsWith("artifact://")) {
      const artifactId = value.slice("artifact://".length);
      if (!ARTIFACT_ID.test(artifactId) || !options.artifactBaseUrl) return "";
      return `${String(options.artifactBaseUrl).replace(/\/$/, "")}/${encodeURIComponent(artifactId)}`;
    }
    return /^(https?:\/\/|\/|#|assets\/)/.test(value) ? value : "";
  }

  function appendInline(parent, source, options = {}) {
    const pattern = /(`[^`]+`|\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))/g;
    let cursor = 0;
    for (const match of source.matchAll(pattern)) {
      if (match.index > cursor) parent.append(document.createTextNode(source.slice(cursor, match.index)));
      const token = match[0];
      if (token.startsWith("`")) {
        const code = document.createElement("code");
        code.textContent = token.slice(1, -1);
        parent.append(code);
      } else if (token.startsWith("**")) {
        const strong = document.createElement("strong");
        strong.textContent = token.slice(2, -2);
        parent.append(strong);
      } else {
        const linkMatch = token.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
        const label = linkMatch?.[1] || token;
        const href = resolvedTarget(linkMatch?.[2] || "", options);
        if (href) {
          const link = document.createElement("a");
          link.textContent = label;
          link.href = href;
          if (href.startsWith("http")) {
            link.target = "_blank";
            link.rel = "noreferrer noopener";
          }
          parent.append(link);
        } else {
          parent.append(document.createTextNode(label));
        }
      }
      cursor = match.index + token.length;
    }
    if (cursor < source.length) parent.append(document.createTextNode(source.slice(cursor)));
  }

  function cells(line) {
    return line.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map((item) => item.trim());
  }

  function isTableDivider(line) {
    const parts = cells(line);
    return parts.length > 0 && parts.every((item) => /^:?-{3,}:?$/.test(item));
  }

  function startsBlock(lines, index) {
    const line = lines[index] || "";
    if (!line.trim()) return true;
    if (/^!\[[^\]]*\]\([^)]+\)$/.test(line.trim())) return true;
    if (/^#{1,6}\s+/.test(line) || /^```/.test(line) || /^>\s?/.test(line)) return true;
    if (/^\s*([-+*])\s+/.test(line) || /^\s*\d+\.\s+/.test(line)) return true;
    if (/^\s*([-*_])(?:\s*\1){2,}\s*$/.test(line)) return true;
    return index + 1 < lines.length && line.includes("|") && isTableDivider(lines[index + 1]);
  }

  function markdownFragment(markdown, options = {}) {
    const lines = markdown.replace(/\r\n?/g, "\n").split("\n");
    const fragment = document.createDocumentFragment();
    let index = 0;

    while (index < lines.length) {
      const line = lines[index];
      if (!line.trim()) {
        index += 1;
        continue;
      }

      const heading = line.match(/^(#{1,6})\s+(.+)$/);
      if (heading) {
        const element = document.createElement(`h${heading[1].length}`);
        appendInline(element, heading[2].trim(), options);
        fragment.append(element);
        index += 1;
        continue;
      }

      const image = line.trim().match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
      if (image) {
        const source = resolvedTarget(image[2], options);
        if (source) {
          const figure = document.createElement("figure");
          figure.className = "markdown-figure";
          const element = document.createElement("img");
          element.src = source;
          element.alt = image[1];
          element.loading = "lazy";
          element.decoding = "async";
          figure.append(element);
          if (image[1]) {
            const caption = document.createElement("figcaption");
            caption.textContent = image[1];
            figure.append(caption);
          }
          fragment.append(figure);
        }
        index += 1;
        continue;
      }

      if (/^```/.test(line)) {
        const language = line.slice(3).trim();
        const content = [];
        index += 1;
        while (index < lines.length && !/^```/.test(lines[index])) {
          content.push(lines[index]);
          index += 1;
        }
        if (index < lines.length) index += 1;
        const pre = document.createElement("pre");
        const code = document.createElement("code");
        if (language) code.dataset.language = language;
        code.textContent = content.join("\n");
        pre.append(code);
        fragment.append(pre);
        continue;
      }

      if (/^>\s?/.test(line)) {
        const quote = document.createElement("blockquote");
        const content = [];
        while (index < lines.length && /^>\s?/.test(lines[index])) {
          content.push(lines[index].replace(/^>\s?/, ""));
          index += 1;
        }
        appendInline(quote, content.join(" "), options);
        fragment.append(quote);
        continue;
      }

      if (index + 1 < lines.length && line.includes("|") && isTableDivider(lines[index + 1])) {
        const wrapper = document.createElement("div");
        wrapper.className = "markdown-table-wrap";
        const table = document.createElement("table");
        const thead = document.createElement("thead");
        const headRow = document.createElement("tr");
        cells(line).forEach((value) => {
          const cell = document.createElement("th");
          appendInline(cell, value, options);
          headRow.append(cell);
        });
        thead.append(headRow);
        table.append(thead);
        index += 2;
        const tbody = document.createElement("tbody");
        while (index < lines.length && lines[index].trim() && lines[index].includes("|")) {
          const row = document.createElement("tr");
          cells(lines[index]).forEach((value) => {
            const cell = document.createElement("td");
            appendInline(cell, value, options);
            row.append(cell);
          });
          tbody.append(row);
          index += 1;
        }
        table.append(tbody);
        wrapper.append(table);
        fragment.append(wrapper);
        continue;
      }

      const unordered = line.match(/^\s*[-+*]\s+(.+)$/);
      const ordered = line.match(/^\s*\d+\.\s+(.+)$/);
      if (unordered || ordered) {
        const list = document.createElement(ordered ? "ol" : "ul");
        const matcher = ordered ? /^\s*\d+\.\s+(.+)$/ : /^\s*[-+*]\s+(.+)$/;
        while (index < lines.length) {
          const itemMatch = lines[index].match(matcher);
          if (!itemMatch) break;
          const item = document.createElement("li");
          appendInline(item, itemMatch[1], options);
          list.append(item);
          index += 1;
        }
        fragment.append(list);
        continue;
      }

      if (/^\s*([-*_])(?:\s*\1){2,}\s*$/.test(line)) {
        fragment.append(document.createElement("hr"));
        index += 1;
        continue;
      }

      const paragraphLines = [line.trim()];
      index += 1;
      while (index < lines.length && !startsBlock(lines, index)) {
        paragraphLines.push(lines[index].trim());
        index += 1;
      }
      const paragraph = document.createElement("p");
      appendInline(paragraph, paragraphLines.join(" "), options);
      fragment.append(paragraph);
    }

    return fragment;
  }

  function renderMarkdown(root, markdown, options = {}) {
    root.replaceChildren(markdownFragment(markdown, options));
  }

  function markdownMarkup(markdown, options = {}) {
    const root = document.createElement("div");
    renderMarkdown(root, markdown, options);
    return root.innerHTML;
  }

  window.renderMarkdownPreview = renderMarkdown;
  window.markdownMarkup = markdownMarkup;
})();
