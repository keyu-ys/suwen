from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass, field
from typing import Any

from .tools import ToolRegistry, input_schema_accepts_contract, tool_schema_digest
from .types import ToolDefinition, ToolRisk


@dataclass(frozen=True)
class ConnectorResolution:
    bindings: tuple[dict[str, Any], ...]
    tools: ToolRegistry
    provenance: tuple[dict[str, Any], ...]
    catalog_changed: bool = False
    baseline_tools: ToolRegistry = field(default_factory=ToolRegistry)


def resolve_connector_bindings(
    connection: sqlite3.Connection,
    runtime_tools: ToolRegistry,
    raw_bindings: Any,
    *,
    normalize: bool,
) -> ConnectorResolution:
    """Resolve one current, compatible read-only MCP surface for a new Run.

    A published Agent keeps the catalog it was reviewed against as its baseline.
    MCP servers are nevertheless allowed to evolve independently: a new Run may
    adopt the latest observed catalog when every previously selected read-only
    Tool still accepts the published input contract and keeps the same Evidence
    contract.  The exact adopted catalog is returned as Run provenance.  Removed
    Tools, risk escalation, narrowed inputs, invalid catalogs and name conflicts
    remain fail-closed boundaries.
    """

    if raw_bindings is None:
        raw_bindings = []
    if not isinstance(raw_bindings, list):
        raise ValueError("Agent Connector bindings must be an array")
    normalized: list[dict[str, Any]] = []
    provenance: list[dict[str, Any]] = []
    selected_tools = ToolRegistry()
    baseline_tools = ToolRegistry()
    seen: set[str] = set()
    catalog_changed = False
    allowed_keys = {"provider_id", "schema_version_id", "schema_digest", "selection"}
    for raw in raw_bindings:
        if not isinstance(raw, dict) or set(raw) - allowed_keys:
            raise ValueError("Agent Connector binding contains unsupported fields")
        provider_id = raw.get("provider_id")
        if not isinstance(provider_id, str) or not provider_id or provider_id in seen:
            raise ValueError("Agent Connector bindings require unique provider_id values")
        seen.add(provider_id)
        selection = raw.get("selection", "all_read_only")
        if selection != "all_read_only":
            raise ValueError("Agent Connector selection must be all_read_only")
        row = connection.execute(
            """SELECT id, provider_type, status, binding_generation,
                      runtime_metadata_json
               FROM tool_providers WHERE id=? AND archived_at IS NULL""",
            (provider_id,),
        ).fetchone()
        if not row:
            raise ValueError(f"Agent Connector is unavailable: {provider_id}")
        if row["provider_type"] not in {"mcp_http", "mcp_stdio"}:
            raise ValueError(f"Agent Connector must use MCP: {provider_id}")
        if row["status"] != "connected":
            raise ValueError(f"Agent Connector is not connected: {provider_id}")
        schema = connection.execute(
            """SELECT id, version, schema_json, digest, observed_at
               FROM tool_schema_versions WHERE tool_provider_id=?
               ORDER BY version DESC LIMIT 1""",
            (provider_id,),
        ).fetchone()
        if not schema or not schema["observed_at"]:
            raise ValueError(f"Agent Connector has no observed catalog: {provider_id}")
        baseline = schema
        if not normalize:
            configured_digest = raw.get("schema_digest")
            configured_version_id = raw.get("schema_version_id")
            if not isinstance(configured_digest, str) or not configured_digest:
                raise ValueError(f"Agent Connector catalog baseline is missing: {provider_id}")
            if configured_version_id is not None and not isinstance(configured_version_id, str):
                raise ValueError(f"Agent Connector catalog baseline is invalid: {provider_id}")
            if configured_version_id:
                baseline = connection.execute(
                    """SELECT id, version, schema_json, digest, observed_at
                       FROM tool_schema_versions
                       WHERE id=? AND tool_provider_id=?""",
                    (configured_version_id, provider_id),
                ).fetchone()
            else:
                baseline = connection.execute(
                    """SELECT id, version, schema_json, digest, observed_at
                       FROM tool_schema_versions
                       WHERE tool_provider_id=? AND digest=?
                       ORDER BY version DESC LIMIT 1""",
                    (provider_id, configured_digest),
                ).fetchone()
            if not baseline or baseline["digest"] != configured_digest:
                raise ValueError(f"Agent Connector catalog baseline is unavailable: {provider_id}")
        catalog = json.loads(schema["schema_json"])
        if not isinstance(catalog, list):
            raise ValueError(f"Agent Connector catalog is invalid: {provider_id}")
        baseline_catalog = json.loads(baseline["schema_json"])
        if not isinstance(baseline_catalog, list):
            raise ValueError(f"Agent Connector catalog baseline is invalid: {provider_id}")
        configured_read_only = _read_only_catalog(provider_id, baseline_catalog)
        current_read_only = _read_only_catalog(provider_id, catalog)
        baseline_tools.merge_from(
            _catalog_registry(provider_id, configured_read_only),
        )
        changed = baseline["id"] != schema["id"] or baseline["digest"] != schema["digest"]
        if changed:
            _validate_compatible_update(
                provider_id,
                configured_read_only,
                current_read_only,
            )
            catalog_changed = True
        read_only_names: list[str] = []
        by_name = {
            definition.name: definition
            for definition in runtime_tools.definitions()
            if definition.provider_id == provider_id
        }
        for item in catalog:
            if not isinstance(item, dict) or item.get("risk") != ToolRisk.READ_ONLY.value:
                continue
            name = item.get("name")
            definition = by_name.get(name) if isinstance(name, str) else None
            if definition is None:
                raise ValueError(f"Agent Connector Tool is not process-loaded: {provider_id}:{name}")
            if (
                definition.risk != ToolRisk.READ_ONLY
                or definition.input_schema != item.get("input_schema")
                or definition.description != item.get("description")
                or definition.result_contract != item.get("result_contract", "model-evidence.v2")
            ):
                raise ValueError(f"Agent Connector Tool contract drifted: {provider_id}:{name}")
            read_only_names.append(definition.name)
        if not read_only_names:
            raise ValueError(f"Agent Connector exposes no read-only Tool: {provider_id}")
        selected_tools.merge_from(runtime_tools.subset(read_only_names))
        current_binding = {
            "provider_id": provider_id,
            "schema_version_id": str(schema["id"]),
            "schema_digest": str(schema["digest"]),
            "selection": "all_read_only",
        }
        binding = (
            current_binding
            if normalize
            else {
                "provider_id": provider_id,
                "schema_version_id": str(baseline["id"]),
                "schema_digest": str(baseline["digest"]),
                "selection": "all_read_only",
            }
        )
        normalized.append(binding)
        try:
            runtime_metadata = json.loads(row["runtime_metadata_json"] or "{}")
        except json.JSONDecodeError:
            runtime_metadata = {}
        provenance.append(
            {
                **current_binding,
                "configured_schema_version_id": str(baseline["id"]),
                "configured_schema_digest": str(baseline["digest"]),
                "catalog_state": "compatible_update" if changed else "exact",
                "provider_type": str(row["provider_type"]),
                "binding_generation": int(row["binding_generation"]),
                "observed_at": str(schema["observed_at"]),
                "runtime_metadata": runtime_metadata if isinstance(runtime_metadata, dict) else {},
                "tool_names": sorted(read_only_names),
                "configured_tool_names": sorted(configured_read_only),
            }
        )
    return ConnectorResolution(
        tuple(normalized),
        selected_tools,
        tuple(provenance),
        catalog_changed,
        baseline_tools,
    )


def effective_connector_allowlist(
    configured_allowlist: list[str],
    resolution: ConnectorResolution,
) -> list[str]:
    """Expand ``all_read_only`` selections with compatible current additions."""

    effective = list(configured_allowlist)
    configured_names = set(configured_allowlist)
    for connector in resolution.provenance:
        baseline_names = {
            str(name) for name in connector.get("configured_tool_names", [])
        }
        if baseline_names and baseline_names.issubset(configured_names):
            effective.extend(str(name) for name in connector.get("tool_names", []))
    return list(dict.fromkeys(effective))


def published_tool_baseline_digest(
    base_tools: ToolRegistry,
    resolution: ConnectorResolution,
    configured_allowlist: list[str],
) -> str:
    """Reconstruct the exact Tool surface reviewed by a published Agent.

    Compatibility is deliberately scoped to Connector-owned definitions.  This
    digest proves that Packs, native capabilities and the stored Connector
    baseline still match the published aggregate before a current compatible
    catalog is allowed to extend the surface for a new Run.
    """

    baseline = ToolRegistry()
    baseline.merge_from(base_tools)
    baseline.merge_from(resolution.baseline_tools)
    return tool_schema_digest(baseline.subset(configured_allowlist))


def validate_compatible_catalog_update(
    provider_id: str,
    baseline_catalog: list[Any],
    current_catalog: list[Any],
) -> None:
    """Validate stored MCP catalogs without requiring a process-loaded handler."""

    _validate_compatible_update(
        provider_id,
        _read_only_catalog(provider_id, baseline_catalog),
        _read_only_catalog(provider_id, current_catalog),
    )


def _read_only_catalog(
    provider_id: str,
    catalog: list[Any],
) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    seen_names: set[str] = set()
    for item in catalog:
        if not isinstance(item, dict):
            raise ValueError(f"Agent Connector catalog is invalid: {provider_id}")
        name = item.get("name")
        if not isinstance(name, str) or not name or name in seen_names:
            raise ValueError(f"Agent Connector catalog is invalid: {provider_id}")
        seen_names.add(name)
        if item.get("risk") == ToolRisk.READ_ONLY.value:
            result[name] = item
    return result


def _catalog_registry(
    provider_id: str,
    catalog: dict[str, dict[str, Any]],
) -> ToolRegistry:
    registry = ToolRegistry()
    for name, item in catalog.items():
        description = item.get("description")
        input_schema = item.get("input_schema")
        result_contract = item.get("result_contract", "model-evidence.v2")
        if (
            not isinstance(description, str)
            or not isinstance(input_schema, dict)
            or not isinstance(result_contract, str)
            or not result_contract
        ):
            raise ValueError(f"Agent Connector catalog baseline is invalid: {provider_id}:{name}")
        registry.register(
            ToolDefinition(
                name=name,
                description=description,
                input_schema=input_schema,
                risk=ToolRisk.READ_ONLY,
                result_contract=result_contract,
                provider_id=provider_id,
            ),
            _baseline_only_handler,
        )
    return registry


def _baseline_only_handler(_arguments: dict[str, Any]) -> Any:
    raise RuntimeError("Connector baseline Tool cannot execute")


def _validate_compatible_update(
    provider_id: str,
    baseline: dict[str, dict[str, Any]],
    current: dict[str, dict[str, Any]],
) -> None:
    missing = sorted(set(baseline) - set(current))
    if missing:
        raise ValueError(
            f"Agent Connector catalog update removed or reclassified Tool: "
            f"{provider_id}:{missing[0]}"
        )
    for name, frozen in baseline.items():
        observed = current[name]
        if observed.get("result_contract", "model-evidence.v2") != frozen.get(
            "result_contract",
            "model-evidence.v2",
        ):
            raise ValueError(
                f"Agent Connector catalog update changed Evidence contract: {provider_id}:{name}"
            )
        frozen_schema = frozen.get("input_schema")
        observed_schema = observed.get("input_schema")
        if (
            not isinstance(frozen_schema, dict)
            or not isinstance(observed_schema, dict)
            or not input_schema_accepts_contract(frozen_schema, observed_schema)
        ):
            raise ValueError(
                f"Agent Connector catalog update narrowed Tool input: {provider_id}:{name}"
            )
