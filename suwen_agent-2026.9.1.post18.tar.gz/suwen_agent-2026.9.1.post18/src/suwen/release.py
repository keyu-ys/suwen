"""Product release identity.

The package build, deployment manifest, health endpoint and management UI all
derive the public release label from this single PEP 440 version.
"""

from __future__ import annotations

import re

__version__ = "2026.9.1.post18"


def product_release_label(version: str = __version__) -> str:
    match = re.fullmatch(r"(\d{4})\.(\d{1,2})\.(\d{1,2})\.post(\d+)", version)
    if not match:
        return version
    year, month, day, post = (int(part) for part in match.groups())
    return f"v{year:04d}.{month:02d}.{day:02d} post{post}"


SUWEN_RELEASE_VERSION = product_release_label()
